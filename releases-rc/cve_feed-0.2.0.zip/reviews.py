"""Match-review decisions: kept across syncs, applied by the engine on the next one.

A reviewer can accept one candidate for a device's hardware or software match,
or reject the match. Decisions live in `reviews.json` in the plugin's data
directory - outside the report, which every sync replaces, so they are never
lost to a sync - and take effect on the next sync:

- accepted: the candidate's CPE is pinned for that match, the same way a CPE
  in the device's LogicVein custom field pins it (engine/cpe_field.py), so the
  match is exact and applied.
- rejected: the match is held for review instead of applied, so its CVEs are
  not reported for the device (engine build_device_report(held=...)).

With CPE write-back on, an accepted candidate's CPE is also written to the
device's LogicVein custom field (writeback.py), since the match is then applied.
"""

import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

ROLES = ("hardware", "software")
ACCEPTED = "accepted"
REJECTED = "rejected"
# The hold reason the engine records for a rejected match.
REJECTED_REASON = "rejected in review"


class ReviewStore:
    """The review decisions file."""

    def __init__(self, path: Path) -> None:
        """Use *path* (normally <plugin data dir>/reviews.json).

        Args:
            path: The decisions file.
        """
        self.path = path

    def load(self) -> Dict[str, Dict[str, Dict[str, Any]]]:
        """All decisions: device_key -> role -> decision.

        Returns:
            The decisions; empty when the file is missing or unreadable (a
            damaged file must not stop a sync - it reverts to no decisions).
        """
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}
        return data if isinstance(data, dict) else {}

    def _save(self, data: Dict[str, Dict[str, Dict[str, Any]]]) -> None:
        """Write the file atomically: a temporary file, then a rename."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=self.path.parent, prefix=".reviews-", suffix=".json")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(data, handle, indent=2, sort_keys=True)
            os.replace(tmp, self.path)
        except BaseException:
            Path(tmp).unlink(missing_ok=True)
            raise

    def accept(self, key: str, role: str, candidate: Dict[str, Any], by: str) -> None:
        """Accept one candidate for a device's match.

        Args:
            key: The device's store key.
            role: "hardware" or "software".
            candidate: The candidate (id, name, vendor_name, score, cpe).
            by: Who decided.

        Raises:
            ValueError: Unknown role, or the candidate has no CPE to pin.
        """
        if role not in ROLES:
            raise ValueError(f"Unknown role {role!r}")
        if not candidate.get("cpe"):
            raise ValueError("The candidate has no CPE, so it cannot be pinned")
        self._set(
            key,
            role,
            {
                "decision": ACCEPTED,
                "product_id": candidate.get("id"),
                "name": candidate.get("name"),
                "vendor": candidate.get("vendor_name"),
                "cpe": candidate["cpe"],
                "by": by,
                "at": datetime.now(timezone.utc).isoformat(),
            },
        )

    def reject(self, key: str, role: str, by: str) -> None:
        """Reject a device's match: hold it for review instead of applying it.

        Args:
            key: The device's store key.
            role: "hardware" or "software".
            by: Who decided.

        Raises:
            ValueError: Unknown role.
        """
        if role not in ROLES:
            raise ValueError(f"Unknown role {role!r}")
        self._set(key, role, {"decision": REJECTED, "by": by, "at": datetime.now(timezone.utc).isoformat()})

    def clear(self, key: str, role: str) -> None:
        """Forget the decision for a device's match.

        Args:
            key: The device's store key.
            role: "hardware" or "software".
        """
        data = self.load()
        if data.get(key, {}).pop(role, None) is not None:
            if not data[key]:
                del data[key]
            self._save(data)

    def _set(self, key: str, role: str, decision: Dict[str, Any]) -> None:
        data = self.load()
        data.setdefault(key, {})[role] = decision
        self._save(data)

    def decision(self, key: str, role: str) -> Optional[Dict[str, Any]]:
        """The decision for one device's match, or None."""
        return self.load().get(key, {}).get(role)

    @staticmethod
    def pins(decisions: Dict[str, Dict[str, Any]]) -> Dict[str, str]:
        """A device's accepted CPEs, role -> CPE, from its decisions."""
        return {role: d["cpe"] for role, d in decisions.items() if d.get("decision") == ACCEPTED and d.get("cpe")}

    @staticmethod
    def holds(decisions: Dict[str, Dict[str, Any]]) -> Dict[str, str]:
        """A device's rejected matches, role -> hold reason, from its decisions."""
        return {role: REJECTED_REASON for role, d in decisions.items() if d.get("decision") == REJECTED}
