"""The CVE Feed sync engine: LogicVein devices -> cvefeed.io products -> applicable CVEs.

One run lists the configured LogicVein networks' devices, matches each to
cvefeed.io products, keeps the CVEs that apply to it (NVD's data plus the
vendors' own, see engine/report.py), and writes the result to the report store
one device at a time. The report replaces the previous one only if the run
succeeds.

Failure handling follows lvi_cve_feed's CLI:

- An unexpected error on one device fails that device only; the run carries
  on and ends as a partial success.
- A cvefeed.io or network failure (retries exhausted) would fail every later
  device the same way, so the run stops; its report is discarded and the
  previous one stays current.
- A vendor source that fails falls back to NVD's data for the rest of the run
  and is noted in the run's errors.
"""

import logging
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple

import requests

# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import (  # pyright: ignore[reportMissingImports]
    CancellableSync,
    DeviceSyncOutcome,
    SyncCancelled,
    SyncReport,
    get_plugin_data_dir,
    get_product_name,
    normalize_networks,
)

from .client import CancellableSession, CveFeedTarget
from .engine.cpe_field import CPEFieldSettings, parse_field
from .engine.cve_cache import CVECache, MatchCache
from .engine.cvefeed_client import CVEFeedAPIError
from .engine.device_inventory import Device, list_devices
from .engine.report import (
    CVSSRange,
    DeviceFailure,
    DeviceReport,
    ReportCriteria,
    ReportLinks,
    build_device_report,
    coverage_gaps,
)
from .engine.vendors.arista import AristaAdvisories
from .engine.vendors.cisco import CiscoPSIRT, CiscoPSIRTClient
from .engine.vendors.cisco_tables import CiscoFixedReleases
from .engine.vendors.extreme import ExtremeAdvisories
from .engine.vendors.f5 import F5Advisories
from .engine.vendors.fortinet import FortinetAdvisories
from .engine.vendors.hpe import HPEAdvisories
from .engine.vendors.juniper import JuniperAdvisories
from .engine.vendors.paloalto import PaloAltoAdvisories
from .reviews import ReviewStore
from .store import ReportStore
from .writeback import WriteBackCounts, WriteBackSettings, write_back

logger = logging.getLogger(__name__)

PLUGIN_NAME = "cve_feed"

# Vendor sources that need only a cache directory (no credentials), by config key.
_CACHE_ONLY_VENDORS = {
    "juniper_advisories": ("juniper", JuniperAdvisories),
    "hpe_advisories": ("hpe", HPEAdvisories),
    "fortinet_advisories": ("fortinet", FortinetAdvisories),
    "extreme_advisories": ("extreme", ExtremeAdvisories),
    "paloalto_advisories": ("paloalto", PaloAltoAdvisories),
    "arista_advisories": ("arista", AristaAdvisories),
    "f5_advisories": ("f5", F5Advisories),
    "cisco_fixed_releases": ("cisco_tables", CiscoFixedReleases),
}


def _outcome_detail(report: DeviceReport) -> str:
    """One device's line in the Sync Reports tab: its CVEs by severity, KEV, products.

    Args:
        report: The device's report.

    Returns:
        E.g. "12 CVE(s): 1 critical, 4 high, 6 medium, 1 low; 2 in CISA KEV; Cisco IOS".
    """
    entries = {v["cve"]["id"]: v for m in (report.hardware, report.software) for v in m.vulnerabilities}
    counts: Dict[str, int] = {}
    for entry in entries.values():
        severity = str(entry["cve"].get("severity") or "").lower()
        severity = severity if severity in ("critical", "high", "medium", "low") else "unscored"
        counts[severity] = counts.get(severity, 0) + 1
    kev = sum(1 for e in entries.values() if (e.get("cisa_kev") or {}).get("in_kev"))
    order = ("critical", "high", "medium", "low", "unscored")
    parts = [
        f"{len(entries)} CVE(s)"
        + (": " + ", ".join(f"{counts[s]} {s}" for s in order if counts.get(s)) if entries else "")
    ]
    if kev:
        parts.append(f"{kev} in CISA KEV")
    applied = [m.result.best.name for m in (report.hardware, report.software) if m.auto_applied and m.result.best]
    parts.append(", ".join(applied) if applied else "no applied match")
    return "; ".join(parts)


def _apply_reviews(
    device: Device, decisions: Dict[str, Dict[str, Any]], cpe_settings: CPEFieldSettings
) -> Tuple[Device, CPEFieldSettings, Dict[str, str]]:
    """Apply a device's match-review decisions to what the engine sees.

    An accepted candidate is pinned the way a CPE in the device's custom field
    pins a match: the engine gets a copy of the device whose CPE field holds
    the accepted CPE (plus, when reading the field is on, the field's own CPE
    for the other match), with reading switched on for this device. LogicVein
    itself is not touched. A rejected match is held.

    Args:
        device: The device as LogicVein reports it.
        decisions: The device's decisions, role -> decision (reviews.json).
        cpe_settings: The run's CPE field settings.

    Returns:
        (the device for the engine, its CPE field settings, its holds).
    """
    pins = ReviewStore.pins(decisions)
    held = ReviewStore.holds(decisions)
    if not pins:
        return device, cpe_settings, held
    own = parse_field(device.custom_fields.get(cpe_settings.slot)) if cpe_settings.read else None
    hardware = pins.get("hardware") or (own.hardware if own else None)
    software = pins.get("software") or (own.software if own else None)
    value = " ".join(cpe for cpe in (hardware, software) if cpe)
    pinned = replace(device, custom_fields={**device.custom_fields, cpe_settings.slot: value})
    return pinned, replace(cpe_settings, read=True), held


class CveFeedSync(CancellableSync):
    """One CVE Feed run."""

    def __init__(self, lvi_client: Any, target: CveFeedTarget, config: Dict[str, Any]) -> None:
        """Store the clients and the YAML config (see conf/defaults.yaml).

        Args:
            lvi_client: The host's LogicVein API client for this run.
            target: The cvefeed.io client and optional Cisco credentials.
            config: The plugin's YAML config, as build_sync_config() returns it.
        """
        self.lvi = lvi_client
        self.target = target
        self.config = config
        self.last_report: Optional[SyncReport] = None

    def _vendor_sources(self, cache_dir: Any) -> Dict[str, Any]:
        """Build the enabled vendor sources, keyed by build_device_report()'s argument names."""
        vendors = self.config.get("vendors", {})
        sources: Dict[str, Any] = {}
        if vendors.get("cisco_openvuln", True) and self.target.cisco_client_id and self.target.cisco_client_secret:
            sources["cisco_psirt"] = CiscoPSIRT(
                CiscoPSIRTClient(
                    self.target.cisco_client_id,
                    self.target.cisco_client_secret,
                    session=CancellableSession(self._check_cancelled),
                ),
                cache_dir,
            )
        for key, (arg, cls) in _CACHE_ONLY_VENDORS.items():
            if vendors.get(key, True):
                sources[arg] = cls(cache_dir, session=CancellableSession(self._check_cancelled))
        return sources

    def sync(self) -> bool:
        """Run one sync.

        Returns:
            True when every device was reported; False when any device failed
            or the run stopped early.
        """
        started = datetime.now(timezone.utc)
        # Without this a rejected LogicVein write could pass for a success
        # (see the lite client's README); this client exists for this run only.
        if hasattr(self.lvi, "raise_on_rpc_error"):
            self.lvi.raise_on_rpc_error = True
        cvefeed = self.target.cvefeed
        cvefeed.set_cancel_check(self._check_cancelled)

        data_dir = get_plugin_data_dir(PLUGIN_NAME)
        cache_dir = data_dir / "cache"
        cache_dir.mkdir(parents=True, exist_ok=True)
        store = ReportStore(data_dir / "report")

        matching = self.config.get("matching", {})
        cves_cfg = self.config.get("cves", {})
        cvss_cfg = cves_cfg.get("cvss", {})
        links_cfg = self.config.get("reports", {}).get("links", {})
        lvi_cfg = self.config.get("logicvein", {})
        cpe_cfg = lvi_cfg.get("cpe_field", {})

        threshold = float(matching.get("confidence_threshold", 0.8))
        auto_apply = bool(matching.get("auto_apply", True))
        # build_sync_config() has already checked the numbers (validate_config()).
        cvss_range = CVSSRange(
            float(cvss_cfg.get("min", 0.0)),
            float(cvss_cfg.get("max", 10.0)),
            bool(cvss_cfg.get("include_unscored", False)),
        )
        cpe_settings = CPEFieldSettings(
            slot=str(cpe_cfg.get("slot", "custom1")),
            read=bool(cpe_cfg.get("read", False)),
            write=bool(cpe_cfg.get("write", False)),
            overwrite=bool(cpe_cfg.get("overwrite_existing", True)),
        )
        memo_cfg = lvi_cfg.get("memo", {})
        write_settings = WriteBackSettings(
            cpe=cpe_settings,
            memo=bool(memo_cfg.get("write", False)),
            memo_preserve=bool(memo_cfg.get("preserve_existing", True)),
            memo_verbose=bool(memo_cfg.get("verbose", False)),
        )
        links = ReportLinks(
            cvefeed=bool(links_cfg.get("cve_feed", True)),
            nvd=bool(links_cfg.get("nist", False)),
            vendor=bool(links_cfg.get("vendor_feed", False)),
        )
        cves = CVECache(cvefeed, cache_dir, int(cves_cfg.get("max_per_product", 1000)))
        matches = MatchCache(
            cvefeed, cache_dir / "matches.json", ttl=timedelta(days=int(matching.get("cache_ttl_days", 7)))
        )
        vendors = self._vendor_sources(cache_dir)

        networks = normalize_networks(lvi_cfg.get("networks", "all"))
        excluded_adapters = list(matching.get("excluded_adapters") or [])
        devices, skipped = list_devices(self.lvi, excluded_adapters, networks)
        logger.info(
            "CVE Feed: %d device(s) from %s (networks: %s); skipped by adapter: %s",
            len(devices),
            get_product_name(),
            ", ".join(networks) or "all",
            dict(skipped) or "none",
        )

        decisions = ReviewStore(data_dir / "reviews.json").load()
        writer = store.start_run(started)
        outcomes: List[DeviceSyncOutcome] = []
        run_errors: List[str] = []
        stopped: Optional[Exception] = None
        failed = 0
        no_match = 0
        unreadable = 0
        notes: List[str] = []
        counts = WriteBackCounts()
        committed = False
        try:
            for n, device in enumerate(devices, start=1):
                self._check_cancelled()
                label = device.hostname or device.ip_address
                logger.info("[%d/%d] %s", n, len(devices), label)
                try:
                    engine_device, device_cpe, held = _apply_reviews(
                        device, decisions.get(f"{device.network}|{device.ip_address}", {}), cpe_settings
                    )
                    report = build_device_report(
                        matches,
                        cves,
                        engine_device,
                        threshold,
                        auto_apply,
                        bool(cves_cfg.get("version_filter", True)),
                        cvss_range,
                        device_cpe,
                        links,
                        **vendors,
                        held=held,
                    )
                    report.device = device  # the report keeps LogicVein's own custom field values
                except SyncCancelled:
                    raise
                except (CVEFeedAPIError, requests.RequestException) as exc:
                    stopped = exc
                    break
                except Exception as exc:  # one device's problem - see module docstring
                    failed += 1
                    error = f"{type(exc).__name__}: {str(exc)[:300]}"
                    writer.add_failure(DeviceFailure(device, error))
                    outcomes.append(
                        DeviceSyncOutcome(
                            ip_address=device.ip_address, hostname=device.hostname or "", action="error", error=error
                        )
                    )
                    continue
                writer.add_device(report)
                written = write_back(
                    self.lvi,
                    report,
                    write_settings,
                    ReportCriteria(threshold, cvss_range),
                    started.strftime("%Y-%m-%d %H:%M UTC"),
                    counts,
                )
                if coverage_gaps([report]):
                    no_match += 1
                unreadable += sum(len(m.unreadable_cves) for m in (report.hardware, report.software))
                outcomes.append(
                    DeviceSyncOutcome(
                        ip_address=device.ip_address,
                        hostname=device.hostname or "",
                        action="updated",
                        detail="; ".join([_outcome_detail(report), *written]),
                    )
                )

            # Notes are information, shown in the CVE Report tab; run_errors are
            # failures, which the app counts as the run's errors.
            if no_match:
                notes.append(
                    f"{no_match} device(s) have no applied match, so no CVEs were checked for them"
                    " - see the Match Review tab"
                )
            if unreadable:
                notes.append(
                    f"{unreadable} CVE(s) had vendor or NVD data that could not be read; they are kept as"
                    " 'unknown' version status"
                )
            notes.extend(counts.notes(cpe_settings.slot))
            if counts.cpe["failed"]:
                run_errors.append(f"{counts.cpe['failed']} CPE field write(s) failed")
            if counts.memo["failed"]:
                run_errors.append(
                    f"{counts.memo['failed']} memo write(s) failed"
                    " (writing a memo needs the org.ziptie.memos.administer permission)"
                )
            for name, source in vendors.items():
                if getattr(source, "failure", None):
                    run_errors.append(f"{name} unavailable this run ({source.failure}) - NVD's data was used instead")
            if stopped is not None:
                run_errors.append(
                    f"Stopped after {len(outcomes)}/{len(devices)} device(s): {stopped}. "
                    "The previous report is still current."
                )
                writer.abort()
            else:
                writer.commit(
                    {
                        "networks": networks or ["all"],
                        # What the report was built with, shown in its run notes.
                        "criteria": {
                            "confidence_threshold": threshold,
                            "auto_apply": auto_apply,
                            "cvss_min": cvss_range.minimum,
                            "cvss_max": cvss_range.maximum,
                            "include_unscored": cvss_range.include_unscored,
                        },
                        "skipped_by_adapter": dict(skipped),
                        "errors": run_errors,
                        "notes": notes,
                    }
                )
                committed = True
        finally:
            if not committed and stopped is None:
                writer.abort()  # cancelled or crashed: keep the previous report

        self.last_report = SyncReport(
            plugin_name=PLUGIN_NAME,
            started_at=started.isoformat(),
            finished_at=datetime.now(timezone.utc).isoformat(),
            dry_run=False,
            outcomes=outcomes,
            run_errors=run_errors,
        )
        return stopped is None and failed == 0
