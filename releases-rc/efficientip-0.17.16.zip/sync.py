"""LogicVein to EfficientIP SOLIDserver IPAM sync engine.

Per-device REST upserts (SOLIDserver has no bulk-import mechanism analogous
to Infoblox's discovery CSV, so this follows the NetBox plugin's per-object
style instead).
"""

import ipaddress
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Set, Tuple

from src.plugin_api import (
    CancellableSync,
    CancellationToken,
    DeviceSyncOutcome,
    SyncCancelled,
    SyncReport,
    build_mac_lookup,
    format_epoch_ms,
    normalize_networks,
    prefetch_device_interfaces,
    record_pending_conflicts,
    resolve_display_name,
    resolve_prefetch_networks,
)

from . import space_partition as sp
from .client import EfficientIPClient

logger = logging.getLogger(__name__)

PLUGIN_NAME = "efficientip"

# Written as a class parameter on every IPAM address/NOM device this plugin
# creates or updates, regardless of whether stale-deletion is enabled -
# written unconditionally so a record is already tagged by the time
# delete_stale_ips/delete_stale_devices gets turned on, rather than only
# catching records synced after that point. Stale-deletion only ever
# considers a record carrying this marker, so a manually-added or other
# tool's record sharing the same IP space/NOM folder is never touched.
_LVI_MANAGED_KEY = "lvi_managed"
_LVI_MANAGED_VALUE = "true"


class LogicVeinEfficientIPSync(CancellableSync):
    """Sync LogicVein device inventory into EfficientIP SOLIDserver IPAM."""

    def __init__(
        self,
        lvi_client: Any,
        efficientip_client: EfficientIPClient,
        config: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialise the sync engine.

        Args:
            lvi_client: LogicVeinAPIClient instance.
            efficientip_client: EfficientIPClient instance.
            config: Configuration dict from EfficientIPPlugin.build_sync_config().
        """
        self.lvi = lvi_client
        self.target = efficientip_client
        self.config = config or {}

        self.dry_run = bool(self.config.get("dry_run", False))
        self.continue_on_error = bool(self.config.get("continue_on_error", True))
        self.networks = normalize_networks(self.config.get("network", "Default"))
        self.space_name = self.config.get("space_name", "Local")

        # IP Space partitioning. SOLIDserver enforces address uniqueness per
        # space ((site_id, hostaddr)), so the space is the only container that
        # can hold overlapping addresses - see space_partition.py. "none"
        # keeps the historical single-space behaviour and is the default, so
        # an existing deployment that upgrades and changes nothing sees no
        # difference.
        self.space_partition_by = self.config.get("space_partition_by", sp.MODE_NONE)
        self.space_mapping: Dict[str, str] = self.config.get("space_mapping", {}) or {}
        # A space is a fundamental, user-managed construct in a customer's own
        # IPAM organisation - unlike the NOM folder, which this plugin happily
        # auto-creates - so creating one is opt-in.
        self.create_missing_spaces = bool(self.config.get("create_missing_spaces", False))
        # Key segment for an interface reporting no VRF (the global routing
        # table). Named rather than blank so it can be mapped explicitly.
        self.default_vrf_name = self.config.get("default_vrf_name", "default")
        # Vendor names for the global routing table, folded onto
        # default_vrf_name so one mapping entry covers it across platforms.
        # Configurable because the defaults are a researched starting point,
        # not observed LogicVein output - see space_partition.normalize_vrf().
        self.global_vrf_aliases: List[str] = list(
            self.config.get("global_vrf_aliases", sp.DEFAULT_GLOBAL_VRF_ALIASES) or []
        )
        self.create_missing_subnets = bool(self.config.get("create_missing_subnets", False))
        self.create_missing_blocks = bool(self.config.get("create_missing_blocks", False))
        self.class_parameter_mapping: Dict[str, str] = self.config.get("class_parameter_mapping", {}) or {}
        self.lifecycle_class_parameter_mapping: Dict[str, str] = (
            self.config.get("lifecycle_class_parameter_mapping", {}) or {}
        )
        self.sync_mac_address = bool(self.config.get("sync_mac_address", True))
        self.ip_conflict_policy = self.config.get("ip_conflict_policy", "overwrite")
        self.mac_conflict_policy = self.config.get("mac_conflict_policy", "overwrite")
        # Delete an lvi_managed-marked record in a space/folder this run
        # wrote to, when LogicVein no longer reports it there - see
        # sync()'s stale-deletion pass and _delete_stale_addresses()/
        # _delete_stale_nom_devices() for the full design.
        self.delete_stale_ips = bool(self.config.get("delete_stale_ips", False))
        self.delete_stale_nom_devices = bool(self.config.get("delete_stale_nom_devices", False))

        # Two independent sync targets - IPAM (the original, and only, target
        # until this toggle was added) and NOM (Network Object Manager: a
        # device object plus all its interfaces/ports, organized under one
        # flat folder). Either can be turned off; a device with an unresolved
        # IPAM conflict this run is not also synced to NOM this run (see
        # sync()'s per-device early `continue`s).
        self.sync_to_ipam = bool(self.config.get("sync_to_ipam", True))
        self.sync_to_nom = bool(self.config.get("sync_to_nom", False))
        self.nom_folder_name = self.config.get("nom_folder_name", "LogicVein Devices")
        # The NOM folder is just an organizational container for this
        # sync's own devices (unlike the IPAM space, a fundamental,
        # user-managed construct that must already exist) - auto-created
        # by default. Off requires it to pre-exist; NOM sync is skipped
        # for this run if it doesn't (IPAM, if enabled, is unaffected -
        # see sync()'s pre-flight gate).
        self.create_missing_nom_folder = bool(self.config.get("create_missing_nom_folder", True))

        # What to do when no space_mapping/nom.folder_mapping entry matches a
        # device's partition key - one independent policy per domain, derived
        # from that domain's own "Create missing..." toggle rather than a
        # separate user-set value: off -> "skip", on -> "auto". There is no
        # "fallback" anymore - it silently recreated the very address/hostname
        # collision partitioning exists to prevent, for whichever partitions
        # were unmapped; a device that is not synced and says so in the
        # report is recoverable, a fallback overwrite may go unnoticed for a
        # long time. See space_partition.py.
        self.ipam_unmapped_policy = sp.UNMAPPED_AUTO if self.create_missing_spaces else sp.UNMAPPED_SKIP
        self.nom_unmapped_policy = sp.UNMAPPED_AUTO if self.create_missing_nom_folder else sp.UNMAPPED_SKIP

        # NOM folder partitioning. Unlike the IP space this is not about
        # overlapping addresses - NOM has no IP-uniqueness constraint at all,
        # two interfaces on different devices can carry the same address
        # happily. It fixes a *hostname* collision: NOM identity is
        # name-in-folder, so two devices sharing a hostname in different LVI
        # networks collide in one flat folder and the second silently updates
        # the first. Only the lvi_network axis is offered; a NOM device is a
        # whole device whose interfaces span several VRFs, so there is no
        # single correct VRF folder for it. Uses the same mapping mechanics
        # as the IP space - see space_partition.py.
        self.nom_folder_partition_by = self.config.get("nom_folder_partition_by", sp.MODE_NONE)
        self.nom_folder_mapping: Dict[str, str] = self.config.get("nom_folder_mapping", {}) or {}

        # Devices always sync to NOM when sync_to_nom is on; interfaces are
        # a separate opt-out (default on, for backward compatibility with
        # the original NOM sync behavior). Turning this off never deletes
        # interfaces already synced from an earlier run - it just stops
        # touching them going forward.
        self.sync_nom_interfaces = bool(self.config.get("sync_nom_interfaces", True))

        # When a device would otherwise get no Main IP at all (no
        # interface data in LogicVein, or no interface's own IP matched
        # its management IP and there were too many candidates to guess -
        # see _sync_device_to_nom's Main-selection logic), synthesize a
        # fake "main" interface carrying the device's own IP and mark it
        # Main. Off by default - this interface does not correspond to
        # any real port LogicVein reported.
        self.always_set_main_ip = bool(self.config.get("always_set_nom_main_ip", False))

        # VLAN numbers on synced NOM interfaces - only meaningful (and only
        # read/checked) when sync_to_nom is also on. The VLAN Domain is a
        # real VLAN Manager object (auto-created if missing, like the NOM
        # folder), not just a free-text label - see client.py's NOM
        # docstring section for why that distinction matters.
        self.sync_nom_vlans = bool(self.config.get("sync_nom_vlans", False))
        self.nom_vlan_domain_name = self.config.get("nom_vlan_domain_name", "Default")
        # Auto-create the VLAN Domain/Range/VLAN if missing (see below and
        # _ensure_vlan_domain()/_ensure_vlan_range()/_ensure_vlan()). Off
        # requires the Domain/Range to pre-exist - see sync()'s pre-flight
        # gate, which skips just VLAN sync for this run (not NOM device/
        # interface sync, and not IPAM) when a required one is missing and
        # its toggle is off.
        self.create_missing_vlan_domain = bool(self.config.get("create_missing_vlan_domain", True))

        # A VLAN Range within the Domain - required by SOLIDserver's own
        # vlm_vlan_add API (see client.py's create_vlan() docstring):
        # multiple Ranges can overlap the same VLAN ID span within one
        # Domain, so a bare VLAN ID is ambiguous without naming which Range
        # it belongs to. Same auto-create/skip-VLAN-only treatment as the
        # Domain above. nom_vlan_range_start/_end only matter the moment
        # the Range is actually created - they're ignored once it exists.
        self.nom_vlan_range_name = self.config.get("nom_vlan_range_name", "Default")
        self.create_missing_vlan_range = bool(self.config.get("create_missing_vlan_range", True))
        self.nom_vlan_range_start = int(self.config.get("nom_vlan_range_start", 1))
        self.nom_vlan_range_end = int(self.config.get("nom_vlan_range_end", 4094))

        # "Find connected objects" - populates NOM's Connected Object/Port
        # fields from LVI's LLDP/CDP neighbor data. Only meaningful with
        # interfaces on too (there'd be no NOM ports to link otherwise) -
        # the sync() call site ANDs both toggles together, same pattern as
        # sync_nom_vlans.
        self.sync_nom_connections = bool(self.config.get("sync_nom_connections", False))

        # Create a VRF (VRF > VRFs in the GUI) for every distinct
        # interface.vrfName LVI reports, once per unique name per run. Only
        # meaningful with interfaces on too (there'd be no interface data to
        # read a vrfName from otherwise) - same AND-with-sync_nom_interfaces
        # pattern as sync_nom_vlans/sync_nom_connections above. This only
        # creates the VRF catalog entry - there is no field or Class Studio
        # bridge anywhere on a stock SOLIDserver appliance to attach a VRF
        # to the interface (or any other object) itself, confirmed live -
        # see docs/dev_notes/EFFICIENTIP_VRF_INVESTIGATION.md in the app
        # repo. No create_missing/pre-flight-gate toggle like the
        # Domain/Range above: VRF names are discovered dynamically
        # per-interface, not a single user-configured value to pre-flight-check.
        self.sync_nom_vrfs = bool(self.config.get("sync_nom_vrfs", False))

        # {LVI deviceType -> NOM device type}. SOLIDserver caps
        # nomnetobj_type at 16 characters and rejects the entire device
        # write when it is longer, so types like "Wireless Controller" (19)
        # need a short equivalent. Only overflowing types need an entry.
        # An unmapped type is written through unchanged; if it is still too
        # long the client trims it as a fallback (see _clamp_nom_type),
        # which keeps the device syncing but with a truncated label - a
        # mapping entry is how you choose something readable instead.
        self.nom_type_mapping: Dict[str, str] = self.config.get("nom_type_mapping", {}) or {}

        # Strip an FQDN-looking LVI hostname down to its short name before
        # writing it as IPAM's "name" field / NOM's device name (e.g.
        # "asa5505.home.arpa" -> "asa5505"). Enabled by default. Toggling
        # this renames the existing object rather than creating a
        # duplicate - see _resolve_display_name()/_sync_device_to_nom()'s
        # alt_name handling. IPAM itself is never at duplicate risk from a
        # name change (create_or_update_address upserts by IP, not name);
        # only NOM (which looks devices up by name) needs the rename path.
        self.strip_domain_from_names = bool(self.config.get("strip_domain_from_names", True))

        self._cancel: Optional[CancellationToken] = None
        # Partition key -> site_id, or None when that partition could not be
        # resolved. Cached per key (not a single value) so a run spanning
        # several spaces still looks each up once, and a partition that
        # failed is not retried per device.
        self._site_id_by_key: Dict[str, Optional[str]] = {}
        # site_id -> space name, so a log or report line can name the space
        # actually resolved rather than the single configured space_name,
        # which is wrong for every partition but one.
        self._space_name_by_site: Dict[str, str] = {}
        # Partition keys already reported as unresolvable, so the warning is
        # emitted once per partition rather than once per device.
        self._warned_partitions: set = set()
        # Partition key -> nomfolder_id, or None when unresolvable. Same
        # per-key caching as the IP space, so a run spanning several folders
        # looks each up once.
        self._nom_folder_id_by_key: Dict[str, Optional[str]] = {}
        self._warned_nom_partitions: set = set()
        self._vlan_domain_ready: Optional[bool] = None
        self._vlan_range_ready: Optional[bool] = None
        self._vlan_ready_cache: Dict[str, bool] = {}
        self._vrf_ready_cache: Dict[str, bool] = {}
        self.last_report: Optional[SyncReport] = None

    def _device_vrf(self, device_key: Tuple[str, str], interfaces: List[Dict[str, Any]]) -> str:
        """Return the VRF a device's own management address belongs to.

        A VRF is an interface-level attribute, but the device's management
        address needs exactly one. The interface whose own IP equals the
        management IP is that answer - the same interface NOM marks "Main"
        (see _choose_main_interface()). Falls back to default_vrf_name when no
        interface matches or the matching one reports no VRF, which is also
        the global-routing-table case.

        Vendor names for the global table are folded onto default_vrf_name
        first - every platform spells it differently ("default", "master",
        "Base", "_public_", "0"), so without that a user would need one
        mapping entry per platform for what is one routing table. See
        space_partition.normalize_vrf() for the list and its caveats.
        """
        main = self._choose_main_interface(device_key[1], interfaces)
        raw = ((main.get("interface") or {}).get("vrfName") or "") if main is not None else ""
        return sp.normalize_vrf(raw, self.global_vrf_aliases, self.default_vrf_name)

    def _partition_key(self, device_key: Tuple[str, str], interfaces: List[Dict[str, Any]]) -> str:
        """Build the IP Space partition key for one device."""
        network = device_key[0] if sp.needs_network(self.space_partition_by) else ""
        vrf = self._device_vrf(device_key, interfaces) if sp.needs_vrf(self.space_partition_by) else ""
        return sp.build_key(self.space_partition_by, network, vrf)

    def _resolve_site_id(self, key: str = "") -> Optional[str]:
        """Look up the IP space (site) for one partition key, cached per key.

        Returns None when the partition has no space it can be written to -
        either no space_mapping entry matched and ipam_unmapped_policy is
        "skip" (create_missing_spaces is off), or the named space does not
        exist and create_missing_spaces is off. The caller decides what
        that means for the object in hand; unlike before partitioning, it
        is NOT a whole-run abort, or one missing space for one VRF would
        take down every other partition too.
        """
        if key in self._site_id_by_key:
            return self._site_id_by_key[key]

        space_name = sp.resolve_container_name(
            self.space_partition_by, key, self.space_mapping, self.space_name, self.ipam_unmapped_policy
        )
        site_id: Optional[str] = None
        if space_name is None:
            self._warn_partition(key, "no space_mapping entry matched")
        else:
            space = self.target.get_space_by_name(space_name)
            if space:
                site_id = space["site_id"]
            elif self.create_missing_spaces:
                site_id = self.target.create_space(space_name)
                if site_id:
                    logger.info("Created IP space '%s'", space_name)
                else:
                    self._warn_partition(key, f"IP space '{space_name}' could not be created")
            else:
                self._warn_partition(key, f"IP space '{space_name}' not found and create_missing_spaces is off")

        if site_id is not None and space_name:
            self._space_name_by_site[site_id] = space_name
        self._site_id_by_key[key] = site_id
        return site_id

    def _space_label(self, site_id: Optional[str]) -> str:
        """Name of the space behind *site_id*, for log and report text."""
        if site_id is None:
            return self.space_name
        return self._space_name_by_site.get(site_id, self.space_name)

    def _warn_partition(self, key: str, reason: str) -> None:
        """Log an unresolvable partition once per key rather than once per device."""
        if key in self._warned_partitions:
            return
        self._warned_partitions.add(key)
        label, value = sp.describe(self.space_partition_by, key)
        if self.space_partition_by == sp.MODE_NONE:
            logger.error("Cannot resolve IP space: %s", reason)
        else:
            logger.warning("Skipping %s '%s': %s", label, value, reason)

    def _nom_folder_key(self, device_key: Tuple[str, str]) -> str:
        """Partition key for a device's NOM folder ("" when unpartitioned)."""
        network = device_key[0] if sp.needs_network(self.nom_folder_partition_by) else ""
        return sp.build_key(self.nom_folder_partition_by, network, "")

    def _resolve_nom_folder_id(self, key: str = "") -> Optional[str]:
        """Look up (or create) the NOM folder for one partition key, cached per key.

        Unlike the IPAM space (which must already exist - it's a
        fundamental, user-managed construct), the NOM folder is just an
        organizational container for this sync's own devices, so it's
        created automatically if missing by default
        (create_missing_nom_folder). Off requires it to pre-exist.

        Returns None when this partition has no folder to write to: no
        nom_folder_mapping entry matched under nom_unmapped_policy "skip"
        (create_missing_nom_folder is off), the entry maps to "", or the
        folder is missing with auto-create off. NOM problems degrade rather
        than fail - see the call site.
        """
        if key in self._nom_folder_id_by_key:
            return self._nom_folder_id_by_key[key]

        folder_name = sp.resolve_container_name(
            self.nom_folder_partition_by,
            key,
            self.nom_folder_mapping,
            self.nom_folder_name,
            self.nom_unmapped_policy,
        )
        folder_id: Optional[str] = None
        if folder_name is None:
            self._warn_nom_partition(key, "no nom_folder_mapping entry matched")
        else:
            folder = self.target.get_nom_folder_by_name(folder_name)
            if folder:
                folder_id = folder["nomfolder_id"]
            elif not self.create_missing_nom_folder:
                self._warn_nom_partition(
                    key, f"NOM folder '{folder_name}' not found and create_missing_nom_folder is off"
                )
            else:
                # site_name only seeds the folder's own "site" attribute at
                # creation; it does not scope lookups, so the configured
                # space_name is right even when IPAM is partitioned.
                folder_id = self.target.create_nom_folder(folder_name, site_name=self.space_name)
                if folder_id:
                    logger.info("Created NOM folder '%s'", folder_name)
                else:
                    self._warn_nom_partition(key, f"NOM folder '{folder_name}' could not be created")

        self._nom_folder_id_by_key[key] = folder_id
        return folder_id

    def _warn_nom_partition(self, key: str, reason: str) -> None:
        """Log an unresolvable NOM partition once per key, not once per device."""
        if key in self._warned_nom_partitions:
            return
        self._warned_nom_partitions.add(key)
        if self.nom_folder_partition_by == sp.MODE_NONE:
            logger.warning("Cannot resolve NOM folder: %s", reason)
        else:
            label, value = sp.describe(self.nom_folder_partition_by, key)
            logger.warning("Skipping NOM for %s '%s': %s", label, value, reason)

    def _ensure_vlan_domain(self) -> bool:
        """Look up (or create) the configured VLAN Domain, once per sync.

        Only called when sync_nom_vlans is on. Like the NOM folder (and
        unlike the IPAM space), this is created automatically if missing
        by default (create_missing_vlan_domain) - `vlm_domain_add` with
        just a name defaults to a full 1-4094 VLAN ID range, confirmed
        against a live instance. Off requires it to pre-exist.
        """
        if self._vlan_domain_ready is not None:
            return self._vlan_domain_ready
        if self.target.get_vlan_domain_by_name(self.nom_vlan_domain_name):
            self._vlan_domain_ready = True
            return True
        if not self.create_missing_vlan_domain:
            self._vlan_domain_ready = False
            return False
        created = self.target.create_vlan_domain(self.nom_vlan_domain_name)
        if created:
            logger.info("Created VLAN domain '%s'", self.nom_vlan_domain_name)
        self._vlan_domain_ready = bool(created)
        return self._vlan_domain_ready

    def _ensure_vlan_range(self) -> bool:
        """Look up (or create) the configured VLAN Range within the VLAN Domain, once per sync.

        Only called when sync_nom_vlans is on, after the Domain itself is
        confirmed ready. A Range is required (not just the Domain) because
        SOLIDserver allows multiple Ranges to overlap the same VLAN ID span
        within one Domain (confirmed live) - `vlm_vlan_add` rejects a bare
        VLAN ID with "Missing parameter: vlmrange_id/vlmrange_name" once a
        Range must be named to disambiguate which one a synced VLAN belongs
        to. Same auto-create/off-requires-pre-existing treatment as the
        Domain (create_missing_vlan_range).
        """
        if self._vlan_range_ready is not None:
            return self._vlan_range_ready
        if self.target.get_vlan_range_by_name(self.nom_vlan_domain_name, self.nom_vlan_range_name):
            self._vlan_range_ready = True
            return True
        if not self.create_missing_vlan_range:
            self._vlan_range_ready = False
            return False
        created = self.target.create_vlan_range(
            self.nom_vlan_domain_name,
            self.nom_vlan_range_name,
            self.nom_vlan_range_start,
            self.nom_vlan_range_end,
        )
        if created:
            logger.info("Created VLAN range '%s' in domain '%s'", self.nom_vlan_range_name, self.nom_vlan_domain_name)
        self._vlan_range_ready = bool(created)
        return self._vlan_range_ready

    def _ensure_vlan(self, vlan_number: str) -> bool:
        """Look up (or create) one VLAN ID as a real VLAN Manager object within the
        configured Range, cached per VLAN number for this sync run.

        Only called per-device, once the Domain and Range are already
        confirmed ready by sync()'s pre-flight gate - so unlike those two,
        a single VLAN ID failing to register only affects that one
        interface (the VLAN number/domain are omitted from the NOM write,
        same as today's "no current mapping" case), not the whole run.
        """
        if vlan_number in self._vlan_ready_cache:
            return self._vlan_ready_cache[vlan_number]
        ready = bool(
            self.target.get_vlan_by_number(self.nom_vlan_domain_name, self.nom_vlan_range_name, vlan_number)
            or self.target.create_vlan(self.nom_vlan_domain_name, self.nom_vlan_range_name, vlan_number)
        )
        if not ready:
            logger.warning(
                "Could not find or create VLAN %s in range '%s'/domain '%s' - omitting VLAN from this interface",
                vlan_number,
                self.nom_vlan_range_name,
                self.nom_vlan_domain_name,
            )
        self._vlan_ready_cache[vlan_number] = ready
        return ready

    def _ensure_vrf(self, vrf_name: str) -> bool:
        """Look up (or create) one VRF by name, cached per VRF name for this sync run.

        Only creates the VRF catalog entry (VRF > VRFs in the GUI) - there
        is no attachment to the interface or any other object, since none
        exists on a stock appliance (see sync_nom_vrfs's docstring above).
        A VRF failing to register is logged and otherwise ignored - it's
        not tied to any other part of the interface write, unlike VLAN
        numbers which get omitted from the interface on failure.
        """
        if vrf_name in self._vrf_ready_cache:
            return self._vrf_ready_cache[vrf_name]
        ready = bool(self.target.get_vrf_by_name(vrf_name) or self.target.create_vrf(vrf_name))
        if not ready:
            logger.warning("Could not find or create VRF '%s'", vrf_name)
        self._vrf_ready_cache[vrf_name] = ready
        return ready

    def _build_vlan_lookup(self, ip_address: str, network: str) -> Dict[str, str]:
        """Map port name -> VLAN number for one device.

        Unlike the bulk per-network interface fetch, LVI's VLAN/port
        mapping call (Inventory.getDeviceVlanPortMappings) is one call per
        device - only made when sync_nom_vlans is on, to avoid this extra
        round-trip otherwise. Entries with no port (VLAN definitions not
        assigned to any interface) are skipped.
        """
        lookup: Dict[str, str] = {}
        try:
            for mapping in self.lvi.get_device_vlan_port_mappings(ip_address, network=network):
                port = mapping.get("port")
                number = mapping.get("number")
                if port and number:
                    lookup[port] = str(number)
        except Exception as e:
            logger.warning("Could not fetch VLAN port mappings for %s: %s", ip_address, e)
        return lookup

    def _resolve_display_name(self, raw_name: str) -> Tuple[str, str]:
        """Return (display_name, alt_name) for one LVI-reported hostname,
        per strip_domain_from_names - see plugin_api.resolve_display_name()'s
        docstring for the full FQDN-truncation/alt_name contract, shared by
        every plugin that offers this setting.

        *display_name* is what gets written this run (IPAM's "name" field,
        NOM's device name). Only NOM needs *alt_name*: it looks devices up
        by name, so flipping strip_domain_from_names between runs would
        otherwise miss the existing device (still under its old-style
        name) and create a duplicate. IPAM is never at risk -
        create_or_update_address upserts by IP, not name, so its "name"
        field just gets overwritten on the next run either way.
        """
        return resolve_display_name(raw_name, self.strip_domain_from_names)

    @staticmethod
    def _has_real_class_parameters(class_parameters: Dict[str, str]) -> bool:
        """True if *class_parameters* carries anything beyond the internal
        lvi_managed marker (written on every synced record - see its own
        module-level comment). Used to tell an ip_duplicate_this_run/
        nom_duplicate_this_run conflict's message whether Overwrite would
        actually change anything - a plain `bool(class_parameters)` would
        always be True once the marker is always present, defeating the
        empty-payload special case entirely.
        """
        return any(k != _LVI_MANAGED_KEY for k in class_parameters)

    @staticmethod
    def _ip_duplicate_detail(
        ip_address: str,
        winner_network: str,
        winner_hostname: str,
        loser_network: str,
        loser_hostname: str,
        loser_has_data: bool,
    ) -> str:
        """Build the detail for a same-run cross-network IP collision.

        The naive "duplicate: also synced from network X" wording reads as
        ambiguous about which side Overwrite/Ignore each apply to - Overwrite
        replaces the ALREADY-APPLIED winner's data with this (the deferred,
        losing) entry's data, which is the opposite of what "Overwrite"
        suggests if the winner is the one that looks obviously correct
        (confirmed against a real report: a bare, undiscovered LogicVein stub
        - no hostname, no MAC - lost to a fully enriched device, and clicking
        Overwrite on the stub's conflict predictably did nothing visible).

        When the loser genuinely has no hostname/MAC/class-parameter data of
        its own, Overwrite and Ignore are provably the same end state -
        create_or_update_address only sets a field when the argument is
        truthy, so there is nothing for Overwrite to contribute. Presenting
        that as a decision is misleading, so the caller does not defer to a
        pending conflict at all in that case (see sync()) - this still
        explains why, just without the Overwrite/Ignore framing that would
        no longer make sense.
        """
        winner = f"'{winner_network}' ({winner_hostname})" if winner_hostname else f"'{winner_network}'"
        loser = f"'{loser_network}' ({loser_hostname})" if loser_hostname else f"'{loser_network}'"
        base = f"duplicate: {ip_address} - LogicVein network {winner} already synced and is currently applied."
        if loser_has_data:
            return f"{base} Overwrite replaces it with this entry's data from network {loser}; Ignore keeps the {winner} version."
        return (
            f"{base} This entry is from network {loser} with no hostname or MAC data from "
            f"LogicVein - automatically ignored, nothing to resolve."
        )

    @staticmethod
    def _nom_duplicate_detail(
        nom_name: str,
        winner_network: str,
        loser_network: str,
        loser_has_data: bool,
    ) -> str:
        """Build the detail for a same-run cross-network NOM collision - see
        _ip_duplicate_detail()'s docstring for both the Overwrite-direction
        rationale and the no-data auto-ignore case. NOM's identity is
        name-in-folder rather than an IP, so there is no separate
        winner/loser hostname to show beyond *nom_name* itself (both
        entries share it - that is the whole collision).
        """
        base = (
            f"duplicate: NOM device '{nom_name}' - LogicVein network '{winner_network}' "
            f"already synced and is currently applied."
        )
        if loser_has_data:
            return (
                f"{base} Overwrite replaces it with this entry's data from network "
                f"'{loser_network}'; Ignore keeps the '{winner_network}' version."
            )
        return (
            f"{base} This entry is from network '{loser_network}' with no type or class "
            f"parameter data from LogicVein - automatically ignored, nothing to resolve."
        )

    @staticmethod
    def _first_ipv4(ip_list: List[str]) -> str:
        """Return the first IPv4 address in *ip_list* (CIDR suffix stripped), or "".

        NOM's nomiface_hostaddr is an IPv4-typed field - an interface that
        only reports an IPv6 address (a link-local EUI-64 address off its
        own MAC is common on devices with no routable IPv4 per-port
        address) has no IP usable there. Silently accepting the first
        entry regardless of family used to write that IPv6 string into
        hostaddr, which SOLIDserver quietly failed to store as "Main
        IPv4" while still parsing and surfacing it as "Main IPv6" instead
        - the device ended up with no Main IPv4 at all even though its
        interface data and management IP were both perfectly fine.
        """
        for raw in ip_list:
            candidate = raw.split("/")[0]
            try:
                if ipaddress.ip_address(candidate).version == 4:
                    return candidate
            except ValueError:
                continue
        return ""

    @staticmethod
    def _choose_main_interface(ip_address: str, entries: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """Return the interface entry NOM's "Main" attribute should be set on -
        the one whose own IP exactly matches the device's management IP.

        If more than one interface has that exact IP, the lower-numbered
        (SNMP ifIndex) interface wins.
        """
        candidates = [
            entry for entry in entries if ip_address in [ip.split("/")[0] for ip in (entry.get("interfaceIps") or [])]
        ]
        if not candidates:
            return None
        return min(candidates, key=lambda e: (e.get("interface") or {}).get("index") or 0)

    @staticmethod
    def _merge_outcome(base: DeviceSyncOutcome, other: DeviceSyncOutcome) -> DeviceSyncOutcome:
        """Combine two sync targets' outcomes for the SAME device into one report row.

        Without this, IPAM and NOM each produce their own DeviceSyncOutcome
        when both are enabled - the report showed two rows per device (one
        with IPAM's MAC/hostname fields and notes, one with NOM's notes and
        nothing else), which reads as two separate devices rather than one
        device synced to two places. *base* (IPAM's outcome, since it
        carries the fields - MAC, mac_changed, etc - a report reader
        actually cares about) keeps its own action/MAC fields; *other*'s
        note (its detail, or its error if it has no detail - the "NOM:
        failed to write device" case sets error, not detail) is appended
        into the notes cell. Every note either side produces already
        starts with its own "IPAM: "/"NOM: " label, so no extra labeling
        is added here - if a third sync target is ever added, its own
        outcome should self-label the same way rather than this method
        guessing whose note it is.
        """
        other_note = other.detail or other.error
        if other_note:
            base.detail = f"{base.detail}; {other_note}" if base.detail else other_note
        return base

    def _build_class_parameters(self, device: Dict[str, Any]) -> Dict[str, str]:
        """Map configured LVI device fields to SOLIDserver class parameter names."""
        params: Dict[str, str] = {}
        for lvi_field, class_param_name in self.class_parameter_mapping.items():
            value = device.get(lvi_field)
            if value:
                params[class_param_name] = str(value)
        return params

    # LVI lifecycle/discovery fields come back as raw epoch-milliseconds -
    # calendar-date fields render as YYYY-MM-DD, instant fields as a full
    # ISO-8601 timestamp (matches NetBox/Infoblox's conventions for the same
    # LVI fields).
    _LIFECYCLE_DATE_FIELDS = {
        "end_of_sale": "endOfSale",
        "end_of_life": "endOfLife",
        "sw_end_of_sale": "softwareEndOfSale",
        "sw_end_of_life": "softwareEndOfLife",
    }
    _LIFECYCLE_INSTANT_FIELDS = {
        "last_discovery": "lastDiscovery",
        "last_backup": "lastBackup",
        "last_change": "lastChange",
    }

    def _build_lifecycle_class_parameters(self, device: Dict[str, Any]) -> Dict[str, str]:
        """Map configured LVI lifecycle/discovery fields to SOLIDserver class parameter names.

        Keys of lifecycle_class_parameter_mapping: end_of_sale, end_of_life,
        sw_end_of_sale, sw_end_of_life (calendar dates), last_discovery,
        last_backup, last_change (instants) - unmapped keys are skipped.
        """
        params: Dict[str, str] = {}
        for mapping_key, lvi_field in self._LIFECYCLE_DATE_FIELDS.items():
            class_param_name = self.lifecycle_class_parameter_mapping.get(mapping_key)
            if not class_param_name:
                continue
            value = format_epoch_ms(device.get(lvi_field), date_only=True)
            if value:
                params[class_param_name] = value
        for mapping_key, lvi_field in self._LIFECYCLE_INSTANT_FIELDS.items():
            class_param_name = self.lifecycle_class_parameter_mapping.get(mapping_key)
            if not class_param_name:
                continue
            value = format_epoch_ms(device.get(lvi_field))
            if value:
                params[class_param_name] = value
        return params

    @staticmethod
    def _disambiguate_interface_names(by_mac: Dict[str, Dict[str, Any]]) -> Tuple[Dict[str, str], Set[str]]:
        """Return ({port_mac: name to write to NOM}, {raw names that collided}).

        NOM enforces interface-name uniqueness *per device*, separately
        from its MAC-uniqueness constraint - confirmed live (errno 82012,
        "Interface already exists", distinct from errno 82026's MAC
        collision). Several genuinely distinct physical interfaces can
        share one LVI-reported name (e.g. a VM's multiple vNICs, which all
        report the identical driver-based name "VMware VMXNET3 Ethernet
        Controller" with unique MACs) - each of those needs a unique NOM
        name, or every one past the first fails to create.

        Suffixes are assigned by sorting each name-group's MACs, not by
        input order - `by_mac` is already keyed by MAC (insertion order
        depends on LVI's own interface list ordering, which isn't
        guaranteed stable across runs), so an unstable suffix would rename
        an interface every run for no reason and defeat find_interface()'s
        MAC-keyed lookup pairing it back up with the right existing row.

        The collided-names set exists for _sync_nom_connections(): LVI's
        neighbor data (get_device_neighbors()) identifies a local port only
        by this same raw name, with no MAC or other identifier of its own
        (confirmed against a live LLDP/CDP payload - "otherId" is a REMOTE
        chassis id or router-id, never anything about the local port). For
        a name in this set, that raw name cannot be resolved back to a
        specific one of the colliding physical ports - only the first
        (unsuffixed) one is even reachable by it, so linking a connection
        via such a name would silently wire it to whichever port happened
        to sort first, not the one the neighbor relationship is actually
        about.
        """
        groups: Dict[str, List[str]] = {}
        for port_mac, entry in by_mac.items():
            iface_info = entry.get("interface") or {}
            name = (iface_info.get("name") or iface_info.get("ifName") or "").strip()
            groups.setdefault(name, []).append(port_mac)

        names: Dict[str, str] = {}
        collided: Set[str] = set()
        for name, macs in groups.items():
            if len(macs) == 1:
                names[macs[0]] = name
                continue
            collided.add(name)
            for i, mac in enumerate(sorted(macs), start=1):
                names[mac] = name if i == 1 else f"{name} ({i})"
        return names, collided

    def _check_nom_written_this_run(
        self,
        folder_id: str,
        nom_name: str,
        device_key: Tuple[str, str],
        device_type: str,
        class_parameters: Dict[str, str],
        ip_address: str,
        hostname: str,
        written_this_run: Optional[Dict[Tuple[str, str], Tuple[Tuple[str, str], str]]],
        pending_items: Optional[List[Dict[str, Any]]],
    ) -> Optional[DeviceSyncOutcome]:
        """Return a DeviceSyncOutcome if a DIFFERENT LVI network already
        wrote this (folder_id, nom_name) destination earlier in this same
        run, else None - see _sync_device_to_nom's *written_this_run*/
        *pending_items* docstring for the full rationale.
        """
        if written_this_run is None:
            return None
        prior = written_this_run.get((folder_id, nom_name))
        if prior is None or prior[0] == device_key:
            return None
        prior_network = prior[0][0]
        has_data = bool(device_type) or self._has_real_class_parameters(class_parameters)
        detail = self._nom_duplicate_detail(
            nom_name,
            winner_network=prior_network,
            loser_network=device_key[0],
            loser_has_data=has_data,
        )
        if not has_data:
            # Overwrite and Ignore are the same end state - nothing
            # to defer to a decision that isn't one.
            logger.info("NOM: %s", detail)
            return DeviceSyncOutcome(ip_address=ip_address, hostname=hostname, action="ignored", detail=detail)
        logger.warning("NOM: %s", detail)
        if pending_items is not None:
            pending_items.append(
                {
                    "ip_address": ip_address,
                    "hostname": hostname,
                    "conflict_type": "nom_duplicate_this_run",
                    "detail": detail,
                    "desired_payload": {
                        "folder_id": folder_id,
                        "name": nom_name,
                        "type_": device_type,
                        "class_parameters": class_parameters,
                    },
                }
            )
        return DeviceSyncOutcome(ip_address=ip_address, hostname=hostname, action="pending", detail=detail)

    def _write_nom_device_object(
        self,
        folder_id: str,
        nom_name: str,
        device_type: str,
        class_parameters: Dict[str, str],
        alt_name: str,
        ip_address: str,
        hostname: str,
        device_key: Tuple[str, str],
        netobj_id_by_key: Optional[Dict[Tuple[str, str], str]],
        written_this_run: Optional[Dict[Tuple[str, str], Tuple[Tuple[str, str], str]]],
    ) -> Tuple[Optional[str], Optional[Dict[str, Any]], bool, Optional[DeviceSyncOutcome]]:
        """Find-or-create/update the NOM device object itself.

        Returns (netobj_id, existing, renamed, early_outcome). early_outcome
        is set (netobj_id meaningless) when ip_conflict_policy="ignore"
        skipped an existing device, or the write itself failed - the caller
        must return it early, before touching interfaces.
        """
        existing = self.target.find_network_object(folder_id, nom_name)
        renamed = False
        if existing is None and alt_name:
            existing = self.target.find_network_object(folder_id, alt_name)
            renamed = existing is not None

        # "When an IP already exists" (ip_conflict_policy) is IPAM-named but
        # applies per the help text's "skip the device entirely" - so an
        # existing NOM device by name is a conflict too, checked
        # independently of IPAM's own existing-address check above (a
        # device can be new to IPAM but already have a NOM object, or NOM
        # sync can run with Sync to IPAM off, where the IPAM check never
        # runs at all). "ask" has no NOM equivalent of the Resolve
        # Conflicts screen yet, so it behaves like "overwrite" here rather
        # than silently dropping the update.
        if existing is not None and self.ip_conflict_policy == "ignore":
            logger.info("Ignored NOM device: %s (%s) - device already exists in NOM", ip_address, nom_name)
            return (
                None,
                existing,
                renamed,
                DeviceSyncOutcome(
                    ip_address=ip_address,
                    hostname=hostname,
                    action="ignored",
                    detail="Device already exists in NOM",
                ),
            )

        if existing is not None:
            netobj_id = existing["nomnetobj_id"]
            device_ok = self.target.update_network_object(
                netobj_id,
                type_=device_type,
                class_parameters=class_parameters,
                name=nom_name if renamed else "",
            )
        else:
            netobj_id = self.target.create_network_object(
                folder_id, nom_name, type_=device_type, class_parameters=class_parameters
            )
            device_ok = netobj_id is not None

        if device_ok and netobj_id and netobj_id_by_key is not None:
            netobj_id_by_key[device_key] = netobj_id

        if not device_ok or not netobj_id:
            logger.warning("NOM: failed to sync device %s (%s)", ip_address, nom_name)
            return (
                None,
                existing,
                renamed,
                DeviceSyncOutcome(
                    ip_address=ip_address, hostname=hostname, action="error", error="NOM: failed to write device"
                ),
            )

        if written_this_run is not None:
            written_this_run[(folder_id, nom_name)] = (device_key, nom_name)

        return netobj_id, existing, renamed, None

    def _register_nom_vrfs(self, interfaces: List[Dict[str, Any]]) -> None:
        """Ensure a VRF object exists in SOLIDserver for every non-null
        interface.vrfName seen - see _sync_device_to_nom's *sync_vrfs*
        docstring for why this scans the raw interface list independently
        of the by_mac dedup below."""
        for entry in interfaces:
            vrf_name = ((entry.get("interface") or {}).get("vrfName") or "").strip()
            if vrf_name:
                self._ensure_vrf(vrf_name)

    def _dedupe_nom_interfaces_by_mac(
        self, interfaces: List[Dict[str, Any]]
    ) -> Tuple[Dict[str, Dict[str, Any]], int, int]:
        """Collapse *interfaces* to one entry per MAC (NOM's real per-device
        uniqueness constraint - see _sync_device_to_nom's docstring).

        Returns (by_mac, skipped, duplicate_macs). An entry missing a name
        or MAC is skipped outright (no NOM port can be created without
        one). Of two entries sharing a MAC, the one with an IP wins over
        one without; otherwise the first one seen is kept.
        """
        skipped = 0
        duplicate_macs = 0
        by_mac: Dict[str, Dict[str, Any]] = {}
        for entry in interfaces:
            iface_info = entry.get("interface") or {}
            port_name = (iface_info.get("name") or iface_info.get("ifName") or "").strip()
            port_mac = (iface_info.get("macAddress") or "").replace("-", ":").lower()
            if not port_name or not port_mac:
                skipped += 1
                continue
            if port_mac in by_mac:
                duplicate_macs += 1
                # Prefer an entry that actually has an IP over one that doesn't.
                if (entry.get("interfaceIps") or []) and not (by_mac[port_mac].get("interfaceIps") or []):
                    by_mac[port_mac] = entry
                continue
            by_mac[port_mac] = entry
        return by_mac, skipped, duplicate_macs

    def _resolve_nom_main_interface(
        self, ip_address: str, by_mac: Dict[str, Dict[str, Any]]
    ) -> Tuple[Optional[Dict[str, Any]], bool, bool]:
        """Pick the interface entry NOM's Main attribute goes on, mutating
        *by_mac* in place to add a synthetic entry if always_set_main_ip
        needs one. Returns (main_entry, force_hostaddr, synthetic_main) -
        see _sync_device_to_nom's docstring for the full Main-IP
        resolution rules.
        """
        main_entry = self._choose_main_interface(ip_address, list(by_mac.values()))
        force_hostaddr = False
        if main_entry is None and by_mac:
            entries = list(by_mac.values())
            if len(entries) == 1:
                # The device's only surviving interface is unambiguously
                # its Main one, whether or not its own reported IP happens
                # to textually match the device-level management IP LVI
                # reports - the two legitimately disagree for some real
                # devices (LVI's device record vs. its interface-table
                # walk can each source the address differently). This
                # never overwrites the interface's own IP: it keeps
                # whatever it already reports, and only backfills when it
                # has none at all (same rule as the multi-interface
                # fallback below).
                main_entry = entries[0]
                force_hostaddr = not self._first_ipv4(main_entry.get("interfaceIps") or [])
            else:
                # Several interfaces and none matched - too ambiguous to
                # guess which one is "the" management interface, so fall
                # back to the first surviving (named+MAC'd) one, same
                # "first entry wins" fallback src.common.utils.build_mac_lookup
                # already uses for the device's MAC. Only claims it as
                # Main (and only backfills its hostaddr) when that
                # interface has no IP of its own to begin with - never
                # overwrites a port's own, genuinely different, reported
                # address.
                fallback_entry = entries[0]
                if not self._first_ipv4(fallback_entry.get("interfaceIps") or []):
                    main_entry = fallback_entry
                    force_hostaddr = True

        synthetic_main = False
        if main_entry is None and self.always_set_main_ip:
            # Nothing above could give this device a Main IP - either
            # LogicVein reported no usable interface data at all, or too
            # many candidates existed to safely guess (see the "ambiguous"
            # branch above). always_set_main_ip opts into a synthetic
            # interface that doesn't correspond to any real LogicVein
            # port: name "main", a fixed null MAC (NOM's MAC-uniqueness
            # constraint is per-device, confirmed live, so reusing this
            # same MAC across many devices' own NOM objects is safe), and
            # the device's own management IP. A fixed MAC also means this
            # synthetic interface is found and updated on later runs
            # rather than recreated every time.
            synthetic_mac = "00:00:00:00:00:00"
            synthetic_entry = {
                "interface": {"name": "main", "macAddress": synthetic_mac, "index": 0, "vrfName": None},
                "interfaceIps": [ip_address],
            }
            by_mac[synthetic_mac] = synthetic_entry
            main_entry = synthetic_entry
            synthetic_main = True

        return main_entry, force_hostaddr, synthetic_main

    def _write_nom_interfaces(
        self,
        netobj_id: str,
        by_mac: Dict[str, Dict[str, Any]],
        main_entry: Optional[Dict[str, Any]],
        force_hostaddr: bool,
        ip_address: str,
        device_key: Tuple[str, str],
        sync_vlans: bool,
        collided_names_by_key: Optional[Dict[Tuple[str, str], Set[str]]],
    ) -> Tuple[int, int]:
        """Create/update/recreate each of *by_mac*'s surviving interfaces on
        *netobj_id*. Returns (synced, iface_errors) - see
        _sync_device_to_nom's docstring for the full interface-write rules
        (Main IP, VLAN, the delete+recreate-only-clears-hostaddr/promotes-
        Main quirks).
        """
        synced = 0
        iface_errors = 0
        vlan_lookup = self._build_vlan_lookup(ip_address, device_key[0]) if sync_vlans else {}
        nom_names, collided_names = self._disambiguate_interface_names(by_mac)
        if collided_names and collided_names_by_key is not None:
            collided_names_by_key[device_key] = collided_names

        for port_mac, entry in by_mac.items():
            iface_info = entry.get("interface") or {}
            raw_port_name = (iface_info.get("name") or iface_info.get("ifName") or "").strip()
            port_name = nom_names[port_mac]
            iface_ips = entry.get("interfaceIps") or []
            iface_ipv4 = self._first_ipv4(iface_ips)
            if iface_ipv4:
                iface_hostaddr = iface_ipv4
            elif force_hostaddr and entry is main_entry:
                iface_hostaddr = ip_address
            else:
                iface_hostaddr = ""
            # VLAN mapping is keyed on LVI's own port name (raw_port_name),
            # never the disambiguated NOM display name below - it comes
            # from a separate LVI call (_build_vlan_lookup()) that knows
            # nothing about NOM's per-device name-uniqueness constraint.
            #
            # VLAN can't be explicitly cleared via update at all - confirmed
            # against a live instance: nom_iface_add rejects
            # nomiface_vlan_number "0"/empty as errno 4 "Missing parameter",
            # even with nomiface_vlan_domain also set (likely a PHP
            # empty()-style truthiness check server-side treating "0" as
            # absent). A port with no current mapping just omits both
            # fields, leaving any previous VLAN value untouched.
            vlan_number = vlan_lookup.get(raw_port_name, "") if sync_vlans else ""
            if vlan_number and not self._ensure_vlan(vlan_number):
                vlan_number = ""
            vlan_domain = self.nom_vlan_domain_name if vlan_number else ""
            is_main = entry is main_entry

            # Keyed on MAC, not port name - see find_interface()'s docstring.
            # A port's LVI-reported name isn't stable identity; its MAC is
            # the real per-device uniqueness constraint SOLIDserver
            # enforces (errno 82026 if two ports collide on one).
            existing_iface = self.target.find_interface(netobj_id, port_mac)
            if existing_iface is not None:
                # PUT can change hostaddr between two non-empty values, but
                # can't clear a previously-set one back to empty - confirmed
                # live: it returns success but silently leaves the old IP
                # in place. Delete + recreate is the only way that actually
                # blanks it (and resets VLAN to 0 too, which has no
                # clearing path of its own via update).
                #
                # nomiface_main has the same one-way PUT quirk in reverse:
                # client.py's update_interface() docstring only confirms
                # PUT nomiface_main=0 (clearing) actually applies - setting
                # it from 0 to 1 via PUT was unconfirmed, and turned out
                # not to stick either (an interface newly promoted to Main
                # by the single-interface/no-match fallback above kept
                # showing "No" and no device-level Main IP until deleted
                # and recreated). Recreate whenever this run wants Main on
                # but the stored record doesn't already have it.
                existing_was_main = existing_iface.get("nomiface_main") in ("1", 1, True)
                needs_recreate = (bool(existing_iface.get("nomiface_hostaddr")) and not iface_hostaddr) or (
                    is_main and not existing_was_main
                )
                if needs_recreate:
                    self.target.delete_interface(existing_iface["nomiface_id"])
                    iface_ok = self.target.create_interface(
                        netobj_id,
                        iface_name=port_name,
                        port_name=port_name,
                        port_mac=port_mac,
                        hostaddr=iface_hostaddr,
                        vlan_domain=vlan_domain,
                        vlan_number=vlan_number,
                        is_main=is_main,
                    )
                else:
                    iface_ok = self.target.update_interface(
                        existing_iface["nomiface_id"],
                        iface_name=port_name,
                        port_name=port_name,
                        port_mac=port_mac,
                        hostaddr=iface_hostaddr,
                        vlan_domain=vlan_domain,
                        vlan_number=vlan_number,
                        is_main=is_main,
                    )
            else:
                iface_ok = self.target.create_interface(
                    netobj_id,
                    iface_name=port_name,
                    port_name=port_name,
                    port_mac=port_mac,
                    hostaddr=iface_hostaddr,
                    vlan_domain=vlan_domain,
                    vlan_number=vlan_number,
                    is_main=is_main,
                )
            if iface_ok:
                synced += 1
            else:
                iface_errors += 1

        return synced, iface_errors

    def _build_nom_device_outcome(
        self,
        ip_address: str,
        hostname: str,
        nom_name: str,
        existing: Optional[Dict[str, Any]],
        renamed: bool,
        alt_name: str,
        interfaces: List[Dict[str, Any]],
        synced: int,
        iface_errors: int,
        skipped: int,
        duplicate_macs: int,
        synthetic_main: bool,
    ) -> DeviceSyncOutcome:
        """Build the final DeviceSyncOutcome for a successfully written NOM device."""
        verb = "Updated" if existing is not None else "Created"
        logger.info("NOM: %s device %s (%s), %d interface(s) synced", verb, ip_address, nom_name, synced)
        detail = f"NOM: {verb.lower()} device"
        if renamed:
            detail += f" (renamed from '{alt_name}')"
        if interfaces:
            detail += f", {synced}/{len(interfaces)} interface(s) synced"
        elif self.sync_nom_interfaces and not synthetic_main:
            # LogicVein reports no interface data for this device at all -
            # distinct from an interface being skipped for missing a
            # name/MAC (see the "skipped" branch below, which covers
            # *some* interface data being present but unusable), and from
            # sync_nom_interfaces being off (interfaces is always [] then,
            # by the caller's own design - not a LogicVein data gap, so no
            # note is warranted in that case). Worth calling out
            # explicitly: without a MAC, no NOM interface can be created
            # at all (SOLIDserver requires one - see _sync_device_to_nom's
            # docstring), so this device will never get a Main IP until
            # LogicVein itself reports interface/MAC data for it, unless
            # "Always set device main IP" is on (see below).
            detail += " (no interface data in LogicVein - no Main IP possible)"
        if synthetic_main:
            detail += " (synthetic Main interface created - no real interface data matched)"
        if iface_errors:
            detail += f" ({iface_errors} failed)"
        if skipped:
            detail += f" ({skipped} skipped - no name/MAC)"
        if duplicate_macs:
            detail += f" ({duplicate_macs} skipped - MAC shared with another interface on this device)"

        return DeviceSyncOutcome(
            ip_address=ip_address,
            hostname=hostname,
            action="updated" if existing is not None else "added",
            detail=detail,
        )

    def _sync_device_to_nom(
        self,
        device_key: Tuple[str, str],
        hostname: str,
        device: Dict[str, Any],
        class_parameters: Dict[str, str],
        folder_id: str,
        interfaces: List[Dict[str, Any]],
        sync_vlans: bool,
        sync_vrfs: bool,
        netobj_id_by_key: Optional[Dict[Tuple[str, str], str]] = None,
        alt_name: str = "",
        collided_names_by_key: Optional[Dict[Tuple[str, str], Set[str]]] = None,
        written_this_run: Optional[Dict[Tuple[str, str], Tuple[Tuple[str, str], str]]] = None,
        pending_items: Optional[List[Dict[str, Any]]] = None,
        synced_names_by_folder: Optional[Dict[str, Set[str]]] = None,
    ) -> DeviceSyncOutcome:
        """Create or update one device (and all its interfaces/ports) in NOM.

        Runs independently of IPAM - identifies the device by name (LVI's
        hostname, falling back to its IP when LVI has none) inside one flat
        configured folder, and applies ip_conflict_policy's "ignore" to an
        existing NOM device the same as it applies to an existing IPAM
        address - see the check right after the existing/alt_name lookup
        below. Every interface LVI has for this device syncs
        (from plugin_api.prefetch_device_interfaces - the full per-network interface
        fetch, not just the single management-IP match IPAM/MAC lookup
        uses). An interface with no name or no MAC is skipped -
        nom_iface_add's port MAC field is mandatory on this appliance,
        confirmed empirically.

        NOM enforces MAC uniqueness per port *within a device*, confirmed
        against a live instance (errno 82026, "The port MAC address is
        already used for another port in the same network object") - but
        LVI devices commonly have several logical interfaces sharing one
        physical MAC (port-channel/LAG members, VLAN sub-interfaces,
        virtual OS-level adapters bound to one NIC; seen on real hardware
        during development, not a hypothetical). Only the first interface
        seen per MAC is synced (preferring one that actually has an IP);
        the rest are counted as skipped, not errors - this is an expected
        consequence of the physical MAC, not a write failure.

        Existing interfaces are looked up by MAC (find_interface()), not
        port name - a port's LVI-reported name is not stable identity
        (seen in production: the same physical port/MAC got a different
        display name across syncs), while MAC is the real uniqueness
        constraint above. Looking up by the old name missed the existing
        row and tried to create a new one with an already-claimed MAC,
        failing every time (the same errno 82026 as the duplicate-MAC
        case, but for a genuinely single physical port). A name change is
        applied as a rename on the existing row, not a new interface.

        The interface whose own IP exactly matches the device's management
        IP gets NOM's "Main" attribute (nomiface_main) - every other
        interface explicitly gets it cleared, not just left alone, so the
        Main interface moves correctly if the match changes across runs.
        See _choose_main_interface(). When no interface reports the
        management IP at all, the first surviving interface with no IPv4
        of its own becomes Main and gets the management IP backfilled onto
        it - the device's own IP should always show up somewhere in NOM.
        An interface that already reports a different IPv4 of its own is
        never overwritten with it. nomiface_hostaddr is IPv4-typed - an
        interface reporting only an IPv6 address (a link-local EUI-64 off
        its own MAC is common) counts the same as having no IP of its own
        for this purpose; see _first_ipv4(). If nothing above can give the
        device a Main
        IP at all and always_set_main_ip is on, a synthetic interface
        (name "main", MAC 00:00:00:00:00:00) carrying the device's own IP
        is created and marked Main instead - see its own comment further
        down for why this is opt-in.

        *sync_vlans* (only True when sync_nom_vlans is on and the VLAN
        Domain was successfully resolved this run) fetches this device's
        port->VLAN-number mapping (one extra LVI call per device - see
        _build_vlan_lookup()) and applies it to each synced interface.
        VLAN itself has no clearing path (SOLIDserver rejects
        nomiface_vlan_number "0"/empty outright) - a port whose mapping
        disappears just keeps its last-known VLAN.

        *sync_vrfs* (only True when sync_nom_vrfs is on and sync_nom_interfaces
        is on) scans every entry in *interfaces* for a non-null
        interface.vrfName and ensures a VRF object with that name exists in
        SOLIDserver (see _ensure_vrf()), once per unique name per run. This
        scans the raw interface list directly, independent of the by_mac
        dedup/name-mac-skip logic below - an interface that's itself
        skipped or deduped for NOM sync purposes can still carry a VRF name
        worth registering. Nothing links the VRF to the interface itself;
        see sync_nom_vrfs's docstring in __init__ for why.

        An interface whose IP is removed in LogicVein (iface_hostaddr
        becomes "") is deleted and recreated rather than updated in place
        - PUT can change hostaddr between two non-empty values but can't
        clear a previously-set one back to empty (confirmed live: it
        reports success but silently keeps the stale IP). Recreating also
        resets that interface's VLAN to 0, since there's no other way to
        clear it either.

        NOM has no single-call upsert like IPAM's ip_add - creating an
        already-existing object errors even with an explicit ID, and
        updating requires PUT on the same "_add" service instead of POST
        (both confirmed empirically; see EfficientIPClient's NOM methods).
        So the existing/not-existing decision is made explicitly here, not
        delegated to the client.

        *interfaces* is already an empty list by the time it reaches here
        when sync_nom_interfaces is off (sync()'s call site passes {}
        instead of the real prefetch) - so the device itself still syncs,
        but no interface is looked up, created, updated, or deleted.
        Interfaces synced from an earlier run when the toggle was on are
        never touched, let alone removed, while it's off.

        *netobj_id_by_key*, when given, gets this device's (network,
        management IP) -> netobj_id recorded on a successful device write -
        sync()'s "Find connected objects" pass (_sync_nom_connections())
        uses this to resolve a neighbor's IP to its own already-synced NOM
        device, without a second round of find_network_object() lookups.

        *alt_name*, when given (see _resolve_display_name()), is the name
        this device would have under the *other* strip_domain_from_names
        setting. If nothing is found under this run's name but something
        is found under alt_name, that's the same device from before the
        setting was toggled - it gets renamed in place (via
        update_network_object()'s name= param) rather than treated as
        missing, which would otherwise create a duplicate device.

        *collided_names_by_key*, when given, gets this device's raw LVI
        interface names that needed disambiguation (see
        _disambiguate_interface_names()) recorded under *device_key* -
        _sync_nom_connections() uses this to refuse to link a neighbor
        relationship through an ambiguous name rather than silently wiring
        it to the wrong physical port.

        *written_this_run*, when given, detects a DIFFERENT LVI network
        writing this exact (folder_id, nom_name) destination earlier in
        this same run (see sync()'s matching IPAM-side check for the full
        rationale - the two live independently since NOM's own folder
        partitioning can differ from IPAM's space partitioning). Its value
        also carries the winning device's own nom_name, not just its
        device_key, so the pending-conflict message can name it.

        *pending_items*, when given, gets a nom_duplicate_this_run entry
        appended when written_this_run detects a collision - the device is
        never written this run, only deferred, exactly like IPAM's
        ip_duplicate_this_run. resolve_conflict()'s NOM branch replays the
        desired_payload (folder_id, name, type_, class_parameters) the same
        way _sync_device_to_nom() itself would have. When pending_items is
        not given (None), a collision is still skipped and logged, just
        never recorded anywhere resolvable - callers that want the
        conflict to be reviewable must pass both written_this_run and
        pending_items together.

        *synced_names_by_folder*, when given, records nom_name under
        folder_id regardless of what happens next (write, ignore, deferred
        conflict) - delete_stale_devices's stale scan (see sync()) uses this
        to know LogicVein still genuinely reports this device in this
        folder, even on a run where it was not actually written.

        Split into phase helpers below (finding 2 of the 2026-08-14
        cross-repo review): _check_nom_written_this_run,
        _write_nom_device_object, _register_nom_vrfs,
        _dedupe_nom_interfaces_by_mac, _resolve_nom_main_interface,
        _write_nom_interfaces, _build_nom_device_outcome. This method is
        now a thin orchestrator calling each in sequence; the behavior
        documented above is unchanged, just relocated.
        """
        ip_address = device_key[1]
        nom_name = hostname or ip_address

        if synced_names_by_folder is not None:
            synced_names_by_folder.setdefault(folder_id, set()).add(nom_name)

        raw_device_type = device.get("deviceType", "")
        # Mapped before the write so a long LVI type becomes a readable
        # short one ("Wireless Controller" -> "WLC") rather than falling
        # through to the client's blunt 16-character trim. Computed early
        # (before the collision check below) since a deferred conflict's
        # desired_payload needs it too.
        device_type = self.nom_type_mapping.get(raw_device_type, raw_device_type)

        collision_outcome = self._check_nom_written_this_run(
            folder_id,
            nom_name,
            device_key,
            device_type,
            class_parameters,
            ip_address,
            hostname,
            written_this_run,
            pending_items,
        )
        if collision_outcome is not None:
            return collision_outcome

        netobj_id, existing, renamed, early_outcome = self._write_nom_device_object(
            folder_id,
            nom_name,
            device_type,
            class_parameters,
            alt_name,
            ip_address,
            hostname,
            device_key,
            netobj_id_by_key,
            written_this_run,
        )
        if early_outcome is not None:
            return early_outcome
        # _write_nom_device_object() guarantees early_outcome is set
        # whenever netobj_id would be None - narrows Optional[str] to str
        # for the rest of this method, mirroring the original code's
        # single "if not device_ok or not netobj_id: return" guard.
        assert netobj_id is not None

        if sync_vrfs:
            self._register_nom_vrfs(interfaces)

        by_mac, skipped, duplicate_macs = self._dedupe_nom_interfaces_by_mac(interfaces)
        main_entry, force_hostaddr, synthetic_main = self._resolve_nom_main_interface(ip_address, by_mac)
        synced, iface_errors = self._write_nom_interfaces(
            netobj_id,
            by_mac,
            main_entry,
            force_hostaddr,
            ip_address,
            device_key,
            sync_vlans,
            collided_names_by_key,
        )

        return self._build_nom_device_outcome(
            ip_address,
            hostname,
            nom_name,
            existing,
            renamed,
            alt_name,
            interfaces,
            synced,
            iface_errors,
            skipped,
            duplicate_macs,
            synthetic_main,
        )

    def _sync_nom_connections(
        self,
        netobj_id_by_key: Dict[Tuple[str, str], str],
        outcome_by_key: Dict[Tuple[str, str], DeviceSyncOutcome],
        collided_names_by_key: Optional[Dict[Tuple[str, str], Set[str]]] = None,
    ) -> None:
        """Link each synced device's LLDP/CDP neighbor ports as NOM connections.

        Runs as a second pass, after every device in this run already has
        its NOM device+interfaces synced - *netobj_id_by_key* only has
        entries for devices _sync_device_to_nom() actually wrote
        successfully this run. A neighbor can only be linked if its own
        device was *also* synced to NOM in this same run: LVI's neighbor
        data (get_device_neighbors()) gives an IP and a port name, not a
        NOM id, and resolving a neighbor outside this run (LVI device
        search by IP, then NOM lookup by hostname) is out of scope for now
        - such neighbors are just skipped, counted, and noted.

        Keys are (network, management IP). A neighbor is resolved within
        the *same* LVI managed network as the device reporting it: LVI's
        neighbor data carries no network of its own, and a physical
        LLDP/CDP adjacency is between two devices on the same managed
        network. This also stops a neighbor IP from accidentally resolving
        to an unrelated device that happens to share that IP in a
        different network.

        Only LLDP/CDP entries represent a physical port-to-port link -
        confirmed live that routing-protocol neighbors (OSPF, etc.) always
        report remoteInterface as null (an L3 adjacency, not a cable), so
        they're filtered out rather than hardcoding every non-physical
        protocol LVI might ever report.

        *collided_names_by_key*, when given, is consulted before resolving
        either side of a link. A neighbor entry names its local and remote
        ports only by a raw LVI interface name (confirmed against a live
        LLDP/CDP payload - no local MAC, no ifIndex; "otherId" identifies
        the REMOTE device, either its chassis MAC or its OSPF router-id
        depending on protocol, never anything about the local port). When
        that name is one _disambiguate_interface_names() had to suffix for
        the device in question (several physical interfaces sharing one
        raw name - see that method's docstring), there is no data available
        here to say which of them this specific neighbor relationship is
        about. Resolving anyway would silently wire the connection to
        whichever one happened to keep the bare, unsuffixed name - proven
        live: a device with such a collision had one port set to a
        different remote on almost every neighbor processed for it, each
        overwriting the last, because every one of those lookups can only
        ever reach that same single port. Skipped and counted separately
        from "neighbor not found" instead, since the cause and the fix
        (nothing further to look up; LVI would need to report more than a
        name) are both different.

        A port can also have more than one physical-protocol neighbor entry
        pointing at *different* remotes within LVI's own data for a single
        run - confirmed live: one local port had three distinct
        (protocol, remote) entries against it, for a local device with no
        interface-name collision at all (so the paragraph above does not
        explain it). LVI's neighbor payload carries nothing to say which of
        several conflicting entries for one port is the current physical
        link and which are stale - most plausibly leftover LLDP/CDP cache
        entries from earlier cabling that a lab gets rewired out of but LVI
        never expires.

        EfficientIPClient.set_interface_connection()'s own docstring used to
        claim reassigning a port automatically clears its previous
        connection, "confirmed live" - proven wrong by the case above: none
        of the three conflicting attempts against that one port cleared its
        real, pre-existing connection to a fourth device: every one of them
        failed with "already connected to another port" instead, and the
        original connection was still there afterwards. *current_connection*
        (nomiface_id -> its connected_port_id, seeded live from
        get_interfaces_for_netobj() before this run's first attempt, spanning
        the whole call rather than reset per device) is checked before every
        attempt: a port already connected to something else - whether from
        the live appliance state or a link this same run already made - is
        refused rather than retried into a guaranteed, noisy failure. A
        successful link updates both directions in *current_connection*
        immediately, so a later neighbor entry naming either port sees it as
        already-connected too, without a second read from the appliance.

        set_interface_connection()'s connected_port_id argument takes a
        *nomport_id*, not a nomiface_id - confirmed live: PUTting a peer's
        own nomiface_id there errors (errno 82027, "Connected port not
        found"; SOLIDserver's response body for it is itself malformed -
        several JSON objects concatenated with no enclosing array, so
        response.json() raised ValueError and this surfaced as a bare
        "HTTP 400 (no error body)" with no clue what actually went wrong -
        see _request()'s handling of this). nomiface_id and nomport_id are
        two different fields on the same nom_iface_list row - *_ports_for()*
        returns both per port name so the PUT's *subject* (nomiface_id, the
        interface being updated - correct, unchanged) and its *value*
        (nomport_id, the peer being pointed at) never get confused for one
        another again. *current_connection* stays keyed by nomiface_id
        (matching how a listed interface's own identity works) but its
        values are nomport_id throughout, matching exactly what
        connected_port_id itself already contains on a live-read interface.
        """
        ports_by_netobj: Dict[str, Dict[str, Tuple[str, str]]] = {}
        current_connection: Dict[str, str] = {}

        def _ports_for(netobj_id: str) -> Dict[str, Tuple[str, str]]:
            """port_name -> (nomiface_id, nomport_id)."""
            if netobj_id not in ports_by_netobj:
                names: Dict[str, Tuple[str, str]] = {}
                for iface in self.target.get_interfaces_for_netobj(netobj_id):
                    port_name = iface.get("nomiface_port_name")
                    iface_id = iface.get("nomiface_id")
                    port_id = iface.get("nomport_id")
                    if not port_name or not iface_id or not port_id:
                        continue
                    names[port_name] = (iface_id, port_id)
                    current_connection[iface_id] = iface.get("connected_port_id") or ""
                ports_by_netobj[netobj_id] = names
            return ports_by_netobj[netobj_id]

        def _collided(key: Tuple[str, str], name: str) -> bool:
            if collided_names_by_key is None:
                return False
            return name in collided_names_by_key.get(key, set())

        for device_key, netobj_id in netobj_id_by_key.items():
            network, ip_address = device_key
            try:
                neighbors = self.lvi.get_device_neighbors(ip_address, network)
            except Exception as exc:
                logger.warning("NOM: failed to fetch neighbors for %s: %s", ip_address, exc)
                continue
            physical = [n for n in neighbors if n.get("protocol") in ("LLDP", "CDP") and n.get("remoteInterface")]
            if not physical:
                continue

            local_ports = _ports_for(netobj_id)
            linked = 0
            skipped = 0
            ambiguous = 0
            conflicting = 0
            for neighbor in physical:
                try:
                    local_name = neighbor.get("localInterface", "")
                    remote_ip = neighbor.get("ipAddress", "")
                    remote_name = neighbor.get("remoteInterface", "")
                    neighbor_netobj_id = netobj_id_by_key.get((network, remote_ip))
                    if _collided(device_key, local_name) or (
                        neighbor_netobj_id is not None and _collided((network, remote_ip), remote_name)
                    ):
                        ambiguous += 1
                        continue
                    local_entry = local_ports.get(local_name)
                    if not local_entry or not neighbor_netobj_id:
                        skipped += 1
                        continue
                    local_iface_id, local_port_id = local_entry
                    remote_entry = _ports_for(neighbor_netobj_id).get(remote_name)
                    if not remote_entry:
                        skipped += 1
                        continue
                    remote_iface_id, remote_port_id = remote_entry
                    existing_local = current_connection.get(local_iface_id, "")
                    existing_remote = current_connection.get(remote_iface_id, "")
                    if existing_local == remote_port_id and existing_remote == local_port_id:
                        continue  # already connected (this run or earlier) - nothing to redo
                    if (existing_local and existing_local != remote_port_id) or (
                        existing_remote and existing_remote != local_port_id
                    ):
                        conflicting += 1
                        continue
                    if self.target.set_interface_connection(local_iface_id, remote_port_id):
                        linked += 1
                        current_connection[local_iface_id] = remote_port_id
                        current_connection[remote_iface_id] = local_port_id
                    else:
                        skipped += 1
                except SyncCancelled:
                    raise
                except Exception as exc:
                    # One malformed/stale neighbor must never take down the
                    # rest of this device's connections, let alone every
                    # other device's - confirmed live: a stale
                    # connected_port_id (pointing at a since-deleted port)
                    # raised past set_interface_connection() and aborted
                    # the whole pass for all 13 devices in one run before
                    # this was caught here.
                    logger.warning("NOM: failed to link a connection for %s: %s", ip_address, exc)
                    skipped += 1

            if not linked and not skipped and not ambiguous and not conflicting:
                continue
            note = f"NOM: {linked} connection(s) linked"
            if skipped:
                note += f" ({skipped} skipped - neighbor not found)"
            if ambiguous:
                note += f" ({ambiguous} skipped - local/remote port name not unique on that device)"
            if conflicting:
                note += f" ({conflicting} skipped - port already connected to a different neighbor)"
            outcome = outcome_by_key.get(device_key)
            if outcome is not None:
                outcome.detail = f"{outcome.detail}; {note}" if outcome.detail else note

    def _ensure_block_exists(self, ip_address: str, site_id: str) -> bool:
        """Return True once a covering IP block exists for *ip_address*.

        Creates one (a /16) only when create_missing_blocks is enabled -
        independent of create_missing_subnets, which only controls whether
        the /24 subnet itself gets created. A /16 is large enough to hold
        many /24 subnets, so devices sharing a /16 reuse the same block
        instead of each needing their own. Only called when not in
        dry-run mode.
        """
        if self.target.find_block_for_ip(ip_address, site_id=site_id) is not None:
            return True
        if not self.create_missing_blocks:
            return False
        try:
            block_network = ipaddress.ip_interface(f"{ip_address}/16").network
        except ValueError:
            return False
        created = self.target.create_block(str(block_network), site_id=site_id)
        if created:
            logger.info("Created block %s in space '%s'", block_network, self._space_label(site_id))
        else:
            logger.warning("Could not create block %s for %s", block_network, ip_address)
        return created

    def _resolve_subnet_id(self, ip_address: str, site_id: str) -> Optional[str]:
        """Return the subnet_id containing *ip_address*, creating the subnet (and its parent
        block, if needed) first if configured to.

        This lookup always runs (not just when create_missing_subnets is
        set) because create_or_update_address needs the subnet_id to link
        the address record - without it, SOLIDserver creates the address
        under the site but leaves it unassociated with any subnet, where it
        shows up under "Orphan Addresses" in the UI.

        create_missing_blocks and create_missing_subnets are independent:
        enabling only create_missing_blocks still ensures/creates the
        covering block (useful to pre-provision address space) but never
        attempts the subnet itself; enabling only create_missing_subnets
        never creates a block, so subnet creation fails when none exists.
        """
        subnet = self.target.find_subnet_for_ip(ip_address, site_id=site_id)
        if subnet is not None:
            return subnet.get("subnet_id")

        if not self.create_missing_blocks and not self.create_missing_subnets:
            return None

        if self.dry_run:
            if self.create_missing_blocks and self.target.find_block_for_ip(ip_address, site_id=site_id) is None:
                block_network = ipaddress.ip_interface(f"{ip_address}/16").network
                logger.info("[DRY RUN] Would create block %s in space '%s'", block_network, self._space_label(site_id))
            if self.create_missing_subnets:
                try:
                    network = ipaddress.ip_interface(f"{ip_address}/24").network
                    logger.info("[DRY RUN] Would create subnet %s in space '%s'", network, self._space_label(site_id))
                except ValueError:
                    pass
            return None

        # Ensure/create the covering block regardless of whether we are
        # also going to create the subnet - a standalone create_missing_blocks
        # must still take effect.
        block_exists = self._ensure_block_exists(ip_address, site_id)

        if not self.create_missing_subnets:
            return None

        try:
            network = ipaddress.ip_interface(f"{ip_address}/24").network
        except ValueError:
            logger.warning("Could not derive a subnet for invalid IP: %s", ip_address)
            return None

        if not block_exists:
            logger.warning(
                "Could not create subnet %s for %s: no covering IP block (create_missing_blocks is %s)",
                network,
                ip_address,
                "on but creation failed" if self.create_missing_blocks else "off",
            )
            return None

        created = self.target.create_subnet(str(network), site_id=site_id)
        if not created:
            logger.warning("Could not create subnet %s for %s", network, ip_address)
            return None

        logger.info("Created subnet %s in space '%s'", network, self._space_label(site_id))
        subnet = self.target.find_subnet_for_ip(ip_address, site_id=site_id)
        return subnet.get("subnet_id") if subnet else None

    @staticmethod
    def _normalize_mac(mac: str) -> str:
        """Lowercase/colon-normalize a MAC, or "" when there's no real MAC to compare.

        SOLIDserver auto-populates mac_addr with a synthetic "EIP:<hash>"
        placeholder on an address that has never had a real MAC written -
        confirmed live (e.g. "EIP:6a52e249c73de5.88275437" on an address
        with no actual MAC). Treating that as a real value produced a
        false "MAC differs" conflict against LogicVein's real MAC every
        run, since the placeholder never matches anything - it isn't a
        MAC at all, just SOLIDserver's own internal marker for "none set".
        """
        normalized = (mac or "").replace("-", ":").lower()
        return "" if normalized.startswith("eip:") else normalized

    def _detect_duplicate_mac(
        self,
        device_key: Tuple[str, str],
        mac: str,
        site_id: str,
        mac_to_keys: Dict[str, List[Tuple[str, str]]],
    ) -> str:
        """Return a human-readable note if *mac* is also used by another device, else "".

        Checks both sources independently: the same LVI sync run (free, from
        the already-prefetched interface data) and existing EfficientIP
        address records (one lookup call, only for devices that have a MAC).

        *device_key*/*mac_to_keys* are keyed on (network, management IP) -
        see plugin_api.prefetch_device_interfaces(). A sibling in the same LVI
        network is
        reported as a bare IP (unchanged from when this was IP-keyed); one
        in a different network is qualified as "network/IP", since the IP
        alone would be ambiguous exactly when it matters.

        Callers decide whether this gates the write - mac_conflict_policy
        "ask" defers the whole device (see sync()); "overwrite" and
        "leave_untouched" only use this as a report annotation, matching
        their existing same-IP-MAC-changed behavior.
        """
        network, ip_address = device_key
        siblings = [k for k in mac_to_keys.get(mac, []) if k != device_key]
        if siblings:
            labels = [sib_ip if sib_net == network else f"{sib_net}/{sib_ip}" for sib_net, sib_ip in siblings]
            return f"duplicate MAC in LogicVein, also on {', '.join(labels)}"

        try:
            eip_matches = self.target.find_addresses_by_mac(mac, site_id=site_id)
        except Exception as e:
            logger.debug("Could not check for duplicate MAC %s in EfficientIP: %s", mac, e)
            return ""
        eip_siblings = [
            r.get("hostaddr", "") for r in eip_matches if r.get("hostaddr") and r.get("hostaddr") != ip_address
        ]
        if eip_siblings:
            return f"MAC already assigned in EfficientIP to {', '.join(eip_siblings)}"
        return ""

    def _delete_stale_addresses(self, synced_ips_by_site: Dict[str, Set[str]]) -> int:
        """Delete an IPAM address record if LogicVein no longer reports it in a
        space this run wrote to. Only called when self.delete_stale_ips is on.

        Two safety boundaries, both essential: only a site_id that appears
        as a key in *synced_ips_by_site* is scanned at all (a space this run
        never touched is never swept, however partitioned this run is), and
        within a scanned space, only a record carrying the lvi_managed
        marker (written on every synced record - see the module-level
        constant) is ever considered for deletion - a manually-added or
        other tool's address sharing the same space is left alone.
        """
        deleted = 0
        for site_id, synced_ips in synced_ips_by_site.items():
            try:
                existing = self.target.get_addresses(site_id)
            except Exception as e:
                logger.warning("Could not list addresses for stale check (site_id=%s): %s", site_id, e)
                continue
            for record in existing:
                hostaddr = record.get("hostaddr", "")
                if not hostaddr or hostaddr in synced_ips:
                    continue
                params = self.target.decode_class_parameters(record.get("ip_class_parameters", ""))
                if params.get(_LVI_MANAGED_KEY) != _LVI_MANAGED_VALUE:
                    continue
                ip_id = record.get("ip_id", "")
                if not ip_id:
                    continue
                if self.target.delete_address(ip_id):
                    logger.info("Deleted stale address: %s (site_id=%s)", hostaddr, site_id)
                    deleted += 1
                else:
                    logger.warning("Failed to delete stale address: %s (site_id=%s)", hostaddr, site_id)
        return deleted

    def _delete_stale_nom_devices(self, synced_names_by_folder: Dict[str, Set[str]]) -> int:
        """NOM equivalent of _delete_stale_addresses() - see its docstring
        for the two safety boundaries (folder scope, lvi_managed marker),
        which apply identically here. Only called when
        self.delete_stale_nom_devices is on.
        """
        deleted = 0
        for folder_id, synced_names in synced_names_by_folder.items():
            try:
                existing = self.target.get_network_objects(folder_id)
            except Exception as e:
                logger.warning("Could not list NOM devices for stale check (folder_id=%s): %s", folder_id, e)
                continue
            for record in existing:
                name = record.get("nomnetobj_name", "")
                if not name or name in synced_names:
                    continue
                params = self.target.decode_class_parameters(record.get("nomnetobj_class_parameters", ""))
                if params.get(_LVI_MANAGED_KEY) != _LVI_MANAGED_VALUE:
                    continue
                netobj_id = record.get("nomnetobj_id", "")
                if not netobj_id:
                    continue
                if self.target.delete_network_object(netobj_id):
                    logger.info("Deleted stale NOM device: %s (folder_id=%s)", name, folder_id)
                    deleted += 1
                else:
                    logger.warning("Failed to delete stale NOM device: %s (folder_id=%s)", name, folder_id)
        return deleted

    def sync(self) -> bool:
        """Run one sync. Return True if every device synced without error.

        Builds self.last_report (a SyncReport) with a per-device outcome for
        every processed device - picked up by the core after the run to
        render/store an HTML report. Devices deferred by an "ask" conflict
        policy are recorded as pending in the sync_pending_conflicts table
        (see src.common.sync_reports) rather than written now.

        Two different LVI networks resolving the same management IP to the
        same IPAM space within this one run is deferred to a pending
        conflict (conflict_type "ip_duplicate_this_run"), regardless of
        ip_conflict_policy - even "overwrite". This is deliberately
        stricter than that policy's normal job (deciding how to treat a
        record that predates this run): two LVI devices disagreeing about
        one destination within a single run is almost always a data
        problem, not a legitimate overwrite decision - seen live, an
        EfficientIP rule that writes IPs back into LogicVein duplicated a
        device across networks, and the second one to sync silently
        overwrote the first with a "0 errors" run. A legitimately
        overlapping-IP multi-VRF/partitioned setup is unaffected, since the
        check is keyed on the actual resolved destination (site_id), not
        just the IP - two networks correctly partitioned into different
        spaces never collide. NOM has the equivalent check keyed on
        (folder_id, nom_name) and, like IPAM, defers to a pending conflict
        (conflict_type "nom_duplicate_this_run") rather than being skipped
        outright - see _sync_device_to_nom()'s docstring. In both cases, if
        the losing entry carries no real data of its own (no hostname/MAC
        for IPAM, no type/class parameters for NOM), Overwrite and Ignore
        are the same end state - resolve_conflict() only sets a field when
        it is truthy, so there is nothing for Overwrite to contribute. That
        case is auto-ignored instead of deferred (action "ignored", not
        "pending") - presenting a choice with one real outcome as if it
        needed a decision was actively misleading. See
        _ip_duplicate_detail()'s docstring.

        delete_stale_ips/delete_stale_nom_devices (both off by default)
        delete an lvi_managed-marked record in a space/folder this run
        wrote to, once LogicVein stops reporting it there - see
        _delete_stale_addresses()/_delete_stale_nom_devices(). Never runs
        on a stopped-early or dry-run pass.
        """
        logger.info(
            "LogicVein to EfficientIP SOLIDserver sync starting (dry_run=%s, ipam=%s, nom=%s)",
            self.dry_run,
            self.sync_to_ipam,
            self.sync_to_nom,
        )
        started_at = datetime.now(timezone.utc).isoformat()

        def _abort(message: str) -> bool:
            logger.error("Aborting sync before any object was pushed: %s", message)
            self.last_report = SyncReport(
                plugin_name=PLUGIN_NAME,
                started_at=started_at,
                finished_at=datetime.now(timezone.utc).isoformat(),
                dry_run=self.dry_run,
                run_errors=[message],
            )
            return False

        run_warnings: List[str] = []

        # Config problems are one clear message before anything is pushed,
        # rather than a puzzling per-device failure or a mapping key that
        # silently never matches.
        config_problems = sp.validate_config(
            self.space_partition_by, self.space_mapping, self.ipam_unmapped_policy, self.sync_nom_vrfs
        )
        if self.nom_folder_partition_by not in (sp.MODE_NONE, sp.MODE_NETWORK):
            # The VRF axis is deliberately unavailable for NOM: a device is a
            # whole object whose interfaces span several VRFs, so there is no
            # single correct VRF folder for it.
            config_problems.append(
                f"nom_folder_partition_by '{self.nom_folder_partition_by}' is not one of "
                f"{sp.MODE_NONE}, {sp.MODE_NETWORK}"
            )
        else:
            config_problems += [
                p.replace("space_mapping", "nom_folder_mapping").replace(
                    "space_partition_by", "nom_folder_partition_by"
                )
                for p in sp.validate_config(
                    self.nom_folder_partition_by, self.nom_folder_mapping, self.nom_unmapped_policy
                )
            ]
        if config_problems:
            return _abort("; ".join(dict.fromkeys(config_problems)))

        if self.sync_to_ipam and self.space_partition_by == sp.MODE_NONE:
            # Unpartitioned: one space for everything, and its absence is
            # still a whole-run abort as it always was - there is no other
            # space for anything to go to.
            if self._resolve_site_id() is None:
                return _abort(f"IP space '{self.space_name}' not found")

        # Pre-flight only - nothing is pushed above this point. NOM
        # folder/VLAN Domain/VLAN Range each either already exist, get
        # auto-created here (create_missing_* on), or - when off and
        # missing - degrade gracefully: skip just the NOM portion (or, for
        # VLANs, just the VLAN portion) of this run rather than aborting
        # IPAM too. IPAM has its own independent gates - IP space
        # resolution above, and per-device subnet auto-creation below -
        # and is unaffected by NOM-only infrastructure being missing.
        if self.sync_to_nom:
            # Unpartitioned: one folder for the whole run, and failing to
            # resolve it still disables NOM for the run exactly as before -
            # there is no other folder for anything to go to. Partitioned:
            # each device's folder is resolved in the loop instead, so one
            # unmapped network does not take NOM down for every other.
            if self.nom_folder_partition_by == sp.MODE_NONE and self._resolve_nom_folder_id() is None:
                msg = (
                    f"NOM folder '{self.nom_folder_name}' not found and create_missing_nom_folder "
                    "is off - skipping NOM for this run"
                )
                logger.warning(msg)
                run_warnings.append(msg)
                self.sync_to_nom = False

        # VLAN infrastructure is folder-independent, so it is checked once per
        # run regardless of partitioning - but only when NOM is still on.
        if self.sync_to_nom:
            if self.sync_nom_vlans:
                if not self._ensure_vlan_domain():
                    msg = (
                        f"VLAN domain '{self.nom_vlan_domain_name}' not found and create_missing_vlan_domain "
                        "is off - skipping VLAN sync for this run"
                    )
                    logger.warning(msg)
                    run_warnings.append(msg)
                    self.sync_nom_vlans = False
                elif not self._ensure_vlan_range():
                    msg = (
                        f"VLAN range '{self.nom_vlan_range_name}' not found in domain "
                        f"'{self.nom_vlan_domain_name}' and create_missing_vlan_range is off"
                        " - skipping VLAN sync for this run"
                    )
                    logger.warning(msg)
                    run_warnings.append(msg)
                    self.sync_nom_vlans = False

        devices: List[dict] = self.lvi.search_devices_in_network(network=self.networks)
        logger.info("Fetched %d device(s) from LogicVein", len(devices))

        # One interface fetch per network, shared by the MAC lookup and NOM
        # interface sync (these used to make the same LVI call separately).
        # Everything derived from it is keyed on (network, management IP) -
        # see plugin_api.prefetch_device_interfaces() for why the bare IP is
        # not a safe key.
        # A VRF-partitioned run needs interface data even with MAC sync and NOM
        # both off, because a device's VRF is read from the interface matching
        # its management IP (_device_vrf). One extra paginated call per network.
        need_interfaces = (
            self.sync_mac_address
            or (self.sync_to_nom and self.sync_nom_interfaces)
            or (self.sync_to_ipam and sp.needs_vrf(self.space_partition_by))
        )
        interfaces_by_key: Dict[Tuple[str, str], List[Dict[str, Any]]] = (
            prefetch_device_interfaces(self.lvi, resolve_prefetch_networks(self.networks, devices))
            if need_interfaces
            else {}
        )
        mac_lookup = build_mac_lookup(interfaces_by_key) if self.sync_mac_address else {}
        mac_to_keys: Dict[str, List[Tuple[str, str]]] = {}
        for device_key, mac in mac_lookup.items():
            mac_to_keys.setdefault(mac, []).append(device_key)
        all_interfaces_by_key = interfaces_by_key if self.sync_to_nom and self.sync_nom_interfaces else {}

        observed_vrfs = sorted(
            {
                ((e.get("interface") or {}).get("vrfName") or "").strip()
                for entries in interfaces_by_key.values()
                for e in entries
            }
        )
        if interfaces_by_key:
            # Reported every run so the VRF names LogicVein actually emits are
            # on the record. The alias list that folds vendor spellings of the
            # global table onto one name is researched from vendor docs, not
            # from observed LVI output - no VRF-bearing device has been seen
            # yet - so this is how that gets confirmed or corrected.
            named = [v for v in observed_vrfs if v]
            logger.info(
                "LogicVein reported %d distinct interface VRF name(s): %s",
                len(named),
                ", ".join(repr(v) for v in named) if named else "none (all null/empty)",
            )
            if named and sp.needs_vrf(self.space_partition_by):
                folded = {v for v in named if sp.normalize_vrf(v, self.global_vrf_aliases, "\x00") == "\x00"}
                if folded:
                    logger.info(
                        "Treated as the global routing table and folded onto '%s': %s",
                        self.default_vrf_name,
                        ", ".join(sorted(repr(v) for v in folded)),
                    )

        # A '/' in a network or VRF name would split a composite key into the
        # wrong number of segments and match the wrong entry, or none. Checked
        # against the real names this run will use, not guessed at.
        name_problems = sp.validate_names(
            self.space_partition_by,
            sorted({d.get("network", "") for d in devices}),
            observed_vrfs,
        )
        if name_problems:
            return _abort("; ".join(name_problems))

        outcomes: List[DeviceSyncOutcome] = []
        pending_items: List[Dict[str, Any]] = []
        errors = 0
        stopped_early = False
        # Built up across the loop below, only used by the "Find connected
        # objects" pass after it - see _sync_nom_connections()'s docstring.
        nom_netobj_id_by_key: Dict[Tuple[str, str], str] = {}
        # Per device, raw LVI interface names _disambiguate_interface_names()
        # had to suffix - see _sync_nom_connections()'s docstring for why
        # these must not be linked through.
        nom_collided_names_by_key: Dict[Tuple[str, str], Set[str]] = {}
        outcome_by_key: Dict[Tuple[str, str], DeviceSyncOutcome] = {}
        # Detects two different LVI networks resolving to the SAME
        # destination within this one run - e.g. an external automation
        # loop (an EfficientIP rule that writes IPs back into LogicVein) can
        # duplicate a device across networks, and without this the second
        # one to sync silently overwrites the first with no signal at all
        # (find_address/find_network_object see it as an ordinary "existing
        # record", indistinguishable from one that predates this run).
        # Keyed on the actual destination (site_id/folder_id), not just the
        # IP - a deliberately overlapping-IP multi-VRF/partitioned setup
        # legitimately sends the same IP to two DIFFERENT spaces/folders,
        # and must never be flagged. See sync()'s docstring and
        # _sync_device_to_nom()'s for the full explanation.
        # Value also carries the winning device's hostname (not just its
        # device_key) so a same-run collision's pending-conflict message can
        # name which device is already applied, not just which network.
        ipam_written_this_run: Dict[Tuple[str, str], Tuple[Tuple[str, str], str]] = {}
        nom_written_this_run: Dict[Tuple[str, str], Tuple[Tuple[str, str], str]] = {}
        # Every IP/name LogicVein reported this run, per destination it
        # resolved to - independent of write outcome (a device left alone
        # by ip_conflict_policy="ignore"/"ask", or deferred to a pending
        # conflict, still genuinely exists in LogicVein and must not look
        # stale). Only used when delete_stale_ips/delete_stale_nom_devices
        # is on - see _delete_stale_addresses()/_delete_stale_nom_devices().
        synced_ips_by_site: Dict[str, Set[str]] = {}
        synced_nom_names_by_folder: Dict[str, Set[str]] = {}

        for device in devices:
            self._check_cancelled()

            ip_address = device.get("ipAddress", "")
            if not ip_address:
                continue

            device_key = (device.get("network", "Default"), ip_address)
            hostname, alt_hostname = self._resolve_display_name(device.get("hostname", ""))
            new_mac = mac_lookup.get(device_key, "")
            class_parameters = self._build_class_parameters(device)
            class_parameters.update(self._build_lifecycle_class_parameters(device))
            class_parameters[_LVI_MANAGED_KEY] = _LVI_MANAGED_VALUE

            ipam_outcome: Optional[DeviceSyncOutcome] = None
            nom_outcome: Optional[DeviceSyncOutcome] = None
            ipam_stop = False

            try:
                if self.dry_run:
                    targets = [t for t, on in (("IPAM", self.sync_to_ipam), ("NOM", self.sync_to_nom)) if on]
                    logger.info(
                        "[DRY RUN] Would sync %s (%s) to %s",
                        ip_address,
                        hostname or "no hostname",
                        "/".join(targets) or "nothing",
                    )
                    continue

                if self.sync_to_ipam:
                    # Resolved per device now, not once per run: which space an
                    # address belongs in depends on its LVI network and/or its
                    # VRF. Cached per partition key, so this is one lookup per
                    # distinct partition, not per device.
                    partition_key = self._partition_key(device_key, interfaces_by_key.get(device_key, []))
                    site_id = self._resolve_site_id(partition_key)

                    if site_id is None:
                        # This partition has nowhere to write - unmapped under
                        # ipam_unmapped_policy "skip" (create_missing_spaces
                        # off), explicitly mapped to "", or its space is
                        # missing. Recorded per device so the
                        # report shows exactly what was left out and why,
                        # rather than the run appearing to succeed.
                        label, value = sp.describe(self.space_partition_by, partition_key)
                        detail = f"no IP space resolved for {label} '{value}'"
                        logger.debug("Skipping %s: %s", ip_address, detail)
                        outcomes.append(
                            DeviceSyncOutcome(ip_address=ip_address, hostname=hostname, action="error", error=detail)
                        )
                        errors += 1
                        if not self.continue_on_error:
                            logger.error("Stopping due to error (continue_on_error=False)")
                            stopped_early = True
                            break
                        continue

                    # Seen regardless of what happens next (write, ignore,
                    # deferred conflict, or even a later error) - LogicVein
                    # genuinely reports this device at this IP in this
                    # space, so it must never look stale.
                    synced_ips_by_site.setdefault(site_id, set()).add(ip_address)

                    subnet_id = self._resolve_subnet_id(ip_address, site_id)

                    if subnet_id is None:
                        # No containing subnet (missing, or create_missing_subnets
                        # failed) - skip rather than create an address unlinked
                        # to any subnet ("Orphan Addresses" in the SOLIDserver UI).
                        logger.warning(
                            "Skipping %s: no subnet found in space '%s' (device not synced)",
                            ip_address,
                            self._space_label(site_id),
                        )
                        errors += 1
                        outcomes.append(
                            DeviceSyncOutcome(
                                ip_address=ip_address,
                                hostname=hostname,
                                action="error",
                                error=f"no subnet found in space '{self._space_label(site_id)}'",
                            )
                        )
                        if not self.continue_on_error:
                            logger.error("Stopping due to error (continue_on_error=False)")
                            stopped_early = True
                            break
                        continue

                    existing = self.target.find_address(ip_address, site_id=site_id)

                    # Same-run collision: a DIFFERENT LVI network already
                    # wrote this exact (site_id, ip) destination earlier in
                    # this very run. This is categorically different from
                    # "an address predates this run" (ip_conflict_policy's
                    # normal job below) - two LVI devices disagreeing about
                    # one destination within a single run is almost always a
                    # data problem (seen live: an EfficientIP rule that
                    # writes IPs back into LogicVein, duplicating a device
                    # across networks) - so it always defers to a pending
                    # conflict, regardless of ip_conflict_policy, even
                    # "overwrite". The first device_key to reach a
                    # destination this run is unaffected; only later ones
                    # colliding with it are deferred.
                    prior = ipam_written_this_run.get((site_id, ip_address))
                    if prior is not None and prior[0] != device_key:
                        prior_key, prior_hostname = prior
                        prior_network = prior_key[0]
                        has_data = bool(hostname or new_mac) or self._has_real_class_parameters(class_parameters)
                        detail = self._ip_duplicate_detail(
                            ip_address,
                            winner_network=prior_network,
                            winner_hostname=prior_hostname,
                            loser_network=device_key[0],
                            loser_hostname=hostname,
                            loser_has_data=has_data,
                        )
                        if not has_data:
                            # Overwrite and Ignore are the same end state -
                            # nothing to defer to a decision that isn't one.
                            logger.info("%s (%s) - %s", ip_address, hostname or "no hostname", detail)
                            outcomes.append(
                                DeviceSyncOutcome(
                                    ip_address=ip_address,
                                    hostname=hostname,
                                    action="ignored",
                                    detail=detail,
                                    mac=new_mac,
                                )
                            )
                            continue
                        logger.warning(
                            "Conflict: %s (%s) - %s, deferred for review",
                            ip_address,
                            hostname or "no hostname",
                            detail,
                        )
                        pending_items.append(
                            {
                                "ip_address": ip_address,
                                "hostname": hostname,
                                "conflict_type": "ip_duplicate_this_run",
                                "detail": detail,
                                "desired_payload": {
                                    "ip_address": ip_address,
                                    "site_id": site_id,
                                    "subnet_id": subnet_id,
                                    "hostname": hostname,
                                    "mac_address": new_mac,
                                    "class_parameters": class_parameters,
                                },
                            }
                        )
                        outcomes.append(
                            DeviceSyncOutcome(
                                ip_address=ip_address,
                                hostname=hostname,
                                action="pending",
                                detail=detail,
                                mac=new_mac,
                            )
                        )
                        continue

                    # IP-level conflict: the address already has a record.
                    if existing is not None and self.ip_conflict_policy in ("ignore", "ask"):
                        if self.ip_conflict_policy == "ignore":
                            logger.info(
                                "Ignored address: %s (%s) - IP already exists in EfficientIP",
                                ip_address,
                                hostname or "no hostname",
                            )
                            outcomes.append(
                                DeviceSyncOutcome(
                                    ip_address=ip_address,
                                    hostname=hostname,
                                    action="ignored",
                                    detail="IP already exists in EfficientIP",
                                    mac=new_mac,
                                )
                            )
                        else:  # ask
                            logger.warning(
                                "Conflict: %s (%s) - IP already exists in EfficientIP,"
                                " policy=ask, deferred for review",
                                ip_address,
                                hostname or "no hostname",
                            )
                            pending_items.append(
                                {
                                    "ip_address": ip_address,
                                    "hostname": hostname,
                                    "conflict_type": "ip_exists",
                                    "detail": "IP already exists in EfficientIP",
                                    "desired_payload": {
                                        "ip_address": ip_address,
                                        "site_id": site_id,
                                        "subnet_id": subnet_id,
                                        "hostname": hostname,
                                        "mac_address": new_mac,
                                        "class_parameters": class_parameters,
                                    },
                                }
                            )
                            outcomes.append(
                                DeviceSyncOutcome(
                                    ip_address=ip_address,
                                    hostname=hostname,
                                    action="pending",
                                    detail="IP already exists in EfficientIP - awaiting decision",
                                    mac=new_mac,
                                )
                            )
                        continue

                    # MAC handling - only when the master toggle is on and LVI
                    # has a MAC for this device.
                    mac_to_write = new_mac
                    mac_changed = False
                    mac_previous = ""
                    duplicate_of = ""
                    mac_pending_note = ""
                    if self.sync_mac_address and new_mac:
                        duplicate_of = self._detect_duplicate_mac(device_key, new_mac, site_id, mac_to_keys)

                        # A MAC shared with a *different* device/IP - distinct
                        # from mac_changed below, which is this same IP's own
                        # previous record disagreeing with LVI. Only "ask" gates
                        # on this; "overwrite"/"leave_untouched" keep writing and
                        # just carry the note through to the report (unchanged
                        # behavior - see _detect_duplicate_mac's docstring).
                        if duplicate_of and self.mac_conflict_policy == "ask":
                            logger.warning(
                                "Conflict: %s (%s) - %s, policy=ask, deferred for review",
                                ip_address,
                                hostname or "no hostname",
                                duplicate_of,
                            )
                            pending_items.append(
                                {
                                    "ip_address": ip_address,
                                    "hostname": hostname,
                                    "conflict_type": "mac_duplicate",
                                    "detail": duplicate_of,
                                    "desired_payload": {
                                        "ip_address": ip_address,
                                        "site_id": site_id,
                                        "subnet_id": subnet_id,
                                        "hostname": hostname,
                                        "mac_address": new_mac,
                                        "class_parameters": class_parameters,
                                    },
                                }
                            )
                            outcomes.append(
                                DeviceSyncOutcome(
                                    ip_address=ip_address,
                                    hostname=hostname,
                                    action="pending",
                                    detail=f"{duplicate_of} - awaiting decision",
                                    mac=new_mac,
                                )
                            )
                            continue

                        mac_previous = self._normalize_mac((existing or {}).get("mac_addr", "")) if existing else ""
                        mac_changed = bool(mac_previous and mac_previous != new_mac)
                        if mac_changed:
                            if self.mac_conflict_policy == "leave_untouched":
                                mac_to_write = ""
                            elif self.mac_conflict_policy == "ask":
                                mac_to_write = ""
                                mac_pending_note = "MAC change pending decision"
                                logger.warning(
                                    "Conflict: %s (%s) - MAC differs (EfficientIP has %s, LogicVein has %s),"
                                    " policy=ask, MAC deferred for review",
                                    ip_address,
                                    hostname or "no hostname",
                                    mac_previous,
                                    new_mac,
                                )
                                pending_items.append(
                                    {
                                        "ip_address": ip_address,
                                        "hostname": hostname,
                                        "conflict_type": "mac_differs",
                                        "detail": (
                                            f"MAC differs: EfficientIP has {mac_previous}," f" LogicVein has {new_mac}"
                                        ),
                                        "desired_payload": {
                                            "ip_address": ip_address,
                                            "site_id": site_id,
                                            "mac_address": new_mac,
                                        },
                                    }
                                )
                            # "overwrite": mac_to_write stays new_mac

                    success = self.target.create_or_update_address(
                        ip_address=ip_address,
                        site_id=site_id,
                        subnet_id=subnet_id,
                        hostname=hostname,
                        mac_address=mac_to_write,
                        class_parameters=class_parameters,
                    )
                    if success:
                        logger.info(
                            "%s address: %s (%s)",
                            "Updated" if existing is not None else "Created",
                            ip_address,
                            hostname or "no hostname",
                        )
                        ipam_written_this_run[(site_id, ip_address)] = (device_key, hostname)
                        # Self-labeled "IPAM: " the same way every NOM note
                        # already is (see _merge_outcome()'s docstring) -
                        # without this, a device synced to both targets
                        # showed only the NOM note in the merged Notes cell,
                        # since IPAM's own detail was otherwise empty on the
                        # ordinary success path.
                        ipam_note = f"IPAM: {'Updated' if existing is not None else 'Created'} address"
                        detail_parts = [ipam_note] + [p for p in (mac_pending_note,) if p]
                        ipam_outcome = DeviceSyncOutcome(
                            ip_address=ip_address,
                            hostname=hostname,
                            action="updated" if existing is not None else "added",
                            detail="; ".join(detail_parts),
                            mac=mac_to_write or new_mac,
                            mac_changed=mac_changed,
                            mac_previous=mac_previous,
                            duplicate_mac_of=duplicate_of,
                        )
                    else:
                        errors += 1
                        logger.warning("Failed to write address: %s (%s)", ip_address, hostname or "no hostname")
                        ipam_outcome = DeviceSyncOutcome(
                            ip_address=ip_address,
                            hostname=hostname,
                            action="error",
                            error="write failed",
                            mac=mac_to_write or new_mac,
                        )
                        if not self.continue_on_error:
                            ipam_stop = True

                # IPAM failing with continue_on_error off stops before NOM,
                # matching that setting's meaning for this device - but the
                # IPAM outcome itself still gets appended below before the
                # loop breaks, so the report doesn't silently drop the row.
                device_folder_id = (
                    self._resolve_nom_folder_id(self._nom_folder_key(device_key))
                    if not ipam_stop and self.sync_to_nom
                    else None
                )
                if not ipam_stop and self.sync_to_nom and device_folder_id is None:
                    # This partition has no folder. NOM problems degrade rather
                    # than fail the run - the long-standing contract, and the
                    # device may well have synced to IPAM already - so this is
                    # a note on the report row, not an error.
                    label, value = sp.describe(self.nom_folder_partition_by, self._nom_folder_key(device_key))
                    nom_outcome = DeviceSyncOutcome(
                        ip_address=ip_address,
                        hostname=hostname,
                        action="ignored",
                        detail=(
                            f"NOM: skipped - no folder for {label} '{value}'"
                            if self.nom_folder_partition_by != sp.MODE_NONE
                            else "NOM: skipped - no folder"
                        ),
                    )
                elif not ipam_stop and self.sync_to_nom and device_folder_id:
                    nom_outcome = self._sync_device_to_nom(
                        device_key,
                        hostname,
                        device,
                        class_parameters,
                        device_folder_id,
                        all_interfaces_by_key.get(device_key, []),
                        # self.sync_nom_vlans has already been forced off
                        # above (in the pre-flight gate) if it was on but
                        # the Domain/Range weren't ready, so this correctly
                        # evaluates to False rather than needing a separate
                        # vlan_domain_ready check here.
                        self.sync_nom_interfaces and self.sync_nom_vlans,
                        self.sync_nom_interfaces and self.sync_nom_vrfs,
                        nom_netobj_id_by_key,
                        alt_hostname,
                        nom_collided_names_by_key,
                        nom_written_this_run,
                        pending_items,
                        synced_nom_names_by_folder,
                    )
                    if nom_outcome.action == "error":
                        errors += 1

                # One report row per device even when both targets ran -
                # see _merge_outcome()'s docstring for why.
                if ipam_outcome is not None and nom_outcome is not None:
                    outcome_by_key[device_key] = self._merge_outcome(ipam_outcome, nom_outcome)
                elif ipam_outcome is not None:
                    outcome_by_key[device_key] = ipam_outcome
                elif nom_outcome is not None:
                    outcome_by_key[device_key] = nom_outcome
                if device_key in outcome_by_key:
                    outcomes.append(outcome_by_key[device_key])

                if ipam_stop or (
                    nom_outcome is not None and nom_outcome.action == "error" and not self.continue_on_error
                ):
                    logger.error("Stopping due to error (continue_on_error=False)")
                    stopped_early = True
                    break
            except SyncCancelled:
                raise
            except Exception as exc:
                errors += 1
                logger.error("EfficientIP sync failed on %s: %s", ip_address, exc)
                outcomes.append(
                    DeviceSyncOutcome(
                        ip_address=ip_address, hostname=hostname, action="error", error=str(exc), mac=new_mac
                    )
                )
                if not self.continue_on_error:
                    logger.error("Stopping due to error (continue_on_error=False)")
                    stopped_early = True
                    break

        if self.sync_to_nom and self.sync_nom_interfaces and self.sync_nom_connections and nom_netobj_id_by_key:
            try:
                self._sync_nom_connections(nom_netobj_id_by_key, outcome_by_key, nom_collided_names_by_key)
            except SyncCancelled:
                raise
            except Exception as exc:
                logger.error("NOM: failed to sync connected objects: %s", exc)

        if pending_items and not self.dry_run:
            try:
                record_pending_conflicts(PLUGIN_NAME, pending_items)
            except Exception as e:
                logger.warning("Could not record pending conflicts: %s", e)

        # Never runs on a stopped-early or dry-run pass - an incomplete
        # device list would make a real device look stale just because the
        # run ended before reaching it, and dry_run's own per-device
        # short-circuit above means synced_ips_by_site/synced_nom_names_by_folder
        # never got populated in the first place (matches netbox's own
        # delete_stale_* skipping entirely under dry_run, no preview mode).
        stale_ips_deleted = 0
        stale_nom_devices_deleted = 0
        if not stopped_early and not self.dry_run:
            if self.delete_stale_ips and synced_ips_by_site:
                try:
                    stale_ips_deleted = self._delete_stale_addresses(synced_ips_by_site)
                except Exception as e:
                    logger.warning("Could not complete stale IP cleanup: %s", e)
            if self.delete_stale_nom_devices and synced_nom_names_by_folder:
                try:
                    stale_nom_devices_deleted = self._delete_stale_nom_devices(synced_nom_names_by_folder)
                except Exception as e:
                    logger.warning("Could not complete stale NOM device cleanup: %s", e)

        self.last_report = SyncReport(
            plugin_name=PLUGIN_NAME,
            started_at=started_at,
            finished_at=datetime.now(timezone.utc).isoformat(),
            dry_run=self.dry_run,
            outcomes=outcomes,
            run_errors=(["Stopped early (continue_on_error=False)"] if stopped_early else []) + run_warnings,
            pending_conflicts=len(pending_items),
        )

        duplicate_conflicts = sum(
            1 for i in pending_items if i.get("conflict_type") in ("ip_duplicate_this_run", "nom_duplicate_this_run")
        )
        summary = f"EfficientIP sync complete: {len(devices)} device(s), {errors} error(s)"
        if duplicate_conflicts:
            summary += f", {duplicate_conflicts} duplicate(s) flagged"
        stale_deleted = stale_ips_deleted + stale_nom_devices_deleted
        if stale_deleted:
            summary += f", {stale_deleted} stale record(s) deleted"
        logger.info(summary)
        # Matches netbox/snow's own sync() return: continue_on_error (on by
        # default) means per-device errors were already logged and counted
        # individually rather than aborting the run, so the run itself
        # completed - the Run Sync tab's error/warning counts still show
        # what happened, but the overall badge shouldn't read "Failed" for
        # a run that finished and simply skipped some devices.
        return errors == 0 or self.continue_on_error
