"""Each account's report-table layout: hidden columns, column order, widths.

Kept in `column_prefs.json` in the plugin's data directory, keyed by
username, so a layout survives signing out (the app clears its per-session
storage then) and follows the account to any browser. An account several
people sign in as shares one layout.

File format:

    {<username>: {"<kind>.<table>": <value>}}

where kind is "hidden" or "order" (lists of column names) or "widths" (column
name -> pixels). Maintenance's cache actions do not touch this file.
"""

import json
import os
import tempfile
import threading
from pathlib import Path
from typing import Any, Dict

FILE_NAME = "column_prefs.json"

_lock = threading.Lock()


class PrefsStore:
    """Reads and writes column_prefs.json."""

    def __init__(self, path: Path) -> None:
        """
        Args:
            path: The column_prefs.json file.
        """
        self.path = path

    def _load(self) -> Dict[str, Dict[str, Any]]:
        """Every account's layout; empty when the file is missing or unreadable."""
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}
        if not isinstance(data, dict):
            return {}
        return {str(k): dict(v) for k, v in data.items() if isinstance(v, dict)}

    def get(self, username: str, key: str) -> Any:
        """One saved value for an account, or None.

        Args:
            username: The account.
            key: "<kind>.<table>".
        """
        return self._load().get(username, {}).get(key)

    def set(self, username: str, key: str, value: Any) -> None:
        """Save one value for an account.

        Args:
            username: The account.
            key: "<kind>.<table>".
            value: The value (JSON-serialisable).
        """
        with _lock:
            data = self._load()
            data.setdefault(username, {})[key] = value
            self._save(data)

    def _save(self, data: Dict[str, Dict[str, Any]]) -> None:
        """Write the file atomically: a temporary file, then a rename."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=self.path.parent, prefix=".column_prefs-", suffix=".json")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(data, handle, indent=2, sort_keys=True)
            os.replace(tmp, self.path)
        except BaseException:
            Path(tmp).unlink(missing_ok=True)
            raise
