"""Plugin-local access to the ServiceNow sync configuration and client."""

from pathlib import Path
from typing import Any, Dict

# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import get_config  # pyright: ignore[reportMissingImports]

_CONFIG_FILE = Path("conf/snow_sync_config.yaml")
_DEFAULTS_FILE = Path(__file__).parent / "conf" / "defaults.yaml"


def get_snow_settings() -> Dict[str, Any]:
    """Return the full ServiceNow sync config (created from defaults on first use)."""
    return get_config(_CONFIG_FILE, _DEFAULTS_FILE)


def get_change_detection_settings() -> Dict[str, Any]:
    """Change-detection settings: app-level config plus snow-specific incident fields.

    The plugin-neutral keys (mode, poll_interval_minutes, networks,
    max_seen_events, scheme) live in conf/app.yaml under change_detection;
    enabled comes from the app's features.change_detection switch; only
    snow_incident remains in the plugin's own config.
    """
    from src.plugin_api import get_app_settings

    app_settings = get_app_settings()
    cfg: Dict[str, Any] = dict(app_settings.get("change_detection", {}) or {})
    cfg["enabled"] = bool(app_settings.get("features", {}).get("change_detection", True))
    cfg["snow_incident"] = get_snow_settings().get("lvi_config_change_poller", {}).get("snow_incident", {})
    return cfg


def get_snow_client() -> Any:
    """Return a ServiceNowClient built from environment variables."""
    from .client import ServiceNowClient

    return ServiceNowClient()
