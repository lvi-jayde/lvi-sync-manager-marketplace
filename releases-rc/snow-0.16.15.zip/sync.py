"""LogicVein to ServiceNow CMDB inventory sync."""

import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

# logicvein (the vendored LVI API client) lives in the sibling lvi_sync_manager repo too.
from logicvein import LogicVeinAPIClient  # pyright: ignore[reportMissingImports]

# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import (  # pyright: ignore[reportMissingImports]
    CancellableSync,
    CancellationToken,
    DeviceSyncOutcome,
    SyncCancelled,
    SyncReport,
    build_mac_lookup,
    mac_for,
    normalize_networks,
    pending_conflict_item,
    prefetch_device_interfaces,
    record_pending_conflicts,
    resolve_display_name,
    resolve_prefetch_networks,
)

from .client import ServiceNowClient

logger = logging.getLogger(__name__)

PLUGIN_NAME = "snow"

# Default LVI device-type → SNOW CMDB table mapping
_DEFAULT_CI_TABLE_MAP: Dict[str, str] = {
    "Router": "cmdb_ci_ip_router",
    "Switch": "cmdb_ci_ip_switch",
    "Firewall": "cmdb_ci_ip_firewall",
    "Load Balancer": "cmdb_ci_netgear",
    "Wireless Controller": "cmdb_ci_wireless_lan_controller",
    "Server": "cmdb_ci_server",
    "Power Supply": "cmdb_ci_power_supply",
}

# Default LVI field → SNOW CI field mapping
_DEFAULT_FIELD_MAPPING: Dict[str, str] = {
    "hostname": "name",
    "ipAddress": "ip_address",
    "hardwareVendor": "manufacturer",
    "model": "model_id",
    "serialNumber": "serial_number",
    "osType": "os",
    "osVersion": "os_version",
    "macAddress": "mac_address",
    "deviceType": "subcategory",
    "sysLocation": "location",
    "sysDescr": "short_description",
    "memoSummary": "comments",
}

# Default LVI interface field → SNOW cmdb_ci_network_adapter field mapping
_DEFAULT_INTERFACE_FIELD_MAPPING: Dict[str, str] = {
    "name": "name",
    "macAddress": "mac_address",
    "description": "short_description",
}


class LogicVeinSnowSync(CancellableSync):
    """Sync LogicVein device inventory into ServiceNow CMDB Configuration Items."""

    def __init__(
        self,
        lvi_client: LogicVeinAPIClient,
        snow_client: ServiceNowClient,
        config: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialise the sync engine.

        Args:
            lvi_client: Authenticated LogicVein API client.
            snow_client: Authenticated ServiceNow client.
            config: Sync configuration dict produced by ServiceNowPlugin.build_sync_config().
        """
        self.lvi_client = lvi_client
        self.snow_client = snow_client
        self.config = config or {}

        self.dry_run: bool = self.config.get("dry_run", False)
        self.networks: list = normalize_networks(self.config.get("network", "Default"))
        self.continue_on_error: bool = self.config.get("continue_on_error", True)

        cmdb = self.config.get("cmdb", {})
        self.ci_table_map: Dict[str, str] = cmdb.get("ci_table_map", _DEFAULT_CI_TABLE_MAP)
        self.default_ci_table: str = cmdb.get("default_ci_table", "cmdb_ci_netgear")
        self.create_missing_cis: bool = cmdb.get("create_missing_cis", True)
        self.update_existing_cis: bool = cmdb.get("update_existing_cis", True)
        # Gates _resolve_location()/_resolve_company()/_resolve_model()'s
        # auto-create of the CI-adjacent reference records those fields
        # point to (cmn_location, core_company, cmdb_model) - previously
        # always created with no toggle, matching NetBox's
        # create_missing_resources. Off leaves a field unresolved (empty)
        # rather than failing the whole CI write, same as any other
        # unresolved optional field.
        self.create_missing_reference_records: bool = cmdb.get("create_missing_reference_records", True)
        _fm = cmdb.get("field_mapping")
        self.field_mapping: Dict[str, str] = _fm if _fm is not None else _DEFAULT_FIELD_MAPPING
        self.custom_field_mapping: Dict[str, str] = cmdb.get("custom_field_mapping", {})
        # A dedicated gate (matching EfficientIP/NetBox's sync_mac_address),
        # not just "remove macAddress from field_mapping" - discoverable as
        # a real settings toggle rather than an edit-the-YAML idiom. Off
        # skips the bulk interface prefetch entirely (no wasted LVI call),
        # same as EfficientIP's equivalent.
        self.sync_mac_address: bool = bool(cmdb.get("sync_mac_address", True))
        # Truncate an FQDN-looking LVI hostname to its short name before
        # writing it as the CI's "name" field (e.g. "asa5505.home.arpa" ->
        # "asa5505"). The CI's primary lookup key is a stable correlation_id
        # (LVI device_id/IP, not the name), so this plugin is never at
        # duplicate risk from the name changing - except the legacy
        # by-name fallback lookup for CIs that pre-date correlation_id,
        # which _resolve_display_name()'s alt_name also covers.
        self.strip_domain_from_names: bool = bool(cmdb.get("strip_domain_from_names", True))
        # What to do when the IP LogicVein reports is already assigned to a
        # *different* CI (checked whenever it's not "overwrite", regardless
        # of whether this device's own CI already exists): "overwrite"
        # (default, proceed with the write as today), "ignore" (skip this
        # device's whole CI write this run), "ask" (defer for review in the
        # Resolve Conflicts screen).
        self.ip_conflict_policy: str = cmdb.get("ip_conflict_policy", "overwrite")
        # What to do when this device's own existing CI has a different MAC
        # than LogicVein reports, or the incoming MAC is already set on a
        # *different* CI: "overwrite" (default), "leave_untouched" (skip the
        # MAC field only, every other CI field still syncs), "ask" (defer
        # for review). Only consulted when sync_mac_address is on, and only
        # when this device's own CI already exists (a brand new CI has no
        # prior state to conflict with).
        self.mac_conflict_policy: str = cmdb.get("mac_conflict_policy", "overwrite")

        interfaces_cfg = self.config.get("interfaces", {})
        self.sync_interfaces: bool = interfaces_cfg.get("sync_interfaces", False)
        self.delete_stale_interfaces: bool = interfaces_cfg.get("delete_stale_interfaces", False)
        _ifm = interfaces_cfg.get("field_mapping")
        self.interface_field_mapping: Dict[str, str] = _ifm if _ifm is not None else _DEFAULT_INTERFACE_FIELD_MAPPING

        # Caches for reference field lookups (avoids repeated SNOW API calls)
        self._location_cache: Dict[str, str] = {}
        self._company_cache: Dict[str, str] = {}
        self._model_cache: Dict[str, str] = {}

        # Per-device outcomes for this run's SyncReport (see sync())
        self._outcomes: List[DeviceSyncOutcome] = []

        # Conflicts deferred this run under an "ask" policy - recorded once
        # at the end of sync() via record_pending_conflicts().
        self._pending_items: List[Dict[str, Any]] = []

        # (network, management IP) -> MAC map, populated once
        # per sync (see that method for why this is needed at all).
        self._mac_lookup: Dict[Tuple[str, str], str] = {}

        self._cancel_token: Optional[CancellationToken] = None

    def _resolve_display_name(self, raw_name: str) -> Tuple[str, str]:
        """Return (display_name, alt_name) for one LVI-reported hostname,
        per strip_domain_from_names - see plugin_api.resolve_display_name()'s
        docstring for the full FQDN-truncation/alt_name contract.

        The CI's primary lookup key is a stable correlation_id, so *alt_name*
        only matters for the legacy by-name fallback (_sync_device()) that
        catches CIs pre-dating correlation_id.
        """
        return resolve_display_name(raw_name, self.strip_domain_from_names)

    # ------------------------------------------------------------------ #
    # Public entry point                                                   #
    # ------------------------------------------------------------------ #

    def sync(self) -> bool:
        """Execute the inventory sync.

        Returns:
            True if the sync completed without errors, False otherwise.
        """
        logger.info("=" * 70)
        logger.info("LogicVein → ServiceNow CMDB Inventory Sync")
        logger.info("=" * 70)
        if self.dry_run:
            logger.info("DRY RUN - no changes will be written to ServiceNow")

        started_at = datetime.now(timezone.utc).isoformat()

        def _finish(success: bool, run_errors: Optional[List[str]] = None) -> bool:
            if self._pending_items and not self.dry_run:
                try:
                    record_pending_conflicts(PLUGIN_NAME, self._pending_items)
                except Exception as e:
                    logger.warning("Could not record pending conflicts: %s", e)

            self.last_report = SyncReport(
                plugin_name=PLUGIN_NAME,
                started_at=started_at,
                finished_at=datetime.now(timezone.utc).isoformat(),
                dry_run=self.dry_run,
                outcomes=self._outcomes,
                run_errors=run_errors or [],
            )
            return success

        try:
            self._check_cancelled()
            if not self.snow_client.test_connection():
                logger.error("ServiceNow connection test failed")
                return _finish(False, ["ServiceNow connection test failed"])
            logger.info("ServiceNow connection verified")
        except SyncCancelled:
            logger.warning("Sync cancelled before connecting")
            return _finish(False, ["Sync cancelled before connecting"])
        except Exception as e:
            logger.error("ServiceNow connection error: %s", e)
            return _finish(False, [f"ServiceNow connection error: {e}"])

        try:
            self._check_cancelled()
            return _finish(self._sync_cmdb())
        except SyncCancelled:
            logger.warning("Sync cancelled")
            return _finish(False, ["Sync cancelled"])

    # ------------------------------------------------------------------ #
    # CMDB sync                                                            #
    # ------------------------------------------------------------------ #

    def _sync_cmdb(self) -> bool:
        """Sync LVI devices to SNOW CMDB Configuration Items.

        Returns:
            True if all devices were processed without fatal errors.
        """
        logger.info("-" * 70)
        logger.info("CMDB Sync: LVI Devices → SNOW Configuration Items")
        logger.info("-" * 70)

        # Iterate per-network so each device's source network is known.
        # This allows us to write u_lvi_network on the CI during sync.
        # When self.networks is empty we do a single pass with network=[] (all networks).
        network_batches: list = self.networks if self.networks else [""]

        # Devices are fetched per network batch below, so the MAC map is
        # built up batch by batch rather than in one pass. Each batch is
        # either a single named network or (when self.networks is empty)
        # the every-network pass, whose real network names can only come
        # from the devices it returns - see resolve_prefetch_networks().
        self._mac_lookup = {}

        synced = 0
        errors = 0

        for network in network_batches:
            network_arg = [network] if network else []
            net_label = f"LVI network '{network}'" if network else "all LVI networks"
            try:
                devices = self.lvi_client.search_devices_in_network(network=network_arg)
            except Exception as e:
                logger.error("Failed to retrieve devices from %s: %s", net_label, e)
                if not self.continue_on_error:
                    return False
                errors += 1
                continue

            if not devices:
                logger.warning("No devices found in %s", net_label)
                continue

            logger.info("Found %s devices in %s (sync_interfaces=%s)", len(devices), net_label, self.sync_interfaces)

            if self.sync_mac_address:
                self._mac_lookup.update(
                    build_mac_lookup(
                        prefetch_device_interfaces(self.lvi_client, resolve_prefetch_networks(network_arg, devices))
                    )
                )

            for device in devices:
                outcomes_before = len(self._outcomes)
                try:
                    self._check_cancelled()
                    ci_sys_id = self._sync_device(device, network=network)
                    if self.sync_interfaces and ci_sys_id:
                        self._sync_device_interfaces(device, ci_sys_id)
                    synced += 1
                except SyncCancelled:
                    raise
                except Exception as e:
                    ip = device.get("ipAddress", "unknown")
                    logger.error("Error syncing device %s: %s", ip, e)
                    errors += 1
                    # _sync_device() already appends its own outcome on success -
                    # only add one here if the exception happened before that
                    # (or in a later step like interface sync).
                    if len(self._outcomes) == outcomes_before:
                        self._outcomes.append(
                            DeviceSyncOutcome(
                                ip_address=ip,
                                hostname=device.get("hostname", ""),
                                action="error",
                                error=str(e),
                                mac=mac_for(self._mac_lookup, device),
                            )
                        )
                    if not self.continue_on_error:
                        return False

        logger.info("CMDB sync complete - %s processed, %s errors", synced, errors)
        return errors == 0 or self.continue_on_error

    def _sync_device(self, device: Dict[str, Any], network: str = "") -> Optional[str]:
        """Create or update a single SNOW CI from an LVI device record.

        Args:
            device: LVI device dict from search_devices_in_network().
            network: LVI network name the device belongs to.

        Returns:
            The sys_id of the created or existing CI, or None if skipped/dry-run.
        """
        device_type = device.get("deviceType", "")
        ci_table = self.ci_table_map.get(device_type, self.default_ci_table)
        raw_hostname = device.get("hostname", "")
        if raw_hostname:
            hostname, alt_hostname = self._resolve_display_name(raw_hostname)
        else:
            hostname, alt_hostname = device.get("ipAddress", "unknown"), ""
        ip_address = device.get("ipAddress", "")
        # LVI's device search never returns a MAC directly (confirmed against
        # a live instance) - it comes from the separate bulk interface fetch
        # prefetched by plugin_api.prefetch_device_interfaces().
        mac_address = mac_for(self._mac_lookup, device)

        # _build_ci_data() maps "hostname" generically via device.get() - a
        # copy with the (possibly stripped) display name substituted keeps
        # that method untouched rather than special-casing hostname there
        # the way macAddress already is.
        device_for_mapping = device
        if raw_hostname and hostname != raw_hostname:
            device_for_mapping = dict(device)
            device_for_mapping["hostname"] = hostname
        ci_data = self._build_ci_data(device_for_mapping, network=network)

        # Use stable correlation_id so we can idempotently find the record again
        device_id = device.get("id") or device.get("ipAddress", "")
        correlation_id = f"LVI:device:{device_id}"
        ci_data["correlation_id"] = correlation_id

        existing = self.snow_client.get_ci_by_correlation_id(correlation_id, table=ci_table)
        if not existing:
            # Fall back to name lookup for devices that pre-existed without
            # a correlation_id - alt_hostname (the name under the *other*
            # strip_domain_from_names setting) catches one of these still
            # under its old-style name, so toggling never creates a
            # duplicate for it.
            existing = self.snow_client.get_ci_by_name(hostname, table=ci_table)
            if not existing and alt_hostname:
                existing = self.snow_client.get_ci_by_name(alt_hostname, table=ci_table)
        if not existing:
            # Search base cmdb_ci table to catch CIs that live under a different class
            existing = self.snow_client.get_ci_by_correlation_id(correlation_id, table="cmdb_ci")
            if not existing:
                existing = self.snow_client.get_ci_by_name(hostname, table="cmdb_ci")
            if not existing and alt_hostname:
                existing = self.snow_client.get_ci_by_name(alt_hostname, table="cmdb_ci")

        exclude_sys_id = existing.get("sys_id", "") if existing else ""

        # IP conflict: the IP LogicVein reports is already assigned to a
        # *different* CI (regardless of whether this device's own CI
        # exists yet) - gates the entire CI write, same as EfficientIP's
        # ip_exists (unlike the MAC checks below, which only ever hold back
        # the MAC field).
        if ip_address and self.ip_conflict_policy != "overwrite":
            conflicting = self.snow_client.get_ci_by_ip_address(ip_address, ci_table, exclude_sys_id=exclude_sys_id)
            if conflicting:
                detail = f"IP {ip_address} already assigned to a different CI"
                if self.dry_run:
                    logger.info("[DRY RUN] Would defer %s (%s) - %s", hostname, ci_table, detail)
                elif self.ip_conflict_policy == "ignore":
                    logger.info("Ignored %s (%s) - %s", hostname, ci_table, detail)
                    self._outcomes.append(
                        DeviceSyncOutcome(
                            ip_address=ip_address, hostname=hostname, action="ignored", detail=detail, mac=mac_address
                        )
                    )
                    return existing["sys_id"] if existing else None
                else:  # ask
                    logger.warning(
                        "Conflict: %s (%s) - %s, policy=ask, deferred for review", hostname, ci_table, detail
                    )
                    self._pending_items.append(
                        pending_conflict_item(
                            ip_address,
                            hostname,
                            "ip_exists",
                            detail,
                            {
                                "table": ci_table,
                                "sys_id": existing["sys_id"] if existing else None,
                                "ci_data": ci_data,
                            },
                        )
                    )
                    self._outcomes.append(
                        DeviceSyncOutcome(
                            ip_address=ip_address,
                            hostname=hostname,
                            action="pending",
                            detail=f"{detail} - awaiting decision",
                            mac=mac_address,
                        )
                    )
                    return existing["sys_id"] if existing else None

        # MAC handling, subject to mac_conflict_policy - only meaningful
        # when this device's own CI already exists (a brand new CI has no
        # prior MAC to differ from, and deferring just its MAC field would
        # need a sys_id that doesn't exist yet). "mac_differs": this CI's
        # own MAC disagrees with LogicVein's. "mac_duplicate": the incoming
        # MAC is already set on a *different* CI. Both only ever hold back
        # the MAC field - every other CI field still syncs.
        mac_field_name = self.field_mapping.get("macAddress", "mac_address")
        mac_changed = False
        mac_previous = ""
        mac_pending_note = ""
        if mac_address and existing:
            existing_mac = existing.get(mac_field_name)
            mac_previous = existing_mac if isinstance(existing_mac, str) else ""
            mac_changed = bool(mac_previous and mac_previous.lower() != mac_address.lower())

            duplicate_of = ""
            if self.mac_conflict_policy != "overwrite":
                dup = self.snow_client.get_ci_by_mac_address(mac_address, ci_table, exclude_sys_id=exclude_sys_id)
                if dup:
                    duplicate_of = f"MAC {mac_address} already assigned to a different CI"

            if duplicate_of and self.mac_conflict_policy == "ask":
                ci_data.pop(mac_field_name, None)
                mac_pending_note = f"{duplicate_of} - awaiting decision"
                logger.warning(
                    "Conflict: %s (%s) - %s, policy=ask, deferred for review", hostname, ci_table, duplicate_of
                )
                self._pending_items.append(
                    pending_conflict_item(
                        ip_address,
                        hostname,
                        "mac_duplicate",
                        duplicate_of,
                        {
                            "table": ci_table,
                            "sys_id": existing["sys_id"],
                            "mac_field": mac_field_name,
                            "mac_address": mac_address,
                        },
                    )
                )
            elif mac_changed:
                if self.mac_conflict_policy == "leave_untouched":
                    ci_data.pop(mac_field_name, None)
                elif self.mac_conflict_policy == "ask":
                    ci_data.pop(mac_field_name, None)
                    mac_pending_note = "MAC change pending decision"
                    detail = f"MAC differs: SNOW has {mac_previous}, LogicVein has {mac_address}"
                    logger.warning(
                        "Conflict: %s (%s) - %s, policy=ask, deferred for review", hostname, ci_table, detail
                    )
                    self._pending_items.append(
                        pending_conflict_item(
                            ip_address,
                            hostname,
                            "mac_differs",
                            detail,
                            {
                                "table": ci_table,
                                "sys_id": existing["sys_id"],
                                "mac_field": mac_field_name,
                                "mac_address": mac_address,
                            },
                        )
                    )
                # "overwrite": ci_data keeps its already-mapped mac field

        if existing:
            if self.update_existing_cis:
                class_raw = existing.get("sys_class_name", ci_table)
                existing_class = class_raw if isinstance(class_raw, str) else class_raw.get("value", ci_table)
                if existing_class != ci_table:
                    # CI is under a different CMDB class - reclassify it
                    reclassify_data = dict(ci_data)
                    reclassify_data["sys_class_name"] = ci_table
                    if self.dry_run:
                        logger.info("[DRY RUN] Would reclassify CI: %s (%s → %s)", hostname, existing_class, ci_table)
                    else:
                        self.snow_client.update_ci(existing_class, existing["sys_id"], reclassify_data)
                        logger.info("Reclassified CI: %s (%s → %s)", hostname, existing_class, ci_table)
                else:
                    if self.dry_run:
                        logger.info("[DRY RUN] Would update CI: %s (%s)", hostname, ci_table)
                    else:
                        self.snow_client.update_ci(ci_table, existing["sys_id"], ci_data)
                        logger.info("Updated CI: %s (%s)", hostname, ci_table)
                self._outcomes.append(
                    DeviceSyncOutcome(
                        ip_address=ip_address,
                        hostname=hostname,
                        action="updated",
                        detail=mac_pending_note,
                        mac=mac_address,
                        mac_changed=mac_changed,
                        mac_previous=mac_previous,
                    )
                )
            else:
                logger.debug("Skipping existing CI (update disabled): %s", hostname)
                self._outcomes.append(
                    DeviceSyncOutcome(
                        ip_address=ip_address,
                        hostname=hostname,
                        action="ignored",
                        detail="update disabled",
                        mac=mac_address,
                    )
                )
            return existing["sys_id"]
        elif self.create_missing_cis:
            if self.dry_run:
                logger.info("[DRY RUN] Would create CI: %s (%s)", hostname, ci_table)
                self._outcomes.append(
                    DeviceSyncOutcome(
                        ip_address=ip_address,
                        hostname=hostname,
                        action="added",
                        detail="[DRY RUN]",
                        mac=mac_address,
                    )
                )
                return None
            else:
                result = self.snow_client.create_ci(ci_table, ci_data)
                logger.info("Created CI: %s (%s)", hostname, ci_table)
                self._outcomes.append(
                    DeviceSyncOutcome(ip_address=ip_address, hostname=hostname, action="added", mac=mac_address)
                )
                return result.get("sys_id")
        else:
            logger.debug("Skipping missing CI (create disabled): %s", hostname)
            self._outcomes.append(
                DeviceSyncOutcome(
                    ip_address=ip_address,
                    hostname=hostname,
                    action="ignored",
                    detail="create disabled",
                    mac=mac_address,
                )
            )
            return None

    # ------------------------------------------------------------------ #
    # Interface sync                                                       #
    # ------------------------------------------------------------------ #

    def _sync_device_interfaces(self, device: Dict[str, Any], ci_sys_id: str) -> None:
        """Sync all interfaces for one LVI device to SNOW cmdb_ci_network_adapter.

        Args:
            device: LVI device dict.
            ci_sys_id: sys_id of the parent SNOW CI.
        """
        ip_address = device.get("ipAddress", "")
        device_network = device.get("network") or (self.networks[0] if self.networks else "Default")
        try:
            interfaces = self.lvi_client.get_device_interfaces(ip_address, device_network)
        except Exception as e:
            logger.warning("Failed to fetch interfaces for %s: %s", ip_address, e)
            return

        if not interfaces:
            logger.debug("No interfaces returned from LVI for %s", ip_address)
            return

        logger.info("Syncing %d interfaces for %s", len(interfaces), ip_address)
        lvi_names: set = set()
        synced = 0
        for iface in interfaces:
            try:
                self._sync_interface(iface, ci_sys_id, ip_address)
                name = iface.get("name")
                if name:
                    lvi_names.add(name)
                    synced += 1
            except Exception as e:
                iface_name = iface.get("name", "unknown")
                logger.warning("Failed to sync interface %s on %s: %s", iface_name, ip_address, e)
        logger.info("Interface sync complete for %s: %d/%d synced", ip_address, synced, len(interfaces))

        if self.delete_stale_interfaces:
            try:
                existing = self.snow_client.get_network_adapters_for_ci(ci_sys_id)
                for adapter in existing:
                    if adapter.get("name") not in lvi_names:
                        if self.dry_run:
                            logger.info(
                                "[DRY RUN] Would delete stale interface: %s %s", ip_address, adapter.get("name")
                            )
                        else:
                            self.snow_client.delete_record("cmdb_ci_network_adapter", adapter["sys_id"])
                            logger.info("Deleted stale interface: %s %s", ip_address, adapter.get("name"))
            except Exception as e:
                logger.warning("Failed to delete stale interfaces for %s: %s", ip_address, e)

    def _sync_interface(self, iface: Dict[str, Any], ci_sys_id: str, device_ip: str) -> None:
        """Create or update a single SNOW network adapter from an LVI interface.

        Args:
            iface: LVI interface dict from get_device_interfaces().
            ci_sys_id: sys_id of the parent SNOW CI.
            device_ip: Device IP (for log messages).
        """
        iface_name = iface.get("name", "")
        if not iface_name:
            return

        iface_data = self._build_interface_data(iface)
        iface_data["cmdb_ci"] = ci_sys_id

        existing = self.snow_client.get_network_adapter(ci_sys_id, iface_name)
        if existing:
            if self.dry_run:
                logger.info("[DRY RUN] Would update interface: %s %s", device_ip, iface_name)
            else:
                self.snow_client.update_record("cmdb_ci_network_adapter", existing["sys_id"], iface_data)
                logger.info("Updated interface: %s %s", device_ip, iface_name)
        else:
            if self.dry_run:
                logger.info("[DRY RUN] Would create interface: %s %s", device_ip, iface_name)
            else:
                self.snow_client.create_record("cmdb_ci_network_adapter", iface_data)
                logger.info("Created interface: %s %s", device_ip, iface_name)

    # ------------------------------------------------------------------ #
    # Field mapping                                                        #
    # ------------------------------------------------------------------ #

    def _build_ci_data(self, device: Dict[str, Any], network: str = "") -> Dict[str, Any]:
        """Map an LVI device record to a SNOW CI field dict.

        Args:
            device: LVI device dict.
            network: LVI network name the device belongs to.  When non-empty,
                written to ``u_lvi_network`` so SNOW Change BRs can pass the
                correct network back to the Sync Manager webhook.

        Returns:
            Dict of SNOW CI field values ready for create/update.
        """
        ci_data: Dict[str, Any] = {}

        for lvi_field, snow_field in self.field_mapping.items():
            value: Any
            if lvi_field == "macAddress":
                # LVI's device search never returns a MAC directly (confirmed
                # against a live instance) - it comes from the separate bulk
                # interface fetch prefetched by
                # plugin_api.prefetch_device_interfaces().
                value = mac_for(self._mac_lookup, device)
            else:
                value = device.get(lvi_field)
            if not value:
                continue
            if snow_field == "manufacturer":
                resolved = self._resolve_company(str(value))
                if resolved:
                    ci_data[snow_field] = resolved
            elif snow_field == "model_id":
                resolved = self._resolve_model(str(value))
                if resolved:
                    ci_data[snow_field] = resolved
            elif snow_field == "location":
                resolved = self._resolve_location(str(value))
                if resolved:
                    ci_data[snow_field] = resolved
            elif snow_field == "short_description":
                ci_data[snow_field] = str(value)[:160]
            else:
                ci_data[snow_field] = value

        # sysLocation → location fallback if not already resolved via field_mapping.
        # Only apply when sysLocation is present in the user's field mapping - if they
        # removed it we must not silently re-introduce it.
        if "location" not in ci_data and "sysLocation" in self.field_mapping:
            sys_location = device.get("sysLocation", "")
            if sys_location:
                resolved = self._resolve_location(sys_location)
                if resolved:
                    ci_data["location"] = resolved

        # Ensure name is always set - fall back to IP address if hostname is absent
        if "name" not in ci_data:
            ip = device.get("ipAddress")
            if ip:
                ci_data["name"] = ip

        # LVI custom fields (custom1-custom5) mapped to SNOW fields
        for lvi_custom, snow_field in self.custom_field_mapping.items():
            if snow_field:
                value = device.get(lvi_custom)
                if value:
                    ci_data[snow_field] = value

        # Write the LVI network name so SNOW Change BRs can include it in the
        # webhook payload, allowing the Sync Manager to route the job correctly
        # without needing to probe multiple networks at runtime.
        if network:
            ci_data["u_lvi_network"] = network

        return ci_data

    def _build_interface_data(self, iface: Dict[str, Any]) -> Dict[str, Any]:
        """Map an LVI interface record to a SNOW cmdb_ci_network_adapter field dict.

        Args:
            iface: LVI interface dict from get_device_interfaces().

        Returns:
            Dict of SNOW field values (without cmdb_ci, which is added by the caller).
        """
        data: Dict[str, Any] = {}
        for lvi_field, snow_field in self.interface_field_mapping.items():
            value = iface.get(lvi_field)
            if value:
                data[snow_field] = value

        # ipAddresses is an array - take the first address for ip_address
        if "ip_address" not in data:
            ip_list = iface.get("ipAddresses") or []
            if ip_list and isinstance(ip_list, list):
                first_ip = ip_list[0].get("ipAddress") if isinstance(ip_list[0], dict) else str(ip_list[0])
                if first_ip:
                    data["ip_address"] = first_ip

        return data

    # ------------------------------------------------------------------ #
    # Reference resolution (cached)                                        #
    # ------------------------------------------------------------------ #

    def _resolve_location(self, name: str) -> str:
        """Resolve a location name to its SNOW sys_id, creating if absent
        and create_missing_reference_records is on.

        Args:
            name: Location name string.

        Returns:
            sys_id string, or "" if not found (or on error).
        """
        if name not in self._location_cache:
            try:
                record = self.snow_client.get_location_by_name(name)
                if not record and self.create_missing_reference_records:
                    record = self.snow_client.create_record("cmn_location", {"name": name})
                    logger.info("Created SNOW location: %s", name)
                self._location_cache[name] = record.get("sys_id", "") if record else ""
            except Exception as e:
                logger.warning("Failed to resolve/create location '%s': %s", name, e)
                self._location_cache[name] = ""
        return self._location_cache[name]

    def _resolve_company(self, name: str) -> str:
        """Resolve a company/manufacturer name to its SNOW sys_id, creating
        if absent and create_missing_reference_records is on.

        Args:
            name: Company name string.

        Returns:
            sys_id string, or "" if not found (or on error).
        """
        if name not in self._company_cache:
            try:
                record = self.snow_client.get_company_by_name(name)
                if not record and self.create_missing_reference_records:
                    record = self.snow_client.create_record("core_company", {"name": name})
                    logger.info("Created SNOW company: %s", name)
                self._company_cache[name] = record.get("sys_id", "") if record else ""
            except Exception as e:
                logger.warning("Failed to resolve/create company '%s': %s", name, e)
                self._company_cache[name] = ""
        return self._company_cache[name]

    def _resolve_model(self, name: str) -> str:
        """Resolve a model name to its SNOW cmdb_model sys_id, creating if
        absent and create_missing_reference_records is on.

        Args:
            name: Model name string.

        Returns:
            sys_id string, or "" if not found (or on error).
        """
        if name not in self._model_cache:
            try:
                record = self.snow_client.get_model_by_name(name)
                if not record and self.create_missing_reference_records:
                    record = self.snow_client.create_record("cmdb_model", {"name": name})
                    logger.info("Created SNOW model: %s", name)
                self._model_cache[name] = record.get("sys_id", "") if record else ""
            except Exception as e:
                logger.warning("Failed to resolve/create model '%s': %s", name, e)
                self._model_cache[name] = ""
        return self._model_cache[name]
