"""Background services contributed by the ServiceNow plugin.

The ServiceNow plugin is a *subscriber*: it registers handlers and does not start
a config-change detection backend. The detection backend (the universal emitter)
is owned by the core - one instance for the whole process - so several plugins
receive the same ConfigChangeEvent stream without each starting their own. This
plugin's tabs read the core backend's live status through the accessors below.
"""

from typing import Any, List, Optional


def build_services() -> List[Any]:
    """Register the ServiceNow handlers (no backend - the core owns the emitter).

    Reentrant: the host calls it again when settings change. Registrations are
    idempotent by identity; the websocket-only job-completion handler is dropped
    first so a poll<->websocket switch leaves none stale. Returns no services -
    the config-change detection backend is core-owned (see
    ``src/change_detection/services.py``); this plugin only subscribes.
    """
    # src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
    from src.plugin_api import get_app_settings  # pyright: ignore[reportMissingImports]

    from .settings import get_change_detection_settings

    _unregister_event_handlers()

    # LVI alert handler (capability "alerts"); the core /webhook/lvi-alert route
    # fans events out to it. Independent of config-change detection below.
    if get_app_settings().get("features", {}).get("alerts", True):
        # src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
        from src.plugin_api import register_alert_handler  # pyright: ignore[reportMissingImports]

        from .webhook.alert_incident import get_alert_handler

        register_alert_handler(get_alert_handler())

    cfg = get_change_detection_settings()
    if not cfg.get("enabled", False):
        return []

    # Subscribe to the core-owned config-change emitter: our incident creator
    # consumes each ConfigChangeEvent (in either detection mode).
    # src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
    from src.plugin_api import register_change_handler  # pyright: ignore[reportMissingImports]

    from .change_detection.incident import get_incident_creator

    register_change_handler(get_incident_creator())

    # The change runner posts LVI job completion back to the SNOW change via the
    # event bus, so register that event handler when the bus is active (websocket
    # mode). The watcher itself is started by the core.
    if cfg.get("mode", "websocket") == "websocket":
        # src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
        from src.plugin_api import register_event_handler  # pyright: ignore[reportMissingImports]

        from .event_bus.handler import get_handler as get_job_completion_handler

        register_event_handler(get_job_completion_handler())

    return []


def services_match_config() -> bool:
    """Whether the running detection backend matches the saved configuration.

    Delegates to the host: ``False`` means a setting that selects which service
    runs was changed since the services were built, so the Config Change tab
    shows a "restart to apply" banner.
    """
    # src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
    from src.plugin_api import service_config_matches  # pyright: ignore[reportMissingImports]

    return service_config_matches()


def active_watcher() -> Optional[Any]:
    """Return the running (core-owned) event-bus watcher, if websocket mode is active."""
    # src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
    from src.plugin_api import running_core_service  # pyright: ignore[reportMissingImports]

    return running_core_service("EventBusWatcher")


def active_poller() -> Optional[Any]:
    """Return the running (core-owned) config-change poller, if poll mode is active."""
    # src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
    from src.plugin_api import running_core_service  # pyright: ignore[reportMissingImports]

    return running_core_service("ConfigChangePoller")


def _unregister_event_handlers() -> None:
    """Drop this plugin's websocket-only event handler (idempotent; any mode).

    Only the job-completion handler is ours; the core websocket change detector
    is owned and managed by the core, not unregistered here.
    """
    try:
        # src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
        from src.plugin_api import unregister_event_handler  # pyright: ignore[reportMissingImports]

        from .event_bus.handler import get_handler as get_job_completion_handler

        unregister_event_handler(get_job_completion_handler())
    except Exception:
        pass  # best-effort cleanup; never block a rebuild
