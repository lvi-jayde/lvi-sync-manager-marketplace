"""Create a Jira issue for each detected LogicVein configuration change.

Registered with the core change dispatch (``register_change_handler``). Core
config-change detection (the REST poller or the websocket detector) emits a
:class:`ConfigChangeEvent` per unseen change; this handler opens a Jira issue
describing it. Like the alert handler it correlates Jira-side with a label
(``lvi-chg-<hash>``) found via JQL, so a restart does not re-open an issue for a
change that already has one, and it honours JSM mode (``service_desk_id`` +
``request_type_id``) so issues land in service-desk queues.

A config change is informational - there is no resolve lifecycle (unlike alerts);
the handler only creates.
"""

import hashlib
import logging
from typing import Any, Dict, List, Optional

from src.plugin_api import ConfigChangeEvent, config_diff
from src.plugin_api import webhook_store as store

from .. import adf
from ..settings import get_change_detection_settings, get_jira_client, get_jira_settings

logger = logging.getLogger(__name__)

_PLUGIN_ID = "jira"

_NO_DIFF_EXTS = (".gz", ".tgz", ".tar", ".zip", ".bak", ".dat")
_MAX_DESCRIPTION_CHARS = 40000


def _log_event(**kwargs: Any) -> None:
    """Record a webhook event tagged with this plugin's id (UI per-plugin filter)."""
    store.log_event(plugin=_PLUGIN_ID, **kwargs)


def _change_label(event_key: str) -> str:
    """A correlation label for a config-change event (labels disallow spaces)."""
    return "lvi-chg-" + hashlib.sha1(event_key.encode("utf-8")).hexdigest()[:12]


def _build_change_description(event: ConfigChangeEvent, diff_text: str = "") -> dict:
    """ADF body summarising the config change, with optional diff."""
    paths = ", ".join(event.paths) if event.paths else "unknown"
    rows = [
        ("Device", adf.text(event.hostname or "")),
        ("IP Address", adf.text(event.ip_address or "")),
        ("Network", adf.text(event.managed_network or "")),
        ("Changed At", adf.text(event.last_changed or "")),
        ("Author", adf.text(event.author or "unknown")),
        ("Config Paths", adf.text(paths)),
    ]
    blocks: List[Any] = [adf.detail_table(rows)]
    if diff_text:
        blocks.append(adf.paragraph(adf.text("Config diff:")))
        blocks.append(adf.code_block(diff_text))
    return adf.doc(*blocks)


def _build_change_description_text(event: ConfigChangeEvent, diff_text: str = "") -> str:
    """Plain-text body for the JSM Service Desk API (it does not accept ADF)."""
    paths = ", ".join(event.paths) if event.paths else "unknown"
    base = (
        f"Device: {event.hostname or ''}\n"
        f"IP Address: {event.ip_address or ''}\n"
        f"Network: {event.managed_network or ''}\n"
        f"Changed At: {event.last_changed or ''}\n"
        f"Author: {event.author or 'unknown'}\n"
        f"Config Paths: {paths}"
    )
    if diff_text:
        return base + "\n\nConfig diff:\n" + diff_text
    return base


def _fetch_diff(event: ConfigChangeEvent, lvi: Any, min_lines: int) -> tuple:
    """Fetch per-path diffs from LVI. Returns (diff_text, diffs_fetched, total_changed_lines).

    Returns (None, False, 0) when no path_details are available or all paths are
    binary. Returns ("", True, N) when diffs were fetched but produced no output.
    """
    ip = event.ip_address or ""
    network = event.managed_network or ""
    changed_at = event.last_changed or ""

    diff_sections: List[str] = []
    total_changed_lines = 0
    diffs_fetched = False

    for pd in event.path_details:
        path = pd.get("path", "")
        prev_change = pd.get("prev_change", "")
        if not path or not prev_change or not changed_at:
            continue
        if path.lower().endswith(_NO_DIFF_EXTS):
            continue
        try:
            segments = lvi.get_config_revision_word_diff(
                ip_address=ip,
                timestamp1=prev_change,
                timestamp2=changed_at,
                network=network,
                config_path=path,
            )
            diffs_fetched = True
            total_changed_lines += config_diff.count_changed_lines(segments)
            diff_text = config_diff.format_diff(segments)
            if diff_text:
                diff_sections.append(f"--- {path} ---\n{diff_text}")
        except Exception as exc:
            logger.debug("Could not fetch diff for %s %s: %s", event.hostname, path, exc)

    if not diffs_fetched:
        return None, False, 0

    combined = "\n\n".join(diff_sections)
    if len(combined) > _MAX_DESCRIPTION_CHARS:
        combined = combined[:_MAX_DESCRIPTION_CHARS].rstrip() + "\n" + config_diff.TRUNCATION_NOTE

    return combined, True, total_changed_lines


class JiraIssueChangeCreator:
    """Change handler that opens a Jira issue for each LVI config change."""

    def __call__(self, event: ConfigChangeEvent, lvi: Any) -> bool:
        """Create a Jira issue for *event*. Return True if one was created."""
        node = event.hostname or event.ip_address or "?"
        try:
            jira = get_jira_client()
        except Exception as exc:
            logger.error("JiraIssueChangeCreator: failed to create Jira client: %s", exc)
            _log_event(
                direction="sync mgr→jira",
                action="config_change",
                node=node,
                correlation_hash=event.event_key,
                severity="",
                result="error",
                src="Sync Manager",
                dst="",
                error=f"Jira client init failed: {exc}",
                status_code=500,
                event_type="config_change",
                description=config_diff.change_event_title(event),
            )
            return False

        label = _change_label(event.event_key)
        try:
            existing = jira.find_any_issue_by_label(label)
            if existing:
                logger.info("Config change for %s already has Jira issue %s", node, existing.get("key"))
                return False
            key = self._create_issue(jira, event, label, lvi)
        except Exception as exc:
            logger.error("JiraIssueChangeCreator: failed to create Jira issue for %s: %s", node, exc)
            _log_event(
                direction="sync mgr→jira",
                action="config_change",
                node=node,
                correlation_hash=event.event_key,
                severity="",
                result="error",
                src="Sync Manager",
                dst=jira.base_url,
                error=str(exc),
                status_code=500,
                event_type="config_change",
                description=config_diff.change_event_title(event),
            )
            return False

        if key is None:
            return False  # suppressed by minimum_changed_lines

        # Same jira_change.impact setting _create_issue() maps onto the
        # created issue's own priority field (non-JSM mode only) - mirrored
        # here so the Webhooks tab's "Severity/Impact" column (shared with
        # the SNOW change handler, which populates it from its own
        # `urgency` setting) is not blank for every Jira config-change
        # event. Read directly rather than threaded through _create_issue's
        # return value - simplest option, and the two never disagree since
        # both read the same config key.
        impact = (get_change_detection_settings().get("jira_change", {}).get("impact") or "").strip()

        _log_event(
            direction="sync mgr→jira",
            action="config_change",
            node=node,
            correlation_hash=event.event_key,
            severity=impact,
            result="created",
            src="LogicVein",
            dst=jira.base_url,
            incident=key,
            status_code=201,
            event_type="config_change",
            description=config_diff.change_event_title(event),
        )
        logger.info("Created Jira issue %s for config change on %s", key, node)
        return True

    def _create_issue(self, jira: Any, event: ConfigChangeEvent, label: str, lvi: Any) -> Optional[str]:
        """Create the Jira issue (JSM request when configured, else a plain issue).

        Returns the issue key, or None if suppressed by minimum_changed_lines.
        """
        cfg = get_jira_settings().get("jira", {})
        change_cfg = get_change_detection_settings().get("jira_change", {})
        min_lines = int(change_cfg.get("minimum_changed_lines", 1))

        diff_text, diffs_fetched, total_changed_lines = _fetch_diff(event, lvi, min_lines)

        if diffs_fetched and total_changed_lines < min_lines:
            logger.info(
                "JiraIssueChangeCreator: skipping %s - %d changed line(s) < minimum_changed_lines=%d",
                event.hostname or event.ip_address,
                total_changed_lines,
                min_lines,
            )
            return None

        summary = config_diff.change_event_title(event)
        sd_id = str(cfg.get("service_desk_id", "") or "").strip()
        rt_id = str(cfg.get("request_type_id", "") or "").strip()

        if sd_id and rt_id:
            created = jira.create_request(
                service_desk_id=sd_id,
                request_type_id=rt_id,
                summary=summary,
                description=_build_change_description_text(event, diff_text or ""),
                labels=[label],
            )
        else:
            issue_type = change_cfg.get("issue_type") or cfg.get("issue_type", "Task")
            impact = (change_cfg.get("impact") or "").strip()
            fields: Dict[str, Any] = {
                "project": {"key": cfg.get("project_key", "")},
                "issuetype": {"name": issue_type},
                "summary": summary,
                "description": _build_change_description(event, diff_text or ""),
                "labels": [label],
            }
            if impact:
                fields["priority"] = {"name": impact}
            created = jira.create_issue(fields)
        return created.get("key", created.get("id", "unknown"))


_creator: Optional[JiraIssueChangeCreator] = None


def get_change_creator() -> JiraIssueChangeCreator:
    """Return the module-level singleton change handler (created on first use)."""
    global _creator
    if _creator is None:
        _creator = JiraIssueChangeCreator()
    return _creator
