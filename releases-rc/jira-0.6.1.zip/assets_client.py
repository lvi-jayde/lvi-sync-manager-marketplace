"""Jira Assets (JSM CMDB) REST client for inventory sync.

Jira Assets lives on a *different* host from the Jira issue API
(``https://api.atlassian.com/jsm/assets/workspace/{workspaceId}/v1``), keyed by a
per-site workspace id. This client reuses an existing :class:`JiraClient` for the
shared HTTP Basic ``email:api_token`` auth (verified to work on both hosts) and for
the one-time workspace-id lookup, then talks to the Assets host directly.

Object values are keyed by a numeric ``objectTypeAttributeId`` (per object type),
not by attribute name, so callers resolve names -> ids via
:meth:`get_type_attributes` before building a create/update payload. See
``docs/dev_notes/JIRA_ASSETS_INVESTIGATION.md`` for the full API notes.
"""

import logging
from typing import Any, Dict, List, Optional

import requests

logger = logging.getLogger(__name__)

# How much of an HTTP error body to log. Bounded because an error body is
# unbounded in principle - an HTML error page or an API that echoes the
# rejected payload can both run to tens of KB. The head, not the tail: for
# a JSON API the message sits at the front ({"error":{"message":...}}), and
# when a body is HTML rather than JSON the opening tag is itself the
# diagnosis.
_ERROR_BODY_CHARS = 500

_ASSETS_HOST = "https://api.atlassian.com/jsm/assets/workspace"


def _aql_escape(value: str) -> str:
    """Escape a value for use inside a double-quoted AQL string literal."""
    return value.replace("\\", "\\\\").replace('"', '\\"')


class JiraAssetsClient:
    """Client for the Jira Assets REST API, built on top of a JiraClient."""

    def __init__(self, jira_client: Any, workspace_id: str = "") -> None:
        """Initialise from a JiraClient (for auth + workspace discovery).

        Args:
            jira_client: A connected ``JiraClient`` (its session carries the
                ``email:api_token`` Basic auth and the retry adapter).
            workspace_id: Optional explicit workspace id; auto-discovered when blank.
        """
        self._jira = jira_client
        self._workspace_id = (workspace_id or "").strip()
        self._base = ""  # resolved lazily once the workspace id is known

    # ------------------------------------------------------------------ #
    # Transport                                                            #
    # ------------------------------------------------------------------ #

    def get_workspace_id(self) -> str:
        """Look up the Assets workspace id for this site (one-time, cached)."""
        if self._workspace_id:
            return self._workspace_id
        resp = self._jira._request("GET", "rest/servicedeskapi/assets/workspace")
        values = resp.json().get("values", [])
        if not values:
            raise RuntimeError("No Assets workspace found - is Assets (JSM) enabled on this site?")
        self._workspace_id = values[0]["workspaceId"]
        return self._workspace_id

    def _assets_base(self) -> str:
        if not self._base:
            self._base = f"{_ASSETS_HOST}/{self.get_workspace_id()}/v1"
        return self._base

    def _request(self, method: str, path: str, json_data: Optional[Dict] = None) -> Any:
        """Call the Assets host with the JiraClient's authenticated session.

        Borrows JiraClient's session rather than owning one, which is why this
        is a separate method and not the same code as JiraClient._request. The
        logging conventions are shared - see docs/PLUGIN_DEVELOPMENT.md.
        """
        url = f"{self._assets_base()}/{path}"
        logger.debug("Request: %s %s", method, path)
        if json_data:
            logger.debug("JSON: %s", json_data)
        try:
            resp = self._jira.session.request(method=method, url=url, json=json_data, timeout=self._jira.timeout)
            resp.raise_for_status()
        except requests.exceptions.RequestException as e:
            # Previously this raised with nothing logged, so an Assets API
            # failure left no explanation behind at all.
            err = getattr(e, "response", None)
            if err is not None:
                logger.error("HTTP error: %s - %s", err.status_code, err.text[:_ERROR_BODY_CHARS])
            else:
                logger.error("Request error: %s", e)
            raise
        return resp

    def test_connection(self) -> bool:
        """Return True if the Assets workspace + schema list are reachable."""
        try:
            self._request("GET", "objectschema/list")
            return True
        except Exception as exc:
            logger.error("Jira Assets connection test failed: %s", exc)
            return False

    # ------------------------------------------------------------------ #
    # Schema / object type / attribute resolution                          #
    # ------------------------------------------------------------------ #

    def find_schema_id(self, schema: str) -> Optional[str]:
        """Resolve an object schema by id, key, or name to its id."""
        wanted = str(schema).strip()
        for s in self._request("GET", "objectschema/list").json().get("values", []):
            if wanted in (str(s.get("id")), s.get("objectSchemaKey"), s.get("name")):
                return str(s.get("id"))
        return None

    def find_object_type_id(self, schema_id: str, object_type: str) -> Optional[str]:
        """Resolve an object type within a schema by id or name to its id."""
        wanted = str(object_type).strip()
        for t in self._request("GET", f"objectschema/{schema_id}/objecttypes/flat").json():
            if wanted in (str(t.get("id")), t.get("name")):
                return str(t.get("id"))
        return None

    def get_type_attributes(self, object_type_id: str) -> Dict[str, str]:
        """Return a {attribute name -> objectTypeAttributeId} map for a type."""
        attrs = self._request("GET", f"objecttype/{object_type_id}/attributes").json()
        return {a["name"]: str(a["id"]) for a in attrs if a.get("name") and a.get("id") is not None}

    # ------------------------------------------------------------------ #
    # Objects                                                              #
    # ------------------------------------------------------------------ #

    def find_object_id(self, object_type_name: str, attribute_name: str, value: str) -> Optional[str]:
        """Find an object of *object_type_name* whose *attribute_name* == *value*.

        Returns the first matching object's id, or None. Assets does not enforce
        attribute uniqueness, so the caller's correlation attribute should be
        unique in practice (hostname or a dedicated key).
        """
        qlq = f'objectType = "{_aql_escape(object_type_name)}" AND "{_aql_escape(attribute_name)}" = "{_aql_escape(value)}"'
        body = {"qlQuery": qlq, "page": 1, "resultsPerPage": 2}
        values = self._request("POST", "object/aql", json_data=body).json().get("values", [])
        return str(values[0]["id"]) if values else None

    def create_object(self, object_type_id: str, attributes: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Create an object. ``attributes`` is the resolved attributes payload."""
        body = {"objectTypeId": str(object_type_id), "attributes": attributes}
        return self._request("POST", "object/create", json_data=body).json()

    def update_object(self, object_id: str, object_type_id: str, attributes: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Update an existing object (only the supplied attributes change)."""
        body = {"objectTypeId": str(object_type_id), "attributes": attributes}
        return self._request("PUT", f"object/{object_id}", json_data=body).json()

    @staticmethod
    def build_attributes(name_to_id: Dict[str, str], values: Dict[str, str]) -> List[Dict[str, Any]]:
        """Build the create/update ``attributes`` array from name->value pairs.

        Skips attribute names that the object type does not have. Each value is sent
        as a single string ``objectAttributeValues`` entry.
        """
        out: List[Dict[str, Any]] = []
        for attr_name, value in values.items():
            attr_id = name_to_id.get(attr_name)
            if attr_id is None:
                continue
            out.append({"objectTypeAttributeId": attr_id, "objectAttributeValues": [{"value": value}]})
        return out
