"""NetBox IPAM sync plugin implementation."""

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import (  # pyright: ignore[reportMissingImports]
    SyncPlugin,
    get_product_name,
    load_plugin_config,
    normalize_networks,
)

from .client import NetBoxClient
from .sync import LogicVeinNetBoxSync

logger = logging.getLogger(__name__)


class NetBoxPlugin(SyncPlugin):
    """Plugin for synchronizing LogicVein devices to NetBox IPAM."""

    def __init__(self):
        """Initialize the NetBox plugin from its manifest.json."""
        self.config = load_plugin_config(Path(__file__).parent)

    def create_client(self, credentials: Dict[str, Any]) -> Any:
        """Create NetBox client.

        Args:
            credentials: Dictionary with 'host' and 'token' keys.

        Returns:
            NetBoxClient instance.
        """
        from .settings import get_netbox_settings

        netbox_cfg = get_netbox_settings().get("netbox", {})
        kwargs: Dict[str, Any] = {
            "verify_ssl": bool(netbox_cfg.get("verify_ssl", False)),
            "timeout": int(netbox_cfg.get("timeout", 120)),
        }
        if credentials.get("ignore_env_vars"):
            kwargs["ignore_env_vars"] = True
        if credentials.get("host"):
            kwargs["host"] = credentials["host"]
        if credentials.get("token"):
            kwargs["api_token"] = credentials["token"]

        return NetBoxClient(**kwargs)

    def create_sync_engine(
        self,
        lvi_client: Any,
        target_client: Any,
        sync_config: Dict[str, Any],
    ) -> Any:
        """Create NetBox sync engine.

        Args:
            lvi_client: LogicVein API client.
            target_client: NetBox client.
            sync_config: Sync configuration dictionary.

        Returns:
            LogicVeinNetBoxSync instance.
        """
        return LogicVeinNetBoxSync(
            lvi_client=lvi_client,
            netbox_client=target_client,
            config=sync_config,
        )

    def build_sync_config(
        self,
        yaml_config: Dict[str, Any],
        timestamp: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Build sync configuration from YAML config.

        Args:
            yaml_config: Parsed YAML configuration dictionary.
            timestamp: Optional timestamp for archive file naming.

        Returns:
            Configuration dictionary ready for LogicVeinNetBoxSync.
        """
        sync_config = yaml_config.get("sync", {})
        lvi_config = yaml_config.get("logicvein", {})
        netbox_config = yaml_config.get("netbox", {})
        # netbox.dcim.*/ipam.*/interfaces.*/location.* group the live YAML
        # for readability only - the flat keys below (and every
        # self.config.get() in sync.py) are unaffected by that grouping, so
        # this is the only place the nesting is ever un-done.
        dcim = netbox_config.get("dcim", {})
        ipam = netbox_config.get("ipam", {})
        interfaces = netbox_config.get("interfaces", {})
        location = netbox_config.get("location", {})

        return {
            # Sync options
            "dry_run": sync_config.get("dry_run", False),
            "network": lvi_config.get("networks", "Default"),
            "continue_on_error": sync_config.get("continue_on_error", True),
            # NetBox device options
            "sync_to_dcim": netbox_config.get("sync_to_dcim", True),
            "strip_domain_from_names": dcim.get("strip_domain_from_names", True),
            "site_name": dcim.get("site_name", ""),
            # None (key genuinely absent - never configured) uses the vendor
            # display name; an explicit "" disables tenant classification.
            "tenant_name": get_product_name() if dcim.get("tenant_name") is None else dcim.get("tenant_name"),
            "device_role_name": dcim.get("device_role_name", ""),
            "default_device_type": dcim.get("default_device_type", ""),
            "default_manufacturer": dcim.get("default_manufacturer", "Unknown"),
            "create_missing_resources": dcim.get("create_missing_resources", True),
            "populate_custom_fields": dcim.get("populate_custom_fields", False),
            "custom_field_mapping": dcim.get("custom_field_mapping", {}),
            "auto_create_custom_fields": dcim.get("auto_create_custom_fields", False),
            # NetBox IPAM options
            "create_ip_addresses": ipam.get("create_ip_addresses", True),
            "set_primary_ip": ipam.get("set_primary_ip", True),
            "default_ip_status": ipam.get("default_ip_status", "active"),
            "default_subnet_mask": ipam.get("default_subnet_mask", 32),
            # Extended field sync options
            "sync_platform": dcim.get("sync_platform", False),
            "sync_comments": dcim.get("sync_comments", False),
            "sync_description": dcim.get("sync_description", False),
            "sync_mac_address": interfaces.get("sync_mac_address", False),
            "ip_conflict_policy": ipam.get("ip_conflict_policy", "overwrite"),
            "mac_conflict_policy": interfaces.get("mac_conflict_policy", "overwrite"),
            # Lifecycle custom fields
            "sync_lifecycle": dcim.get("sync_lifecycle", False),
            "lifecycle_field_mapping": dcim.get("lifecycle_field_mapping", {}),
            # Location sync options
            "sync_location": location.get("sync_location", False),
            "create_missing_locations": location.get("create_missing_locations", True),
            # Interface sync options
            "sync_interfaces": interfaces.get("sync_interfaces", False),
            "delete_stale_interfaces": interfaces.get("delete_stale_interfaces", False),
            "sync_vlans": interfaces.get("sync_vlans", False),
            "sync_vrfs": interfaces.get("sync_vrfs", False),
            "global_vrf_aliases": interfaces.get("global_vrf_aliases")
            or ["default", "master", "Base", "_public_", "global", "GRT", "0"],
            # Stale device/IP deletion options
            "delete_stale_devices": dcim.get("delete_stale_devices", False),
            "delete_stale_ips": ipam.get("delete_stale_ips", False),
        }

    def test_connection(
        self,
        credentials: Dict[str, Any],
    ) -> Tuple[bool, str]:
        """Test connection to NetBox.

        Args:
            credentials: Dictionary with 'host' and 'token' keys.

        Returns:
            Tuple of (success, message).
        """
        try:
            client = self.create_client(credentials)
            # Try a simple API call to verify connection
            if client.test_connection():
                return True, "Connected to NetBox successfully"
            else:
                return False, "Connection test failed - check credentials"
        except Exception as e:
            return False, f"Connection failed: {e}"

    def get_status_detail(self, config: Dict[str, Any]) -> str:
        """Return a one-line status string for the NetBox sync tab header.

        Args:
            config: Parsed YAML configuration dictionary.

        Returns:
            Human-readable summary of the active network(s) and target site.
        """
        networks = normalize_networks(config.get("logicvein", {}).get("networks", "Default"))
        network_str = ", ".join(networks) if networks else "all"
        site = config.get("netbox", {}).get("dcim", {}).get("site_name", "")
        return f"Network: {network_str} | Site: {site or 'Not set'}"

    def resolve_conflict(self, conflict_type: str, desired_payload: Dict[str, Any]) -> bool:
        """Apply an "Overwrite" decision for one pending conflict.

        Uses create_client({}) - the same "no override, resolve from stored
        credentials/settings" call real sync runs make. "ip_exists" writes
        the deferred IP assignment; "mac_duplicate"/"mac_differs" write the
        deferred MAC onto the interface (both primary/mgmt0 and secondary
        interfaces use the same {"interface_id", "mac_address"} shape).

        Args:
            conflict_type: The kind of conflict being resolved.
            desired_payload: The payload recorded when the conflict was detected.

        Returns:
            True if the overwrite succeeded.
        """
        client = self.create_client({})
        if conflict_type == "ip_exists":
            ip_id = desired_payload["ip_id"]
            # NetBox rejects the reassignment outright (HTTP 400, "Cannot
            # reassign IP address while it is designated as the primary IP
            # for the parent object") while the address is still its
            # parent's primary. The sync path's own "overwrite" branch
            # already clears that first; this path did not, so every
            # Overwrite decision on a primary IP failed - exactly the case
            # the "ask" policy exists to defer.
            client.clear_primary_ip_owner(ip_id)
            if not client.update_ip_address(ip_id, desired_payload["ip_data"]):
                return False
            # Re-point the primary at the device this address now belongs
            # to, mirroring what the sync path does after its own
            # reassignment - otherwise Overwrite leaves the old owner
            # stripped of its primary and the new one without it, until
            # some later sync happens to repair it. Older pending items
            # carry no device_id (the key was added alongside this fix), so
            # they simply skip this and behave as before.
            device_id = desired_payload.get("device_id")
            if device_id:
                client.update_device(device_id, {"primary_ip4": ip_id})
            return True
        interface_id = desired_payload.get("interface_id")
        if not interface_id:
            return False
        return bool(client.update_interface(interface_id, {"mac_address": desired_payload.get("mac_address", "")}))

    def get_output_csv_paths(self, yaml_config: Dict[str, Any]) -> List[str]:
        """Return output CSV file paths for this plugin.

        Args:
            yaml_config: Parsed YAML configuration dictionary.

        Returns:
            Empty list - NetBox sync does not produce CSV output files.
        """
        return []
