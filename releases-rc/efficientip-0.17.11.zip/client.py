"""Client for the EfficientIP SOLIDserver REST API.

Credentials are accepted as explicit constructor parameters; if omitted they
fall back to the EFFICIENTIP_* environment variables unless ignore_env_vars
is True. TLS verification and request timeout are read from
conf/efficientip_sync_config.yaml (not env vars) unless passed explicitly.

Confirmed SOLIDserver-specific conventions this client wraps (verified
against a live instance):

- **All parameters go in the URL query string, never the request body -
  even for POST/PUT/DELETE.** A form-encoded POST body is silently rejected
  (HTTP 400, empty body); the same call succeeds when the identical
  parameters are query-string args.
- IP addresses are represented internally in hex (e.g. "c0a80100" for
  192.168.1.0) alongside a dotted-decimal field. Exact-match WHERE queries
  need the hex form - see _ip_to_hex().
- Per-object custom metadata ("class parameters") is not a separate object
  type: it's a single <object>_class_parameters field holding a raw
  URL-query-encoded blob (e.g. "key1=val1&key2=val2"), decoded/encoded with
  urllib.parse.parse_qs/urlencode - see decode_class_parameters()/
  _encode_class_parameters().
- Error convention: a failed call returns a JSON array wrapping one error
  object, e.g. [{"errno": "3", "errmsg": "unknown service", ...}], even for
  a single error - not a bare object. A successful empty list result is
  HTTP 204 with an empty body, not "[]".
- Creating a subnet requires it to fall within an existing IP block
  (errno 5001, "Subnet is not in a block") unless SOLIDserver already has
  address space provisioned there - see create_block()/create_subnet().
- The ``type`` field in ip_block_subnet_list is always "subnet" for both
  blocks and terminal subnets - it does NOT distinguish them. Use
  ``is_terminal`` instead ("0" = block, "1" = terminal/assignable subnet).

Token-based authentication (Token ID / Token Secret, generated in the
SOLIDserver UI under Administration > Authentication & Security > API
tokens) is a signed-request scheme, not Basic auth with the token as a
password - confirmed by reading EfficientIP-Labs' own SOLIDserverRest
client source (no public API doc covers this) and verified against a live
instance:

- Each request adds ``Authorization: SDS {token_id}:{signature}`` and
  ``X-SDS-TS: {unix_timestamp}`` headers. ``signature`` is
  ``sha3_256(f"{token_secret}\\n{timestamp}\\n{METHOD}\\n{full_url_with_querystring}").hexdigest()``.
- ``X-SDS-TS`` is a timestamp-windowed anti-replay check - a clock more than
  a few minutes off between this client and the SOLIDserver appliance makes
  every signed request fail (seen empirically: a 4-hour clock skew produced
  a consistent, generic ``412 {"connected": false}`` on every service,
  including ones the token's module scope should have allowed).
- The token itself is scoped to specific SOLIDserver modules (chosen when
  it's created). A token missing a module used by this client's calls (even
  read-only ones like ip_site_list) fails the same generic
  ``412 {"connected": false}`` - there is no separate "permission denied"
  response distinguishing a scope problem from a bad signature. Grant every
  module this plugin touches (IPAM at minimum; DNS/NetChange if those
  services are ever added) rather than trying to guess the minimal set.

NOM (Network Object Manager - folders/devices/interfaces-ports, module
"nom") conventions, confirmed against a live instance:

- The actual service names on a live instance are ``nom_folder_add``/
  ``nom_netobj_add``/``nom_iface_add`` (create) with **no separate
  ``_update`` service** - EfficientIP-Labs' own SOLIDserverRest client
  (checked for the auth scheme above) assumes older ``nom_folder_create``/
  etc. names that don't exist on this appliance; always verify service
  names against the live ``service_list`` service rather than trusting
  that library.
- Unlike IPAM's ``ip_add`` (a single call upserts by hostaddr/site_id),
  NOM's ``_add`` services do **not** upsert by natural key or by ID with
  ``add_flag`` - confirmed empirically: calling ``nom_netobj_add`` again
  for a name that already exists in the same folder fails with
  ``errno 82006 "Network object already exists"``, even when the existing
  object's ID is passed explicitly alongside ``add_flag=edit_only`` or
  ``new_edit``. **The fix is the HTTP verb, not add_flag: POST creates,
  PUT updates** (same URL/service, just ``nomnetobj_id``/``nomiface_id``
  plus whichever fields changed) - this client always looks the object up
  first (by name for netobj, by port name for iface) and picks POST vs PUT
  itself; callers never choose the verb.
- An interface is created via ``nom_iface_add`` and implicitly creates its
  port in the same call (``nomiface_port_name``/``nomiface_port_mac``) -
  there is no separate port-create service (``nom_port_list``/``_info``
  are read-only).
- ``nomiface_vlan_domain``/``nomiface_vlan_number`` (VLAN Manager module,
  "vlm") are free-text/integer fields with no validation against a real
  VLAN Manager domain or VLAN object - confirmed empirically, a completely
  made-up domain name is accepted and stored as-is, and writing a VLAN
  number this way does **not** create or check a corresponding ``vlmvlan``
  object at all. This client looks up/creates a real domain via
  ``vlmdomain_list``/``vlm_domain_add`` (``vlm_domain_add`` with just a name
  defaults to a 1-4094 VLAN ID range) and separately registers the VLAN ID
  itself via ``vlm_vlan_add`` (see ``create_vlan()``), so both the domain
  and the specific VLAN actually exist as real VLAN Manager objects rather
  than just labels on the interface. ``vlm_vlan_add`` *requires*
  ``vlmrange_id``/``vlmrange_name`` - SOLIDserver allows multiple VLAN
  Ranges to overlap the same ID span within one Domain, so a bare VLAN ID
  is ambiguous without naming which Range it belongs to (see
  ``create_vlan_range()``'s docstring for the overlap-creation quirk).
- **PUT can change a set value but can't clear one back to empty** for
  ``nomiface_hostaddr`` - confirmed against a live instance: sending an
  empty value returns 201 but the previous IP silently stays in place.
  ``nomiface_vlan_number``/``nomiface_vlan_domain`` are worse - "0"/empty
  is rejected outright (``errno 4``, "Missing parameter"), even with both
  fields present, likely a PHP ``empty()``-style truthiness check
  server-side treating the string "0" as absent. The only way to actually
  blank these fields is ``delete_interface()`` followed by
  ``create_interface()`` (confirmed live: a freshly recreated interface
  reports an empty hostaddr and VLAN 0) - see ``update_interface()``'s and
  ``LogicVeinEfficientIPSync._sync_device_to_nom()``'s docstrings.
- ``nomiface_main=1`` is rejected (``errno 82029``, "An interface without
  IP cannot be set as main") on an interface with no ``nomiface_hostaddr``
  - confirmed live. Clearing ``nomiface_main`` back to 0 via PUT works
  fine as long as the interface still has an IP at the time.
- **"Connected object"/"Connected port" (``connected_port_id``) has no
  dedicated connect service either** - ``macro_connect_nom_ports.php``
  (found in ``service_list``) is a ``notif_``-prefixed internal hook, not
  a callable REST endpoint (confirmed live: calling it directly 400s the
  same way as a genuinely nonexistent service, unlike a real service's
  JSON error body). The actual write is the same ``nom_iface_add`` PUT
  ``update_interface()`` uses, with a ``connected_port_id`` field added -
  see ``set_interface_connection()``. Confirmed live this is automatically
  bidirectional (the other port's own ``connected_port_id`` updates
  without a second call). Does NOT reliably clear a port's previous
  connection when reassigned to a different one - disproven live in
  production despite an earlier "confirmed live" claim here, see
  ``set_interface_connection()``'s docstring. Unlike hostaddr/VLAN,
  clearing is at least a plain value (``"0"``), not delete+recreate.
  ``nom_netobj_list``'s
  ``nomnetobj_nb_connected_ports``/``nomnetobj_connected_nom`` fields
  (NOM's "No. of connected ports"/"Connected objects (list)") update
  automatically once ports are linked - nothing else to write.
"""

import hashlib
import ipaddress
import logging
import os
import time
from typing import Any, Dict, List, Optional
from urllib.parse import parse_qs, urlencode

import requests
import urllib3
from src.plugin_api import build_retry_adapter

logger = logging.getLogger(__name__)

# How much of an HTTP error body to log. Bounded because an error body is
# unbounded in principle - an HTML error page or an API that echoes the
# rejected payload can both run to tens of KB. The head, not the tail: for
# a JSON API the message sits at the front ({"error":{"message":...}}), and
# when a body is HTML rather than JSON the opening tag is itself the
# diagnosis.
_ERROR_BODY_CHARS = 500


# SOLIDserver caps nomnetobj_type at 16 characters and rejects the WHOLE
# nom_netobj_add call when it is longer (errno 10, "Parameter size too
# long", max_size 16) - so an over-long type meant the device was never
# created in NOM at all, not merely created without a type. Several stock
# LogicVein device types exceed this (e.g. "Wireless Controller", 19), so
# this is not an edge case. See _clamp_nom_type().
_NOM_TYPE_MAX_LEN = 16


class EfficientIPError(Exception):
    """Raised when the SOLIDserver REST API returns an error response."""


class EfficientIPClient:
    """Native Python client for the EfficientIP SOLIDserver REST API."""

    def __init__(
        self,
        host: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        token_id: Optional[str] = None,
        token_secret: Optional[str] = None,
        verify_ssl: Optional[bool] = None,
        timeout: Optional[int] = None,
        ignore_env_vars: bool = False,
    ) -> None:
        """Initialise the EfficientIP SOLIDserver client.

        Token auth (token_id/token_secret) takes priority over username/
        password whenever both resolve to a value - see the module docstring
        for how the token is scoped and why it needs every module this
        client touches.

        Args:
            host: SOLIDserver hostname or URL. Defaults to EFFICIENTIP_HOST env var.
            username: API username. Defaults to EFFICIENTIP_USERNAME env var.
            password: API password. Defaults to EFFICIENTIP_PASSWORD env var.
            token_id: API token ID. Defaults to EFFICIENTIP_TOKEN_ID env var.
            token_secret: API token secret. Defaults to EFFICIENTIP_TOKEN_SECRET env var.
            verify_ssl: Verify TLS certificates. Defaults to
                        conf/efficientip_sync_config.yaml efficientip.verify_ssl, or False.
            timeout: Request timeout in seconds. Defaults to
                     conf/efficientip_sync_config.yaml efficientip.timeout, or 120.
            ignore_env_vars: If True, do not fall back to environment variables.
        """
        if ignore_env_vars:
            self.host = host
            self.username = username
            self.password = password
            self.token_id = token_id
            self.token_secret = token_secret
            self.verify_ssl = verify_ssl if verify_ssl is not None else False
            self.timeout = timeout or 120
        else:
            self.host = host or os.getenv("EFFICIENTIP_HOST")
            self.username = username or os.getenv("EFFICIENTIP_USERNAME")
            self.password = password or os.getenv("EFFICIENTIP_PASSWORD")
            self.token_id = token_id or os.getenv("EFFICIENTIP_TOKEN_ID")
            self.token_secret = token_secret or os.getenv("EFFICIENTIP_TOKEN_SECRET")
            if verify_ssl is not None and timeout is not None:
                self.verify_ssl = verify_ssl
                self.timeout = timeout
            else:
                from .settings import get_efficientip_settings

                eip_cfg = get_efficientip_settings().get("efficientip", {})
                self.verify_ssl = verify_ssl if verify_ssl is not None else bool(eip_cfg.get("verify_ssl", False))
                self.timeout = timeout if timeout is not None else int(eip_cfg.get("timeout", 120))

        # Normalize host - remove protocol if present
        if self.host and self.host.startswith(("http://", "https://")):
            self.host = self.host.split("://", 1)[1]

        self.base_url = f"https://{self.host}/rest"

        self.use_token = bool(self.token_id and self.token_secret)

        self.session = requests.Session()
        if not self.use_token and self.username and self.password:
            self.session.auth = (self.username, self.password)
        self.session.headers.update({"Accept": "application/json"})
        self.session.verify = self.verify_ssl
        if not self.verify_ssl:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        _adapter = build_retry_adapter()
        self.session.mount("https://", _adapter)
        self.session.mount("http://", _adapter)

        # Per-space subnet/block lists, cached for the lifetime of this
        # client (one sync run - sync_runner builds a fresh client per run).
        # SOLIDserver has no "which subnet contains this IP" service, so
        # find_subnet_for_ip()/find_block_for_ip() have to pull the whole
        # list and match locally; without this they re-pulled it for every
        # single device. Invalidated on create_subnet()/create_block() so a
        # just-created object is visible to the very next lookup - see
        # clear_topology_cache().
        self._subnet_cache: Dict[str, List[Dict[str, Any]]] = {}
        self._block_cache: Dict[str, List[Dict[str, Any]]] = {}

        # Device types already reported as too long for nomnetobj_type, so
        # the warning is emitted once per distinct type rather than once
        # per device - see _clamp_nom_type().
        self._warned_long_nom_types: set = set()

    def _token_auth_headers(self, method: str, url: str) -> Dict[str, str]:
        """Build the signed Authorization/X-SDS-TS headers for one token-auth request.

        See the module docstring for the signing scheme - it must be
        computed fresh per request since the timestamp and URL are part of
        the signed string.
        """
        timestamp = int(time.time())
        string_to_sign = f"{self.token_secret}\n{timestamp}\n{method}\n{url}"
        signature = hashlib.sha3_256(string_to_sign.encode()).hexdigest()
        return {"Authorization": f"SDS {self.token_id}:{signature}", "X-SDS-TS": str(timestamp)}

    # ------------------------------------------------------------------ #
    # Low-level request handling                                          #
    # ------------------------------------------------------------------ #

    def _request(
        self,
        method: str,
        service: str,
        params: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """Call a SOLIDserver REST service and return its parsed result list.

        All parameters are sent as URL query-string args regardless of
        method - SOLIDserver silently rejects a form-encoded request body
        (confirmed empirically; see module docstring).

        Args:
            method: HTTP method (GET, POST, PUT, DELETE).
            service: Service name (e.g. "ip_site_list", "ip_add").
            params: Query parameters.

        Returns:
            Parsed JSON array of result objects. Empty list on HTTP 204
            (SOLIDserver's convention for an empty result set).

        Raises:
            EfficientIPError: If the service returns an error object.
        """
        url = f"{self.base_url}/{service}"
        if params:
            url = f"{url}?{urlencode(params)}"
        logger.debug("Request: %s %s", method, url)

        headers = self._token_auth_headers(method, url) if self.use_token else None
        response = self.session.request(method=method, url=url, headers=headers, timeout=self.timeout)

        if response.status_code == 204:
            return []

        try:
            data = response.json()
        except ValueError:
            # A non-JSON body on a 4xx/5xx (e.g. a routing-level reject, or
            # SOLIDserver choking on something unexpected server-side) -
            # confirmed live this happens (an empty-body 400 calling a
            # notif_-prefixed internal macro directly, and again with a
            # stale connected_port_id in production - see
            # set_interface_connection()). Raising EfficientIPError here
            # (instead of letting raise_for_status() leak a raw
            # requests.HTTPError) means every "returns bool" method's
            # `except EfficientIPError` already catches this uniformly,
            # rather than each call site needing its own second except
            # clause for the same failure mode.
            if response.status_code >= 400:
                raise EfficientIPError(f"{service} failed: HTTP {response.status_code} (no error body)")
            return []

        if response.status_code >= 400:
            errmsg = self._extract_errmsg(data)
            raise EfficientIPError(f"{service} failed: {errmsg}")

        return data if isinstance(data, list) else [data]

    @staticmethod
    def _extract_errmsg(data: Any) -> str:
        """Pull a human-readable message out of a failed response's error envelope.

        Not every error has an `errmsg` - a malformed WHERE clause (e.g. an
        unescaped quote) instead returns `{"errno": "50028", "sql_error":
        "7", "severity": "error"}` with no errmsg at all, confirmed against
        a live instance. Falling back to "unknown error" for that case hid
        the real cause; dumping the whole error object instead keeps every
        future not-yet-seen error shape diagnosable without another
        investigation cycle.
        """
        if not (isinstance(data, list) and data):
            return str(data)
        error = data[0]
        if error.get("errmsg"):
            return str(error["errmsg"])
        return str(error)

    # ------------------------------------------------------------------ #
    # SOLIDserver-specific encoding helpers                                #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _ip_to_hex(ip_address: str) -> str:
        """Convert a dotted-decimal IPv4 address to SOLIDserver's internal hex form."""
        return format(int(ipaddress.IPv4Address(ip_address)), "08x")

    @staticmethod
    def decode_class_parameters(raw: str) -> Dict[str, str]:
        """Decode a SOLIDserver `<object>_class_parameters` blob into a flat dict.

        Public (unlike encode, which only the client itself ever needs for
        writes) - stale-record scanning reads this back from a listed
        record to check its marker class parameter, outside the client.
        """
        if not raw:
            return {}
        parsed = parse_qs(raw, keep_blank_values=True)
        return {k: v[0] if v else "" for k, v in parsed.items()}

    @staticmethod
    def _encode_class_parameters(params: Dict[str, str]) -> str:
        """Encode a flat dict into a SOLIDserver `<object>_class_parameters` blob."""
        return urlencode(params)

    @staticmethod
    def _escape_where(value: str) -> str:
        """Escape a value for safe interpolation into a SOLIDserver WHERE clause.

        SOLIDserver's WHERE syntax uses standard SQL single-quote escaping
        (double the quote) - confirmed against a live instance: an
        unescaped literal single quote in a value (e.g. LVI's ASA interface
        names, which look like "Adaptive Security Appliance 'Ethernet0/0'
        interface") breaks the WHERE clause entirely (errno 50028,
        sql_error 7), while doubling the quote parses correctly. Every
        WHERE clause built from a free-text name (device/interface/folder/
        domain name) needs this - IDs and hex-encoded IPs/MACs don't, since
        they can't contain a quote.
        """
        return value.replace("'", "''")

    # ------------------------------------------------------------------ #
    # Connection                                                           #
    # ------------------------------------------------------------------ #

    def test_connection(self) -> bool:
        """Test connectivity to the SOLIDserver instance."""
        try:
            self._request("GET", "ip_site_list", params={"limit": 1})
            return True
        except Exception as e:
            logger.error("EfficientIP connection test failed: %s", e)
            return False

    # ------------------------------------------------------------------ #
    # IP spaces (sites)                                                    #
    # ------------------------------------------------------------------ #

    def get_spaces(self) -> List[Dict[str, Any]]:
        """Return all IP spaces (SOLIDserver "sites")."""
        return self._request("GET", "ip_site_list")

    def create_space(self, name: str) -> Optional[str]:
        """Create an IP space (site). Returns its new site_id, or None on failure.

        Verified against a live appliance: ``ip_site_add`` with ``site_name``
        creates the space and returns its ``ret_oid``. Called with no
        parameters the appliance answers ``errno 4`` naming
        ``site_id/site_name`` - ``site_id`` updates an existing space,
        ``site_name`` creates one - which is how the parameter was confirmed
        rather than inferred from the other ``_add`` services.

        Deleting a space needs the ``DELETE`` verb on ``ip_site_delete``
        specifically (confirmed live), the same deviation from this API's
        usual POST-for-everything convention that VRF objects have - see
        the app repo's EFFICIENTIP_VRF_INVESTIGATION.md. No delete_space()
        is exposed here because nothing in the plugin removes a space; the
        note is recorded so the next person does not have to rediscover it.

        A failure is logged and returns None, so the caller skips that
        partition rather than writing anywhere unexpected.
        """
        try:
            result = self._request("POST", "ip_site_add", params={"site_name": name})
            return result[0].get("ret_oid") if result else None
        except EfficientIPError as e:
            logger.warning("Failed to create IP space %s: %s", name, e)
            return None

    def get_space_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        """Return one IP space by name, or None if not found."""
        results = self._request("GET", "ip_site_list", params={"WHERE": f"site_name='{self._escape_where(name)}'"})
        return results[0] if results else None

    # ------------------------------------------------------------------ #
    # Subnets                                                              #
    # ------------------------------------------------------------------ #

    def get_subnets(self, site_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Return all terminal subnets (excludes blocks), optionally filtered to one IP space.

        Blocks and subnets are the same underlying object and both report
        ``type: "subnet"`` in ip_block_subnet_list - that field does NOT
        distinguish them (confirmed against a live instance). The real
        distinguishing field is ``is_terminal``: ``"1"`` for an assignable
        leaf subnet, ``"0"`` for a block that only contains child subnets.
        """
        where = "is_terminal='1'"
        if site_id:
            where += f" AND site_id='{site_id}'"
        return self._request("GET", "ip_block_subnet_list", params={"WHERE": where})

    def get_blocks(self, site_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Return all IP blocks (excludes terminal subnets), optionally filtered to one IP space."""
        where = "is_terminal='0'"
        if site_id:
            where += f" AND site_id='{site_id}'"
        return self._request("GET", "ip_block_subnet_list", params={"WHERE": where})

    @staticmethod
    def _find_most_specific(ip_address: str, candidates: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """Return the most specific (largest prefix length) of *candidates* containing *ip_address*."""
        ip = ipaddress.IPv4Address(ip_address)
        matches = []
        for candidate in candidates:
            try:
                network = ipaddress.IPv4Network(
                    f"{candidate['start_hostaddr']}/{candidate['subnet_prefix']}", strict=False
                )
            except (KeyError, ValueError):
                continue
            if ip in network:
                matches.append((network.prefixlen, candidate))
        if not matches:
            return None
        return max(matches, key=lambda m: m[0])[1]

    def clear_topology_cache(self, site_id: Optional[str] = None) -> None:
        """Drop the cached subnet/block lists for *site_id* (or every space when None).

        Called after creating a subnet or block so the new object is
        visible to the next find_*_for_ip() lookup - _resolve_subnet_id()
        in the sync engine relies on exactly that, creating a subnet and
        then immediately looking it back up to read its subnet_id.
        """
        if site_id is None:
            self._subnet_cache.clear()
            self._block_cache.clear()
        else:
            self._subnet_cache.pop(site_id, None)
            self._block_cache.pop(site_id, None)

    def find_subnet_for_ip(self, ip_address: str, site_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Return the most specific terminal subnet containing *ip_address*, or None.

        The per-space subnet list is fetched once and cached (see
        __init__) - this is called once per device, and previously
        re-pulled every subnet in the space each time.
        """
        key = site_id or ""
        if key not in self._subnet_cache:
            self._subnet_cache[key] = self.get_subnets(site_id=site_id)
        return self._find_most_specific(ip_address, self._subnet_cache[key])

    def find_block_for_ip(self, ip_address: str, site_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Return the most specific IP block containing *ip_address*, or None.

        Cached per space, same as find_subnet_for_ip().
        """
        key = site_id or ""
        if key not in self._block_cache:
            self._block_cache[key] = self.get_blocks(site_id=site_id)
        return self._find_most_specific(ip_address, self._block_cache[key])

    def create_subnet(self, cidr: str, site_id: str, name: str = "") -> bool:
        """Create a subnet in the given IP space. Returns True on success.

        SOLIDserver requires the subnet to fall within an existing IP block
        (address space must be pre-provisioned) - this fails with a clear
        error (errno 5001, "Subnet is not in a block") when no covering
        block exists. Callers that also want to auto-create a covering
        block should call create_block() first - see create_block().
        """
        network = ipaddress.IPv4Network(cidr, strict=False)
        params = {
            "site_id": site_id,
            "subnet_addr": str(network.network_address),
            "subnet_prefix": str(network.prefixlen),
            "subnet_name": name or str(network),
        }
        try:
            self._request("POST", "ip_subnet_add", params=params)
            self.clear_topology_cache(site_id)
            return True
        except EfficientIPError as e:
            logger.warning("Failed to create subnet %s: %s", cidr, e)
            return False

    def create_block(self, cidr: str, site_id: str, name: str = "") -> bool:
        """Create an IP block in the given IP space. Returns True on success.

        Same request shape as create_subnet() (SOLIDserver's block and
        subnet objects share the ip_block_subnet_list/ip_subnet_add family)
        but posted to ip_block_add - confirmed against a live instance to
        create a non-terminal parent (is_terminal="0") that a subsequent
        create_subnet() call can nest under.
        """
        network = ipaddress.IPv4Network(cidr, strict=False)
        params = {
            "site_id": site_id,
            "subnet_addr": str(network.network_address),
            "subnet_prefix": str(network.prefixlen),
            "subnet_name": name or str(network),
        }
        try:
            self._request("POST", "ip_block_add", params=params)
            self.clear_topology_cache(site_id)
            return True
        except EfficientIPError as e:
            logger.warning("Failed to create block %s: %s", cidr, e)
            return False

    # ------------------------------------------------------------------ #
    # Addresses                                                            #
    # ------------------------------------------------------------------ #

    def find_address(self, ip_address: str, site_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Return an existing IP address record, or None if not registered."""
        where = f"ip_addr='{self._ip_to_hex(ip_address)}'"
        if site_id:
            where += f" AND site_id='{site_id}'"
        results = self._request("GET", "ip_address_list", params={"WHERE": where})
        return results[0] if results else None

    def find_address_by_mac(self, mac_address: str, site_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Return the first existing IP address record matching *mac_address*, or None.

        Unlike ip_addr, mac_addr is stored exactly as submitted (no hex
        encoding) - confirmed against a live instance: writing
        "aa:bb:cc:dd:ee:ff" via create_or_update_address is retrievable with
        an identical WHERE clause, no conversion needed.
        """
        results = self.find_addresses_by_mac(mac_address, site_id=site_id)
        return results[0] if results else None

    def find_addresses_by_mac(self, mac_address: str, site_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Return every existing IP address record matching *mac_address* (plural).

        Used to detect the same MAC already assigned to a different address
        record - a single find_address_by_mac() lookup would miss a second
        or third match.
        """
        where = f"mac_addr='{mac_address}'"
        if site_id:
            where += f" AND site_id='{site_id}'"
        return self._request("GET", "ip_address_list", params={"WHERE": where})

    def create_or_update_address(
        self,
        ip_address: str,
        site_id: str,
        subnet_id: Optional[str] = None,
        hostname: str = "",
        mac_address: str = "",
        class_parameters: Optional[Dict[str, str]] = None,
    ) -> bool:
        """Create or update an IP address record (ip_add is an upsert). Returns True on success.

        Passing *subnet_id* is what links the address to its containing
        subnet - without it, SOLIDserver still creates the record under the
        site but leaves it unassociated with any subnet, where it shows up
        under "Orphan Addresses" in the UI.
        """
        params: Dict[str, Any] = {
            "site_id": site_id,
            "hostaddr": ip_address,
        }
        if subnet_id:
            params["subnet_id"] = subnet_id
        if hostname:
            params["name"] = hostname
        if mac_address:
            params["mac_addr"] = mac_address
        if class_parameters:
            params["ip_class_parameters"] = self._encode_class_parameters(class_parameters)
        try:
            self._request("POST", "ip_add", params=params)
            return True
        except EfficientIPError as e:
            logger.warning("Failed to create/update address %s: %s", ip_address, e)
            return False

    def get_addresses(self, site_id: str) -> List[Dict[str, Any]]:
        """Return every IP address record in *site_id* (one IP space)."""
        return self._request("GET", "ip_address_list", params={"WHERE": f"site_id='{site_id}'"})

    def delete_address(self, ip_id: str) -> bool:
        """Delete an IP address record by its own ip_id. Returns True on success.

        Uses DELETE, not POST - matching the verb every other delete
        service on this appliance needs (ip_site_delete, nom_netobj_delete,
        nom_iface_delete). Confirmed live: calling ip_delete with no
        parameters names ip_id/hostaddr as accepted, ip_id used here since
        callers already have it from a prior list/find call.
        """
        try:
            self._request("DELETE", "ip_delete", params={"ip_id": ip_id})
            return True
        except EfficientIPError as e:
            logger.warning("Failed to delete address %s: %s", ip_id, e)
            return False

    # ------------------------------------------------------------------ #
    # NOM (Network Object Manager) - folders, devices, interfaces/ports    #
    # ------------------------------------------------------------------ #

    def get_nom_folder_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        """Return one NOM folder by exact name, or None if not found."""
        results = self._request(
            "GET", "nom_folder_list", params={"WHERE": f"nomfolder_name='{self._escape_where(name)}'"}
        )
        return results[0] if results else None

    def create_nom_folder(self, name: str, site_name: str = "") -> Optional[str]:
        """Create a NOM folder. Returns its new nomfolder_id, or None on failure."""
        params: Dict[str, Any] = {"nomfolder_name": name}
        if site_name:
            params["nomfolder_site_name"] = site_name
        try:
            result = self._request("POST", "nom_folder_add", params=params)
            return result[0].get("ret_oid") if result else None
        except EfficientIPError as e:
            logger.warning("Failed to create NOM folder %s: %s", name, e)
            return None

    def find_network_object(self, folder_id: str, name: str) -> Optional[Dict[str, Any]]:
        """Return one NOM network object (device) by name within *folder_id*, or None."""
        where = f"nomfolder_id='{folder_id}' AND nomnetobj_name='{self._escape_where(name)}'"
        results = self._request("GET", "nom_netobj_list", params={"WHERE": where})
        return results[0] if results else None

    def get_network_objects(self, folder_id: str) -> List[Dict[str, Any]]:
        """Return every NOM network object (device) in *folder_id*."""
        return self._request("GET", "nom_netobj_list", params={"WHERE": f"nomfolder_id='{folder_id}'"})

    def delete_network_object(self, netobj_id: str) -> bool:
        """Delete a NOM network object (device) by ID. Returns True on success.

        Uses DELETE, matching nom_iface_delete's verb - confirmed live:
        calling nom_netobj_delete with no parameters names
        nomnetobj_id/nomnetobj_name as accepted, nomnetobj_id used here
        since callers already have it from a prior list/find call.
        """
        try:
            self._request("DELETE", "nom_netobj_delete", params={"nomnetobj_id": netobj_id})
            return True
        except EfficientIPError as e:
            logger.warning("Failed to delete NOM device %s: %s", netobj_id, e)
            return False

    def _clamp_nom_type(self, type_: str) -> str:
        """Trim a device type to what SOLIDserver's nomnetobj_type field accepts.

        SOLIDserver rejects the entire nom_netobj_add call when this field
        exceeds 16 characters (errno 10, "Parameter size too long"), so
        passing a longer LogicVein deviceType straight through meant losing
        the device from NOM completely. Stock LogicVein types that exceed
        it include "Wireless Controller" (19).

        The field is free text on this appliance - "Router"/"Switch" and
        anything else short enough are all accepted as-is - so trimming is
        safe and keeps the device (and its interfaces) syncing. Trailing
        whitespace from the cut is removed, so "Wireless Access Point"
        becomes "Wireless Access" rather than "Wireless Access " with a
        dangling space ("Wireless Controller" needs no such trim - it cuts
        mid-word, to "Wireless Control").

        Warned once per distinct value per client (one sync run) rather
        than once per device, which would otherwise repeat the same line
        for every device of that type.
        """
        if len(type_) <= _NOM_TYPE_MAX_LEN:
            return type_
        clamped = type_[:_NOM_TYPE_MAX_LEN].rstrip()
        if type_ not in self._warned_long_nom_types:
            self._warned_long_nom_types.add(type_)
            logger.warning(
                "Device type '%s' exceeds SOLIDserver's %d-character NOM type limit - "
                "syncing it as '%s' (the device would otherwise fail to sync at all)",
                type_,
                _NOM_TYPE_MAX_LEN,
                clamped,
            )
        return clamped

    def create_network_object(
        self,
        folder_id: str,
        name: str,
        type_: str = "",
        state: str = "",
        class_parameters: Optional[Dict[str, str]] = None,
    ) -> Optional[str]:
        """Create a NOM network object (device). Returns its new nomnetobj_id, or None on failure.

        *type_* is trimmed to SOLIDserver's 16-character limit if needed -
        see _clamp_nom_type().
        """
        params: Dict[str, Any] = {"nomfolder_id": folder_id, "nomnetobj_name": name}
        if type_:
            params["nomnetobj_type"] = self._clamp_nom_type(type_)
        if state:
            params["nomnetobj_state"] = state
        if class_parameters:
            params["nomnetobj_class_parameters"] = self._encode_class_parameters(class_parameters)
        try:
            result = self._request("POST", "nom_netobj_add", params=params)
            return result[0].get("ret_oid") if result else None
        except EfficientIPError as e:
            logger.warning("Failed to create NOM device %s: %s", name, e)
            return None

    def update_network_object(
        self,
        netobj_id: str,
        type_: str = "",
        state: str = "",
        class_parameters: Optional[Dict[str, str]] = None,
        name: str = "",
    ) -> bool:
        """Update an existing NOM network object (device) by ID. Returns True on success.

        Uses PUT, not POST - see the module docstring's NOM section for why
        (nom_netobj_add has no upsert; POST always means create).

        *name*, when given, renames the device (nomnetobj_name) - confirmed
        live this works via the same PUT. Only sent when non-empty; a
        normal update (no rename) omits it.
        """
        params: Dict[str, Any] = {"nomnetobj_id": netobj_id}
        if type_:
            params["nomnetobj_type"] = self._clamp_nom_type(type_)
        if state:
            params["nomnetobj_state"] = state
        if class_parameters:
            params["nomnetobj_class_parameters"] = self._encode_class_parameters(class_parameters)
        if name:
            params["nomnetobj_name"] = name
        try:
            self._request("PUT", "nom_netobj_add", params=params)
            return True
        except EfficientIPError as e:
            logger.warning("Failed to update NOM device %s: %s", netobj_id, e)
            return False

    def find_interface(self, netobj_id: str, port_mac: str) -> Optional[Dict[str, Any]]:
        """Return one NOM interface by its port MAC on *netobj_id*, or None.

        Keyed on MAC, not port name - confirmed against a live instance
        that MAC is SOLIDserver's real per-device uniqueness constraint for
        a port (errno 82026 if violated), while a port's *name* is not
        stable identity at all: LVI can report a different display name
        for the same physical port/MAC across syncs (seen in production -
        a device's port went from one verbose name to another between
        runs). Looking this up by the old name-based key missed the
        existing row and tried to create a new one with an already-claimed
        MAC, failing every time. MAC values are colon-hex and never need
        WHERE-escaping.
        """
        where = f"nomnetobj_id='{netobj_id}' AND nomiface_port_mac='{port_mac}'"
        results = self._request("GET", "nom_iface_list", params={"WHERE": where})
        return results[0] if results else None

    def delete_interface(self, iface_id: str) -> bool:
        """Delete a NOM interface (and its port). Returns True on success.

        Uses DELETE, not POST - matching the verb NOM's other delete
        services need (nom_netobj_delete/nom_folder_delete), confirmed
        against a live instance. See update_interface()'s docstring for
        why a caller would delete-then-recreate rather than update.
        """
        try:
            self._request("DELETE", "nom_iface_delete", params={"nomiface_id": iface_id})
            return True
        except EfficientIPError as e:
            logger.warning("Failed to delete NOM interface %s: %s", iface_id, e)
            return False

    def create_interface(
        self,
        netobj_id: str,
        iface_name: str,
        port_name: str,
        port_mac: str,
        hostaddr: str = "",
        vlan_domain: str = "",
        vlan_number: str = "",
        is_main: bool = False,
    ) -> bool:
        """Create a NOM interface (and its port, in the same call) on a device. Returns True on success.

        is_main and hostaddr are always sent (not conditionally omitted
        like the other fields) since "0"/empty is a real, meaningful value
        for both on a fresh create. Clearing an *existing* interface's
        hostaddr back to empty needs delete_interface() + create_interface()
        instead of update_interface() - see update_interface()'s docstring.
        """
        params: Dict[str, Any] = {
            "nomnetobj_id": netobj_id,
            "nomiface_name": iface_name,
            "nomiface_port_name": port_name,
            "nomiface_port_mac": port_mac,
            "nomiface_main": "1" if is_main else "0",
            "nomiface_hostaddr": hostaddr,
        }
        if vlan_domain:
            params["nomiface_vlan_domain"] = vlan_domain
        if vlan_number:
            params["nomiface_vlan_number"] = vlan_number
        try:
            self._request("POST", "nom_iface_add", params=params)
            return True
        except EfficientIPError as e:
            logger.warning("Failed to create NOM interface %s on device %s: %s", port_name, netobj_id, e)
            return False

    def update_interface(
        self,
        iface_id: str,
        iface_name: str = "",
        port_name: str = "",
        port_mac: str = "",
        hostaddr: str = "",
        vlan_domain: str = "",
        vlan_number: str = "",
        is_main: bool = False,
    ) -> bool:
        """Update an existing NOM interface by ID. Returns True on success.

        Uses PUT, not POST - see the module docstring's NOM section.

        iface_name and port_name are two separate SOLIDserver fields
        (nomiface_name/nomiface_port_name) - both need sending to actually
        rename a port whose display name changed in LVI while its MAC (the
        real lookup key - see find_interface()) stayed the same; confirmed
        live that PUT-ing only one leaves the other stale.

        is_main clears correctly this way (confirmed against a live
        instance: PUT nomiface_main=0 while hostaddr stays set works
        fine) - but hostaddr does NOT: PUT-ing an empty nomiface_hostaddr
        onto an interface that already has one returns 201 but silently
        leaves the old value in place, confirmed empirically. Callers
        needing to actually clear a previously-set hostaddr (or VLAN -
        see _sync_device_to_nom) must delete_interface() +
        create_interface() instead; this method still always sends
        hostaddr for the normal case (changing between two non-empty
        values, which does work via PUT).

        Also confirmed: NOM rejects nomiface_main=1 on an interface with
        no IP (errno 82029, "An interface without IP cannot be set as
        main") - never call this with is_main=True and hostaddr="" together.
        """
        params: Dict[str, Any] = {
            "nomiface_id": iface_id,
            "nomiface_main": "1" if is_main else "0",
            "nomiface_hostaddr": hostaddr,
        }
        if iface_name:
            params["nomiface_name"] = iface_name
        if port_name:
            params["nomiface_port_name"] = port_name
        if port_mac:
            params["nomiface_port_mac"] = port_mac
        if vlan_domain:
            params["nomiface_vlan_domain"] = vlan_domain
        if vlan_number:
            params["nomiface_vlan_number"] = vlan_number
        try:
            self._request("PUT", "nom_iface_add", params=params)
            return True
        except EfficientIPError as e:
            logger.warning("Failed to update NOM interface %s: %s", iface_id, e)
            return False

    def get_interfaces_for_netobj(self, netobj_id: str) -> List[Dict[str, Any]]:
        """Return every NOM interface belonging to one network object."""
        return self._request("GET", "nom_iface_list", params={"WHERE": f"nomnetobj_id='{netobj_id}'"})

    def set_interface_connection(self, nomiface_id: str, connected_port_id: str) -> bool:
        """Link (or clear) one interface's NOM "connected port". Returns True on success.

        Uses the same nom_iface_add PUT update_interface() does, with just
        connected_port_id added - there's no dedicated connect service.
        macro_connect_nom_ports.php (found in service_list) is a
        notif_-prefixed internal hook, not a callable REST endpoint
        (confirmed live: calling it directly 400s the same way as a
        genuinely nonexistent service, unlike a real service's JSON error
        body). Confirmed live this write is automatically bidirectional -
        the other port's own connected_port_id updates without a second call.

        Does NOT reliably clear a port's previous connection when reassigned
        to a different one - this docstring previously claimed it did,
        "confirmed live". Disproven live in production: a port with a real,
        pre-existing connection to device D was targeted at three other
        devices in one run (a stale-neighbor-data situation - see
        LogicVeinEfficientIPSync._sync_nom_connections()'s docstring), and
        every one of the three failed with errno 82017 ("The port is
        already connected to another port") while the connection to D was
        still there afterwards - not cleared, not replaced. Reassigning a
        connected port to a genuinely different one may need this port
        explicitly cleared first (pass "0" as *connected_port_id*) before
        setting the new value; that two-step path has not been verified
        live. Callers that only want to establish a link where none
        conflicts should check the port's current connected_port_id (from
        get_interfaces_for_netobj()) before calling this, as
        _sync_nom_connections() now does, rather than rely on this call to
        sort it out.

        Pass "0" to clear, not "" - confirmed live that an empty string is
        rejected outright (errno 12, "Bad parameter format", requires
        "integer >= 0"), unlike hostaddr/VLAN this needs no delete+recreate
        workaround.
        """
        try:
            self._request(
                "PUT", "nom_iface_add", params={"nomiface_id": nomiface_id, "connected_port_id": connected_port_id}
            )
            return True
        except EfficientIPError as e:
            logger.warning("Failed to set NOM interface connection for %s: %s", nomiface_id, e)
            return False

    def get_vlan_domain_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        """Return one VLAN Domain (VLAN Manager module) by exact name, or None if not found."""
        results = self._request(
            "GET", "vlmdomain_list", params={"WHERE": f"vlmdomain_name='{self._escape_where(name)}'"}
        )
        return results[0] if results else None

    def create_vlan_domain(self, name: str) -> Optional[str]:
        """Create a VLAN Domain with the default VLAN ID range (1-4094). Returns its new vlmdomain_id, or None."""
        try:
            result = self._request("POST", "vlm_domain_add", params={"vlmdomain_name": name})
            return result[0].get("ret_oid") if result else None
        except EfficientIPError as e:
            logger.warning("Failed to create VLAN domain %s: %s", name, e)
            return None

    def get_vlan_range_by_name(self, domain_name: str, range_name: str) -> Optional[Dict[str, Any]]:
        """Return one VLAN Range (VLAN Manager module) by domain + exact name, or None if not found."""
        where = (
            f"vlmdomain_name='{self._escape_where(domain_name)}' AND vlmrange_name='{self._escape_where(range_name)}'"
        )
        results = self._request("GET", "vlmrange_list", params={"WHERE": where})
        return results[0] if results else None

    def create_vlan_range(
        self, domain_name: str, range_name: str, start_vlan_id: int = 1, end_vlan_id: int = 4094
    ) -> Optional[str]:
        """Create a VLAN Range within a VLAN Domain, permitting overlap with any existing range.

        SOLIDserver allows multiple Ranges to cover the same VLAN ID span
        within one Domain (a real, intentional feature - confirmed live: the
        appliance already had two ranges both spanning 1-4094). Creating a
        new Range that overlaps an existing one is rejected (errno 6018,
        "VLAN Range overlap") *unless the new Range itself* sets
        vlmrange_disable_overlapping=0 - confirmed live this is required
        even when the existing overlapping Range already has
        disable_overlapping=0 itself; the check is against the Range being
        created, not the ones already there. Returns the new vlmrange_id,
        or None on failure.
        """
        params: Dict[str, Any] = {
            "vlmdomain_name": domain_name,
            "vlmrange_name": range_name,
            "vlmrange_start_vlan_id": str(start_vlan_id),
            "vlmrange_end_vlan_id": str(end_vlan_id),
            "vlmrange_disable_overlapping": "0",
        }
        try:
            result = self._request("POST", "vlm_range_add", params=params)
            return result[0].get("ret_oid") if result else None
        except EfficientIPError as e:
            logger.warning("Failed to create VLAN range %s in domain %s: %s", range_name, domain_name, e)
            return None

    def get_vlan_by_number(self, domain_name: str, range_name: str, vlan_id: str) -> Optional[Dict[str, Any]]:
        """Return one VLAN Manager VLAN by domain + range + VLAN ID, or None if not found."""
        where = (
            f"vlmdomain_name='{self._escape_where(domain_name)}' AND "
            f"vlmrange_name='{self._escape_where(range_name)}' AND vlmvlan_vlan_id='{vlan_id}'"
        )
        results = self._request("GET", "vlmvlan_list", params={"WHERE": where})
        return results[0] if results else None

    def create_vlan(self, domain_name: str, range_name: str, vlan_id: str, name: str = "") -> Optional[str]:
        """Register a VLAN ID as a real VLAN Manager object within a Range. Returns the new
        vlmvlan_id, or None on failure.

        vlmrange_name (or _id) is a *required* parameter of vlm_vlan_add -
        confirmed live: since multiple Ranges can overlap the same VLAN ID
        space within a Domain, SOLIDserver has no way to infer which Range a
        bare VLAN ID belongs to. Writing nomiface_vlan_number directly onto
        a NOM interface (create_interface()/update_interface() above) does
        NOT create or validate against a vlmvlan object at all - confirmed
        live, it's a free-text field with no linkage - so this method is
        what actually makes a synced VLAN show up in VLAN Manager's own
        inventory rather than existing only as a label on the interface.
        """
        params: Dict[str, Any] = {
            "vlmdomain_name": domain_name,
            "vlmrange_name": range_name,
            "vlmvlan_vlan_id": str(vlan_id),
        }
        if name:
            params["vlmvlan_name"] = name
        try:
            result = self._request("POST", "vlm_vlan_add", params=params)
            return result[0].get("ret_oid") if result else None
        except EfficientIPError as e:
            logger.warning("Failed to create VLAN %s in range %s/%s: %s", vlan_id, domain_name, range_name, e)
            return None

    def get_vrf_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        """Return one VRF (VRF module) by exact name, or None if not found."""
        results = self._request(
            "GET", "vrfobject_list", params={"WHERE": f"vrfobject_name='{self._escape_where(name)}'"}
        )
        return results[0] if results else None

    def create_vrf(self, name: str) -> Optional[str]:
        """Create a VRF with an auto-assigned route distinguisher. Returns the new
        vrfobject_id, or None on failure.

        vrfobject_name is the only required parameter - confirmed live,
        SOLIDserver assigns vrfobject_rd_id itself when omitted. This only
        creates the VRF catalog entry (VRF > VRFs in the GUI); there is no
        field or Class Studio bridge anywhere (IP space, subnet, address,
        NOM interface/device) to attach it to an object on this appliance -
        see docs/dev_notes/EFFICIENTIP_VRF_INVESTIGATION.md in the app repo.
        """
        try:
            result = self._request("POST", "vrf_vrfobject_add", params={"vrfobject_name": name})
            return result[0].get("ret_oid") if result else None
        except EfficientIPError as e:
            logger.warning("Failed to create VRF %s: %s", name, e)
            return None
