"""LogicVein -> phpIPAM inventory sync.

Syncs each LVI device's management IP into a phpIPAM Address, within a
Subnet resolved (or, if enabled, auto-created) under one configured Section
(also resolved, or if enabled, auto-created) - optionally partitioned into
a nested child Section (see ``section_partition.py``). Also optionally
strips the domain suffix from device names, and syncs VRF/VLAN onto the
resolved Subnet (phpIPAM has no per-Address VRF/VLAN field - both are
Subnet-scoped, coarser than a per-device model but the only one phpIPAM's
own object model supports). No interface IPs or the phpIPAM Devices object
- see ``docs/dev_notes/PHPIPAM_PLUGIN_PLAN.md`` in the sibling app repo for
the full API reference and why those remain out of scope.

One thing must always already exist in phpIPAM before this plugin's first
run - it is not creatable via the API, so :meth:`LogicVeinPhpIpamSync.sync`
fails fast with an actionable message rather than silently degrading:

- A ``lvi_managed`` custom field on Addresses (Administration -> Custom
  fields -> Custom IP addresses fields), the marker this plugin's stale-
  address cleanup uses to scope deletion to records it actually owns.

The target Section (``phpipam.section_name``) also fails fast by default
if missing, but can instead be auto-created via
``phpipam.create_missing_sections`` (off by default) - phpIPAM's API does
support creating a Section, confirmed against its own API reference
after this plugin originally shipped believing otherwise; see
:meth:`plugins.phpipam.client.PhpIpamClient.create_section`'s docstring.
"""

import ipaddress
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Set, Tuple

# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import (  # pyright: ignore[reportMissingImports]
    CancellableSync,
    DeviceSyncOutcome,
    SyncReport,
    build_mac_lookup,
    get_vendor_name,
    mac_for,
    normalize_networks,
    pending_conflict_item,
    prefetch_device_interfaces,
    record_pending_conflicts,
    resolve_display_name,
    resolve_prefetch_networks,
)

from . import section_partition as sp
from .client import MARKER_FIELD, PhpIpamApiError, PhpIpamClient

logger = logging.getLogger(__name__)

PLUGIN_NAME = "phpipam"

# Vendor spellings of the global routing table, folded onto one configured
# name so a device's VRF doesn't need one mapping entry per platform. Same
# list, same caveats, as EfficientIP's DEFAULT_GLOBAL_VRF_ALIASES (see
# plugins/efficientip/space_partition.py's own comment for the full vendor
# citation) - unvalidated against real phpIPAM-target VRF data for the same
# reason: the lab had no VRF-bearing devices when this was written. Every
# run's log reports the distinct vrfName values actually seen and which
# were folded - check new deployments against that rather than assuming
# this list is complete.
DEFAULT_GLOBAL_VRF_ALIASES = ("default", "master", "base", "_public_", "global", "grt", "0", "mgmt-vrf", "management")


def _normalize_vrf(vrf: str, aliases: List[str], global_name: str) -> str:
    """Fold a vendor's name for the global routing table onto *global_name*.

    Matching is case-insensitive and whitespace-trimmed. A blank *vrf*
    (LogicVein reports null for a device with no VRF, the common case)
    also returns *global_name*.

    Args:
        vrf: The raw VRF name as reported by LogicVein.
        aliases: Vendor spellings of the global routing table to fold.
        global_name: The name to fold matches (and blanks) onto.

    Returns:
        The normalized VRF name.
    """
    cleaned = (vrf or "").strip()
    if not cleaned:
        return global_name
    if cleaned.casefold() in {a.strip().casefold() for a in aliases if a and a.strip()}:
        return global_name
    return cleaned


def _subnet_contains(ip_address: str, subnet: str, mask: str) -> bool:
    """Whether *ip_address* falls inside the CIDR *subnet*/*mask*.

    Args:
        ip_address: The IP address to test.
        subnet: The subnet's network address.
        mask: The subnet's prefix length.

    Returns:
        True if the address is inside the subnet.
    """
    try:
        return ipaddress.ip_address(ip_address) in ipaddress.ip_network(f"{subnet}/{mask}", strict=False)
    except ValueError:
        return False


def _derive_subnet_cidr(ip_address: str, prefix_len: int) -> Tuple[str, str]:
    """Derive the containing network address/mask for *ip_address* at *prefix_len*.

    Args:
        ip_address: The IP address to derive a covering subnet for.
        prefix_len: The desired prefix length.

    Returns:
        (network_address, mask) as strings, ready for create_subnet().
    """
    network = ipaddress.ip_network(f"{ip_address}/{prefix_len}", strict=False)
    return str(network.network_address), str(network.prefixlen)


class LogicVeinPhpIpamSync(CancellableSync):
    """Sync LVI device management IPs into phpIPAM addresses."""

    def __init__(self, lvi_client: Any, target_client: PhpIpamClient, config: Dict[str, Any]) -> None:
        """Store the clients and flat config dict build_sync_config() produced.

        Args:
            lvi_client: LogicVein API client instance.
            target_client: PhpIpamClient instance.
            config: Flat config dict from PhpIpamPlugin.build_sync_config().
        """
        self.lvi = lvi_client
        self.client = target_client
        self.config = config or {}

        self.dry_run = bool(self.config.get("dry_run", False))
        self.continue_on_error = bool(self.config.get("continue_on_error", True))
        self.networks = normalize_networks(self.config.get("network", "Default"))
        self.section_name = str(self.config.get("section_name", ""))
        self.create_missing_sections = bool(self.config.get("create_missing_sections", False))
        self.sync_mac_address = bool(self.config.get("sync_mac_address", True))
        self.create_missing_subnets = bool(self.config.get("create_missing_subnets", False))
        self.default_subnet_mask = int(self.config.get("default_subnet_mask", 24))
        self.delete_stale_ips = bool(self.config.get("delete_stale_ips", False))
        self.ip_conflict_policy = str(self.config.get("ip_conflict_policy", "ask"))
        self.mac_conflict_policy = str(self.config.get("mac_conflict_policy", "ask"))
        self.strip_domain_from_names = bool(self.config.get("strip_domain_from_names", True))
        self.sync_vrfs = bool(self.config.get("sync_vrfs", False))
        self.default_vrf_name = str(self.config.get("default_vrf_name", "default"))
        self.global_vrf_aliases = list(self.config.get("global_vrf_aliases") or DEFAULT_GLOBAL_VRF_ALIASES)
        self.section_partition_by = str(self.config.get("section_partition_by", "none"))
        self.section_mapping = dict(self.config.get("section_mapping") or {})
        self.sync_vlans = bool(self.config.get("sync_vlans", False))
        self.vlan_domain_name = str(self.config.get("vlan_domain_name", "Default"))
        self.create_missing_vlan_domain = bool(self.config.get("create_missing_vlan_domain", True))

        self.last_report: Optional[SyncReport] = None
        self._outcomes: List[DeviceSyncOutcome] = []
        self._pending_items: List[Dict[str, Any]] = []

        # Per-run caches - see the corresponding _ensure_*/_resolve_* methods.
        self._section_cache: Dict[str, Tuple[str, List[Dict[str, Any]]]] = {}
        self._vrf_ids_by_name: Dict[str, str] = {}
        self._vlan_domain_id: Optional[str] = None
        self._vlan_ids_by_number: Dict[str, str] = {}

    # ------------------------------------------------------------------ #
    # Entry point                                                          #
    # ------------------------------------------------------------------ #

    def sync(self) -> bool:
        """Run one sync. Return True if every device synced without error.

        Returns:
            True on success, False if any device errored or a run-level
            precondition (missing section/custom field) failed.
        """
        started_at = datetime.now(timezone.utc).isoformat()
        self._outcomes = []
        self._pending_items = []
        logger.info(
            "phpIPAM sync starting: networks=%s section=%s dry_run=%s",
            self.networks or ["all"],
            self.section_name,
            self.dry_run,
        )

        try:
            custom_fields = self.client.get_custom_fields()
        except PhpIpamApiError as exc:
            return self._fail_run(started_at, f"Failed to check phpIPAM custom fields: {exc}")
        if MARKER_FIELD not in custom_fields:
            return self._fail_run(
                started_at,
                f"phpIPAM is missing the '{MARKER_FIELD}' custom field on Addresses - create it once via "
                "Administration > Custom fields > Custom IP addresses fields before enabling this sync "
                "(see docs/dev_notes/PHPIPAM_PLUGIN_PLAN.md).",
            )

        problems = sp.validate_config(self.section_partition_by, self.section_mapping, self.sync_vrfs)
        if problems:
            return self._fail_run(started_at, "Invalid phpIPAM section partitioning config: " + "; ".join(problems))

        try:
            section = self.client.get_section_by_name(self.section_name)
        except PhpIpamApiError as exc:
            return self._fail_run(started_at, f"Failed to look up phpIPAM section '{self.section_name}': {exc}")

        # A freshly-created (or dry-run-simulated) section cannot have any
        # subnets yet, so both branches below skip the real
        # get_subnets_in_section() call entirely rather than querying an
        # id that either doesn't exist yet (dry run) or was only just
        # created a moment ago (guaranteed empty either way).
        if section is None:
            if not self.create_missing_sections:
                return self._fail_run(
                    started_at,
                    f"phpIPAM section '{self.section_name}' not found - create it once via the phpIPAM UI "
                    "before enabling this sync, or turn on 'Create Missing Sections'.",
                )
            if self.dry_run:
                logger.info("[DRY RUN] Would create phpIPAM section '%s'", self.section_name)
                base_section_id = "dry-run-section"
            else:
                try:
                    base_section_id = self.client.create_section(
                        self.section_name, description="Created by LVI Sync Manager"
                    )
                except PhpIpamApiError as exc:
                    return self._fail_run(started_at, f"Failed to create phpIPAM section '{self.section_name}': {exc}")
            base_subnets: List[Dict[str, Any]] = []
        else:
            base_section_id = str(section["id"])
            try:
                base_subnets = self.client.get_subnets_in_section(base_section_id)
            except PhpIpamApiError as exc:
                return self._fail_run(
                    started_at, f"Failed to fetch phpIPAM subnets for section '{self.section_name}': {exc}"
                )
        self._section_cache[""] = (base_section_id, base_subnets)

        if self.sync_vlans:
            try:
                self._ensure_vlan_domain()
            except PhpIpamApiError as exc:
                return self._fail_run(started_at, f"Failed to resolve phpIPAM VLAN domain: {exc}")
            if self._vlan_domain_id is None:
                return self._fail_run(
                    started_at,
                    f"phpIPAM VLAN domain '{self.vlan_domain_name}' not found - create it once via the phpIPAM "
                    "UI before enabling Sync VLANs, or turn on 'Create Missing VLAN Domain'.",
                )

        try:
            tag_ids = self.client.get_address_tags()
        except PhpIpamApiError as exc:
            return self._fail_run(started_at, f"Failed to fetch phpIPAM address states: {exc}")
        used_tag_id = tag_ids.get("Used")

        devices: List[Dict[str, Any]] = self.lvi.search_devices_in_network(network=self.networks)
        logger.info("phpIPAM sync: %d device(s) from LVI", len(devices))

        mac_lookup: Dict[Tuple[str, str], str] = {}
        interfaces_by_key: Dict[Tuple[str, str], List[Dict[str, Any]]] = {}
        need_interfaces = (
            self.sync_mac_address or self.sync_vrfs or self.sync_vlans or sp.needs_vrf(self.section_partition_by)
        )
        if need_interfaces:
            prefetch_networks = resolve_prefetch_networks(self.networks, devices)
            interfaces_by_key = prefetch_device_interfaces(self.lvi, prefetch_networks)
            if self.sync_mac_address:
                mac_lookup = build_mac_lookup(interfaces_by_key)

        vrf_names_seen: Set[str] = set()
        errors = 0
        synced_ips: Set[str] = set()
        for device in devices:
            self._check_cancelled()
            ip_address = device.get("ipAddress", "")
            raw_hostname = device.get("hostname") or device.get("name") or ""
            if not ip_address:
                continue
            # phpIPAM looks addresses up by IP (search_address_by_ip), never
            # by name, so only the display_name half matters here - unlike a
            # target that looks objects up by name, there's no duplicate-
            # object risk from alt_name to guard against.
            hostname, _ = resolve_display_name(raw_hostname, self.strip_domain_from_names)

            mac_address = mac_for(mac_lookup, device) if self.sync_mac_address else ""

            vrf_name = ""
            if self.sync_vrfs or sp.needs_vrf(self.section_partition_by):
                vrf_name = _normalize_vrf(
                    self._device_vrf(interfaces_by_key, device), self.global_vrf_aliases, self.default_vrf_name
                )
                vrf_names_seen.add(vrf_name)

            try:
                section_id, subnets = self._resolve_section(base_section_id, base_subnets, device, vrf_name)
            except PhpIpamApiError as exc:
                errors += 1
                logger.error("Error resolving phpIPAM section for %s (%s): %s", ip_address, hostname, exc)
                self._outcomes.append(
                    DeviceSyncOutcome(ip_address=ip_address, hostname=hostname, action="error", error=str(exc))
                )
                if not self.continue_on_error:
                    break
                continue

            try:
                subnet_id = self._resolve_subnet(subnets, ip_address, section_id)
            except PhpIpamApiError as exc:
                errors += 1
                logger.error("Error resolving phpIPAM subnet for %s (%s): %s", ip_address, hostname, exc)
                self._outcomes.append(
                    DeviceSyncOutcome(ip_address=ip_address, hostname=hostname, action="error", error=str(exc))
                )
                if not self.continue_on_error:
                    break
                continue

            if self.sync_vrfs and vrf_name and subnet_id is not None:
                self._apply_vrf_to_subnet(subnets, subnet_id, vrf_name)

            if self.sync_vlans and subnet_id is not None:
                vlan_number = self._device_vlan_number(interfaces_by_key, device, ip_address)
                if vlan_number:
                    self._apply_vlan_to_subnet(subnets, subnet_id, vlan_number)

            ok = self._sync_one_device(ip_address, hostname, subnet_id, device, mac_address, used_tag_id)
            synced_ips.add(ip_address)
            if not ok:
                errors += 1
                if not self.continue_on_error:
                    break

        if vrf_names_seen:
            logger.info(
                "phpIPAM sync: distinct VRF names seen this run (post-normalization): %s", sorted(vrf_names_seen)
            )

        if self.delete_stale_ips and not self.dry_run:
            for section_id, subnets in self._section_cache.values():
                self._delete_stale_addresses(subnets, synced_ips)

        if self._pending_items and not self.dry_run:
            try:
                record_pending_conflicts(PLUGIN_NAME, self._pending_items)
            except Exception as exc:
                logger.warning("Failed to record pending conflicts: %s", exc)

        self.last_report = SyncReport(
            plugin_name=PLUGIN_NAME,
            started_at=started_at,
            finished_at=datetime.now(timezone.utc).isoformat(),
            dry_run=self.dry_run,
            outcomes=self._outcomes,
        )
        return errors == 0

    def _fail_run(self, started_at: str, message: str) -> bool:
        """Record a run-level failure (a precondition, not a per-device error).

        Args:
            started_at: The run's start timestamp.
            message: The failure to log and surface in the report.

        Returns:
            False, always - lets callers `return self._fail_run(...)`.
        """
        logger.error(message)
        self.last_report = SyncReport(
            plugin_name=PLUGIN_NAME,
            started_at=started_at,
            finished_at=datetime.now(timezone.utc).isoformat(),
            dry_run=self.dry_run,
            outcomes=[],
            run_errors=[message],
        )
        return False

    # ------------------------------------------------------------------ #
    # Subnet resolution                                                    #
    # ------------------------------------------------------------------ #

    def _resolve_subnet(self, subnets: List[Dict[str, Any]], ip_address: str, section_id: str) -> Optional[str]:
        """Find (or, if enabled, create) the Subnet containing *ip_address*.

        Args:
            subnets: The Section's subnets, mutated in place with any newly
                created subnet so later devices in this run reuse it.
            ip_address: The device's management IP.
            section_id: The target Section's id.

        Returns:
            The containing subnet's id, or None if none exists and
            create_missing_subnets is off.
        """
        for subnet in subnets:
            if _subnet_contains(ip_address, subnet["subnet"], subnet["mask"]):
                return str(subnet["id"])

        if not self.create_missing_subnets:
            return None

        network_str, mask_str = _derive_subnet_cidr(ip_address, self.default_subnet_mask)
        if self.dry_run:
            logger.info("[DRY RUN] Would create subnet %s/%s", network_str, mask_str)
            # A stable negative sentinel so per-device dry-run logic below
            # can treat this exactly like a real subnet id without ever
            # sending it to a write call - every write stays gated on
            # self.dry_run independently.
            sentinel_id = f"dry-run-{network_str}-{mask_str}"
            subnets.append({"id": sentinel_id, "subnet": network_str, "mask": mask_str})
            return sentinel_id

        new_id = self.client.create_subnet(network_str, mask_str, section_id, description="Created by LVI Sync Manager")
        subnets.append({"id": new_id, "subnet": network_str, "mask": mask_str})
        return new_id

    @staticmethod
    def _find_subnet(subnets: List[Dict[str, Any]], subnet_id: str) -> Optional[Dict[str, Any]]:
        """Look up a subnet dict by id in an already-fetched subnets list."""
        for subnet in subnets:
            if str(subnet["id"]) == str(subnet_id):
                return subnet
        return None

    # ------------------------------------------------------------------ #
    # Section partitioning                                                 #
    # ------------------------------------------------------------------ #

    def _resolve_section(
        self,
        base_section_id: str,
        base_subnets: List[Dict[str, Any]],
        device: Dict[str, Any],
        vrf_name: str,
    ) -> Tuple[str, List[Dict[str, Any]]]:
        """Return the (section_id, subnets) a device's Address should land in.

        With ``section_partition_by`` off (the default), every device uses
        the base Section unchanged. Otherwise resolves or creates a child
        Section nested under the base one via ``masterSection`` - cached
        per partition-key name for the rest of this run.

        Args:
            base_section_id: The base Section's id.
            base_subnets: The base Section's subnets.
            device: The raw LVI device record.
            vrf_name: The device's normalized VRF name (only meaningful
                when the partition mode needs it).

        Returns:
            (section_id, subnets) to resolve this device's Subnet/Address
            against.

        Raises:
            PhpIpamApiError: On a genuine API failure creating the child
                Section.
        """
        if self.section_partition_by == sp.MODE_NONE:
            return base_section_id, base_subnets

        network = str(device.get("network", "Default"))
        key = sp.build_key(self.section_partition_by, network, vrf_name)
        child_name = sp.resolve_section_name(
            self.section_partition_by,
            key,
            self.section_mapping,
            sp.UNMAPPED_AUTO if self.create_missing_sections else sp.UNMAPPED_SKIP,
        )
        if child_name is None:
            return base_section_id, base_subnets

        if child_name in self._section_cache:
            return self._section_cache[child_name]

        # A same-named child could otherwise collide with an unrelated
        # top-level (or differently-parented) section - scope the lookup
        # to children of this run's own base section.
        existing = next(
            (
                s
                for s in self.client.get_sections()
                if s.get("name") == child_name and str(s.get("masterSection")) == str(base_section_id)
            ),
            None,
        )
        if existing is not None:
            section_id = str(existing["id"])
            subnets = self.client.get_subnets_in_section(section_id)
        elif not self.create_missing_sections:
            logger.warning(
                "Section partition '%s' (key '%s') not found under '%s' and 'Create Missing Sections' is off - "
                "using the base section instead",
                child_name,
                key,
                self.section_name,
            )
            return base_section_id, base_subnets
        elif self.dry_run:
            logger.info("[DRY RUN] Would create phpIPAM section '%s' under '%s'", child_name, self.section_name)
            section_id = f"dry-run-section-{child_name}"
            subnets = []
        else:
            section_id = self.client.create_section(
                child_name, description="Created by LVI Sync Manager", master_section_id=base_section_id
            )
            logger.info("Created phpIPAM section '%s' under '%s'", child_name, self.section_name)
            subnets = []

        self._section_cache[child_name] = (section_id, subnets)
        return section_id, subnets

    # ------------------------------------------------------------------ #
    # VRF sync                                                             #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _device_vrf(interfaces_by_key: Dict[Tuple[str, str], List[Dict[str, Any]]], device: Dict[str, Any]) -> str:
        """Return the raw VRF name of the interface carrying *device*'s own IP.

        Mirrors the same interface-matching logic build_mac_lookup() uses -
        the interface whose own IP equals the device's management IP,
        falling back to the first prefetched interface when none match.

        Args:
            interfaces_by_key: prefetch_device_interfaces()'s output.
            device: The raw LVI device record.

        Returns:
            The raw (not yet normalized) VRF name, or "" if unavailable.
        """
        key = (device.get("network", "Default"), device.get("ipAddress", ""))
        entries = interfaces_by_key.get(key)
        if not entries:
            return ""
        mgmt_ip = key[1]
        matched = next(
            (e for e in entries if any(ip.split("/")[0] == mgmt_ip for ip in e.get("interfaceIps", []) or [])),
            entries[0],
        )
        return ((matched.get("interface") or {}).get("vrfName") or "").strip()

    def _ensure_vrf(self, vrf_name: str) -> bool:
        """Resolve (or, if enabled, create) a VRF by name, cached per run.

        Args:
            vrf_name: The normalized VRF name.

        Returns:
            True if the VRF exists (or would, in dry-run) and its id is
            cached in self._vrf_ids_by_name.
        """
        if vrf_name in self._vrf_ids_by_name:
            return True
        if self.dry_run:
            logger.info("[DRY RUN] Would ensure phpIPAM VRF '%s' exists", vrf_name)
            self._vrf_ids_by_name[vrf_name] = "dry-run-vrf"
            return True
        try:
            existing = self.client.get_vrf_by_name(vrf_name)
            if existing is not None:
                self._vrf_ids_by_name[vrf_name] = str(existing["vrfId"])
            else:
                self._vrf_ids_by_name[vrf_name] = self.client.create_vrf(vrf_name)
                logger.info("Created phpIPAM VRF '%s'", vrf_name)
            return True
        except PhpIpamApiError as exc:
            logger.warning("Could not resolve/create phpIPAM VRF '%s': %s", vrf_name, exc)
            return False

    def _apply_vrf_to_subnet(self, subnets: List[Dict[str, Any]], subnet_id: str, vrf_name: str) -> None:
        """Set a Subnet's VRF if unset, matching the resolved VRF.

        Subnets are shared infrastructure objects this plugin doesn't
        otherwise own (unlike Addresses, which carry the marker field), so
        an already-set VRF is never overwritten - only warned about on a
        mismatch. A dry-run or just-created sentinel subnet is skipped
        (nothing real to write to yet).

        Args:
            subnets: The current section's subnets (mutated in place to
                reflect the new vrfId so a later device sees it without a
                re-fetch).
            subnet_id: The target subnet's id.
            vrf_name: The device's normalized VRF name.
        """
        if subnet_id.startswith("dry-run-"):
            return
        subnet = self._find_subnet(subnets, subnet_id)
        if subnet is None or not self._ensure_vrf(vrf_name):
            return
        current_vrf_id = subnet.get("vrfId")
        vrf_id = self._vrf_ids_by_name[vrf_name]
        if current_vrf_id:
            if str(current_vrf_id) != str(vrf_id):
                logger.warning(
                    "phpIPAM subnet %s already has a different VRF set (id %s) - not overwriting; "
                    "LogicVein reports VRF '%s'",
                    subnet.get("subnet"),
                    current_vrf_id,
                    vrf_name,
                )
            return
        if self.dry_run:
            logger.info("[DRY RUN] Would set VRF '%s' on phpIPAM subnet %s", vrf_name, subnet.get("subnet"))
            subnet["vrfId"] = vrf_id
            return
        try:
            self.client.update_subnet(subnet_id, vrfId=vrf_id)
        except PhpIpamApiError as exc:
            logger.warning("Failed to set VRF '%s' on phpIPAM subnet %s: %s", vrf_name, subnet.get("subnet"), exc)
            return
        subnet["vrfId"] = vrf_id
        logger.info("Set VRF '%s' on phpIPAM subnet %s", vrf_name, subnet.get("subnet"))

    # ------------------------------------------------------------------ #
    # VLAN sync                                                            #
    # ------------------------------------------------------------------ #

    def _ensure_vlan_domain(self) -> None:
        """Resolve (or, if enabled, create) the configured VLAN L2 domain.

        Populates self._vlan_domain_id, or leaves it None if the domain is
        missing and auto-create is off - the caller treats that as a
        run-level failure, matching the base Section's own precedent.

        Raises:
            PhpIpamApiError: On a genuine API failure.
        """
        if self.dry_run:
            existing = None
            try:
                existing = self.client.get_l2domain_by_name(self.vlan_domain_name)
            except PhpIpamApiError:
                pass
            if existing is not None:
                self._vlan_domain_id = str(existing["id"])
            elif self.create_missing_vlan_domain:
                logger.info("[DRY RUN] Would create phpIPAM VLAN domain '%s'", self.vlan_domain_name)
                self._vlan_domain_id = "dry-run-vlan-domain"
            return

        existing = self.client.get_l2domain_by_name(self.vlan_domain_name)
        if existing is not None:
            self._vlan_domain_id = str(existing["id"])
        elif self.create_missing_vlan_domain:
            self._vlan_domain_id = self.client.create_l2domain(self.vlan_domain_name)
            logger.info("Created phpIPAM VLAN domain '%s'", self.vlan_domain_name)

    def _ensure_vlan(self, vlan_number: str) -> bool:
        """Resolve (or, if enabled, create) a VLAN by number, cached per run.

        Args:
            vlan_number: The VLAN number (802.1Q tag) as a string.

        Returns:
            True if the VLAN exists (or would, in dry-run) and its id is
            cached in self._vlan_ids_by_number.
        """
        if vlan_number in self._vlan_ids_by_number:
            return True
        if self.dry_run:
            logger.info(
                "[DRY RUN] Would ensure phpIPAM VLAN %s exists in domain '%s'", vlan_number, self.vlan_domain_name
            )
            self._vlan_ids_by_number[vlan_number] = "dry-run-vlan"
            return True
        # Only reachable after _ensure_vlan_domain() has confirmed a real
        # domain id - sync() fails the whole run before the device loop if
        # self._vlan_domain_id is still None at that point.
        domain_id = self._vlan_domain_id
        if domain_id is None:
            return False
        try:
            existing = self.client.get_vlan_by_number(domain_id, vlan_number)
            if existing is not None:
                self._vlan_ids_by_number[vlan_number] = str(existing["vlanId"])
            else:
                self._vlan_ids_by_number[vlan_number] = self.client.create_vlan(domain_id, vlan_number)
                logger.info("Created phpIPAM VLAN %s in domain '%s'", vlan_number, self.vlan_domain_name)
            return True
        except PhpIpamApiError as exc:
            logger.warning("Could not resolve/create phpIPAM VLAN %s: %s", vlan_number, exc)
            return False

    def _device_vlan_number(
        self, interfaces_by_key: Dict[Tuple[str, str], List[Dict[str, Any]]], device: Dict[str, Any], ip_address: str
    ) -> str:
        """Return the VLAN number of the port carrying *device*'s own IP.

        LVI's device search/interface prefetch never reports a VLAN number -
        it comes from a separate per-device call
        (``Inventory.getDeviceVlanPortMappings``, same one EfficientIP's
        VLAN sync uses), keyed by port name, not IP. This makes one LVI
        call per device (only when sync_vlans is on) and cross-references
        it against the prefetched interface entry carrying the device's own
        IP, to find that entry's port name.

        Args:
            interfaces_by_key: prefetch_device_interfaces()'s output.
            device: The raw LVI device record.
            ip_address: The device's management IP.

        Returns:
            The VLAN number as a string, or "" if unavailable.
        """
        key = (device.get("network", "Default"), device.get("ipAddress", ""))
        entries = interfaces_by_key.get(key)
        if not entries:
            return ""
        matched = next(
            (e for e in entries if any(ip.split("/")[0] == ip_address for ip in e.get("interfaceIps", []) or [])),
            entries[0],
        )
        iface_info = matched.get("interface") or {}
        port_name = (iface_info.get("name") or iface_info.get("ifName") or "").strip()
        if not port_name:
            return ""
        network = str(device.get("network", "Default"))
        try:
            mappings = self.lvi.get_device_vlan_port_mappings(ip_address, network=network)
        except Exception as exc:
            logger.warning("Failed to fetch VLAN port mappings for %s: %s", ip_address, exc)
            return ""
        for mapping in mappings or []:
            if mapping.get("port") == port_name and mapping.get("number"):
                return str(mapping["number"])
        return ""

    def _apply_vlan_to_subnet(self, subnets: List[Dict[str, Any]], subnet_id: str, vlan_number: str) -> None:
        """Set a Subnet's VLAN if unset, matching the resolved VLAN.

        Same "never overwrite, warn on mismatch" safety rule as
        _apply_vrf_to_subnet - see its docstring.

        Args:
            subnets: The current section's subnets (mutated in place).
            subnet_id: The target subnet's id.
            vlan_number: The device's VLAN number.
        """
        if subnet_id.startswith("dry-run-"):
            return
        subnet = self._find_subnet(subnets, subnet_id)
        if subnet is None or not self._ensure_vlan(vlan_number):
            return
        current_vlan_id = subnet.get("vlanId")
        vlan_id = self._vlan_ids_by_number[vlan_number]
        if current_vlan_id:
            if str(current_vlan_id) != str(vlan_id):
                logger.warning(
                    "phpIPAM subnet %s already has a different VLAN set (id %s) - not overwriting; "
                    "LogicVein reports VLAN %s",
                    subnet.get("subnet"),
                    current_vlan_id,
                    vlan_number,
                )
            return
        if self.dry_run:
            logger.info("[DRY RUN] Would set VLAN %s on phpIPAM subnet %s", vlan_number, subnet.get("subnet"))
            subnet["vlanId"] = vlan_id
            return
        try:
            self.client.update_subnet(subnet_id, vlanId=vlan_id)
        except PhpIpamApiError as exc:
            logger.warning("Failed to set VLAN %s on phpIPAM subnet %s: %s", vlan_number, subnet.get("subnet"), exc)
            return
        subnet["vlanId"] = vlan_id
        logger.info("Set VLAN %s on phpIPAM subnet %s", vlan_number, subnet.get("subnet"))

    # ------------------------------------------------------------------ #
    # Per-device sync                                                      #
    # ------------------------------------------------------------------ #

    def _sync_one_device(
        self,
        ip_address: str,
        hostname: str,
        subnet_id: Optional[str],
        device: Dict[str, Any],
        mac_address: str,
        used_tag_id: Optional[int],
    ) -> bool:
        """Sync one device's management IP to a phpIPAM Address.

        Conflict detection runs before any write, and every write is gated
        on ``self.dry_run`` individually rather than a single early return,
        so dry-run conflicts stay reachable and reported.

        Args:
            ip_address: The device's management IP.
            hostname: The device's hostname.
            subnet_id: The resolved target subnet's id, or None if none
                could be resolved/created.
            device: The raw LVI device record.
            mac_address: The device's MAC, or "" if not syncing MAC.
            used_tag_id: The "Used" address-state id, or None.

        Returns:
            True if the device was handled without an error (added,
            updated, ignored, or deferred as pending all count as success;
            only an actual write/lookup failure returns False).
        """
        if subnet_id is None:
            error = "No phpIPAM subnet contains this IP and 'Create Missing Subnets' is off"
            logger.error("Error syncing %s (%s): %s", ip_address, hostname, error)
            self._outcomes.append(
                DeviceSyncOutcome(
                    ip_address=ip_address,
                    hostname=hostname,
                    action="error",
                    error=error,
                )
            )
            return False

        try:
            existing = self.client.search_address_by_ip(ip_address)
        except PhpIpamApiError as exc:
            logger.error("Error looking up phpIPAM address %s (%s): %s", ip_address, hostname, exc)
            self._outcomes.append(
                DeviceSyncOutcome(ip_address=ip_address, hostname=hostname, action="error", error=str(exc))
            )
            return False

        description = str(device.get("deviceType", ""))
        desired_payload = {
            "ip_address": ip_address,
            "subnet_id": subnet_id,
            "hostname": hostname,
            "description": description,
            "mac": mac_address,
            "tag_id": used_tag_id,
        }

        if existing is not None and not existing.get(MARKER_FIELD):
            detail = f"IP already exists in phpIPAM (hostname '{existing.get('hostname', '')}'), not managed by LVI Sync Manager"
            if self.ip_conflict_policy == "ignore":
                logger.info("Ignored address %s: %s", ip_address, detail)
                self._outcomes.append(
                    DeviceSyncOutcome(ip_address=ip_address, hostname=hostname, action="ignored", detail=detail)
                )
                return True
            if self.ip_conflict_policy == "ask":
                logger.warning("Conflict: %s - %s, policy=ask, deferred for review", ip_address, detail)
                self._pending_items.append(
                    pending_conflict_item(ip_address, hostname, "ip_exists", detail, desired_payload)
                )
                self._outcomes.append(
                    DeviceSyncOutcome(
                        ip_address=ip_address,
                        hostname=hostname,
                        action="pending",
                        detail=f"{detail} - awaiting decision",
                    )
                )
                return True
            # "overwrite" falls through and claims the existing record below.

        mac_previous = ""
        mac_changed = False
        mac_detail = ""
        duplicate_of = ""
        if self.sync_mac_address and mac_address:
            if existing is not None:
                mac_previous = str(existing.get("mac") or "")
                mac_changed = bool(mac_previous) and mac_previous.lower() != mac_address.lower()

            if self.mac_conflict_policy != "overwrite":
                dups = self.client.search_address_by_mac(mac_address)
                existing_id = str(existing["id"]) if existing is not None else None
                others = [d for d in dups if str(d.get("id")) != existing_id]
                if others:
                    duplicate_of = f"MAC already in use by '{others[0].get('hostname') or others[0].get('ip')}'"

            # A MAC conflict strips only the MAC field and defers it for
            # review (see pending_conflict_item below) - it never blocks the
            # rest of the record from being created/updated, matching
            # Infoblox's precedent. Only the ip_exists case above skips the
            # whole record.
            if duplicate_of and self.mac_conflict_policy == "ask":
                logger.warning("Conflict: %s MAC %s - %s, policy=ask, deferred", ip_address, mac_address, duplicate_of)
                self._pending_items.append(
                    pending_conflict_item(
                        ip_address, hostname, "mac_duplicate", duplicate_of, {**desired_payload, "mac": mac_address}
                    )
                )
                mac_detail = f"{duplicate_of} - awaiting decision"
                mac_address = ""
            elif mac_changed and self.mac_conflict_policy == "leave_untouched":
                mac_address = mac_previous
            elif mac_changed and self.mac_conflict_policy == "ask":
                logger.warning(
                    "Conflict: %s MAC differs (phpIPAM has %s, LogicVein has %s), policy=ask, deferred",
                    ip_address,
                    mac_previous,
                    mac_address,
                )
                self._pending_items.append(
                    pending_conflict_item(
                        ip_address,
                        hostname,
                        "mac_differs",
                        f"MAC differs: phpIPAM has {mac_previous}, {get_vendor_name()} has {mac_address}",
                        desired_payload,
                    )
                )
                mac_detail = "MAC differs - awaiting decision"
                mac_address = mac_previous

        action = "updated" if existing is not None else "added"
        if self.dry_run:
            logger.info("[DRY RUN] Would %s address %s (%s)", "update" if existing else "create", ip_address, hostname)
            self._outcomes.append(
                DeviceSyncOutcome(
                    ip_address=ip_address,
                    hostname=hostname,
                    action=action,
                    mac=mac_address,
                    mac_changed=mac_changed,
                    mac_previous=mac_previous,
                    duplicate_mac_of=duplicate_of,
                    detail=mac_detail or "[DRY RUN]",
                )
            )
            return True

        try:
            if existing is not None:
                self.client.update_address(
                    existing["id"], hostname=hostname, description=description, mac=mac_address, **{MARKER_FIELD: "yes"}
                )
            else:
                self.client.create_address(
                    ip_address,
                    subnet_id,
                    hostname=hostname,
                    description=description,
                    mac=mac_address,
                    tag_id=used_tag_id,
                    custom_fields={MARKER_FIELD: "yes"},
                )
        except PhpIpamApiError as exc:
            logger.error(
                "Error %s phpIPAM address %s (%s): %s",
                "updating" if existing is not None else "creating",
                ip_address,
                hostname,
                exc,
            )
            self._outcomes.append(
                DeviceSyncOutcome(ip_address=ip_address, hostname=hostname, action="error", error=str(exc))
            )
            return False

        logger.info(
            "%s phpIPAM address %s (%s)%s",
            "Updated" if existing is not None else "Created",
            ip_address,
            hostname,
            f" - {mac_detail}" if mac_detail else "",
        )
        self._outcomes.append(
            DeviceSyncOutcome(
                ip_address=ip_address,
                hostname=hostname,
                action=action,
                detail=mac_detail,
                mac=mac_address,
                mac_changed=mac_changed,
                mac_previous=mac_previous,
                duplicate_mac_of=duplicate_of,
            )
        )
        return True

    # ------------------------------------------------------------------ #
    # Stale-address cleanup                                                #
    # ------------------------------------------------------------------ #

    def _delete_stale_addresses(self, subnets: List[Dict[str, Any]], synced_ips: Set[str]) -> None:
        """Delete lvi_managed addresses this run no longer reports.

        Only ever considers addresses carrying the marker field, scoped to
        the subnets under the target Section this run touched - a
        manually-added or other tool's address is never touched.

        Args:
            subnets: The Section's subnets (including any created this run).
            synced_ips: Every IP this run actually wrote/confirmed.
        """
        for subnet in subnets:
            try:
                addresses = self.client.get_addresses_in_subnet(subnet["id"])
            except PhpIpamApiError as exc:
                logger.warning("Failed to list addresses in subnet %s for stale cleanup: %s", subnet["id"], exc)
                continue
            for address in addresses:
                ip_address = address.get("ip", "")
                if not address.get(MARKER_FIELD) or ip_address in synced_ips:
                    continue
                try:
                    self.client.delete_address(address["id"])
                except PhpIpamApiError as exc:
                    logger.warning("Failed to delete stale address %s: %s", ip_address, exc)
                    continue
                logger.info("Deleted stale phpIPAM address %s (%s)", ip_address, address.get("hostname", ""))
                self._outcomes.append(
                    DeviceSyncOutcome(ip_address=ip_address, hostname=address.get("hostname", ""), action="deleted")
                )
