"""ServiceNow incident creator: a ConfigChangeEvent handler.

Registered with the core change-detection dispatch (``register_change_handler``),
this handler receives each detected :class:`ConfigChangeEvent` together with an
initialised LVI client. It fetches per-path word diffs, applies the
``minimum_changed_lines`` suppression, computes a deterministic correlation_id,
deduplicates against ServiceNow, looks up the caller and CMDB CI, and creates the
incident. It returns True when an incident was created (so the detection cycle
can count it).

This is the ServiceNow-specific half of config-change detection; all the
target-agnostic work (LVI history fetch, coalescing, dedup, cycle recording)
lives in core.
"""

import hashlib
import logging
import os
from typing import Any, Dict, Optional

# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import (  # pyright: ignore[reportMissingImports]
    ConfigChangeEvent,
    config_diff,
    get_product_name,
    webhook_store,
)

from ..settings import get_change_detection_settings, get_snow_client
from ..webhook.alert_incident import _resolve_caller_sys_id

logger = logging.getLogger(__name__)


def _log_event(**kwargs):
    """Record a webhook event tagged with this plugin's id (UI per-plugin filter)."""
    webhook_store.log_event(plugin="snow", **kwargs)


_STATE_NEW = 1

# Cap the diff text embedded in the incident. A large device (e.g. an F5 BIG-IP)
# can produce a multi-megabyte config diff; ServiceNow rejects REST payloads over
# ~10 MB ("Rejected large REST payload"), and an incident description that large
# is unusable anyway. Truncate per-path and overall, well under the SNOW limit.
_MAX_DESCRIPTION_CHARS = 40000


def _lookup_snow_ci(snow: Any, hostname: str, ip: str, cache: Dict[str, str]) -> str:
    """Return the sys_id of the CMDB CI matching *hostname* or *ip*, or '' on miss.

    Queries the ``cmdb_ci`` base table: hostname first (``name`` field), then IP
    (``ip_address`` field).

    Args:
        snow: The ServiceNowClient to query.
        hostname: The device's hostname.
        ip: The device's IP address.
        cache: value -> sys_id cache, read and updated in place.

    Returns:
        The matching CI's sys_id, or "" on miss.
    """
    for field, value in (("name", hostname), ("ip_address", ip)):
        if not value or value == "unknown":
            continue
        key = f"ci:{value}"
        if key in cache:
            return cache[key]
        try:
            rows = snow.query_table("cmdb_ci", f"{field}={value}", fields=["sys_id"], limit=1)
            if rows:
                sys_id = rows[0].get("sys_id", "")
                cache[key] = sys_id
                return sys_id
        except Exception as exc:
            logger.debug("SNOW CI lookup failed for %s=%s: %s", field, value, exc)
    return ""


class SnowIncidentCreator:
    """Config-change handler that creates a ServiceNow incident per change."""

    def __init__(self) -> None:
        """Initialize the CI/caller lookup cache."""
        # CI/caller lookups are cached across events for the life of the process.
        self._lookup_cache: Dict[str, str] = {}

    def __call__(self, event: ConfigChangeEvent, lvi: Any) -> bool:
        """Create a SNOW incident for *event*. Return True if one was created."""
        try:
            snow = get_snow_client()
        except Exception as exc:
            logger.error("SnowIncidentCreator: failed to create SNOW client: %s", exc)
            snow_dst = os.getenv("SNOW_INSTANCE", "")
            _log_event(
                direction="sync mgr→snow",
                action="config_change",
                node=event.hostname or event.ip_address or "?",
                correlation_hash=event.event_key,
                severity="",
                result="snow_error",
                src="Sync Manager",
                dst=snow_dst,
                error=f"SNOW client init failed: {exc}",
                status_code=503,
                event_type="config_change",
                description=config_diff.change_event_title(event),
            )
            return False

        snow_cfg = get_change_detection_settings().get("snow_incident", {})
        snow_dst = os.getenv("SNOW_INSTANCE", "")
        try:
            number = self._create_incident(snow, lvi, event, snow_cfg, snow_dst)
        except Exception as exc:
            node = event.hostname or event.ip_address or "?"
            logger.error("SnowIncidentCreator: failed to create SNOW incident for %s: %s", node, exc)
            _log_event(
                direction="sync mgr→snow",
                action="config_change",
                node=node,
                correlation_hash=event.event_key,
                severity="",
                result="error",
                src="Sync Manager",
                dst=snow_dst,
                error=str(exc),
                status_code=500,
                event_type="config_change",
                description=config_diff.change_event_title(event),
            )
            return False
        return number is not None

    def _create_incident(
        self,
        snow: Any,
        lvi: Any,
        event: ConfigChangeEvent,
        snow_cfg: Dict[str, Any],
        snow_dst: str,
    ) -> Optional[str]:
        """Create a SNOW incident for a config change event.

        Returns:
            The created incident number (e.g. ``INC0001234``), or ``None`` if the
            incident already exists in SNOW or creation was suppressed.
        """
        hostname = event.hostname or event.ip_address or "unknown"
        ip = event.ip_address or ""
        network = event.managed_network or ""
        author = event.author or "unknown"
        changed_at = event.last_changed or ""
        paths = event.paths or []
        paths_str = ", ".join(paths) if paths else "unknown"

        short_description = f"[{get_product_name()}] Config change on {hostname}"

        # Build the stable header first so we can compute the correlation_id before
        # fetching diffs (diffs are optional and may not always be available).
        # The title line is pinned to the literal "LogicVein" wording - not
        # get_product_name() - so correlation_id (hashed below) never changes
        # based on VENDOR or varies from what was already computed for an
        # existing change before this vendor-branding feature existed. The
        # *displayed* title a couple of lines down does use get_product_name().
        description_header = [
            "LogicVein Configuration Change Detected",
            "=" * 40,
            f"Device:       {hostname}",
            f"IP Address:   {ip}",
            f"Network:      {network}",
            f"Changed At:   {changed_at}",
            f"Author:       {author}",
            f"Config Paths: {paths_str}",
        ]

        # Correlation ID: SHA-256 of the stable header (device + timestamp + paths).
        # Deterministic across restarts so SNOW can deduplicate even if the local
        # seen_events DB is wiped (e.g. fresh Docker volume).
        correlation_id = hashlib.sha256("\n".join(description_header).encode()).hexdigest()[:40]

        # Only now does the header's title line switch to the display-branded
        # form - after correlation_id has already been computed from the pinned
        # text above.
        description_header[0] = f"{get_product_name()} Configuration Change Detected"

        # Check SNOW for an existing incident before doing any expensive work.
        try:
            existing = snow.query_table(
                "incident", f"correlation_id={correlation_id}", fields=["number", "state"], limit=1
            )
            if existing:
                number = existing[0].get("number", "?")
                logger.info("SnowIncidentCreator: %s already in SNOW as %s - skipping", hostname, number)
                return None
        except Exception as exc:
            logger.warning(
                "SnowIncidentCreator: SNOW dedup check failed for %s (%s) - proceeding: %s",
                hostname,
                correlation_id,
                exc,
            )

        description_lines = list(description_header)

        _NO_DIFF_EXTS = (".gz", ".tgz", ".tar", ".zip", ".bak", ".dat")
        min_lines = int(snow_cfg.get("minimum_changed_lines", 1))
        total_changed_lines = 0
        diffs_fetched = False

        # Append per-path diffs - skip gracefully if the API call fails.
        for pd in event.path_details:
            path = pd.get("path", "")
            prev_change = pd.get("prev_change", "")
            if not path or not prev_change or not changed_at:
                continue
            if path.lower().endswith(_NO_DIFF_EXTS):
                continue
            try:
                segments = lvi.get_config_revision_word_diff(
                    ip_address=ip,
                    timestamp1=prev_change,
                    timestamp2=changed_at,
                    network=network,
                    config_path=path,
                )
                diffs_fetched = True
                total_changed_lines += config_diff.count_changed_lines(segments)
                diff_text = config_diff.format_diff(segments)
                if diff_text:
                    description_lines.append("")
                    description_lines.append(f"--- {path} ---")
                    description_lines.append(diff_text)
            except Exception as exc:
                logger.debug("Could not fetch diff for %s %s: %s", hostname, path, exc)

        # Suppress incident creation when we have diff data but the change is
        # below the configured minimum.  If no diffs could be fetched (first
        # revision, binary paths, etc.) we always proceed.
        if diffs_fetched and total_changed_lines < min_lines:
            logger.info(
                "SnowIncidentCreator: skipping %s - %d changed line(s) < minimum_changed_lines=%d",
                hostname,
                total_changed_lines,
                min_lines,
            )
            return None

        description = "\n".join(description_lines)
        # Final guard: keep the whole description (many paths combined) well under
        # ServiceNow's REST payload limit even if individual diffs were each small.
        if len(description) > _MAX_DESCRIPTION_CHARS:
            description = description[:_MAX_DESCRIPTION_CHARS].rstrip() + "\n" + config_diff.TRUNCATION_NOTE

        # Look up caller and CI in SNOW - fail gracefully if not found.
        caller_sys_id = _resolve_caller_sys_id(snow)
        ci_sys_id = _lookup_snow_ci(snow, hostname, ip, self._lookup_cache)

        incident_data: Dict[str, Any] = {
            "short_description": short_description,
            "description": description,
            "correlation_id": correlation_id,
            "correlation_display": f"{get_product_name()} Config Change",
            "category": snow_cfg.get("category", "Network"),
            "subcategory": snow_cfg.get("subcategory", "Network Monitoring"),
            "urgency": str(snow_cfg.get("urgency", 2)),
            "impact": str(snow_cfg.get("impact", 2)),
            "state": str(_STATE_NEW),
        }
        if caller_sys_id:
            incident_data["caller_id"] = caller_sys_id
        if ci_sys_id:
            incident_data["cmdb_ci"] = ci_sys_id

        created = snow.create_record("incident", incident_data)
        number = created.get("number", created.get("sys_id", "unknown"))
        node_label = f"{hostname} ({ip})" if ip and ip != hostname else hostname

        _urgency_map = {1: "High", 2: "Medium", 3: "Low"}
        _severity = _urgency_map.get(int(snow_cfg.get("urgency", 2)), "Medium")

        _log_event(
            direction="sync mgr→snow",
            action="config_change",
            node=node_label,
            correlation_hash=correlation_id,
            severity=_severity,
            result="created",
            src=get_product_name(),
            dst=snow_dst,
            incident=number,
            status_code=201,
            event_type="config_change",
            description=config_diff.change_event_title(event),
        )
        logger.info(
            "SnowIncidentCreator: created SNOW incident %s for config change on %s (author=%s paths=%s)",
            number,
            hostname,
            author,
            paths_str,
        )
        return number


_creator: Optional[SnowIncidentCreator] = None


def get_incident_creator() -> SnowIncidentCreator:
    """Return the module-level singleton incident creator (created on first use)."""
    global _creator
    if _creator is None:
        _creator = SnowIncidentCreator()
    return _creator
