"""Plugin-local access to the Jira sync configuration and client."""

from pathlib import Path
from typing import Any, Dict

# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import get_config  # pyright: ignore[reportMissingImports]

_CONFIG_FILE = Path("conf/jira_sync_config.yaml")
_DEFAULTS_FILE = Path(__file__).parent / "conf" / "defaults.yaml"


def get_jira_settings() -> Dict[str, Any]:
    """Return the full Jira sync config (created from defaults on first use)."""
    return get_config(_CONFIG_FILE, _DEFAULTS_FILE)


def get_change_detection_settings() -> Dict[str, Any]:
    """Config-change settings: app-wide detection config plus Jira issue fields.

    The plugin-neutral keys (mode, poll_interval_minutes, networks, dedup) live
    in conf/app.yaml under change_detection, and ``enabled`` comes from the app's
    features.change_detection switch; only the Jira issue fields live in the
    plugin's own config (lvi_config_change_poller.jira_change).

    Returns:
        The combined change-detection settings.
    """
    # src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
    from src.plugin_api import get_app_settings  # pyright: ignore[reportMissingImports]

    app_settings = get_app_settings()
    cfg: Dict[str, Any] = dict(app_settings.get("change_detection", {}) or {})
    cfg["enabled"] = bool(app_settings.get("features", {}).get("change_detection", True))
    cfg["jira_change"] = get_jira_settings().get("lvi_config_change_poller", {}).get("jira_change", {})
    return cfg


def get_jira_client() -> Any:
    """Return a JiraClient built from environment variables."""
    from .client import JiraClient

    return JiraClient()
