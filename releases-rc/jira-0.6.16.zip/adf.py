"""Minimal Atlassian Document Format (ADF) builders.

Jira Cloud REST API v3 takes rich text (issue ``description`` and comment bodies)
as ADF - a JSON document, not plain text or wiki markup. These helpers build the
small subset we need: a document wrapping paragraphs, a two-column detail table,
and inline links. See https://developer.atlassian.com/cloud/jira/platform/apis/document/structure/
"""

from typing import Any, Dict, List, Tuple


def doc(*content: Dict[str, Any]) -> Dict[str, Any]:
    """Wrap block nodes in an ADF document."""
    return {"version": 1, "type": "doc", "content": list(content)}


def text(value: str) -> Dict[str, Any]:
    """A plain text node."""
    return {"type": "text", "text": value}


def link(value: str, href: str) -> Dict[str, Any]:
    """A text node marked as a hyperlink."""
    return {"type": "text", "text": value, "marks": [{"type": "link", "attrs": {"href": href}}]}


def paragraph(*nodes: Dict[str, Any]) -> Dict[str, Any]:
    """A paragraph block of inline nodes."""
    return {"type": "paragraph", "content": list(nodes)}


def _cell(node: Dict[str, Any]) -> Dict[str, Any]:
    """Wrap *node* as a single-paragraph ADF table cell."""
    return {"type": "tableCell", "attrs": {}, "content": [paragraph(node)]}


def detail_table(rows: List[Tuple[str, Dict[str, Any]]]) -> Dict[str, Any]:
    """A two-column table: each row is ``(label, value_node)``.

    The value is an inline ADF node (use ``text(...)`` or ``link(...)``). Rows
    whose value text is empty are skipped so the table stays compact.

    Args:
        rows: (label, value_node) pairs.

    Returns:
        The ADF table node.
    """
    table_rows: List[Dict[str, Any]] = []
    for label, value_node in rows:
        if not value_node.get("text"):
            continue
        table_rows.append({"type": "tableRow", "content": [_cell(text(label)), _cell(value_node)]})
    return {"type": "table", "attrs": {"isNumberColumnEnabled": False, "layout": "default"}, "content": table_rows}


def code_block(text_content: str) -> Dict[str, Any]:
    """A preformatted code block (used for config diffs)."""
    return {"type": "codeBlock", "attrs": {}, "content": [{"type": "text", "text": text_content}]}


def comment(message: str) -> Dict[str, Any]:
    """A one-paragraph comment document."""
    return doc(paragraph(text(message)))
