"""LogicVein -> phpIPAM inventory sync.

Syncs each LVI device's management IP into a phpIPAM Address, within a
Subnet resolved (or, if enabled, auto-created) under one configured Section
(also resolved, or if enabled, auto-created). No interface IPs, VLAN/VRF,
or the phpIPAM Devices object - see
``docs/dev_notes/PHPIPAM_PLUGIN_ITERATION_1_PLAN.md`` in the sibling app repo
for the full v0.1.0 scope and why each of those is deferred.

One thing must always already exist in phpIPAM before this plugin's first
run - it is not creatable via the API, so :meth:`LogicVeinPhpIpamSync.sync`
fails fast with an actionable message rather than silently degrading:

- A ``lvi_managed`` custom field on Addresses (Administration -> Custom
  fields -> Custom IP addresses fields), the marker this plugin's stale-
  address cleanup uses to scope deletion to records it actually owns.

The target Section (``phpipam.section_name``) also fails fast by default
if missing, but can instead be auto-created via
``phpipam.create_missing_sections`` (off by default) - phpIPAM's API does
support creating a Section, confirmed against its own API reference
after this plugin originally shipped believing otherwise; see
:meth:`plugins.phpipam.client.PhpIpamClient.create_section`'s docstring
for the one open caveat (its request field names are inferred, not yet
live-verified).
"""

import ipaddress
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Set, Tuple

# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import (  # pyright: ignore[reportMissingImports]
    CancellableSync,
    DeviceSyncOutcome,
    SyncReport,
    build_mac_lookup,
    mac_for,
    normalize_networks,
    pending_conflict_item,
    prefetch_device_interfaces,
    record_pending_conflicts,
    resolve_prefetch_networks,
)

from .client import MARKER_FIELD, PhpIpamApiError, PhpIpamClient

logger = logging.getLogger(__name__)

PLUGIN_NAME = "phpipam"


def _subnet_contains(ip_address: str, subnet: str, mask: str) -> bool:
    """Whether *ip_address* falls inside the CIDR *subnet*/*mask*.

    Args:
        ip_address: The IP address to test.
        subnet: The subnet's network address.
        mask: The subnet's prefix length.

    Returns:
        True if the address is inside the subnet.
    """
    try:
        return ipaddress.ip_address(ip_address) in ipaddress.ip_network(f"{subnet}/{mask}", strict=False)
    except ValueError:
        return False


def _derive_subnet_cidr(ip_address: str, prefix_len: int) -> Tuple[str, str]:
    """Derive the containing network address/mask for *ip_address* at *prefix_len*.

    Args:
        ip_address: The IP address to derive a covering subnet for.
        prefix_len: The desired prefix length.

    Returns:
        (network_address, mask) as strings, ready for create_subnet().
    """
    network = ipaddress.ip_network(f"{ip_address}/{prefix_len}", strict=False)
    return str(network.network_address), str(network.prefixlen)


class LogicVeinPhpIpamSync(CancellableSync):
    """Sync LVI device management IPs into phpIPAM addresses."""

    def __init__(self, lvi_client: Any, target_client: PhpIpamClient, config: Dict[str, Any]) -> None:
        """Store the clients and flat config dict build_sync_config() produced.

        Args:
            lvi_client: LogicVein API client instance.
            target_client: PhpIpamClient instance.
            config: Flat config dict from PhpIpamPlugin.build_sync_config().
        """
        self.lvi = lvi_client
        self.client = target_client
        self.config = config or {}

        self.dry_run = bool(self.config.get("dry_run", False))
        self.continue_on_error = bool(self.config.get("continue_on_error", True))
        self.networks = normalize_networks(self.config.get("network", "Default"))
        self.section_name = str(self.config.get("section_name", ""))
        self.create_missing_sections = bool(self.config.get("create_missing_sections", False))
        self.sync_mac_address = bool(self.config.get("sync_mac_address", True))
        self.create_missing_subnets = bool(self.config.get("create_missing_subnets", False))
        self.default_subnet_mask = int(self.config.get("default_subnet_mask", 24))
        self.delete_stale_ips = bool(self.config.get("delete_stale_ips", False))
        self.ip_conflict_policy = str(self.config.get("ip_conflict_policy", "ask"))
        self.mac_conflict_policy = str(self.config.get("mac_conflict_policy", "ask"))

        self.last_report: Optional[SyncReport] = None
        self._outcomes: List[DeviceSyncOutcome] = []
        self._pending_items: List[Dict[str, Any]] = []

    # ------------------------------------------------------------------ #
    # Entry point                                                          #
    # ------------------------------------------------------------------ #

    def sync(self) -> bool:
        """Run one sync. Return True if every device synced without error.

        Returns:
            True on success, False if any device errored or a run-level
            precondition (missing section/custom field) failed.
        """
        started_at = datetime.now(timezone.utc).isoformat()
        self._outcomes = []
        self._pending_items = []
        logger.info(
            "phpIPAM sync starting: networks=%s section=%s dry_run=%s",
            self.networks or ["all"],
            self.section_name,
            self.dry_run,
        )

        try:
            custom_fields = self.client.get_custom_fields()
        except PhpIpamApiError as exc:
            return self._fail_run(started_at, f"Failed to check phpIPAM custom fields: {exc}")
        if MARKER_FIELD not in custom_fields:
            return self._fail_run(
                started_at,
                f"phpIPAM is missing the '{MARKER_FIELD}' custom field on Addresses - create it once via "
                "Administration > Custom fields > Custom IP addresses fields before enabling this sync "
                "(see docs/dev_notes/PHPIPAM_PLUGIN_ITERATION_1_PLAN.md).",
            )

        try:
            section = self.client.get_section_by_name(self.section_name)
        except PhpIpamApiError as exc:
            return self._fail_run(started_at, f"Failed to look up phpIPAM section '{self.section_name}': {exc}")

        # A freshly-created (or dry-run-simulated) section cannot have any
        # subnets yet, so both branches below skip the real
        # get_subnets_in_section() call entirely rather than querying an
        # id that either doesn't exist yet (dry run) or was only just
        # created a moment ago (guaranteed empty either way).
        if section is None:
            if not self.create_missing_sections:
                return self._fail_run(
                    started_at,
                    f"phpIPAM section '{self.section_name}' not found - create it once via the phpIPAM UI "
                    "before enabling this sync, or turn on 'Create Missing Sections'.",
                )
            if self.dry_run:
                logger.info("[DRY RUN] Would create phpIPAM section '%s'", self.section_name)
                section_id = "dry-run-section"
            else:
                try:
                    section_id = self.client.create_section(
                        self.section_name, description="Created by LVI Sync Manager"
                    )
                except PhpIpamApiError as exc:
                    return self._fail_run(started_at, f"Failed to create phpIPAM section '{self.section_name}': {exc}")
            subnets: List[Dict[str, Any]] = []
        else:
            section_id = str(section["id"])
            try:
                subnets = self.client.get_subnets_in_section(section_id)
            except PhpIpamApiError as exc:
                return self._fail_run(
                    started_at, f"Failed to fetch phpIPAM subnets for section '{self.section_name}': {exc}"
                )

        try:
            tag_ids = self.client.get_address_tags()
        except PhpIpamApiError as exc:
            return self._fail_run(started_at, f"Failed to fetch phpIPAM address states: {exc}")
        used_tag_id = tag_ids.get("Used")

        devices: List[Dict[str, Any]] = self.lvi.search_devices_in_network(network=self.networks)
        logger.info("phpIPAM sync: %d device(s) from LVI", len(devices))

        mac_lookup: Dict[Tuple[str, str], str] = {}
        if self.sync_mac_address:
            prefetch_networks = resolve_prefetch_networks(self.networks, devices)
            interfaces_by_key = prefetch_device_interfaces(self.lvi, prefetch_networks)
            mac_lookup = build_mac_lookup(interfaces_by_key)

        errors = 0
        synced_ips: Set[str] = set()
        for device in devices:
            self._check_cancelled()
            ip_address = device.get("ipAddress", "")
            hostname = device.get("hostname") or device.get("name") or ""
            if not ip_address:
                continue

            mac_address = mac_for(mac_lookup, device) if self.sync_mac_address else ""

            try:
                subnet_id = self._resolve_subnet(subnets, ip_address, section_id)
            except PhpIpamApiError as exc:
                errors += 1
                self._outcomes.append(
                    DeviceSyncOutcome(ip_address=ip_address, hostname=hostname, action="error", error=str(exc))
                )
                if not self.continue_on_error:
                    break
                continue

            ok = self._sync_one_device(ip_address, hostname, subnet_id, device, mac_address, used_tag_id)
            synced_ips.add(ip_address)
            if not ok:
                errors += 1
                if not self.continue_on_error:
                    break

        if self.delete_stale_ips and not self.dry_run:
            self._delete_stale_addresses(subnets, synced_ips)

        if self._pending_items and not self.dry_run:
            try:
                record_pending_conflicts(PLUGIN_NAME, self._pending_items)
            except Exception as exc:
                logger.warning("Failed to record pending conflicts: %s", exc)

        self.last_report = SyncReport(
            plugin_name=PLUGIN_NAME,
            started_at=started_at,
            finished_at=datetime.now(timezone.utc).isoformat(),
            dry_run=self.dry_run,
            outcomes=self._outcomes,
        )
        return errors == 0

    def _fail_run(self, started_at: str, message: str) -> bool:
        """Record a run-level failure (a precondition, not a per-device error).

        Args:
            started_at: The run's start timestamp.
            message: The failure to log and surface in the report.

        Returns:
            False, always - lets callers `return self._fail_run(...)`.
        """
        logger.error(message)
        self.last_report = SyncReport(
            plugin_name=PLUGIN_NAME,
            started_at=started_at,
            finished_at=datetime.now(timezone.utc).isoformat(),
            dry_run=self.dry_run,
            outcomes=[],
            run_errors=[message],
        )
        return False

    # ------------------------------------------------------------------ #
    # Subnet resolution                                                    #
    # ------------------------------------------------------------------ #

    def _resolve_subnet(self, subnets: List[Dict[str, Any]], ip_address: str, section_id: str) -> Optional[str]:
        """Find (or, if enabled, create) the Subnet containing *ip_address*.

        Args:
            subnets: The Section's subnets, mutated in place with any newly
                created subnet so later devices in this run reuse it.
            ip_address: The device's management IP.
            section_id: The target Section's id.

        Returns:
            The containing subnet's id, or None if none exists and
            create_missing_subnets is off.
        """
        for subnet in subnets:
            if _subnet_contains(ip_address, subnet["subnet"], subnet["mask"]):
                return str(subnet["id"])

        if not self.create_missing_subnets:
            return None

        network_str, mask_str = _derive_subnet_cidr(ip_address, self.default_subnet_mask)
        if self.dry_run:
            logger.info("[DRY RUN] Would create subnet %s/%s", network_str, mask_str)
            # A stable negative sentinel so per-device dry-run logic below
            # can treat this exactly like a real subnet id without ever
            # sending it to a write call - every write stays gated on
            # self.dry_run independently.
            sentinel_id = f"dry-run-{network_str}-{mask_str}"
            subnets.append({"id": sentinel_id, "subnet": network_str, "mask": mask_str})
            return sentinel_id

        new_id = self.client.create_subnet(network_str, mask_str, section_id, description="Created by LVI Sync Manager")
        subnets.append({"id": new_id, "subnet": network_str, "mask": mask_str})
        return new_id

    # ------------------------------------------------------------------ #
    # Per-device sync                                                      #
    # ------------------------------------------------------------------ #

    def _sync_one_device(
        self,
        ip_address: str,
        hostname: str,
        subnet_id: Optional[str],
        device: Dict[str, Any],
        mac_address: str,
        used_tag_id: Optional[int],
    ) -> bool:
        """Sync one device's management IP to a phpIPAM Address.

        Conflict detection runs before any write, and every write is gated
        on ``self.dry_run`` individually rather than a single early return,
        so dry-run conflicts stay reachable and reported.

        Args:
            ip_address: The device's management IP.
            hostname: The device's hostname.
            subnet_id: The resolved target subnet's id, or None if none
                could be resolved/created.
            device: The raw LVI device record.
            mac_address: The device's MAC, or "" if not syncing MAC.
            used_tag_id: The "Used" address-state id, or None.

        Returns:
            True if the device was handled without an error (added,
            updated, ignored, or deferred as pending all count as success;
            only an actual write/lookup failure returns False).
        """
        if subnet_id is None:
            self._outcomes.append(
                DeviceSyncOutcome(
                    ip_address=ip_address,
                    hostname=hostname,
                    action="error",
                    error="No phpIPAM subnet contains this IP and 'Create Missing Subnets' is off",
                )
            )
            return False

        try:
            existing = self.client.search_address_by_ip(ip_address)
        except PhpIpamApiError as exc:
            self._outcomes.append(
                DeviceSyncOutcome(ip_address=ip_address, hostname=hostname, action="error", error=str(exc))
            )
            return False

        description = str(device.get("deviceType", ""))
        desired_payload = {
            "ip_address": ip_address,
            "subnet_id": subnet_id,
            "hostname": hostname,
            "description": description,
            "mac": mac_address,
            "tag_id": used_tag_id,
        }

        if existing is not None and not existing.get(MARKER_FIELD):
            detail = f"IP already exists in phpIPAM (hostname '{existing.get('hostname', '')}'), not managed by LVI Sync Manager"
            if self.ip_conflict_policy == "ignore":
                logger.info("Ignored address %s: %s", ip_address, detail)
                self._outcomes.append(
                    DeviceSyncOutcome(ip_address=ip_address, hostname=hostname, action="ignored", detail=detail)
                )
                return True
            if self.ip_conflict_policy == "ask":
                logger.warning("Conflict: %s - %s, policy=ask, deferred for review", ip_address, detail)
                self._pending_items.append(
                    pending_conflict_item(ip_address, hostname, "ip_exists", detail, desired_payload)
                )
                self._outcomes.append(
                    DeviceSyncOutcome(
                        ip_address=ip_address,
                        hostname=hostname,
                        action="pending",
                        detail=f"{detail} - awaiting decision",
                    )
                )
                return True
            # "overwrite" falls through and claims the existing record below.

        mac_previous = ""
        mac_changed = False
        mac_detail = ""
        duplicate_of = ""
        if self.sync_mac_address and mac_address:
            if existing is not None:
                mac_previous = str(existing.get("mac") or "")
                mac_changed = bool(mac_previous) and mac_previous.lower() != mac_address.lower()

            if self.mac_conflict_policy != "overwrite":
                dups = self.client.search_address_by_mac(mac_address)
                existing_id = str(existing["id"]) if existing is not None else None
                others = [d for d in dups if str(d.get("id")) != existing_id]
                if others:
                    duplicate_of = f"MAC already in use by '{others[0].get('hostname') or others[0].get('ip')}'"

            # A MAC conflict strips only the MAC field and defers it for
            # review (see pending_conflict_item below) - it never blocks the
            # rest of the record from being created/updated, matching
            # Infoblox's precedent. Only the ip_exists case above skips the
            # whole record.
            if duplicate_of and self.mac_conflict_policy == "ask":
                logger.warning("Conflict: %s MAC %s - %s, policy=ask, deferred", ip_address, mac_address, duplicate_of)
                self._pending_items.append(
                    pending_conflict_item(
                        ip_address, hostname, "mac_duplicate", duplicate_of, {**desired_payload, "mac": mac_address}
                    )
                )
                mac_detail = f"{duplicate_of} - awaiting decision"
                mac_address = ""
            elif mac_changed and self.mac_conflict_policy == "leave_untouched":
                mac_address = mac_previous
            elif mac_changed and self.mac_conflict_policy == "ask":
                logger.warning(
                    "Conflict: %s MAC differs (phpIPAM has %s, LogicVein has %s), policy=ask, deferred",
                    ip_address,
                    mac_previous,
                    mac_address,
                )
                self._pending_items.append(
                    pending_conflict_item(
                        ip_address,
                        hostname,
                        "mac_differs",
                        f"MAC differs: phpIPAM has {mac_previous}, LogicVein has {mac_address}",
                        desired_payload,
                    )
                )
                mac_detail = "MAC differs - awaiting decision"
                mac_address = mac_previous

        action = "updated" if existing is not None else "added"
        if self.dry_run:
            logger.info("[DRY RUN] Would %s address %s (%s)", "update" if existing else "create", ip_address, hostname)
            self._outcomes.append(
                DeviceSyncOutcome(
                    ip_address=ip_address,
                    hostname=hostname,
                    action=action,
                    mac=mac_address,
                    mac_changed=mac_changed,
                    mac_previous=mac_previous,
                    duplicate_mac_of=duplicate_of,
                    detail=mac_detail or "[DRY RUN]",
                )
            )
            return True

        try:
            if existing is not None:
                self.client.update_address(
                    existing["id"], hostname=hostname, description=description, mac=mac_address, **{MARKER_FIELD: "yes"}
                )
            else:
                self.client.create_address(
                    ip_address,
                    subnet_id,
                    hostname=hostname,
                    description=description,
                    mac=mac_address,
                    tag_id=used_tag_id,
                    custom_fields={MARKER_FIELD: "yes"},
                )
        except PhpIpamApiError as exc:
            self._outcomes.append(
                DeviceSyncOutcome(ip_address=ip_address, hostname=hostname, action="error", error=str(exc))
            )
            return False

        self._outcomes.append(
            DeviceSyncOutcome(
                ip_address=ip_address,
                hostname=hostname,
                action=action,
                detail=mac_detail,
                mac=mac_address,
                mac_changed=mac_changed,
                mac_previous=mac_previous,
                duplicate_mac_of=duplicate_of,
            )
        )
        return True

    # ------------------------------------------------------------------ #
    # Stale-address cleanup                                                #
    # ------------------------------------------------------------------ #

    def _delete_stale_addresses(self, subnets: List[Dict[str, Any]], synced_ips: Set[str]) -> None:
        """Delete lvi_managed addresses this run no longer reports.

        Only ever considers addresses carrying the marker field, scoped to
        the subnets under the target Section this run touched - a
        manually-added or other tool's address is never touched.

        Args:
            subnets: The Section's subnets (including any created this run).
            synced_ips: Every IP this run actually wrote/confirmed.
        """
        for subnet in subnets:
            try:
                addresses = self.client.get_addresses_in_subnet(subnet["id"])
            except PhpIpamApiError as exc:
                logger.warning("Failed to list addresses in subnet %s for stale cleanup: %s", subnet["id"], exc)
                continue
            for address in addresses:
                ip_address = address.get("ip", "")
                if not address.get(MARKER_FIELD) or ip_address in synced_ips:
                    continue
                try:
                    self.client.delete_address(address["id"])
                except PhpIpamApiError as exc:
                    logger.warning("Failed to delete stale address %s: %s", ip_address, exc)
                    continue
                logger.info("Deleted stale phpIPAM address %s (%s)", ip_address, address.get("hostname", ""))
                self._outcomes.append(
                    DeviceSyncOutcome(ip_address=ip_address, hostname=address.get("hostname", ""), action="deleted")
                )
