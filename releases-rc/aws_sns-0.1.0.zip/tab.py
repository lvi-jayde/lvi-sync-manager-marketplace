"""The AWS SNS tab: what was sent, what is held back, and a test send."""

from datetime import datetime
from typing import Any, Callable, Dict, List, Optional

from nicegui import run, ui

# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import (  # pyright: ignore[reportMissingImports]
    has_role,
    require_role,
    running_plugin_service,
    t,
)

from .handlers import get_outbox, send_test
from .settings import PLUGIN_ID, get_settings


def _t(key: str, **kwargs: Any) -> str:
    """Translate one of this tab's strings.

    Args:
        key: The key under ``aws_sns.tab.``.
        **kwargs: Placeholder values.

    Returns:
        The translated text.
    """
    return t(f"aws_sns.tab.{key}", plugin=PLUGIN_ID, **kwargs)


def _when(epoch: Optional[float]) -> str:
    """Local time for an epoch timestamp.

    Args:
        epoch: Seconds since the epoch, or None.

    Returns:
        ``YYYY-MM-DD HH:MM:SS``, or "" when there is none.
    """
    if not epoch:
        return ""
    return datetime.fromtimestamp(float(epoch)).strftime("%Y-%m-%d %H:%M:%S")


def _held_rows() -> List[Dict[str, Any]]:
    return [
        {
            "id": r["id"],
            "due": _when(r["due_at"]),
            "kind": r["kind"],
            "node": r["node"],
            "severity": r["severity"],
            "reason": _t(f"reason_{r['hold_reason']}") if r["hold_reason"] else "",
            "attempts": r["attempts"],
            "error": r["error"],
            "message": r["message"],
        }
        for r in get_outbox().held()
    ]


def _recent_rows() -> List[Dict[str, Any]]:
    return [
        {
            "id": r["id"],
            "when": _when(r["sent_at"] or r["created_at"]),
            "kind": r["kind"],
            "node": r["node"],
            "severity": r["severity"],
            "status": r["status"],
            "message": r["message"],
            "message_id": r["message_id"],
            "error": r["error"],
        }
        for r in get_outbox().recent(200)
    ]


def _columns(names: List[str]) -> List[Dict[str, Any]]:
    return [{"name": n, "label": _t(f"col_{n}"), "field": n, "align": "left", "sortable": True} for n in names]


def render_tab() -> Callable[[], None]:
    """Render the AWS SNS tab; returns the refresh run on each visit.

    Returns:
        A callable that reloads the tab.
    """
    container = ui.column().classes("w-full")

    async def test_send() -> None:
        if not require_role("admin"):
            return
        result = await run.io_bound(send_test) or {"ok": False, "error": "no result"}
        if result["ok"]:
            ui.notify(_t("test_sent", message_id=result["message_id"]), type="positive")
        else:
            ui.notify(_t("test_failed", error=result["error"]), type="negative", multi_line=True)
        refresh()

    def confirm_test() -> None:
        with ui.dialog() as dialog, ui.card():
            ui.label(_t("test_confirm"))
            with ui.row():
                ui.button(_t("send"), on_click=lambda: (dialog.close(), test_send())).props("color=primary")
                ui.button(_t("cancel"), on_click=dialog.close).props("flat")
        dialog.open()

    def refresh() -> None:
        container.clear()
        with container:
            arn = str((get_settings().get("sns", {}) or {}).get("topic_arn") or "")
            with ui.row().classes("items-center gap-4 w-full"):
                ui.label(_t("topic", topic=arn) if arn else _t("no_topic")).classes("text-sm")
                ui.space()
                ui.button(_t("refresh"), icon="refresh", on_click=refresh).props("flat dense")
                if has_role("admin"):
                    ui.button(_t("send_test"), icon="sms", on_click=confirm_test).props("dense").mark("aws-sns-test")
            flusher = running_plugin_service(PLUGIN_ID, "Flusher")
            if flusher is None:
                ui.label(_t("flusher_stopped")).classes("text-sm text-warning")
            elif getattr(flusher, "last_error", ""):
                ui.label(_t("flusher_error", error=flusher.last_error)).classes("text-sm text-negative")

            held = _held_rows()
            ui.label(_t("held", n=len(held))).classes("text-base font-bold mt-2")
            if held:
                ui.table(
                    columns=_columns(["due", "kind", "node", "severity", "reason", "attempts", "error", "message"]),
                    rows=held,
                    row_key="id",
                    pagination=10,
                ).props("dense flat bordered").classes("w-full").mark("aws-sns-held")
            else:
                ui.label(_t("none_held")).classes("text-sm")

            ui.label(_t("recent")).classes("text-base font-bold mt-2")
            ui.table(
                columns=_columns(["when", "kind", "node", "severity", "status", "message", "message_id", "error"]),
                rows=_recent_rows(),
                row_key="id",
                pagination=25,
            ).props("dense flat bordered").classes("w-full").mark("aws-sns-recent")

    refresh()
    return refresh
