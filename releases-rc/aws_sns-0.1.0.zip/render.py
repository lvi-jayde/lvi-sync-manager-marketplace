"""Turn an event into the texts one SNS publish carries.

Each notification is one ``Publish`` with ``MessageStructure=json``: a short
SMS text, a full text for email and every other protocol, and an email
subject. See :mod:`.client`.

**SMS text.** The aim is one SMS segment, since each segment is billed. A
segment holds 160 GSM-7 characters, but only 70 if any character forces
UCS-2 - one curly quote or emoji does it. So the SMS text is normalised to
GSM-7-safe ASCII (curly quotes, dashes and ellipses become their ASCII forms,
accented letters lose their accents, anything else is dropped), whitespace is
collapsed to single spaces, and the result is cut at a word boundary, with
``...``, to ``sms.max_length``. GSM-7's extension characters (``^ { } [ ] ~
| \\``) take two septets each, and the budget counts them that way.

**Templates** are ``str.format`` strings over the event's fields. An unknown
placeholder is kept literally, and a template that cannot be formatted at all
(an unbalanced brace) falls back to the default, so a typo in the config never
stops an alert from going out.
"""

import re
import unicodedata
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional

DEFAULT_TEMPLATES: Dict[str, str] = {
    "alert_raise": "[{severity}] {node}: {message}",
    "alert_resolve": "[RESOLVED] {node}: {message}",
    "coalesced": "{node}: {count} alerts in {minutes} min, highest {severity}",
    "capped": "{count} more alerts held back in the last minute - see {product}",
    "test": "Test notification from Sync Manager's AWS SNS plugin",
}

# Severity order for alerts.min_severity; aliases LogicVein may send map to
# the nearest level. An unrecognised or empty severity counts as "high", so
# it is notified rather than silently filtered.
SEVERITY_RANK: Dict[str, int] = {
    "critical": 5,
    "high": 4,
    "major": 4,
    "medium": 3,
    "warning": 3,
    "minor": 2,
    "low": 2,
    "info": 1,
    "informational": 1,
}
_UNKNOWN_RANK = 4

# Characters that become a GSM-7 safe ASCII form rather than being dropped.
_REPLACEMENTS = {
    "\u2018": "'",
    "\u2019": "'",
    "\u201a": "'",
    "\u201b": "'",
    "\u2032": "'",
    "\u201c": '"',
    "\u201d": '"',
    "\u201e": '"',
    "\u2033": '"',
    "\u2010": "-",
    "\u2011": "-",
    "\u2012": "-",
    "\u2013": "-",
    "\u2014": "-",
    "\u2015": "-",
    "\u2212": "-",
    "\u2026": "...",
    "\u00a0": " ",
    "\u2022": "*",
    "`": "'",
}
# GSM-7 extension characters: valid, but two septets each.
_EXTENDED = frozenset("^{}[]~|\\")
_ELLIPSIS = "..."
SUBJECT_MAX = 99  # SNS: "less than 100 characters"
MIN_SMS_LENGTH = 70


def severity_rank(severity: str) -> int:
    """Rank a LogicVein severity for the minimum-severity filter.

    Args:
        severity: e.g. ``"critical"``; case-insensitive.

    Returns:
        5 (critical) down to 1 (info); an unknown or empty severity ranks as
        high.
    """
    return SEVERITY_RANK.get((severity or "").strip().lower(), _UNKNOWN_RANK)


def gsm_safe(text: str) -> str:
    """Normalise *text* to GSM-7-safe ASCII on one line.

    Args:
        text: Any text.

    Returns:
        ASCII text with whitespace collapsed to single spaces.
    """
    out = []
    for char in text or "":
        if char in _REPLACEMENTS:
            out.append(_REPLACEMENTS[char])
            continue
        if char.isspace():
            out.append(" ")
            continue
        if " " <= char <= "~":
            out.append(char)
            continue
        # Accented letters keep their base letter (e -> e, n~ -> n); anything
        # with no ASCII form is dropped.
        decomposed = unicodedata.normalize("NFKD", char).encode("ascii", "ignore").decode("ascii")
        out.append("".join(c for c in decomposed if " " <= c <= "~"))
    return re.sub(r" +", " ", "".join(out)).strip()


def septets(text: str) -> int:
    """GSM-7 length: extension characters count twice.

    Args:
        text: GSM-7-safe text.

    Returns:
        The number of septets it takes.
    """
    return len(text) + sum(1 for c in text if c in _EXTENDED)


def truncate(text: str, budget: int) -> str:
    """Cut *text* to *budget* septets, ending in ``...``.

    At a word boundary, unless that would use under two thirds of the
    budget; then inside the long word.

    Args:
        text: GSM-7-safe text.
        budget: The most septets allowed.

    Returns:
        *text* unchanged when it fits, else a shortened version that fits.
    """
    if septets(text) <= budget:
        return text
    room = budget - len(_ELLIPSIS)
    cut = ""
    for word in text.split(" "):
        candidate = f"{cut} {word}" if cut else word
        if septets(candidate) > room:
            break
        cut = candidate
    if septets(cut) < room * 2 // 3:
        # The next word is too long to drop whole (a URL, an interface list):
        # stopping at the boundary would throw most of the budget away, so
        # cut inside it instead.
        cut = ""
        for char in text:
            if septets(cut + char) > room:
                break
            cut += char
    return cut.rstrip(" .,;:-") + _ELLIPSIS


class _KeepUnknown(dict):
    """Format mapping that leaves an unknown ``{placeholder}`` as written."""

    def __missing__(self, key: str) -> str:
        return "{" + key + "}"


def fill(template_name: str, templates: Optional[Mapping[str, Any]], fields: Mapping[str, Any]) -> str:
    """Fill a named template, falling back to the default on a broken one.

    Args:
        template_name: A key of :data:`DEFAULT_TEMPLATES`.
        templates: The configured ``templates`` section (may be None or
            partial).
        fields: The placeholder values.

    Returns:
        The filled text.
    """
    default = DEFAULT_TEMPLATES[template_name]
    configured = (templates or {}).get(template_name)
    template = configured if isinstance(configured, str) and configured.strip() else default
    values = _KeepUnknown({k: "" if v is None else v for k, v in fields.items()})
    try:
        return template.format_map(values)
    except (ValueError, IndexError, AttributeError):
        return default.format_map(values)


@dataclass(frozen=True)
class Rendered:
    """The texts one publish carries."""

    sms: str
    full: str
    subject: str


def subject_line(text: str) -> str:
    """An email subject SNS accepts: ASCII, one line, under 100 characters.

    Args:
        text: The summary.

    Returns:
        The subject.
    """
    return truncate(gsm_safe(text), SUBJECT_MAX)


def sms_text(text: str, max_length: int, link: str = "") -> str:
    """The SMS rendering: GSM-7-safe, within budget, with the link if asked.

    Args:
        text: The filled template.
        max_length: ``sms.max_length``; never below 70.
        link: A link to append (counted in the budget), or "".

    Returns:
        The SMS text.
    """
    budget = max(MIN_SMS_LENGTH, int(max_length or 160))
    text = gsm_safe(text)
    link = gsm_safe(link)
    if link and septets(link) + 1 < budget:
        return f"{truncate(text, budget - septets(link) - 1)} {link}"
    return truncate(text, budget)


def _alert_fields(event: Any, product: str) -> Dict[str, Any]:
    return {
        "severity": (getattr(event, "severity", "") or "alert").upper(),
        "node": getattr(event, "node", "") or "unknown device",
        "message": getattr(event, "message", "") or "violation",
        "occurrences": getattr(event, "occurrences", "") or "",
        "status": getattr(event, "violation_status", "") or "",
        "updated_at": getattr(event, "updated_at", "") or "",
        "link": getattr(event, "link", "") or "",
        "product": product,
    }


def render_alert(
    event: Any, resolved: bool, product: str, sms_max: int, include_link: bool, templates: Optional[Mapping] = None
) -> Rendered:
    """Render an alert raise or resolve.

    Args:
        event: The ``AlertEvent``.
        resolved: True for a resolve.
        product: The LogicVein product name.
        sms_max: ``sms.max_length``.
        include_link: ``sms.include_link``.
        templates: The configured ``templates`` section.

    Returns:
        The SMS text, full text and subject.
    """
    fields = _alert_fields(event, product)
    summary = fill("alert_resolve" if resolved else "alert_raise", templates, fields)
    lines = [
        f"{product} alert {'resolved' if resolved else 'raised'}",
        "",
        f"Severity: {getattr(event, 'severity', '') or '-'}",
        f"Device: {fields['node']}",
        f"Message: {getattr(event, 'message', '') or '-'}",
        f"Occurrences: {fields['occurrences'] or '-'}",
        f"Violation status: {fields['status'] or '-'}",
        f"Updated: {fields['updated_at'] or '-'}",
    ]
    if fields["link"]:
        lines.append(f"Link: {fields['link']}")
    return Rendered(
        sms=sms_text(summary, sms_max, fields["link"] if include_link else ""),
        full="\n".join(lines),
        subject=subject_line(f"[{product}] {summary}"),
    )


def render_coalesced(
    node: str, items: list, minutes: int, product: str, sms_max: int, templates: Optional[Mapping] = None
) -> Rendered:
    """Render one message for several held alerts on one device.

    Args:
        node: The device.
        items: The held alerts, each a mapping with ``severity`` and
            ``message`` (oldest first).
        minutes: The coalescing window.
        product: The LogicVein product name.
        sms_max: ``sms.max_length``.
        templates: The configured ``templates`` section.

    Returns:
        The SMS text, full text and subject.
    """
    highest = max((str(i.get("severity") or "") for i in items), key=severity_rank, default="")
    fields = {
        "node": node or "unknown device",
        "count": len(items),
        "minutes": minutes,
        "severity": (highest or "alert").upper(),
        "product": product,
    }
    summary = fill("coalesced", templates, fields)
    lines = [f"{product}: {len(items)} alerts on {fields['node']} in {minutes} min", ""]
    lines += [f"- [{(i.get('severity') or '-').upper()}] {i.get('message') or '-'}" for i in items]
    return Rendered(
        sms=sms_text(summary, sms_max), full="\n".join(lines), subject=subject_line(f"[{product}] {summary}")
    )


def render_capped(items: list, product: str, sms_max: int, templates: Optional[Mapping] = None) -> Rendered:
    """Render the summary of alerts held back by the per-minute cap.

    Args:
        items: The held alerts, each a mapping with ``node``, ``severity``
            and ``message``.
        product: The LogicVein product name.
        sms_max: ``sms.max_length``.
        templates: The configured ``templates`` section.

    Returns:
        The SMS text, full text and subject.
    """
    summary = fill("capped", templates, {"count": len(items), "product": product})
    lines = [f"{product}: {len(items)} alerts held back by the per-minute limit", ""]
    lines += [
        f"- {i.get('node') or '-'} [{(i.get('severity') or '-').upper()}] {i.get('message') or '-'}" for i in items
    ]
    return Rendered(
        sms=sms_text(summary, sms_max), full="\n".join(lines), subject=subject_line(f"[{product}] {summary}")
    )


def render_test(product: str, sms_max: int, templates: Optional[Mapping] = None) -> Rendered:
    """Render the test notification.

    Args:
        product: The LogicVein product name.
        sms_max: ``sms.max_length``.
        templates: The configured ``templates`` section.

    Returns:
        The SMS text, full text and subject.
    """
    summary = fill("test", templates, {"product": product})
    full = f"{summary}\n\nIf you received this, the topic and its subscriptions work."
    return Rendered(sms=sms_text(summary, sms_max), full=full, subject=subject_line(summary))
