"""The plugin's own state: alert open/closed, and every event's outcome.

Kept in ``aws_sns.db`` in the plugin's data directory, not in the app's
database: the app's schema belongs to its own migrations, and this file
survives plugin upgrades and goes with the plugin's data.

Two tables:

- ``alert_state`` - one row per LogicVein alert ``hash``: ``open`` or
  ``closed``, and what happened to its raise (``raise_outcome``: ``sending``,
  ``sent``, ``held``, ``skipped`` or ``failed``). LogicVein sends ``raise``
  for the first violation, for each further one, and again on a retry, all
  with the same hash; the plugin texts on the closed-to-open transition, not
  on each delivery.
- ``outbox`` - one row per outcome (``sent``, ``held``, ``sending``,
  ``failed``, ``skipped``, ``repeat``, ``resolved before sent``,
  ``superseded``), for the
  tab, for flood control (how many sends in the last minute, whether a
  device's coalescing window is open), and as the queue the flusher sends
  from (``held`` rows, with ``due_at``).

Every decision runs in one ``BEGIN IMMEDIATE`` transaction (read, decide,
write), so two concurrent deliveries of the same raise cannot both send and a
resolve cannot interleave with the raise it closes. The network call happens
after the transaction commits, with the row marked ``sending``.

Rows older than seven days are pruned, except held ones; closed alert states
are pruned after seven days too.
"""

import json
import sqlite3
import threading
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional

RETENTION_SECONDS = 7 * 24 * 3600
# A send still `sending` after this long was interrupted: connect (5 s) plus
# a read (sns.timeout, at most client.MAX_TIMEOUT = 60 s) end inside it.
STALE_SENDING_SECONDS = 120

_SCHEMA = """
CREATE TABLE IF NOT EXISTS alert_state (
    hash TEXT PRIMARY KEY,
    state TEXT NOT NULL,
    raise_outcome TEXT NOT NULL DEFAULT '',
    node TEXT NOT NULL DEFAULT '',
    severity TEXT NOT NULL DEFAULT '',
    opened_at REAL,
    closed_at REAL,
    last_message_id TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS outbox (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kind TEXT NOT NULL,
    key TEXT NOT NULL DEFAULT '',
    node TEXT NOT NULL DEFAULT '',
    severity TEXT NOT NULL DEFAULT '',
    message TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL,
    hold_reason TEXT NOT NULL DEFAULT '',
    due_at REAL,
    attempts INTEGER NOT NULL DEFAULT 0,
    message_id TEXT NOT NULL DEFAULT '',
    error TEXT NOT NULL DEFAULT '',
    payload TEXT NOT NULL DEFAULT '',
    created_at REAL NOT NULL,
    sent_at REAL
);
CREATE INDEX IF NOT EXISTS outbox_status_due ON outbox (status, due_at);
CREATE INDEX IF NOT EXISTS outbox_node_sent ON outbox (node, sent_at);
CREATE INDEX IF NOT EXISTS outbox_key ON outbox (key);
"""

# Kinds that count towards the per-minute cap and open a device's
# coalescing window (a test send does neither). Only rows with no hold
# reason count: one per message actually sent. Held rows the flusher sends
# together keep their hold reason, and the flusher records the message
# itself as a row of its own.
NOTIFICATION_KINDS = ("raise", "resolve", "coalesced", "capped")


class Outbox:
    """The plugin's SQLite store; safe to share across threads."""

    def __init__(self, path: Path) -> None:
        """Open (creating if needed) the database at *path*.

        Args:
            path: The SQLite file.
        """
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        with self._connect() as conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.executescript(_SCHEMA)

    def _connect(self) -> sqlite3.Connection:
        """This thread's connection (autocommit; transactions are explicit).

        Returns:
            The connection.
        """
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = sqlite3.connect(self.path, timeout=30, isolation_level=None, check_same_thread=False)
            conn.row_factory = sqlite3.Row
            self._local.conn = conn
        return conn

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        """Run a read-decide-write step atomically (``BEGIN IMMEDIATE``).

        Yields:
            The connection, inside the transaction.

        Raises:
            BaseException: Whatever the step raised, after rolling back.
        """
        conn = self._connect()
        conn.execute("BEGIN IMMEDIATE")
        try:
            yield conn
        except BaseException:
            conn.execute("ROLLBACK")
            raise
        conn.execute("COMMIT")

    # -- alert state -------------------------------------------------------

    @staticmethod
    def alert(conn: sqlite3.Connection, alert_hash: str) -> Optional[sqlite3.Row]:
        """The alert's state row, or None if never seen.

        Args:
            conn: A connection inside a transaction.
            alert_hash: LogicVein's alert hash.

        Returns:
            The row, or None.
        """
        return conn.execute("SELECT * FROM alert_state WHERE hash = ?", (alert_hash,)).fetchone()

    @staticmethod
    def open_alert(
        conn: sqlite3.Connection, alert_hash: str, node: str, severity: str, outcome: str, now: float
    ) -> None:
        """Mark an alert open with its raise's outcome.

        Args:
            conn: A connection inside a transaction.
            alert_hash: LogicVein's alert hash.
            node: The device.
            severity: The alert severity.
            outcome: What happened to the raise (``sending``, ``held``, ...).
            now: The current time (epoch seconds).
        """
        conn.execute(
            """INSERT INTO alert_state (hash, state, raise_outcome, node, severity, opened_at, closed_at)
               VALUES (?, 'open', ?, ?, ?, ?, NULL)
               ON CONFLICT(hash) DO UPDATE SET state = 'open', raise_outcome = excluded.raise_outcome,
                 node = excluded.node, severity = excluded.severity, opened_at = excluded.opened_at,
                 closed_at = NULL""",
            (alert_hash, outcome, node, severity, now),
        )

    @staticmethod
    def set_raise_outcome(conn: sqlite3.Connection, alert_hash: str, outcome: str, message_id: str = "") -> None:
        """Record what became of an open alert's raise.

        Args:
            conn: A connection inside a transaction.
            alert_hash: LogicVein's alert hash.
            outcome: ``sent``, ``failed``, ...
            message_id: SNS's MessageId, when sent.
        """
        conn.execute(
            "UPDATE alert_state SET raise_outcome = ?, last_message_id = CASE WHEN ? = '' THEN last_message_id ELSE ? END"
            " WHERE hash = ?",
            (outcome, message_id, message_id, alert_hash),
        )

    @staticmethod
    def close_alert(conn: sqlite3.Connection, alert_hash: str, now: float) -> None:
        """Mark an alert closed (creating the row for a never-seen hash).

        Args:
            conn: A connection inside a transaction.
            alert_hash: LogicVein's alert hash.
            now: The current time.
        """
        conn.execute(
            """INSERT INTO alert_state (hash, state, closed_at) VALUES (?, 'closed', ?)
               ON CONFLICT(hash) DO UPDATE SET state = 'closed', closed_at = excluded.closed_at""",
            (alert_hash, now),
        )

    @staticmethod
    def reopen_alert(conn: sqlite3.Connection, alert_hash: str) -> None:
        """Undo a close (a resolve whose notification failed and will be retried).

        Args:
            conn: A connection inside a transaction.
            alert_hash: LogicVein's alert hash.
        """
        conn.execute("UPDATE alert_state SET state = 'open', closed_at = NULL WHERE hash = ?", (alert_hash,))

    # -- outbox ------------------------------------------------------------

    @staticmethod
    def record(
        conn: sqlite3.Connection,
        kind: str,
        status: str,
        now: float,
        key: str = "",
        node: str = "",
        severity: str = "",
        message: str = "",
        hold_reason: str = "",
        due_at: Optional[float] = None,
        message_id: str = "",
        error: str = "",
        payload: Optional[Dict[str, Any]] = None,
    ) -> int:
        """Append an outcome row.

        Args:
            conn: A connection (inside a transaction for a decision).
            kind: ``raise``, ``resolve``, ``coalesced``, ``capped`` or ``test``.
            status: ``sent``, ``held``, ``sending``, ``failed``, ``skipped``,
                ``repeat`` or ``resolved before sent``.
            now: The current time.
            key: The alert hash.
            node: The device.
            severity: The alert severity.
            message: The SMS text (or the alert message for a held row).
            hold_reason: ``coalesce`` or ``cap`` for a held row.
            due_at: When a held row may be sent.
            message_id: SNS's MessageId.
            error: The failure, if any.
            payload: The event's fields, for rendering a held row later.

        Returns:
            The row id.
        """
        sent_at = now if status in ("sent", "sending") else None
        cursor = conn.execute(
            """INSERT INTO outbox (kind, key, node, severity, message, status, hold_reason, due_at, message_id,
                 error, payload, created_at, sent_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                kind,
                key,
                node,
                severity,
                message,
                status,
                hold_reason,
                due_at,
                message_id,
                error,
                json.dumps(payload) if payload else "",
                now,
                sent_at,
            ),
        )
        return int(cursor.lastrowid or 0)

    @staticmethod
    def finish(
        conn: sqlite3.Connection, row_ids: List[int], status: str, now: float, message_id: str = "", error: str = ""
    ) -> None:
        """Settle rows after a send attempt.

        Args:
            conn: A connection.
            row_ids: The outbox rows.
            status: ``sent`` or ``failed``.
            now: The current time.
            message_id: SNS's MessageId, when sent.
            error: The failure, when failed.
        """
        conn.executemany(
            "UPDATE outbox SET status = ?, message_id = ?, error = ?, sent_at = ?, due_at = NULL WHERE id = ?",
            [(status, message_id, error, now if status == "sent" else None, row_id) for row_id in row_ids],
        )

    @staticmethod
    def sends_in_last_minute(conn: sqlite3.Connection, now: float) -> int:
        """Notifications sent (or being sent) in the last 60 seconds.

        Args:
            conn: A connection.
            now: The current time.

        Returns:
            The count, for the per-minute cap.
        """
        kinds = ",".join("?" * len(NOTIFICATION_KINDS))
        row = conn.execute(
            f"SELECT COUNT(*) FROM outbox WHERE status IN ('sent', 'sending') AND hold_reason = '' AND kind IN ({kinds}) AND sent_at > ?",
            (*NOTIFICATION_KINDS, now - 60),
        ).fetchone()
        return int(row[0])

    @staticmethod
    def cap_frees_at(conn: sqlite3.Connection, now: float) -> float:
        """When the oldest send in the last minute stops counting.

        Args:
            conn: A connection.
            now: The current time.

        Returns:
            That time, or *now* when nothing counts.
        """
        kinds = ",".join("?" * len(NOTIFICATION_KINDS))
        row = conn.execute(
            f"SELECT MIN(sent_at) FROM outbox WHERE status IN ('sent', 'sending') AND hold_reason = ''"
            f" AND kind IN ({kinds}) AND sent_at > ?",
            (*NOTIFICATION_KINDS, now - 60),
        ).fetchone()
        return float(row[0]) + 60 if row[0] is not None else now

    @staticmethod
    def window_end(conn: sqlite3.Connection, node: str, minutes: int, now: float) -> Optional[float]:
        """When the device's coalescing window closes, if one is open.

        A window opens with each notification sent for the device and lasts
        *minutes*; a device with held rows already has one.

        Args:
            conn: A connection.
            node: The device.
            minutes: ``flood.coalesce_minutes``.
            now: The current time.

        Returns:
            The window's end, or None when no window is open.
        """
        if minutes <= 0:
            return None
        held = conn.execute(
            "SELECT MIN(due_at) FROM outbox WHERE status = 'held' AND hold_reason = 'coalesce' AND node = ?", (node,)
        ).fetchone()
        if held[0] is not None:
            return float(held[0])
        kinds = ",".join("?" * len(NOTIFICATION_KINDS))
        last = conn.execute(
            f"SELECT MAX(sent_at) FROM outbox WHERE status IN ('sent', 'sending') AND hold_reason = ''"
            f" AND kind IN ({kinds}) AND node = ?",
            (*NOTIFICATION_KINDS, node),
        ).fetchone()
        if last[0] is not None and float(last[0]) + minutes * 60 > now:
            return float(last[0]) + minutes * 60
        return None

    @staticmethod
    def held_raise(conn: sqlite3.Connection, alert_hash: str) -> List[sqlite3.Row]:
        """The alert's raise rows still waiting to be sent.

        Args:
            conn: A connection inside a transaction.
            alert_hash: LogicVein's alert hash.

        Returns:
            Its ``held`` raise rows.
        """
        return conn.execute(
            "SELECT * FROM outbox WHERE status = 'held' AND kind = 'raise' AND key = ?", (alert_hash,)
        ).fetchall()

    @staticmethod
    def supersede_held(conn: sqlite3.Connection, alert_hash: str, kind: str, now: float) -> None:
        """Mark the alert's held rows of *kind* ``superseded`` (never sent).

        Args:
            conn: A connection inside a transaction.
            alert_hash: LogicVein's alert hash.
            kind: ``resolve`` (a newer raise supersedes a held resolve).
            now: The current time.
        """
        conn.execute(
            "UPDATE outbox SET status = 'superseded', due_at = NULL, sent_at = ?"
            " WHERE status = 'held' AND kind = ? AND key = ?",
            (now, kind, alert_hash),
        )

    @staticmethod
    def drop_held(conn: sqlite3.Connection, row_ids: List[int], now: float) -> None:
        """Mark held rows ``resolved before sent``.

        Args:
            conn: A connection inside a transaction.
            row_ids: The rows.
            now: The current time.
        """
        conn.executemany(
            "UPDATE outbox SET status = 'resolved before sent', due_at = NULL, sent_at = ? WHERE id = ?",
            [(now, row_id) for row_id in row_ids],
        )

    @staticmethod
    def claim_due(conn: sqlite3.Connection, now: float) -> List[sqlite3.Row]:
        """Mark every held row that is due ``sending`` and return them.

        Args:
            conn: A connection inside a transaction.
            now: The current time.

        Returns:
            The claimed rows, oldest first.
        """
        rows = conn.execute(
            "SELECT * FROM outbox WHERE status = 'held' AND due_at <= ? ORDER BY due_at, id", (now,)
        ).fetchall()
        conn.executemany(
            "UPDATE outbox SET status = 'sending', sent_at = ? WHERE id = ?", [(now, r["id"]) for r in rows]
        )
        return rows

    @staticmethod
    def release(conn: sqlite3.Connection, row_ids: List[int], due_at: float, error: str = "") -> None:
        """Put claimed rows back to ``held``, due at *due_at*.

        Args:
            conn: A connection.
            row_ids: The rows.
            due_at: When to try again.
            error: The last failure, shown on the tab.
        """
        conn.executemany(
            "UPDATE outbox SET status = 'held', due_at = ?, sent_at = NULL, error = ?, attempts = attempts + ?"
            " WHERE id = ?",
            [(due_at, error, 1 if error else 0, row_id) for row_id in row_ids],
        )

    def recover(self, now: Optional[float] = None) -> int:
        """Undo sends a crash or restart interrupted.

        - Rows the flusher had claimed (``sending`` with a hold reason) go back
          to ``held``, due now.
        - An immediate send left ``sending`` fails, and its alert closes, so
          LogicVein's retry of that raise (it got no answer) sends it again
          instead of finding the alert open.

        Only sends older than :data:`STALE_SENDING_SECONDS` count: the
        flusher also restarts on a settings save, while a handler may be in
        the middle of a send. Either case can text twice if the interrupted
        send had reached SNS - the at-least-once side of the design.

        Args:
            now: The current time (tests).

        Returns:
            How many outbox rows were recovered.
        """
        now = now if now is not None else time.time()
        stale = now - STALE_SENDING_SECONDS
        with self.transaction() as conn:
            requeued = conn.execute(
                "UPDATE outbox SET status = 'held', due_at = ?, sent_at = NULL"
                " WHERE status = 'sending' AND hold_reason != '' AND sent_at < ?",
                (now, stale),
            ).rowcount
            failed = conn.execute(
                "UPDATE outbox SET status = 'failed', error = 'interrupted before SNS answered'"
                " WHERE status = 'sending' AND hold_reason = '' AND sent_at < ?",
                (stale,),
            ).rowcount
            conn.execute(
                "UPDATE alert_state SET state = 'closed', closed_at = ?, raise_outcome = 'failed'"
                " WHERE state = 'open' AND raise_outcome = 'sending' AND opened_at < ?",
                (now, stale),
            )
            return requeued + failed

    def prune(self, now: Optional[float] = None) -> None:
        """Delete settled rows and closed alerts older than seven days.

        Args:
            now: The current time (tests).
        """
        cutoff = (now if now is not None else time.time()) - RETENTION_SECONDS
        with self.transaction() as conn:
            conn.execute("DELETE FROM outbox WHERE status NOT IN ('held', 'sending') AND created_at < ?", (cutoff,))
            conn.execute("DELETE FROM alert_state WHERE state = 'closed' AND closed_at < ?", (cutoff,))

    # -- the tab -------------------------------------------------------------

    def recent(self, limit: int = 200) -> List[Dict[str, Any]]:
        """The latest outcome rows, newest first.

        Args:
            limit: How many.

        Returns:
            The rows as dicts.
        """
        rows = self._connect().execute("SELECT * FROM outbox ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]

    def held(self) -> List[Dict[str, Any]]:
        """Every row waiting to be sent, soonest first.

        Returns:
            The rows as dicts.
        """
        rows = (
            self._connect()
            .execute("SELECT * FROM outbox WHERE status IN ('held', 'sending') ORDER BY due_at, id")
            .fetchall()
        )
        return [dict(r) for r in rows]
