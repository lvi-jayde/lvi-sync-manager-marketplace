"""Plugin-local access to the AWS SNS configuration, credentials and client."""

import threading
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import get_config, load_credentials  # pyright: ignore[reportMissingImports]

from .client import SnsClient

PLUGIN_ID = "aws_sns"
_CONFIG_FILE = Path("conf/aws_sns_config.yaml")
_DEFAULTS_FILE = Path(__file__).parent / "conf" / "defaults.yaml"

_client_lock = threading.Lock()
_client: Optional[Tuple[Tuple[Any, ...], SnsClient]] = None


def get_settings() -> Dict[str, Any]:
    """Return the plugin's config (created from the defaults on first use).

    Returns:
        The parsed ``conf/aws_sns_config.yaml``.
    """
    return get_config(_CONFIG_FILE, _DEFAULTS_FILE)


def build_client(credentials: Dict[str, Any], settings: Optional[Dict[str, Any]] = None) -> SnsClient:
    """Build a client from credential values and the current settings.

    A key pair entered in the Credentials tab is used as is; with none,
    boto3's default credential chain applies (which also reads
    ``AWS_ACCESS_KEY_ID`` / ``AWS_SECRET_ACCESS_KEY`` from the environment).

    Args:
        credentials: Saved or form credential values.
        settings: The plugin config; read when omitted.

    Returns:
        A new client. ``SnsClient`` raises ``SnsError`` (a configuration
        error) for a malformed ARN or half a key pair.
    """
    sns = (settings if settings is not None else get_settings()).get("sns", {}) or {}
    return SnsClient(
        str(sns.get("topic_arn") or ""),
        access_key_id=str(credentials.get("access_key_id") or ""),
        secret_access_key=str(credentials.get("secret_access_key") or ""),
        timeout=int(sns.get("timeout") or 10),
    )


def get_client() -> SnsClient:
    """The shared client for the saved credentials and current settings.

    With the Credentials tab's **Use environment variables** switch on (the
    default), a key saved in the tab is ignored and boto3's default chain
    applies, matching what Test Connection is given. Rebuilt when the topic,
    the key pair or the timeout changes, so a settings save takes effect on
    the next send; otherwise the same client (and its boto3 connections) is
    reused across threads.

    Returns:
        The client. Building it raises ``SnsError`` (a configuration error)
        for a malformed ARN or half a key pair.
    """
    global _client
    credentials = load_credentials(PLUGIN_ID) or {}
    if credentials.get("use_env_vars", True):
        # The Credentials tab's "Use environment variables" switch (on by
        # default): ignore any key saved in the tab, as Test Connection does,
        # and let the default chain read AWS_ACCESS_KEY_ID / _SECRET_ACCESS_KEY
        # (or a profile, SSO, the instance or container role) itself.
        credentials = {}
    sns = get_settings().get("sns", {}) or {}
    key = (
        str(sns.get("topic_arn") or "").strip(),
        str(credentials.get("access_key_id") or "").strip(),
        str(credentials.get("secret_access_key") or "").strip(),
        int(sns.get("timeout") or 10),
    )
    with _client_lock:
        if _client is None or _client[0] != key:
            _client = (key, build_client(credentials, {"sns": sns}))
        return _client[1]
