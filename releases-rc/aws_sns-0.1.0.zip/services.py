"""Background services contributed by the AWS SNS plugin.

A subscriber, like the Jira plugin: it registers its handler with the core
``/webhook/lvi-alert`` dispatch and starts no detection backend of its own.

The core calls :func:`build_services` at startup and again on every settings
save, but never unregisters a plugin's handlers itself. So this function
registers the alert handler while ``features.alerts`` is on and
**unregisters** it when it is off - registering only would keep the handler
live until a restart after the switch went off.

It returns the held-event flusher as a service rather than starting a thread
itself: the core stops and restarts returned services on a settings save and
stops them on shutdown, whereas a thread started here would be duplicated on
every save and outlive an uninstall.
"""

from typing import Any, List


def build_services() -> List[Any]:
    """Register or unregister the alert handler; return the flusher.

    Returns:
        ``[Flusher()]`` while alerts are enabled, else ``[]``.
    """
    # src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
    from src.plugin_api import (  # pyright: ignore[reportMissingImports]
        get_app_settings,
        register_alert_handler,
        unregister_alert_handler,
    )

    from .flusher import Flusher
    from .handlers import get_alert_handler

    handler = get_alert_handler()
    if not get_app_settings().get("features", {}).get("alerts", True):
        unregister_alert_handler(handler)
        return []
    register_alert_handler(handler)
    return [Flusher()]
