"""Infoblox WAPI client"""

import csv
import io
import ipaddress
import logging
import os
from typing import Any, Dict, List, Optional, Tuple

import requests
import urllib3

# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import (  # pyright: ignore[reportMissingImports]
    build_retry_adapter,
    get_vendor_name,
    make_json_request,
)

logger = logging.getLogger(__name__)


def _is_same_device(host_obj: Dict[str, Any], ip_address: str, mac_address: str, short_name: str) -> bool:
    """Is *host_obj* this same device recorded under a different domain suffix?

    Identity is same IP + same MAC + same short (pre-domain) hostname. The
    domain deliberately plays no part: recognising a record onboarded under an
    older or since-corrected ``host_domain_name`` is the entire point.

    Both the writer (which updates such a record in place instead of creating a
    duplicate) and the conflict detector (which must not call it a rival owner)
    go through here. They once had separate answers, and the mismatch produced
    a conflict that no "Overwrite" could ever clear: the write succeeded
    against the existing record under its old name, and the next sync raised
    the identical conflict.

    Args:
        host_obj: The existing Infoblox host record.
        ip_address: The device's IP address.
        mac_address: The device's MAC address.
        short_name: The device's pre-domain hostname.

    Returns:
        True if host_obj is the same device.
    """
    if not mac_address:
        return False
    name = host_obj.get("name") or ""
    if name.split(".")[0].lower() != short_name.lower():
        return False
    for addr in host_obj.get("ipv4addrs", []) or []:
        if addr.get("ipv4addr") == ip_address and (addr.get("mac") or "").lower() == mac_address.lower():
            return True
    return False


# How much of an HTTP error body to log. Bounded because an error body is
# unbounded in principle - an HTML error page or an API that echoes the
# rejected payload can both run to tens of KB. The head, not the tail: for
# a JSON API the message sits at the front ({"error":{"message":...}}), and
# when a body is HTML rather than JSON the opening tag is itself the
# diagnosis.
_ERROR_BODY_CHARS = 500


class InfobloxClient:
    """
    Native Python client for Infoblox WAPI.

    Uses Extensible Attributes to store discovery data since WAPI's
    discovered_data field is read-only.
    """

    def __init__(
        self,
        host: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        wapi_version: Optional[str] = None,
        verify_ssl: Optional[bool] = None,
        timeout: Optional[int] = None,
        ignore_env_vars: bool = False,
    ) -> None:
        """
        Initialize Infoblox client.

        Args:
            host: Infoblox Grid Master hostname/IP. Defaults to IB_HOST env var.
            username: API username. Defaults to IB_USERNAME env var.
            password: API password. Defaults to IB_PASSWORD env var.
            wapi_version: WAPI version (e.g., "v2.11"). Defaults to conf/infoblox_sync_config.yaml
                          infoblox.wapi_version, or "v2.11".
            verify_ssl: Whether to verify SSL certificates. Defaults to
                        conf/infoblox_sync_config.yaml infoblox.verify_ssl, or False.
            timeout: Request timeout in seconds. Defaults to conf/infoblox_sync_config.yaml
                     infoblox.timeout, or 120.
            ignore_env_vars: If True, do not fall back to environment variables.
        """
        # Resolve credentials with optional env var fallback
        if ignore_env_vars:
            self.host = host
            self.username = username
            self.password = password
            self.wapi_version = wapi_version or "v2.11"
            self.verify_ssl = verify_ssl if verify_ssl is not None else False
            self.timeout = timeout or 120
        else:
            self.host = host or os.getenv("IB_HOST")
            self.username = username or os.getenv("IB_USERNAME")
            self.password = password or os.getenv("IB_PASSWORD")
            if wapi_version is not None and verify_ssl is not None and timeout is not None:
                self.wapi_version = wapi_version
                self.verify_ssl = verify_ssl
                self.timeout = timeout
            else:
                from .settings import get_infoblox_settings

                ib_cfg = get_infoblox_settings().get("infoblox", {})
                self.wapi_version = wapi_version or ib_cfg.get("wapi_version") or "v2.11"
                self.verify_ssl = verify_ssl if verify_ssl is not None else bool(ib_cfg.get("verify_ssl", False))
                self.timeout = timeout if timeout is not None else int(ib_cfg.get("timeout", 120))

        # Ensure WAPI version has 'v' prefix
        if self.wapi_version and not self.wapi_version.startswith("v"):
            self.wapi_version = f"v{self.wapi_version}"

        # Normalize host - remove protocol if present (the credential field
        # is now labeled "Infoblox Host", but a pasted URL still works
        # rather than silently producing a malformed https://https://... base_url).
        if self.host and self.host.startswith(("http://", "https://")):
            self.host = self.host.split("://", 1)[1]

        self.base_url = f"https://{self.host}/wapi/{self.wapi_version}"

        # Session for connection pooling
        self.session = requests.Session()
        # Credentials are None here in some test/partial-config paths; requests
        # accepts the tuple as-is and only fails at request time, matching
        # existing behavior (see manifest.json: both fields are required in
        # normal operation, this is not a new runtime path).
        self.session.auth = (self.username, self.password)  # type: ignore[assignment]
        self.session.verify = self.verify_ssl
        if not self.verify_ssl:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        _adapter = build_retry_adapter()
        self.session.mount("https://", _adapter)
        self.session.mount("http://", _adapter)

    def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict] = None,
        json_data: Optional[Dict] = None,
        data: Optional[Any] = None,
        files: Optional[Dict] = None,
        suppress_errors: bool = False,
    ) -> requests.Response:
        """Make HTTP request to Infoblox WAPI."""
        url = f"{self.base_url}/{endpoint}"
        return make_json_request(
            self.session,
            method,
            url,
            logger=logger,
            params=params,
            json_data=json_data,
            data=data,
            files=files,
            timeout=self.timeout,
            suppress_errors=suppress_errors,
            error_body_chars=_ERROR_BODY_CHARS,
        )

    def _paginated_get(
        self, endpoint: str, params: Optional[Dict[str, Any]] = None, page_size: int = 1000
    ) -> List[Dict[str, Any]]:
        """GET *endpoint*, following Infoblox WAPI's paging cursor until
        every page is collected.

        Confirmed live against a real Grid Master (2026-08-16, not
        guessed): passing ``_paging=1``, ``_return_as_object=1``, and
        ``_max_results=<page_size>`` on the first request wraps the
        response as ``{"result": [...], "next_page_id": "..."}`` instead
        of a bare list - ``next_page_id`` is present only when more pages
        remain. A follow-up request needs *only* ``_page_id``; the cursor
        already carries the original query and page size, so re-sending
        the filter params, ``_max_results``, ``_paging``, or
        ``_return_as_object`` on it is unnecessary (also confirmed live -
        a follow-up request sent with only ``_page_id`` returned the next
        page correctly).

        This is what `get_dns_zones`/`get_networks`/`get_network_containers`
        route through instead of their old single unpaged request with a
        hardcoded ``_max_results`` cap and no continuation - which
        silently dropped anything past the cap, with no error or warning.

        Args:
            endpoint: The WAPI endpoint to fetch.
            params: Optional query/filter parameters.
            page_size: The page size to request.

        Returns:
            Every result across all pages.
        """
        all_results: List[Dict[str, Any]] = []
        request_params: Dict[str, Any] = {
            **(params or {}),
            "_max_results": page_size,
            "_paging": 1,
            "_return_as_object": 1,
        }
        while True:
            response = self._request("GET", endpoint, params=request_params)
            data = response.json()
            if not isinstance(data, dict):
                logger.warning("Unexpected paging response shape for %s: %s", endpoint, type(data).__name__)
                break
            all_results.extend(data.get("result") or [])
            next_page_id = data.get("next_page_id")
            if not next_page_id:
                break
            request_params = {"_page_id": next_page_id}
        return all_results

    def test_connection(self) -> bool:
        """Test connection to Infoblox Grid Master."""
        try:
            response = self._request("GET", "grid", params={"_return_fields": "name"})
            data = response.json()

            if isinstance(data, list) and len(data) > 0:
                grid_info = data[0]
                name = grid_info.get("name") or grid_info.get("_ref", "Unknown").split(":")[-1]
                logger.info("Connected to Infoblox Grid: %s", name)
                return True
            return False

        except Exception as e:
            logger.error("Connection test failed: %s", e)
            return False

    def get_network_view(self, view_name: str) -> Optional[Dict[str, Any]]:
        """
        Get network view by name.

        Args:
            view_name: Name of the network view

        Returns:
            Network view object or None if not found
        """
        try:
            response = self._request("GET", "networkview", params={"name": view_name})

            data = response.json()
            if isinstance(data, list) and len(data) > 0:
                logger.info("Found network view: %s", view_name)
                return data[0]
            else:
                logger.error("Network view not found: %s", view_name)
                return None

        except Exception as e:
            logger.error("Error getting network view: %s", e)
            return None

    def get_dns_zones(self) -> set:
        """Return the set of all authoritative DNS zone FQDNs."""
        try:
            data = self._paginated_get("zone_auth", params={"_return_fields": "fqdn"})
            return {z["fqdn"] for z in data if isinstance(z, dict) and z.get("fqdn")}
        except Exception as e:
            logger.warning("Could not fetch DNS zones: %s", e)
            return set()

    def get_networks(self, network_view: str = "default") -> List[Dict[str, Any]]:
        """
        Get all networks defined in a network view.

        Args:
            network_view: Network view name

        Returns:
            List of network objects
        """
        try:
            data = self._paginated_get("network", params={"network_view": network_view})
            logger.info("Found %s networks in view '%s'", len(data), network_view)
            for net in data[:5]:  # Log first 5 networks
                logger.info("  Network: %s", net.get("network", "unknown"))
            return data

        except Exception as e:
            logger.error("Error getting networks: %s", e)
            return []

    def get_network_containers(self, network_view: str = "default") -> List[Dict[str, Any]]:
        """
        Get all network containers defined in a network view.

        Args:
            network_view: Network view name

        Returns:
            List of network container objects
        """
        try:
            data = self._paginated_get("networkcontainer", params={"network_view": network_view})
            logger.info("Found %s network containers in view '%s'", len(data), network_view)
            return data

        except Exception as e:
            logger.error("Error getting network containers: %s", e)
            return []

    def create_network(self, cidr: str, network_view: str = "default", comment: str = "") -> Tuple[bool, str]:
        """
        Create a new network in a network view.

        Args:
            cidr: Network CIDR notation (e.g., "10.0.0.0/8")
            network_view: Network view name
            comment: Optional comment for the network

        Returns:
            Tuple of (success, ref_or_error)
        """
        try:
            payload: Dict[str, Any] = {"network": cidr, "network_view": network_view}
            if comment:
                payload["comment"] = comment
            response = self._request("POST", "network", json_data=payload)
            ref = response.text.strip().strip('"')
            logger.info("Created network: %s in view '%s'", cidr, network_view)
            return True, ref

        except requests.exceptions.HTTPError as e:
            error_text = e.response.text if e.response else str(e)
            if e.response is not None and e.response.status_code == 400 and "already exists" in error_text.lower():
                logger.info("Network %s already exists in view '%s'", cidr, network_view)
                return True, "already_exists"
            logger.error("Failed to create network %s: %s", cidr, error_text)
            return False, error_text
        except Exception as e:
            logger.error("Error creating network %s: %s", cidr, e)
            return False, str(e)

    def create_network_container(self, cidr: str, network_view: str = "default", comment: str = "") -> Tuple[bool, str]:
        """
        Create a new network container in a network view.

        Network containers are used for aggregating supernets that contain child
        networks.  Use this instead of create_network() when smaller networks
        already exist within the proposed CIDR.

        Args:
            cidr: Network CIDR notation (e.g., "10.0.0.0/8")
            network_view: Network view name
            comment: Optional comment for the container

        Returns:
            Tuple of (success, ref_or_error)
        """
        try:
            payload: Dict[str, Any] = {"network": cidr, "network_view": network_view}
            if comment:
                payload["comment"] = comment
            response = self._request("POST", "networkcontainer", json_data=payload)
            ref = response.text.strip().strip('"')
            logger.info("Created network container: %s in view '%s'", cidr, network_view)
            return True, ref

        except requests.exceptions.HTTPError as e:
            error_text = e.response.text if e.response else str(e)
            if e.response is not None and e.response.status_code == 400 and "already exists" in error_text.lower():
                logger.info("Network container %s already exists in view '%s'", cidr, network_view)
                return True, "already_exists"
            logger.error("Failed to create network container %s: %s", cidr, error_text)
            return False, error_text
        except Exception as e:
            logger.error("Error creating network container %s: %s", cidr, e)
            return False, str(e)

    def check_ip_in_network(self, ip_address: str, network_view: str = "default") -> bool:
        """
        Check if an IP address belongs to any defined network.

        Args:
            ip_address: IP address to check
            network_view: Network view name

        Returns:
            True if IP belongs to a defined network, False otherwise
        """
        try:
            networks = self.get_networks(network_view)
            ip_obj = ipaddress.ip_address(ip_address)

            for network in networks:
                network_cidr = network.get("network")
                if network_cidr:
                    network_obj = ipaddress.ip_network(network_cidr, strict=False)
                    if ip_obj in network_obj:
                        logger.info("IP %s belongs to network %s", ip_address, network_cidr)
                        return True

            logger.warning("IP %s does NOT belong to any defined network", ip_address)
            return False

        except Exception as e:
            logger.error("Error checking IP in network: %s", e)
            return False

    def get_extensible_attribute_def(self, name: str) -> Optional[Dict[str, Any]]:
        """Get extensible attribute definition by name."""
        try:
            response = self._request("GET", "extensibleattributedef", params={"name": name})
            data = response.json()
            if isinstance(data, list) and len(data) > 0:
                return data[0]
            return None
        except Exception as e:
            logger.debug("EA definition '%s' not found: %s", name, e)
            return None

    def create_extensible_attribute_def(
        self, name: str, ea_type: str = "STRING", comment: str = ""
    ) -> Tuple[bool, str]:
        """
        Create extensible attribute definition.

        Args:
            name: EA name
            ea_type: EA type (STRING, INTEGER, DATE, EMAIL, URL, ENUM)
            comment: Description

        Returns:
            Tuple of (success, message/ref)
        """
        try:
            response = self._request(
                "POST",
                "extensibleattributedef",
                json_data={
                    "name": name,
                    "type": ea_type,
                    "comment": comment or f"Created by {get_vendor_name()} for {name}",
                },
            )
            ref = response.text.strip().strip('"')
            logger.info("Created EA definition: %s", name)
            return True, ref
        except requests.exceptions.HTTPError as e:
            if e.response is not None and e.response.status_code == 400 and "already exists" in e.response.text.lower():
                logger.debug("EA definition '%s' already exists", name)
                return True, "already_exists"
            logger.error("Failed to create EA definition '%s': %s", name, e)
            return False, str(e)
        except Exception as e:
            logger.error("Error creating EA definition '%s': %s", name, e)
            return False, str(e)

    def ensure_extensible_attributes(self, ea_names: list, create_if_missing: bool = False) -> Tuple[int, int]:
        """
        Ensure extensible attribute definitions exist.

        Args:
            ea_names: List of EA names to check/create
            create_if_missing: If True, create missing EAs

        Returns:
            Tuple of (existing_count, created_count)
        """
        existing = 0
        created = 0

        for ea_name in ea_names:
            ea_def = self.get_extensible_attribute_def(ea_name)
            if ea_def:
                existing += 1
            elif create_if_missing:
                success, _ = self.create_extensible_attribute_def(ea_name)
                if success:
                    created += 1

        logger.debug("EAs: %s existing, %s created", existing, created)
        return existing, created

    def upload_file(self, csv_bytes: bytes) -> Optional[str]:
        """
        Upload CSV bytes to Infoblox using fileop.

        Args:
            csv_bytes: CSV content as bytes

        Returns:
            Upload token or None on failure
        """
        try:
            # Log CSV preview so the sync log shows exactly what is being sent
            reader = csv.DictReader(io.StringIO(csv_bytes.decode("utf-8")))
            first_rows = list(reader)[:2]
            if first_rows:
                logger.info("CSV preview - columns: %s", ", ".join(first_rows[0].keys()))
                logger.info("CSV preview - first row (non-empty fields):")
                for key, value in first_rows[0].items():
                    if value:
                        logger.info("  %-35s %s", key + ":", value)

            # Step 1: Initialize upload and get token
            logger.info("Initializing file upload...")
            response = self._request("POST", "fileop", params={"_function": "uploadinit"})

            upload_data = response.json()
            upload_url = upload_data.get("url", "")
            token = upload_data.get("token", "")

            logger.debug("Upload URL: %s", upload_url)
            logger.debug("Upload token: %s", token)

            if not upload_url or not token:
                logger.error("No upload URL or token received")
                return None

            # Step 2: Upload the bytes
            logger.info("Uploading discovery CSV...")
            files = {"file": ("discovery.csv", csv_bytes, "text/csv")}
            upload_response = self.session.post(upload_url, files=files, verify=self.verify_ssl, timeout=self.timeout)
            upload_response.raise_for_status()

            logger.info("File uploaded successfully")
            return token

        except Exception as e:
            logger.error("Error uploading file: %s", e)
            return None

    def import_discovery_csv(self, token: str, network_view: str = "default") -> Tuple[bool, str]:
        """
        Import discovery CSV data using uploaded file token.

        This is the Python equivalent of Perl PAPI's import_data() method
        with type='discovery_csv'.

        From analyzing the Perl PAPI, discovery_csv uses the SetDiscoveryCSV
        function with parameters: data_ref, merge_data, network_view.

        Args:
            token: Upload token from upload_file()
            network_view: Network view name

        Returns:
            Tuple of (success, message)
        """
        try:
            logger.info("Importing discovery CSV to network view: %s", network_view)
            logger.debug("Using upload token: %s", token)

            # The Perl PAPI SetDiscoveryCSV translates to a function call in WAPI
            # We need to call the function with the uploaded file token
            payload = {"token": token, "network_view": network_view, "merge_data": True}
            logger.debug("Import payload: %s", payload)

            response = self._request("POST", "fileop", params={"_function": "setdiscoverycsv"}, json_data=payload)

            result = response.text.strip()
            logger.debug("Import result: %s", result)

            # Check for success
            if response.status_code == 200:
                # Empty result or {} is normal for successful import
                if not result or result == "{}":
                    logger.info("Discovery CSV import request completed")
                else:
                    logger.info("Discovery CSV import successful: %s", result)
                return True, result
            else:
                logger.error("Discovery CSV import failed: %s", result)
                return False, result

        except Exception as e:
            error_msg = str(e)
            logger.error("Error importing discovery CSV: %s", error_msg)
            return False, error_msg

    def import_discovery_data(self, csv_bytes: bytes, network_view: str = "default") -> Tuple[bool, str]:
        """
        Complete discovery data import: upload CSV bytes and import them.

        This is the high-level method that mimics Perl PAPI's import_data().

        Args:
            csv_bytes: Discovery CSV content as bytes
            network_view: Network view name

        Returns:
            Tuple of (success, message)
        """
        # Step 1: Verify network view exists
        view = self.get_network_view(network_view)
        if not view:
            return False, f"Network view '{network_view}' not found"

        # Step 2: Upload CSV bytes
        token = self.upload_file(csv_bytes)
        if not token:
            return False, "Failed to upload CSV"

        # Step 3: Import the uploaded CSV as discovery data
        success, message = self.import_discovery_csv(token, network_view)

        return success, message

    def find_ip_object(self, ip_address: str, name: str, network_view: str = "default") -> Optional[Dict[str, Any]]:
        """
        Find an IP address object in Infoblox.

        Searches for ipv4address, record:host, record:a, or fixedaddress objects.

        Args:
            ip_address: IP address to search for
            network_view: Network view name

        Returns:
            Dictionary with 'type' and 'ref' keys, or None if not found
        """
        # Try record:host
        response = self._request(
            "GET",
            "record:host",
            params={"name": name + ".home.arpa", "network_view": network_view},
            suppress_errors=True,
        )
        if response is None:
            logger.debug("No response from Infoblox looking up %s - server unreachable?", ip_address)
            return None
        data = response.json()
        if isinstance(data, list) and len(data) > 0:
            obj = data[0]
            return {"type": "record:host", "ref": obj.get("_ref"), "data": obj}

        # Try ipv4address
        response = self._request(
            "GET",
            "ipv4address",
            params={
                "ip_address": ip_address,
                "network_view": network_view,
                "_return_fields+": "ip_address,network_view,mac_address,comment",
            },
            suppress_errors=True,
        )
        if response is None:
            return None
        data = response.json()
        if isinstance(data, list) and len(data) > 0:
            obj = data[0]
            return {"type": "ipv4address", "ref": obj.get("_ref"), "data": obj}

        # Try fixedaddress
        response = self._request(
            "GET", "fixedaddress", params={"ipv4addr": ip_address, "network_view": network_view}, suppress_errors=True
        )
        if response is None:
            return None
        data = response.json()
        if isinstance(data, list) and len(data) > 0:
            obj = data[0]
            return {"type": "fixedaddress", "ref": obj.get("_ref"), "data": obj}

        # Try record:a
        response = self._request(
            "GET", "record:a", params={"ipv4addr": ip_address, "network_view": network_view}, suppress_errors=True
        )
        if response is None:
            return None
        data = response.json()
        if isinstance(data, list) and len(data) > 0:
            obj = data[0]
            return {"type": "record:a", "ref": obj.get("_ref"), "data": obj}

        return None

    def update_object_fields(
        self, object_ref: str, updates: Dict[str, Any], extattrs: Optional[Dict[str, Any]] = None
    ) -> Tuple[bool, str]:
        """
        Update fields on an Infoblox object.

        Args:
            object_ref: Object reference (e.g., "ipv4address/...")
            updates: Dictionary of fields to update
            extattrs: Optional dictionary of Extensible Attributes to update

        Returns:
            Tuple of (success, message/ref)
        """
        try:
            payload = updates.copy()

            # Add extensible attributes if provided
            if extattrs:
                payload["extattrs"] = extattrs

            response = self._request("PUT", object_ref, json_data=payload)
            ref = response.text.strip().strip('"')
            logger.debug("Updated object: %s", object_ref)
            return True, ref

        except requests.exceptions.HTTPError as e:
            logger.error("Failed to update object %s: %s", object_ref, e)
            return False, str(e)
        except Exception as e:
            logger.error("Error updating object %s: %s", object_ref, e)
            return False, str(e)

    def update_device_in_ipam(
        self,
        ip_address: str,
        device_data: Dict[str, Any],
        network_view: str = "default",
        create_eas: bool = False,
        ea_mapping: Optional[Dict[str, str]] = None,
        sync_mac_address: bool = True,
    ) -> Tuple[bool, str]:
        """
        Update a device in Infoblox IPAM with native fields and Extensible Attributes.

        Args:
            ip_address: IP address of the device
            device_data: Device data dictionary from LogicVein CSV
            network_view: Network view name
            create_eas: If True, create EA definitions if they don't exist
            ea_mapping: Optional mapping of {csv_column: ea_name} for Extensible Attributes
            sync_mac_address: If False, never write the mac field - this is the
                EA-only update path (used when convert_ips_to_hosts is off and an
                extensible_attribute_mapping is configured), a separate write
                opportunity from the host-conversion path, so it needs its own gate
                rather than relying on populate_host_fields (which only covers the
                host-conversion path).

        Returns:
            Tuple of (success, message)
        """
        try:
            # Find the object in Infoblox
            name = device_data.get("discovered_name", "")
            obj_info = self.find_ip_object(ip_address, name, network_view)
            if not obj_info:
                logger.debug("IP address %s not found in Infoblox (not imported)", ip_address)
                return True, "Skipped - IP not found"

            obj_type = obj_info["type"]
            obj_ref = obj_info["ref"]

            # ipv4address objects are read-only (created by discovery), skip them
            if obj_type == "ipv4address":
                logger.debug("Skipping read-only ipv4address object: %s", ip_address)
                return True, "Skipped read-only ipv4address"

            # Build native field updates based on object type
            updates = {}

            # comment field (applicable to all managed types)
            memo = device_data.get("memo", "")
            if memo:
                updates["comment"] = memo

            # mac_address field (only for certain types)
            mac_address = device_data.get("mac_address", "") if sync_mac_address else ""
            if mac_address:
                if obj_type in ["record:host_ipv4addr", "fixedaddress"]:
                    updates["mac"] = mac_address

            # Build Extensible Attributes from mapping
            extattrs = {}
            if ea_mapping:
                for csv_column, ea_name in ea_mapping.items():
                    value = device_data.get(csv_column, "")
                    if value:
                        extattrs[ea_name] = {"value": value}

            # Ensure EA definitions exist if requested
            if create_eas and extattrs:
                ea_names = list(extattrs.keys())
                self.ensure_extensible_attributes(ea_names, create_if_missing=True)

            # Update the object
            if updates or extattrs:
                success, message = self.update_object_fields(obj_ref, updates, extattrs if extattrs else None)
                if success:
                    logger.info("Updated %s %s", obj_type, ip_address)
                    return True, f"Updated {obj_type}"
                else:
                    return False, message
            else:
                logger.debug("No updates needed for %s", ip_address)
                return True, "No updates needed"

        except Exception as e:
            logger.error("Error updating device %s: %s", ip_address, e)
            return False, str(e)

    def get_host_record(self, fqdn: str, network_view: str = "default") -> Optional[Dict[str, Any]]:
        """
        Get a host record by FQDN.

        Args:
            fqdn: Fully qualified domain name (e.g., "device1.home.arpa")
            network_view: Network view name

        Returns:
            Host record object or None if not found
        """
        try:
            # Infoblox stores hostnames in lowercase, so search case-insensitively
            response = self._request(
                "GET",
                "record:host",
                params={
                    "name~": fqdn.lower(),  # Case-insensitive regex search
                    "network_view": network_view,
                    "_return_fields+": "ipv4addrs,comment,extattrs,configure_for_dns",
                },
                suppress_errors=True,
            )
            if response is None:
                return None
            data = response.json()
            if isinstance(data, list) and len(data) > 0:
                logger.debug("Found existing host record: %s", fqdn)
                return data[0]
            return None

        except Exception as e:
            logger.debug("Host record '%s' not found: %s", fqdn, e)
            return None

    def create_or_update_host_record(
        self,
        ip_address: str,
        fqdn: str,
        network_view: str = "default",
        host_fields: Optional[Dict[str, str]] = None,
        device_data: Optional[Dict[str, Any]] = None,
        configure_for_dns: bool = True,
        rename_to_configured_domain: bool = False,
    ) -> Tuple[bool, str]:
        """
        Create or update a host record in Infoblox.

        If the host exists, updates it with the provided fields.
        If not, creates a new host record.

        Note: MAC address must be applied to the ipv4addrs array, not the host.
        If 'mac' is mapped in host_fields, it's handled specially.

        Args:
            ip_address: IP address for the host
            fqdn: Fully qualified domain name (e.g., "device1.home.arpa")
            network_view: Network view name (used for both 'view' and 'network_view')
            host_fields: Optional mapping of {csv_column: infoblox_field} for host fields
            device_data: Optional device data dictionary from LogicVein CSV
            configure_for_dns: If True (default), creates a DNS A record. Set False
                for pure IPAM use where no managed DNS zone is available.
            rename_to_configured_domain: When this device's record is found under a
                *different* domain suffix, rename it to *fqdn* instead of updating it
                under its existing name. This moves the record's DNS name, so it is
                off by default and driven by the infoblox.rename_host_to_configured_domain
                setting.

        Returns:
            Tuple of (success, message) where message is "created", "updated",
            "renamed:<old fqdn>" (an update that also renamed the record), or
            an error string.
        """
        rename_to: Optional[str] = None
        # Extract MAC if present in host_fields mapping
        mac_address = None
        if host_fields and device_data:
            for csv_column, infoblox_field in host_fields.items():
                if infoblox_field == "mac":
                    mac_address = device_data.get(csv_column, "")
                    break

        # Check if host already exists
        existing_host = self.get_host_record(fqdn, network_view)

        if not existing_host and mac_address:
            # The exact-fqdn miss might mean this device's host record
            # already exists under a *different* domain suffix than the
            # currently configured host_domain_name (e.g. it was onboarded
            # under an older or since-corrected domain) - same IP, same
            # MAC, same short hostname. Recognize it as the same device and
            # update it in place (keeping its existing name) rather than
            # attempting to create a duplicate, which would collide on
            # Infoblox's own MAC/IP uniqueness constraint (confirmed live:
            # "The MAC address ... is used in two host addresses").
            short_name = fqdn.split(".")[0]
            alt_existing = self.find_host_by_ip_mac_and_short_name(ip_address, mac_address, short_name, network_view)
            if alt_existing:
                existing_host = alt_existing
                old_name = alt_existing.get("name", fqdn)
                if rename_to_configured_domain:
                    logger.info(
                        "Recognized %s as the existing host record '%s' under a different domain - renaming it",
                        fqdn,
                        old_name,
                    )
                    rename_to = fqdn
                else:
                    logger.info(
                        "Recognized %s as the existing host record '%s' under a different domain - "
                        "updating in place, keeping its name",
                        fqdn,
                        old_name,
                    )
                    fqdn = old_name

        if existing_host:
            return self._update_host_record(
                existing_host=existing_host,
                ip_address=ip_address,
                fqdn=fqdn,
                mac_address=mac_address,
                host_fields=host_fields,
                device_data=device_data,
                configure_for_dns=configure_for_dns,
                new_name=rename_to,
            )
        else:
            return self._create_host_record(
                ip_address=ip_address,
                fqdn=fqdn,
                network_view=network_view,
                mac_address=mac_address,
                host_fields=host_fields,
                device_data=device_data,
                configure_for_dns=configure_for_dns,
            )

    def _create_host_record(
        self,
        ip_address: str,
        fqdn: str,
        network_view: str,
        mac_address: Optional[str],
        host_fields: Optional[Dict[str, str]],
        device_data: Optional[Dict[str, Any]],
        configure_for_dns: bool = True,
    ) -> Tuple[bool, str]:
        """Create a new host record."""
        try:
            # Build ipv4addr entry with optional MAC
            ipv4addr_entry = {"ipv4addr": ip_address}
            if mac_address:
                ipv4addr_entry["mac"] = mac_address

            payload: Dict[str, Any] = {
                "ipv4addrs": [ipv4addr_entry],
                "name": fqdn,
                "view": network_view,
                "network_view": network_view,
                "configure_for_dns": configure_for_dns,
            }

            # Fields that should never be overwritten by mapping
            protected_fields = {"name", "view", "network_view", "ipv4addrs", "configure_for_dns"}

            # Add host-level fields from mapping
            if host_fields and device_data:
                for csv_column, infoblox_field in host_fields.items():
                    if infoblox_field == "mac":
                        continue  # MAC already in ipv4addrs
                    if infoblox_field in protected_fields:
                        continue
                    value = device_data.get(csv_column, "")
                    if value:
                        payload[infoblox_field] = value

            logger.debug("Creating host record %s with payload: %s", fqdn, payload)

            response = self._request("POST", "record:host", json_data=payload)
            ref = response.text.strip().strip('"')
            logger.info("Created host record: %s -> %s", fqdn, ref)

            return True, "created"

        except requests.exceptions.HTTPError as e:
            error_text = e.response.text if e.response else str(e)
            logger.error("Failed to create host record '%s': %s", fqdn, error_text)
            return False, error_text
        except Exception as e:
            logger.error("Error creating host record '%s': %s", fqdn, e)
            return False, str(e)

    def _update_host_record(
        self,
        existing_host: Dict[str, Any],
        ip_address: str,
        fqdn: str,
        mac_address: Optional[str],
        host_fields: Optional[Dict[str, str]],
        device_data: Optional[Dict[str, Any]],
        configure_for_dns: bool = True,
        new_name: Optional[str] = None,
    ) -> Tuple[bool, str]:
        """Update an existing host record.

        *new_name* renames the record. It is passed only when a rename is
        actually intended, rather than inferred from ``fqdn`` differing from
        the record's current name: ``get_host_record()`` matches with a
        case-insensitive ``name~`` regex, so those two routinely differ by
        case alone, and inferring would rename on every such run.

        Args:
            existing_host: The current host record.
            ip_address: The device's IP address.
            fqdn: The device's fully-qualified name, for log messages.
            mac_address: The MAC to set on the matching ipv4addrs entry, if any.
            host_fields: CSV-column -> Infoblox-field mapping for host-level fields.
            device_data: The device's field values, keyed by CSV column.
            configure_for_dns: Whether the record should be DNS-configured.
            new_name: The new name to rename the record to, if intended.

        Returns:
            (success, message) - message is "updated", "renamed:<old
            name>", or an error string.
        """
        try:
            host_ref = existing_host.get("_ref")
            if not host_ref:
                return False, "No _ref found for existing host"

            payload: Dict[str, Any] = {"configure_for_dns": configure_for_dns}

            # "name" is otherwise protected from the field mapping; a rename is
            # the one case that may legitimately set it.
            current_name = (existing_host.get("name") or "").rstrip(".")
            renamed_from = ""
            if new_name and new_name.rstrip(".").lower() != current_name.lower():
                logger.info("Renaming host record '%s' to '%s'", current_name, new_name)
                payload["name"] = new_name
                renamed_from = current_name

            # Fields that should never be overwritten by mapping
            protected_fields = {"name", "view", "network_view", "ipv4addrs", "configure_for_dns"}

            # Add host-level fields from mapping
            if host_fields and device_data:
                for csv_column, infoblox_field in host_fields.items():
                    if infoblox_field == "mac":
                        continue  # MAC handled separately in ipv4addrs
                    if infoblox_field in protected_fields:
                        continue
                    value = device_data.get(csv_column, "")
                    if value:
                        payload[infoblox_field] = value

            # Update ipv4addrs if MAC needs to be set
            if mac_address:
                # Filter out read-only fields (host, _ref, etc.) to avoid errors
                current_ipv4addrs = existing_host.get("ipv4addrs", [])
                updated_ipv4addrs = []
                writable_fields = {"ipv4addr", "mac", "configure_for_dhcp", "match_client", "options"}
                for addr in current_ipv4addrs:
                    clean_addr = {k: v for k, v in addr.items() if k in writable_fields}
                    if clean_addr.get("ipv4addr") == ip_address:
                        clean_addr["mac"] = mac_address
                    updated_ipv4addrs.append(clean_addr)
                if updated_ipv4addrs:
                    payload["ipv4addrs"] = updated_ipv4addrs

            logger.debug("Updating host record %s with payload: %s", fqdn, payload)
            self._request("PUT", host_ref, json_data=payload)
            logger.info("Updated host record: %s", fqdn)

            # "renamed:<old name>" rather than a separate return value, so every
            # existing caller that only checks message == "updated" is unaffected
            # unless it explicitly wants to notice a rename.
            if renamed_from:
                return True, f"renamed:{renamed_from}"
            return True, "updated"

        except requests.exceptions.HTTPError as e:
            error_text = e.response.text if e.response else str(e)
            logger.error("Failed to update host record '%s': %s", fqdn, error_text)
            return False, error_text
        except Exception as e:
            logger.error("Error updating host record '%s': %s", fqdn, e)
            return False, str(e)

    # Kept as a method-adjacent free function so the conflict detector and the
    # writer share one definition of "this is the same device". They disagreed
    # once - the writer updated a record the detector kept calling a rival
    # owner - and the result was a conflict no resolution could ever clear.
    def find_host_by_ip_mac_and_short_name(
        self, ip_address: str, mac_address: str, short_name: str, network_view: str = "default"
    ) -> Optional[Dict[str, Any]]:
        """Find an existing record:host whose ipv4addrs entry for *ip_address*
        has *mac_address* and whose name's short (pre-domain) portion
        matches *short_name*, case-insensitively - used to recognize a
        device's own host record under a *different* domain suffix than
        the currently configured host_domain_name, so it's treated as the
        same device rather than a false "doesn't exist" miss.

        Args:
            ip_address: The device's IP address.
            mac_address: The device's MAC address.
            short_name: The device's pre-domain hostname.
            network_view: The Infoblox network view to search.

        Returns:
            The matching host record, or None.
        """
        try:
            response = self._request(
                "GET",
                "record:host",
                params={"ipv4addr": ip_address, "network_view": network_view, "_return_fields+": "name,ipv4addrs"},
                suppress_errors=True,
            )
            if response is None:
                return None
            for obj in response.json() or []:
                if _is_same_device(obj, ip_address, mac_address, short_name):
                    return obj
        except Exception as e:
            logger.warning("Could not check for a same-device host record under a different domain: %s", e)
        return None

    def find_conflicting_ip_owner(
        self,
        ip_address: str,
        exclude_fqdn: str,
        network_view: str = "default",
        mac_address: str = "",
    ) -> str:
        """Return a human-readable note if *ip_address* is already claimed by
        a *different* record:host or fixedaddress than *exclude_fqdn*, else
        "". Only meaningful to call when this device has no host record of
        its own yet - reuses the same ipv4addr= WAPI filter find_ip_object()
        already relies on.

        When *mac_address* is given, a claiming record that is recognisably
        **this same device under a different domain suffix** is not a
        conflict. This has to match what create_or_update_host_record() does:
        it already treats same IP + same MAC + same short hostname as the
        same device and updates that record in place, keeping its existing
        name. Comparing names alone made every such device conflict forever -
        the sync defers it, the operator chooses Overwrite, the write
        "succeeds" by updating the record under its old name, and the next
        sync raises the identical conflict, with nothing in Infoblox ever
        changing.

        Without a MAC there is no way to prove identity, so the conservative
        name-only comparison is kept.

        Args:
            ip_address: The IP address to check.
            exclude_fqdn: This device's own fqdn, excluded from the check.
            network_view: The Infoblox network view to search.
            mac_address: This device's MAC, to recognize itself under a
                different domain suffix.

        Returns:
            A human-readable conflict note, or "" if none found.
        """
        exclude_name = exclude_fqdn.rstrip(".").lower()
        short_name = exclude_name.split(".")[0]
        try:
            response = self._request(
                "GET",
                "record:host",
                params={"ipv4addr": ip_address, "network_view": network_view, "_return_fields+": "name,ipv4addrs"},
                suppress_errors=True,
            )
            if response is not None:
                for obj in response.json() or []:
                    name = (obj.get("name") or "").rstrip(".")
                    if not name or name.lower() == exclude_name:
                        continue
                    if mac_address and _is_same_device(obj, ip_address, mac_address, short_name):
                        logger.debug(
                            "IP %s is held by '%s', recognised as this same device under another domain - not a conflict",
                            ip_address,
                            name,
                        )
                        continue
                    return f"IP {ip_address} already claimed by host record '{name}'"

            response = self._request(
                "GET",
                "fixedaddress",
                params={"ipv4addr": ip_address, "network_view": network_view},
                suppress_errors=True,
            )
            if response is not None:
                data = response.json() or []
                if data:
                    return f"IP {ip_address} already claimed by a fixedaddress record"
        except Exception as e:
            logger.warning("Could not check for conflicting IP owner %s: %s", ip_address, e)
        return ""

    def find_duplicate_mac_fixedaddress(self, mac_address: str, network_view: str = "default") -> str:
        """Return a human-readable note if *mac_address* is already set on a
        fixedaddress object anywhere in Infoblox, else "". Scoped to
        fixedaddress only - record:host's MAC lives inside its ipv4addrs
        sub-array, which WAPI does not support a top-level filter query
        against, unlike fixedaddress's own top-level 'mac' field.

        Args:
            mac_address: The MAC address to check.
            network_view: The Infoblox network view to search.

        Returns:
            A human-readable duplicate note, or "" if none found.
        """
        try:
            response = self._request(
                "GET",
                "fixedaddress",
                params={"mac": mac_address, "network_view": network_view, "_return_fields+": "ipv4addr"},
                suppress_errors=True,
            )
            if response is not None:
                data = response.json() or []
                if data:
                    ip = data[0].get("ipv4addr", "?")
                    return f"MAC {mac_address} already set on fixedaddress {ip}"
        except Exception as e:
            logger.warning("Could not check for duplicate MAC %s: %s", mac_address, e)
        return ""

    def set_host_mac(self, fqdn: str, ip_address: str, mac_address: str, network_view: str = "default") -> bool:
        """Apply a deferred MAC-conflict resolution: set *mac_address* on the
        existing host record's ipv4addrs entry for *ip_address*, leaving
        every other host field untouched.

        Args:
            fqdn: The device's fully-qualified name.
            ip_address: The device's IP address.
            mac_address: The MAC address to set.
            network_view: The Infoblox network view.

        Returns:
            True on success.
        """
        existing_host = self.get_host_record(fqdn, network_view)
        if not existing_host:
            return False
        success, _ = self._update_host_record(
            existing_host=existing_host,
            ip_address=ip_address,
            fqdn=fqdn,
            mac_address=mac_address,
            host_fields=None,
            device_data=None,
            configure_for_dns=bool(existing_host.get("configure_for_dns", True)),
        )
        return success
