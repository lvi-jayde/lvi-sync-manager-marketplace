"""AWS SNS plugin: publish LogicVein alerts to an Amazon SNS topic.

A notification-only subscriber, like the Jira and ServiceNow plugins'
alert integrations: it registers a handler for the core
``/webhook/lvi-alert`` route and turns each alert into one SNS ``Publish``.
Whoever subscribes to the topic receives it - SMS numbers, email, SQS or
Lambda - so recipients are managed in AWS, not here. It declares only the
``alerts`` capability: no inventory sync, so no Sync tab.

The design, and the AWS account setup it needs, are in the app repo's
``docs/dev_notes/AWS_SNS_PLUGIN_PLAN.md``.
"""

import logging
from pathlib import Path
from typing import Any, Dict, List, Tuple

# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import SyncPlugin, load_plugin_config, t  # pyright: ignore[reportMissingImports]

from .client import SnsClient, SnsError
from .settings import PLUGIN_ID, build_client

logger = logging.getLogger(__name__)


class AwsSnsPlugin(SyncPlugin):
    """Publishes LogicVein alerts to an SNS topic."""

    def __init__(self) -> None:
        """Initialise the plugin from its manifest.json."""
        self.config = load_plugin_config(Path(__file__).parent)

    def create_client(self, credentials: Dict[str, Any]) -> SnsClient:
        """Build an SNS client from credential values and the saved settings.

        Args:
            credentials: The Credentials tab's values; a blank key pair uses
                boto3's default credential chain.

        Returns:
            The client.
        """
        return build_client(credentials)

    def test_connection(self, credentials: Dict[str, Any]) -> Tuple[bool, str]:
        """Describe the topic with ``GetTopicAttributes`` (sends nothing).

        Args:
            credentials: The Credentials tab's values.

        Returns:
            (ok, message): the topic name and confirmed subscription count,
            with a warning when there are no confirmed subscriptions or the
            topic is FIFO (which cannot deliver SMS); or the reason it failed.
        """
        try:
            client = self.create_client(credentials)
            info = client.topic_info()
        except SnsError as exc:
            return False, f"Connection failed: {exc}"
        except Exception as exc:  # deliberately broad: the Test button must always answer
            logger.exception("AWS SNS test connection failed")
            return False, f"Connection failed: {exc}"
        source = "default credential chain" if client.uses_default_chain else "access key"
        message = (
            f"Connected to topic {info.name} in {client.topic.region} ({source}): "
            f"{info.subscriptions_confirmed} confirmed subscription(s)"
        )
        warnings = []
        if info.fifo:
            warnings.append("this is a FIFO topic, which cannot deliver SMS - use a standard topic")
        if info.subscriptions_confirmed == 0:
            warnings.append("nothing will receive notifications until a subscription is confirmed")
        if warnings:
            message += ". Warning: " + "; ".join(warnings)
        return True, message

    def get_background_services(self) -> List[Any]:
        """Register the alert handler and return the held-event flusher.

        Returns:
            The flusher service while alerts are enabled, else [].
        """
        from .services import build_services

        return build_services()

    def get_extra_tabs(self) -> List[tuple]:
        """The plugin's own tab: recent sends, held events, test send.

        Shown while alerts or change detection is enabled: either can put
        rows on it.

        Returns:
            [(label, icon, render_fn, ["alerts", "change_detection"])].
        """
        from .tab import render_tab  # NiceGUI only when the UI renders

        return [(t("aws_sns.tab.title", plugin=PLUGIN_ID), "sms", render_tab, ["alerts", "change_detection"])]

    def get_webhook_overrides(self) -> Dict[str, Any]:
        """Colours for this plugin's own results on the core Webhooks tab.

        Returns:
            ``result_colors`` for ``sent``, ``held`` and ``resolved before
            sent`` (``error`` is already red).
        """
        return {
            "result_colors": {
                "sent": "#16a34a",
                "held": "#d97706",
                "resolved before sent": "#6b7280",
            }
        }

    def get_status_detail(self, config: Dict[str, Any]) -> str:
        """The configured topic, for the plugin header.

        Args:
            config: The plugin config.

        Returns:
            "Topic: <name>", or "" when none is configured.
        """
        arn = str((config.get("sns", {}) or {}).get("topic_arn") or "")
        return f"Topic: {arn.rsplit(':', 1)[-1]}" if arn else ""

    def supports_cancellation(self) -> bool:
        """No sync engine, so nothing to cancel.

        Returns:
            False.
        """
        return False
