"""EfficientIP SOLIDserver sync plugin - the SyncPlugin entry point."""

import logging
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import (  # pyright: ignore[reportMissingImports]
    SyncPlugin,
    get_product_name,
    load_plugin_config,
    normalize_networks,
)

from .client import EfficientIPClient
from .space_partition import DEFAULT_GLOBAL_VRF_ALIASES as _DEFAULT_GLOBAL_VRF_ALIASES
from .sync import LogicVeinEfficientIPSync

logger = logging.getLogger(__name__)


# SOLIDserver caps nomnetobj_type at 16 characters and rejects the whole
# device write when it is longer, so LVI device types that exceed it need a
# short equivalent. Only the types that actually overflow need an entry;
# anything unmapped and short enough is written through unchanged, and
# anything unmapped and too long is trimmed by the client as a fallback.
# Keys must be the LogicVein device type spelled exactly; a key that does
# not match is silently never applied, and the long type still syncs with
# a truncated label. "Wireless Controller" and "Wireless Access Point" are
# both confirmed against real LogicVein inventory. Other long types very
# likely exist - add them to nom_type_mapping, whose keys are free-form
# (declared in manifest.json's config_freeform_paths, so the config editor
# accepts any device type here).
_DEFAULT_NOM_TYPE_MAPPING: Dict[str, str] = {
    "Wireless Controller": "WLC",
    "Wireless Access Point": "WAP",
}


class EfficientIPPlugin(SyncPlugin):
    """Plugin for synchronizing LogicVein device inventory to EfficientIP SOLIDserver IPAM."""

    def __init__(self) -> None:
        """Initialise the EfficientIP plugin from its manifest.json."""
        self.config = load_plugin_config(Path(__file__).parent)

    # --- Required (abstract) -------------------------------------------------

    def create_client(self, credentials: Dict[str, Any]) -> Any:
        """Create an authenticated EfficientIP SOLIDserver client.

        Args:
            credentials: Dict with keys: host, username, password, token_id,
                         token_secret, use_token, and optionally ignore_env_vars.
                         "use_token" (set by the credentials UI's auth-method
                         toggle) picks username/password vs token_id/
                         token_secret explicitly; when absent (e.g. the empty
                         dict scheduled syncs and resolve_conflict() pass),
                         both pairs are forwarded and EfficientIPClient's own
                         precedence (token wins if both resolve) decides.

        Returns:
            EfficientIPClient instance.
        """
        from .settings import get_efficientip_settings

        eip_cfg = get_efficientip_settings().get("efficientip", {})
        kwargs: Dict[str, Any] = {
            "verify_ssl": bool(eip_cfg.get("verify_ssl", False)),
            "timeout": int(eip_cfg.get("timeout", 120)),
        }
        if credentials.get("ignore_env_vars"):
            kwargs["ignore_env_vars"] = True
        if credentials.get("host"):
            kwargs["host"] = credentials["host"]

        use_token = credentials.get("use_token")
        if use_token is not True:
            if credentials.get("username"):
                kwargs["username"] = credentials["username"]
            if credentials.get("password"):
                kwargs["password"] = credentials["password"]
        if use_token is not False:
            if credentials.get("token_id"):
                kwargs["token_id"] = credentials["token_id"]
            if credentials.get("token_secret"):
                kwargs["token_secret"] = credentials["token_secret"]
        return EfficientIPClient(**kwargs)

    def create_sync_engine(
        self,
        lvi_client: Any,
        target_client: Any,
        sync_config: Dict[str, Any],
    ) -> LogicVeinEfficientIPSync:
        """Create the EfficientIP sync engine.

        Args:
            lvi_client: LogicVein API client.
            target_client: EfficientIPClient instance.
            sync_config: Config dict produced by build_sync_config().

        Returns:
            LogicVeinEfficientIPSync instance.
        """
        return LogicVeinEfficientIPSync(lvi_client=lvi_client, efficientip_client=target_client, config=sync_config)

    def build_sync_config(
        self,
        yaml_config: Dict[str, Any],
        timestamp: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Build sync configuration from YAML config.

        Args:
            yaml_config: Parsed YAML configuration dictionary.
            timestamp: Optional timestamp for archive file naming.

        Returns:
            Configuration dictionary ready for LogicVeinEfficientIPSync.
        """
        sync = yaml_config.get("sync", {})
        lvi = yaml_config.get("logicvein", {})
        eip = yaml_config.get("efficientip", {})
        # efficientip.ipam.*/efficientip.nom.*/efficientip.nom.vlan.* group
        # the live YAML for readability only - the flat keys below (and every
        # self.config.get() in sync.py) are unaffected by that grouping, so
        # this is the only place the nesting is ever un-done.
        ipam = eip.get("ipam", {})
        nom = eip.get("nom", {})
        vlan = nom.get("vlan", {})
        return {
            "dry_run": sync.get("dry_run", False),
            "continue_on_error": sync.get("continue_on_error", True),
            "network": lvi.get("networks", "Default"),
            "space_name": ipam.get("space_name", "Local"),
            "space_partition_by": ipam.get("space_partition_by", "none"),
            "space_mapping": ipam.get("space_mapping", {}),
            "create_missing_spaces": ipam.get("create_missing_spaces", False),
            "default_vrf_name": ipam.get("default_vrf_name", "default"),
            "global_vrf_aliases": ipam.get("global_vrf_aliases", list(_DEFAULT_GLOBAL_VRF_ALIASES)),
            "strip_domain_from_names": eip.get("strip_domain_from_names", True),
            "sync_to_ipam": eip.get("sync_to_ipam", True),
            "sync_to_nom": eip.get("sync_to_nom", False),
            "nom_folder_name": nom.get("folder_name") or f"{get_product_name()} Devices",
            "create_missing_nom_folder": nom.get("create_missing_folder", True),
            "nom_folder_partition_by": nom.get("folder_partition_by", "none"),
            "nom_folder_mapping": nom.get("folder_mapping", {}),
            "sync_nom_interfaces": nom.get("sync_interfaces", True),
            "always_set_nom_main_ip": nom.get("always_set_main_ip", False),
            "sync_nom_vlans": vlan.get("sync", False),
            "nom_vlan_domain_name": vlan.get("domain_name", "Default"),
            "create_missing_vlan_domain": vlan.get("create_missing_domain", True),
            "nom_vlan_range_name": vlan.get("range_name", "Default"),
            "create_missing_vlan_range": vlan.get("create_missing_range", True),
            "nom_vlan_range_start": vlan.get("range_start", 1),
            "nom_vlan_range_end": vlan.get("range_end", 4094),
            "sync_nom_connections": nom.get("sync_connections", False),
            "sync_nom_vrfs": eip.get("sync_vrfs", False),
            "nom_type_mapping": nom.get("type_mapping", _DEFAULT_NOM_TYPE_MAPPING),
            "create_missing_subnets": ipam.get("create_missing_subnets", False),
            "create_missing_blocks": ipam.get("create_missing_blocks", False),
            "class_parameter_mapping": eip.get("class_parameter_mapping", {}),
            "lifecycle_class_parameter_mapping": eip.get("lifecycle_class_parameter_mapping", {}),
            "sync_mac_address": ipam.get("sync_mac_address", True),
            "ip_conflict_policy": ipam.get("ip_conflict_policy", "overwrite"),
            "mac_conflict_policy": ipam.get("mac_conflict_policy", "overwrite"),
            "delete_stale_ips": ipam.get("delete_stale_ips", False),
            "delete_stale_nom_devices": nom.get("delete_stale_devices", False),
            "sync_interface_ips_to_ipam": ipam.get("sync_interface_ips_to_ipam", False),
            "interface_ip_space_partition_by": ipam.get("interface_ip_space_partition_by", "vrf"),
        }

    def test_connection(self, credentials: Dict[str, Any]) -> Tuple[bool, str]:
        """Test connection to EfficientIP SOLIDserver.

        Args:
            credentials: Dict with 'host', 'username', 'password' keys.

        Returns:
            Tuple of (success, message).
        """
        try:
            client = self.create_client(credentials)
            if client.test_connection():
                return True, "Connected to EfficientIP SOLIDserver successfully"
            return False, "Connection test failed - check credentials"
        except Exception as e:
            return False, f"Connection failed: {e}"

    # --- Optional hooks --------------------------------------------------------

    def get_status_detail(self, config: Dict[str, Any]) -> str:
        """One-line summary shown in the sync tab header."""
        networks = normalize_networks(config.get("logicvein", {}).get("networks", "Default"))
        space_name = config.get("efficientip", {}).get("ipam", {}).get("space_name", "Local")
        return f"Network: {', '.join(networks) if networks else 'all'} -> Space: {space_name}"

    def supports_cancellation(self) -> bool:
        """Return True - the sync engine honors set_cancel_token()."""
        return True

    def resolve_conflict(self, conflict_type: str, desired_payload: Dict[str, Any]) -> bool:
        """Apply an "Overwrite" decision for one pending conflict.

        Uses create_client({}) - the same "no override, resolve from stored
        credentials/settings" call real sync runs make (see
        src.common.sync_runner.run_sync's plugin.create_client(target_credentials or {})).

        "mac_differs" only carries mac_address forward (site_id/hostaddr are
        required by ip_add but omitting subnet_id/hostname/class_parameters
        leaves those fields untouched - create_or_update_address only sets a
        field when the argument is truthy).

        "nom_duplicate_this_run" carries no IP address at all - it replays a
        NOM device create-or-update instead (NOM has no single-call upsert,
        so the existing/not-existing decision is made here the same way
        sync.py's own _sync_device_to_nom() makes it).

        Args:
            conflict_type: The kind of conflict being resolved.
            desired_payload: The payload recorded when the conflict was detected.

        Returns:
            True if the overwrite succeeded.
        """
        client = self.create_client({})
        if conflict_type == "mac_differs":
            return client.create_or_update_address(
                ip_address=desired_payload["ip_address"],
                site_id=desired_payload["site_id"],
                mac_address=desired_payload.get("mac_address", ""),
            )
        if conflict_type == "nom_duplicate_this_run":
            return self._resolve_nom_conflict(client, desired_payload)
        return client.create_or_update_address(
            ip_address=desired_payload["ip_address"],
            site_id=desired_payload["site_id"],
            subnet_id=desired_payload.get("subnet_id"),
            hostname=desired_payload.get("hostname", ""),
            mac_address=desired_payload.get("mac_address", ""),
            class_parameters=desired_payload.get("class_parameters") or {},
        )

    @staticmethod
    def _resolve_nom_conflict(client: EfficientIPClient, desired_payload: Dict[str, Any]) -> bool:
        """Apply an "Overwrite" decision for a nom_duplicate_this_run conflict.

        Mirrors _sync_device_to_nom()'s own create-or-update decision:
        create_network_object() errors on an already-existing object, and
        update_network_object() needs the existing nomnetobj_id, so which
        one applies is resolved here rather than delegated to the client.

        Args:
            client: The EfficientIP client to write through.
            desired_payload: The payload recorded when the conflict was detected.

        Returns:
            True if the overwrite succeeded.
        """
        folder_id = desired_payload["folder_id"]
        name = desired_payload["name"]
        type_ = desired_payload.get("type_", "")
        class_parameters = desired_payload.get("class_parameters") or {}
        existing = client.find_network_object(folder_id, name)
        if existing is not None:
            return client.update_network_object(
                existing["nomnetobj_id"], type_=type_, class_parameters=class_parameters
            )
        return client.create_network_object(folder_id, name, type_=type_, class_parameters=class_parameters) is not None
