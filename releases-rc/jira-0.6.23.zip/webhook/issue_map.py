"""Which Jira issue each LogicVein alert opened, kept locally.

The handler finds an alert's issue by its ``lvi-<hash>`` label through JQL.
Two things defeat that lookup right after a create, and a miss there means a
retried raise creates a second issue:

- In Jira Service Management mode the label is added by a second call after
  the request is created; if that call fails, the request has no label.
- Jira Cloud's search index can lag behind a just-created issue.

So the handler records ``hash -> issue key`` the moment an issue exists, and
falls back to this record when the label search finds nothing. Entries are
removed when the alert resolves, or when a later delivery finds the recorded
issue closed or gone, so the file stays small; an issue closed in Jira for an
alert LogicVein never resolves keeps its entry until that alert is next seen.

Stored as ``alert_issues.json`` in the plugin's data directory, written
atomically (temporary file, then rename) under a lock.
"""

import json
import os
import tempfile
import threading
from pathlib import Path
from typing import Dict, Optional

# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import get_plugin_data_dir  # pyright: ignore[reportMissingImports]

FILE_NAME = "alert_issues.json"

_lock = threading.Lock()


def _path() -> Path:
    return get_plugin_data_dir("jira") / FILE_NAME


def _load() -> Dict[str, str]:
    try:
        data = json.loads(_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    if not isinstance(data, dict):
        return {}
    return {str(k): str(v) for k, v in data.items() if isinstance(v, str)}


def _save(data: Dict[str, str]) -> None:
    path = _path()
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=".alert_issues-", suffix=".json")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(data, handle, indent=2, sort_keys=True)
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


def remember(alert_hash: str, issue_key: str) -> None:
    """Record that *alert_hash* opened *issue_key*.

    Args:
        alert_hash: The LogicVein alert hash.
        issue_key: The Jira issue key (e.g. ``"OPS-123"``).
    """
    with _lock:
        data = _load()
        data[alert_hash] = issue_key
        _save(data)


def lookup(alert_hash: str) -> Optional[str]:
    """The issue key recorded for *alert_hash*, or None.

    Args:
        alert_hash: The LogicVein alert hash.

    Returns:
        The recorded issue key, or None.
    """
    with _lock:
        return _load().get(alert_hash)


def forget(alert_hash: str) -> None:
    """Drop the record for *alert_hash* (no-op when there is none).

    Args:
        alert_hash: The LogicVein alert hash.
    """
    with _lock:
        data = _load()
        if data.pop(alert_hash, None) is not None:
            _save(data)
