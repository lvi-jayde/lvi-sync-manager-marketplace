"""phpIPAM IPAM sync plugin."""

from .plugin import PhpIpamPlugin

__all__ = ["PhpIpamPlugin"]
