"""Resolving which SOLIDserver container a device or address belongs in.

Serves two containers with the same key mechanics but different reasons:

* the **IP Space** for IPAM addresses, where partitioning is a *correctness*
  requirement - address identity is ``(site_id, hostaddr)``, so one space
  cannot hold overlapping addresses
* the **NOM folder** for NOM devices, where it is organisational plus a
  hostname-collision fix - NOM identity is name-in-folder, so two devices
  sharing a hostname across networks collide in one flat folder

Only the IP Space offers the VRF axis. A NOM device is a whole device whose
interfaces routinely span several VRFs, so there is no single correct VRF
folder for it; NOM partitions by LVI network only, which is coherent because
that is what partitions devices.


SOLIDserver cannot attach a VRF to any IPAM or NOM object (confirmed live -
see the app repo's docs/dev_notes/historical/EFFICIENTIP_VRF_INVESTIGATION.md),
so a VRF can only ever be expressed as *which container the object lives in*.
The IP Space is the only container that enforces address uniqueness - address
identity is ``(site_id, hostaddr)`` - which makes it the only mechanism for
overlapping addresses. NOM folders have no IP-uniqueness constraint at all.

Two independent axes decide the container, and a deployment can need both:

* an **LVI managed network** partitions *devices*
* a **VRF** is an attribute of an *interface*, and one device routinely has
  interfaces in several VRFs

The same VRF name (``prod``, ``mgmt``) commonly recurs across networks meaning
different things, which is why ``lvi_network+vrf`` composes them rather than
offering only a choice between them.

This module is deliberately pure: it maps names to a space name and nothing
else. It knows nothing about the SOLIDserver API, so the precedence rules can
be tested directly. Kept plugin-local rather than hoisted to core - Infoblox's
``network_view`` has the same shape of problem, but hoisting an abstraction
with a single consumer is how the wrong boundary gets frozen in.
"""

from typing import Dict, Iterable, List, Optional, Tuple

from src.plugin_api import get_product_name  # pyright: ignore[reportMissingImports]

# Partition modes for the `space_partition_by` setting.
MODE_NONE = "none"
MODE_NETWORK = "lvi_network"
MODE_VRF = "vrf"
MODE_NETWORK_VRF = "lvi_network+vrf"
MODES = (MODE_NONE, MODE_NETWORK, MODE_VRF, MODE_NETWORK_VRF)

# Separator between the two segments of a composite key. Not valid inside a
# VRF name, and not used by LVI network names in practice. A name containing
# it is rejected up front (see validate_names) rather than silently mis-keyed;
# escaping would make keys unreadable in the config file for no real gain.
SEPARATOR = "/"

WILDCARD = "*"

# What to do when no mapping entry matches.
UNMAPPED_SKIP = "skip"
UNMAPPED_FALLBACK = "fallback"
UNMAPPED_AUTO = "auto"
UNMAPPED_POLICIES = (UNMAPPED_SKIP, UNMAPPED_FALLBACK, UNMAPPED_AUTO)


# Vendor names for the *global* routing table, which every platform spells
# differently. Verified from vendor documentation (2026-07-30):
#
#   Cisco IOS/IOS-XE   no name at all - implicit when no VRF is given
#   Cisco IOS-XR       "default"   (cannot be created, only referenced)
#   Cisco NX-OS        "default"   (plus a separate built-in "management" VRF)
#   Arista EOS         "default"
#   Juniper Junos      "master"    (table inet.0; reserved, cannot be reused)
#   Nokia SR OS        "Base"      (the Base router instance IS the GRT)
#   Huawei             "_public_"  (undeletable built-in instance)
#   Palo Alto          "default"   virtual router
#   Fortinet FortiOS   "0"         (numeric)
#
# Without normalising these, an IOS-XR device ("default") and a Juniper
# ("master") both sit in the global table but produce different partition
# keys, so a user needs one mapping entry per platform spelling and has to
# know each one. Folding them onto a single configured name means one entry.
#
# IMPORTANT CAVEATS, which is why this list is configurable rather than fixed:
#
# * Palo Alto's "default" virtual router carries no special status - it is
#   renameable and deletable - and Fortinet's VRF 0 is a real VRF that merely
#   also handles local-in traffic specially. Treating those names as "the
#   global table" is a heuristic.
# * Someone who deliberately names a production VRF "default" or "master"
#   would have it folded into the global partition. Remove the alias in that
#   case.
# * "mgmt-vrf"/"management" are not vendor spellings of the global table (NX-OS's
#   own built-in "management" VRF is a real, separate VRF, per the line above) -
#   they are a deliberate policy fold added 2026-08-01 after real lab data
#   showed a dedicated out-of-band management VRF, for deployments that would
#   rather not give it its own IP space. Remove them to partition it separately.
# * These are *vendor* names. Whether LogicVein reports them verbatim,
#   normalises them, or reports something else was unconfirmed as of
#   2026-07-30 - the lab had no VRF-bearing devices at that point (278
#   interfaces, vrfName null on every one). Confirmed live the next day:
#   real interface VRF names 'Mgmt-vrf' and 'clab-mgmt' both appeared,
#   neither a vendor spelling of the global table (see the fold above for
#   the first). Every run's log still reports the distinct vrfName values
#   actually seen, and which of them were folded - check new deployments
#   against that rather than assuming this list is complete.
DEFAULT_GLOBAL_VRF_ALIASES = ("default", "master", "base", "_public_", "global", "grt", "0", "mgmt-vrf", "management")


def normalize_vrf(vrf: str, aliases: Iterable[str], global_name: str) -> str:
    """Fold a vendor's name for the global routing table onto *global_name*.

    Matching is case-insensitive and whitespace-trimmed, so "Base" and "base"
    are the same alias. A blank *vrf* (LogicVein reports null for a device with
    no VRF, which is the common case) also returns *global_name*.

    Args:
        vrf: The raw VRF name as reported by LogicVein.
        aliases: Vendor spellings of the global routing table to fold.
        global_name: The name to fold matches (and blanks) onto.

    Returns:
        The normalized VRF name.
    """
    cleaned = (vrf or "").strip()
    if not cleaned:
        return global_name
    if cleaned.casefold() in {a.strip().casefold() for a in aliases if a and a.strip()}:
        return global_name
    return cleaned


def needs_vrf(mode: str) -> bool:
    """Whether *mode* requires knowing an object's VRF to build its key."""
    return mode in (MODE_VRF, MODE_NETWORK_VRF)


def needs_network(mode: str) -> bool:
    """Whether *mode* requires knowing an object's LVI network to build its key."""
    return mode in (MODE_NETWORK, MODE_NETWORK_VRF)


def build_key(mode: str, network: str, vrf: str) -> str:
    """Build the partition key for one object.

    Args:
        mode: The partition mode.
        network: The object's LVI network.
        vrf: The object's normalized VRF name.

    Returns:
        The partition key, or "" for MODE_NONE, where the key is unused
        and the single configured ``space_name`` applies to everything.
    """
    if mode == MODE_NETWORK:
        return network
    if mode == MODE_VRF:
        return vrf
    if mode == MODE_NETWORK_VRF:
        return f"{network}{SEPARATOR}{vrf}"
    return ""


def _candidates(mode: str, key: str) -> List[str]:
    """Mapping keys to try for *key*, most specific first.

    Specificity is the number of non-wildcard segments, highest first, then
    left to right as the tiebreak - so for ``Default/mgmt``:

    1. ``Default/mgmt``  (exact, 2 segments)
    2. ``Default/*``     (1 segment, left)
    3. ``*/mgmt``        (1 segment, right)

    The left-to-right tiebreak means a network-scoped entry beats a
    VRF-scoped one. That is a judgement call, not a law: the LVI network is
    the outer, device-level boundary a VRF sits inside. It is arbitrary but
    fixed, and an exact entry always overrides it.

    Args:
        mode: The partition mode.
        key: The partition key to build candidates for.

    Returns:
        Mapping keys to try, most specific first.
    """
    if mode != MODE_NETWORK_VRF:
        return [key, WILDCARD]
    network, _, vrf = key.partition(SEPARATOR)
    return [
        key,
        f"{network}{SEPARATOR}{WILDCARD}",
        f"{WILDCARD}{SEPARATOR}{vrf}",
        f"{WILDCARD}{SEPARATOR}{WILDCARD}",
    ]


def resolve_container_name(
    mode: str,
    key: str,
    mapping: Dict[str, str],
    space_name: str,
    unmapped_policy: str,
) -> Optional[str]:
    """Return the IP Space name for *key*, or None when the object should be skipped.

    In MODE_NONE the configured *space_name* always wins and the mapping is
    ignored entirely.

    A mapping value of "" is an explicit "do not sync this partition" and
    returns None regardless of *unmapped_policy* - distinct from no entry at
    all, which the policy decides.

    UNMAPPED_AUTO uses the partition key itself as the container name, so a
    key with no matching entry gets a container named after it rather than
    being skipped or folded into *space_name*. Paired with
    create_missing_spaces (or create_missing_nom_folder), this needs no
    mapping maintained at all - one container per distinct key, named for
    it. In MODE_NETWORK_VRF the key contains SEPARATOR ("/"); whether
    SOLIDserver accepts that in a site_name has not been verified, so a
    literal "/" is passed through rather than guessed at - if it is
    rejected, space creation fails visibly for that key (see the call
    site), the same as any other creation failure.

    Args:
        mode: The partition mode.
        key: The partition key to resolve.
        mapping: The configured key -> container name mapping.
        space_name: The MODE_NONE container name.
        unmapped_policy: What to do when no mapping entry matches.

    Returns:
        The container name, or None when the object should be skipped.
    """
    if mode == MODE_NONE:
        return space_name
    for candidate in _candidates(mode, key):
        if candidate in mapping:
            return mapping[candidate] or None
    if unmapped_policy == UNMAPPED_FALLBACK:
        return space_name
    if unmapped_policy == UNMAPPED_AUTO:
        return key or None
    return None


def validate_config(
    mode: str,
    mapping: Dict[str, str],
    unmapped_policy: str,
    sync_vrfs: bool = True,
) -> List[str]:
    """Return a list of human-readable config problems (empty when valid).

    Checked up front so a misconfiguration is one clear message at the start
    of a run rather than a puzzling per-device failure, or worse a key that
    silently never matches.

    *unmapped_policy* is no longer a user-set value - the caller derives it
    from create_missing_spaces/create_missing_folder (see sync.py's
    ipam_unmapped_policy/nom_unmapped_policy), so this check is defensive
    only: it should never actually fail in practice, but stays here as a
    guard against a future caller passing something invalid directly.

    *sync_vrfs* gates the two modes that need a device's VRF to build their
    partition key (MODE_VRF, MODE_NETWORK_VRF) - efficientip.sync_vrfs is a
    top-level "VRF awareness" switch, not NOM-specific despite also
    controlling NOM's VRF-catalog sync, so a mode that needs VRF data with
    it off is rejected here rather than silently partitioning on a VRF
    nothing else in this run is even looking at. Defaults to True so the
    NOM folder-partitioning call site (whose mode is never one of the two
    VRF-needing ones - see its own docstring) does not need to pass it.

    Args:
        mode: The partition mode.
        mapping: The configured key -> container name mapping.
        unmapped_policy: What to do when no mapping entry matches.
        sync_vrfs: Whether VRF data is being collected this run.

    Returns:
        Human-readable config problems (empty when valid).
    """
    problems: List[str] = []
    if mode not in MODES:
        problems.append(f"space_partition_by '{mode}' is not one of {', '.join(MODES)}")
    if unmapped_policy not in UNMAPPED_POLICIES:
        problems.append(
            f"internal unmapped-key policy '{unmapped_policy}' is not one of {', '.join(UNMAPPED_POLICIES)}"
        )
    if needs_vrf(mode) and not sync_vrfs:
        problems.append(
            f"space_partition_by '{mode}' needs a VRF, but sync_vrfs is off - "
            f"turn it on, or choose a mode that doesn't need VRF data"
        )
    expected = 2 if mode == MODE_NETWORK_VRF else 1
    for entry in mapping:
        segments = entry.split(SEPARATOR)
        if len(segments) != expected:
            problems.append(
                f"space_mapping key '{entry}' has {len(segments)} segment(s) but "
                f"space_partition_by '{mode}' expects {expected}"
                + (f" (<network>{SEPARATOR}<vrf>)" if expected == 2 else "")
            )
        elif any(WILDCARD in seg and seg != WILDCARD for seg in segments):
            problems.append(
                f"space_mapping key '{entry}' uses '{WILDCARD}' inside a segment; "
                f"a wildcard must replace a whole segment"
            )
    return problems


def validate_names(mode: str, networks: List[str], vrfs: List[str]) -> List[str]:
    """Return problems caused by a network or VRF name containing the separator.

    Only meaningful for the composite mode, where such a name would split into
    the wrong number of segments and match the wrong entry (or none).

    Args:
        mode: The partition mode.
        networks: LVI network names observed/configured.
        vrfs: VRF names observed/configured.

    Returns:
        Human-readable naming problems (empty when none).
    """
    if mode != MODE_NETWORK_VRF:
        return []
    problems = []
    for label, values in ((f"{get_product_name()} network", networks), ("VRF", vrfs)):
        for value in sorted({v for v in values if SEPARATOR in v}):
            problems.append(
                f"{label} name '{value}' contains '{SEPARATOR}', which space_mapping uses "
                f"to separate key segments - rename it or use a non-composite "
                f"space_partition_by mode"
            )
    return problems


def describe(mode: str, key: str) -> Tuple[str, str]:
    """Return (label, value) naming the partition, for log and report text."""
    if mode == MODE_NONE:
        return ("space", "")
    if mode == MODE_NETWORK:
        return (f"{get_product_name()} network", key)
    if mode == MODE_VRF:
        return ("VRF", key)
    return ("network/VRF", key)
