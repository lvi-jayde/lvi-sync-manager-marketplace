"""phpIPAM sync plugin - the SyncPlugin entry point."""

import logging
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

# Plugins import ONLY from src.plugin_api - the frozen, versioned surface.
# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import SyncPlugin, load_plugin_config, normalize_networks  # pyright: ignore[reportMissingImports]

from .client import MARKER_FIELD, PhpIpamClient
from .sync import DEFAULT_GLOBAL_VRF_ALIASES, LogicVeinPhpIpamSync

logger = logging.getLogger(__name__)


class PhpIpamPlugin(SyncPlugin):
    """Sync LogicVein device management IPs into phpIPAM addresses."""

    def __init__(self) -> None:
        """Load this plugin's identity/config metadata from manifest.json."""
        self.config = load_plugin_config(Path(__file__).parent)

    # --- Required -------------------------------------------------------

    def create_client(self, credentials: Dict[str, Any]) -> Any:
        """Build the phpIPAM client from saved/credentials-tab values.

        Args:
            credentials: Credential values from the Credentials tab.

        Returns:
            A configured PhpIpamClient.
        """
        kwargs: Dict[str, Any] = {}
        if credentials.get("ignore_env_vars"):
            kwargs["ignore_env_vars"] = True
        for field in ("host", "username", "password", "app_id", "app_code"):
            if credentials.get(field):
                kwargs[field] = credentials[field]
        return PhpIpamClient(**kwargs)

    def create_sync_engine(self, lvi_client: Any, target_client: Any, sync_config: Dict[str, Any]) -> Any:
        """Build the engine that does the actual LVI -> phpIPAM work.

        Args:
            lvi_client: LogicVein API client instance.
            target_client: PhpIpamClient instance.
            sync_config: Flat config dict from build_sync_config().

        Returns:
            A LogicVeinPhpIpamSync engine.
        """
        return LogicVeinPhpIpamSync(lvi_client=lvi_client, target_client=target_client, config=sync_config)

    def build_sync_config(self, yaml_config: Dict[str, Any], timestamp: Optional[str] = None) -> Dict[str, Any]:
        """Flatten the YAML config into the flat dict the engine expects.

        Args:
            yaml_config: The plugin's parsed conf/<config_file> YAML.
            timestamp: Unused.

        Returns:
            The flat config dict LogicVeinPhpIpamSync expects.
        """
        sync = yaml_config.get("sync", {})
        lvi = yaml_config.get("logicvein", {})
        phpipam = yaml_config.get("phpipam", {})
        return {
            "dry_run": sync.get("dry_run", False),
            "continue_on_error": sync.get("continue_on_error", True),
            "network": lvi.get("networks", "Default"),
            "section_name": phpipam.get("section_name", ""),
            "create_missing_sections": phpipam.get("create_missing_sections", False),
            "sync_mac_address": phpipam.get("sync_mac_address", True),
            "create_missing_subnets": phpipam.get("create_missing_subnets", False),
            "default_subnet_mask": phpipam.get("default_subnet_mask", 24),
            "delete_stale_ips": phpipam.get("delete_stale_ips", False),
            "ip_conflict_policy": phpipam.get("ip_conflict_policy", "ask"),
            "mac_conflict_policy": phpipam.get("mac_conflict_policy", "ask"),
            "strip_domain_from_names": phpipam.get("strip_domain_from_names", True),
            "sync_vrfs": phpipam.get("sync_vrfs", False),
            "default_vrf_name": phpipam.get("default_vrf_name", "default"),
            "global_vrf_aliases": phpipam.get("global_vrf_aliases", list(DEFAULT_GLOBAL_VRF_ALIASES)),
            "section_partition_by": phpipam.get("section_partition_by", "none"),
            "section_mapping": phpipam.get("section_mapping", {}),
            "sync_vlans": phpipam.get("sync_vlans", False),
            "vlan_domain_name": phpipam.get("vlan_domain_name", "Default"),
            "create_missing_vlan_domain": phpipam.get("create_missing_vlan_domain", True),
        }

    def test_connection(self, credentials: Dict[str, Any]) -> Tuple[bool, str]:
        """Verify the target credentials for the Credentials tab's Test button.

        Args:
            credentials: Credential values to test.

        Returns:
            (True, message) on success, (False, message) on failure.
        """
        try:
            client = self.create_client(credentials)
            if client.test_connection():
                return True, "Connected to phpIPAM successfully"
            return False, "Connection test failed - check the host, app id, username, and password"
        except Exception as exc:
            return False, f"Connection failed: {exc}"

    # --- Optional ---------------------------------------------------------

    def get_status_detail(self, config: Dict[str, Any]) -> str:
        """One-line summary shown in the sync tab header.

        Args:
            config: The plugin's parsed conf/<config_file> YAML.

        Returns:
            A "Network: ... | Section: ..." summary string.
        """
        networks = normalize_networks(config.get("logicvein", {}).get("networks", "Default"))
        section_name = config.get("phpipam", {}).get("section_name", "")
        return f"Network: {', '.join(networks) if networks else 'all'} | Section: {section_name}"

    def supports_cancellation(self) -> bool:
        """Return True - the sync engine honors set_cancel_token()."""
        return True

    def resolve_conflict(self, conflict_type: str, desired_payload: Dict[str, Any]) -> bool:
        """Apply a deferred conflict decision from the Resolve Conflicts screen.

        Args:
            conflict_type: "ip_exists", "mac_duplicate", or "mac_differs".
            desired_payload: The payload LogicVeinPhpIpamSync recorded via
                pending_conflict_item() when it deferred this device.

        Returns:
            True if the write succeeded.
        """
        client = self.create_client({})
        try:
            existing = client.search_address_by_ip(desired_payload["ip_address"])
            if existing is not None:
                client.update_address(
                    existing["id"],
                    hostname=desired_payload.get("hostname", ""),
                    description=desired_payload.get("description", ""),
                    mac=desired_payload.get("mac", ""),
                    **{MARKER_FIELD: "yes"},
                )
            else:
                client.create_address(
                    desired_payload["ip_address"],
                    desired_payload["subnet_id"],
                    hostname=desired_payload.get("hostname", ""),
                    description=desired_payload.get("description", ""),
                    mac=desired_payload.get("mac", ""),
                    tag_id=desired_payload.get("tag_id"),
                    custom_fields={MARKER_FIELD: "yes"},
                )
            return True
        except Exception as exc:
            logger.error(
                "Failed to resolve %s conflict for %s: %s", conflict_type, desired_payload.get("ip_address"), exc
            )
            return False
