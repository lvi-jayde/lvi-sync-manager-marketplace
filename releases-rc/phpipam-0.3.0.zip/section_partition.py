"""Resolving which nested phpIPAM Section a device belongs in.

Mirrors EfficientIP's ``space_partition.py`` (same key-building, wildcard-
mapping, and unmapped-key mechanics), adapted for phpIPAM's own object
model: phpIPAM has no separate IPAM-space/NOM-folder distinction, and a
partition here is a **child Section nested under the base Section** via
phpIPAM's own ``masterSection`` field - not a second, independent flat
container the way EfficientIP's IP Space is. This module is deliberately
pure (string in, string out) so the precedence rules are testable without
a live client, kept plugin-local rather than shared for the same reason
EfficientIP's own module gives: hoisting an abstraction with a single
consumer freezes the wrong boundary in.

VRF-based partitioning (``vrf``, ``lvi_network+vrf``) needs a normalized
VRF name, sharing the same fold-vendor-spellings-onto-one-name approach
used by phpIPAM's own Sync VRFs feature (see ``sync.py``'s
``_normalize_vrf`` and ``phpipam.global_vrf_aliases``) - the alias list and
normalization function are owned there, not duplicated here; callers pass
in an already-normalized VRF name.
"""

from typing import Dict, List, Optional

# Partition modes for the `section_partition_by` setting.
MODE_NONE = "none"
MODE_NETWORK = "lvi_network"
MODE_VRF = "vrf"
MODE_NETWORK_VRF = "lvi_network+vrf"
MODES = (MODE_NONE, MODE_NETWORK, MODE_VRF, MODE_NETWORK_VRF)

# Separator between the two segments of a composite key - see EfficientIP's
# space_partition.py for the same rationale (not valid inside a VRF name,
# not used by LVI network names in practice).
SEPARATOR = "/"

WILDCARD = "*"

# What to do when no mapping entry matches a partition key.
UNMAPPED_SKIP = "skip"
UNMAPPED_AUTO = "auto"
UNMAPPED_POLICIES = (UNMAPPED_SKIP, UNMAPPED_AUTO)


def needs_vrf(mode: str) -> bool:
    """Whether *mode* requires knowing a device's VRF to build its key."""
    return mode in (MODE_VRF, MODE_NETWORK_VRF)


def build_key(mode: str, network: str, vrf: str) -> str:
    """Build the partition key for one device.

    Args:
        mode: The partition mode.
        network: The device's LVI network.
        vrf: The device's normalized VRF name.

    Returns:
        The partition key, or "" for MODE_NONE, where the key is unused
        and every device shares the one base Section.
    """
    if mode == MODE_NETWORK:
        return network
    if mode == MODE_VRF:
        return vrf
    if mode == MODE_NETWORK_VRF:
        return f"{network}{SEPARATOR}{vrf}"
    return ""


def _candidates(mode: str, key: str) -> List[str]:
    """Mapping keys to try for *key*, most specific first.

    Same precedence as EfficientIP's space_partition._candidates: exact
    match, then network-scoped, then VRF-scoped, then a bare wildcard.

    Args:
        mode: The partition mode.
        key: The partition key to build candidates for.

    Returns:
        Mapping keys to try, most specific first.
    """
    if mode != MODE_NETWORK_VRF:
        return [key, WILDCARD]
    network, _, vrf = key.partition(SEPARATOR)
    return [
        key,
        f"{network}{SEPARATOR}{WILDCARD}",
        f"{WILDCARD}{SEPARATOR}{vrf}",
        f"{WILDCARD}{SEPARATOR}{WILDCARD}",
    ]


def resolve_section_name(
    mode: str,
    key: str,
    mapping: Dict[str, str],
    unmapped_policy: str,
) -> Optional[str]:
    """Return the child Section name for *key*, or None to skip partitioning.

    In MODE_NONE, returns None - the caller should use the base Section
    directly rather than creating a child.

    A mapping value of "" is an explicit "do not partition this key" and
    returns None regardless of *unmapped_policy*, distinct from no entry
    at all, which the policy decides.

    UNMAPPED_AUTO uses the partition key itself as the child Section name,
    so a key with no matching entry gets a Section named after it rather
    than being skipped. Paired with create_missing_sections, this needs no
    mapping maintained at all.

    Args:
        mode: The partition mode.
        key: The partition key to resolve.
        mapping: The configured key -> child Section name mapping.
        unmapped_policy: What to do when no mapping entry matches.

    Returns:
        The child Section name, or None when the device should use the
        base Section unpartitioned (MODE_NONE, an explicit skip, or an
        unmapped key under UNMAPPED_SKIP).
    """
    if mode == MODE_NONE:
        return None
    for candidate in _candidates(mode, key):
        if candidate in mapping:
            return mapping[candidate] or None
    if unmapped_policy == UNMAPPED_AUTO:
        return key or None
    return None


def validate_config(mode: str, mapping: Dict[str, str], sync_vrfs: bool) -> List[str]:
    """Return a list of human-readable config problems (empty when valid).

    Checked up front so a misconfiguration is one clear message at the
    start of a run rather than a puzzling per-device failure or a key that
    silently never matches.

    Args:
        mode: The partition mode.
        mapping: The configured key -> child Section name mapping.
        sync_vrfs: Whether phpipam.sync_vrfs is on this run.

    Returns:
        Human-readable config problems (empty when valid).
    """
    problems: List[str] = []
    if mode not in MODES:
        problems.append(f"section_partition_by '{mode}' is not one of {', '.join(MODES)}")
        return problems
    if needs_vrf(mode) and not sync_vrfs:
        problems.append(
            f"section_partition_by '{mode}' needs a VRF, but sync_vrfs is off - "
            f"turn it on, or choose a mode that doesn't need VRF data"
        )
    expected = 2 if mode == MODE_NETWORK_VRF else 1
    for entry in mapping:
        segments = entry.split(SEPARATOR)
        if len(segments) != expected:
            problems.append(
                f"section_mapping key '{entry}' has {len(segments)} segment(s) but "
                f"section_partition_by '{mode}' expects {expected}"
                + (f" (<network>{SEPARATOR}<vrf>)" if expected == 2 else "")
            )
        elif any(WILDCARD in seg and seg != WILDCARD for seg in segments):
            problems.append(
                f"section_mapping key '{entry}' uses '{WILDCARD}' inside a segment; "
                f"a wildcard must replace a whole segment"
            )
    return problems
