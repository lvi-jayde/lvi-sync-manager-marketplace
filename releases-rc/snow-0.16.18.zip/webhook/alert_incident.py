"""ServiceNow alert handler: raise/resolve incidents from LVI AlertEvents.

Registered with the core alert dispatch (``register_alert_handler``), this
handler is called by the core ``/webhook/lvi-alert`` route with each
:class:`AlertEvent`. It performs the ServiceNow-specific raise/resolve incident
lifecycle that used to live inline in the route: create an incident on first
violation, add a (flood-suppressed) work note on repeats, and resolve the
incident when the violation clears. The correlation between raise and resolve is
LVI's ``{hash}`` mapped to SNOW ``correlation_id``.

Exceptions propagate to the core route, which maps them to 502/500 so LogicVein
retries delivery.
"""

import json
import logging
import os
import time
from datetime import datetime
from typing import Any, Dict, List, Optional

# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import AlertEvent  # pyright: ignore[reportMissingImports]
from src.plugin_api import webhook_store as store  # pyright: ignore[reportMissingImports]

from ..settings import get_snow_client, get_snow_settings

logger = logging.getLogger(__name__)

_PLUGIN_ID = "snow"  # tags webhook events so the UI can filter the log per plugin


def _log_event(**kwargs: Any) -> None:
    """Record a webhook event tagged with this plugin's id."""
    store.log_event(plugin=_PLUGIN_ID, **kwargs)


# Severity -> SNOW urgency/impact mapping
_SEVERITY_MAP: Dict[str, int] = {
    "critical": 1,
    "high": 1,
    "medium": 2,
    "warning": 2,
    "low": 3,
    "info": 3,
    "informational": 3,
}

# Urgency integer -> human-readable label (used in webhook event log)
_URGENCY_LABELS: Dict[int, str] = {1: "High", 2: "Medium", 3: "Low"}

# SNOW incident state values
_STATE_NEW = 1
_STATE_RESOLVED = 6

# Cached values with TTL - stored as (value, expires_at_monotonic) or None
_CACHE_TTL_SECONDS = 3600  # re-validate after 1 hour
_caller_sys_id_cache: Optional[tuple] = None
_close_code_cache: Optional[tuple] = None


def _get_snow_client() -> Any:
    """Build a ServiceNowClient from environment variables."""
    return get_snow_client()


def _severity_to_urgency(severity: str) -> int:
    """Map an LVI severity string to a SNOW urgency/impact integer (1-3)."""
    return _SEVERITY_MAP.get(severity.lower(), 2)


def _urgency_label(severity: str) -> str:
    """Return the SNOW urgency label (High/Medium/Low) for an LVI severity string."""
    return _URGENCY_LABELS.get(_severity_to_urgency(severity), "Medium")


def _build_short_description(payload: AlertEvent) -> str:
    """Build the SNOW incident short_description from the LVI alert payload."""
    sev = payload.severity.upper() if payload.severity else "UNKNOWN"
    node = payload.node or "unknown node"
    msg = payload.message or "alert"
    return f"[LVI] {sev} - {msg} on {node}"


def _build_description(payload: AlertEvent) -> str:
    """Build the full SNOW incident description from the LVI alert payload."""
    lines = [
        "LogicVein Alert Details",
        "=" * 40,
        f"Node:             {payload.node}",
        f"Severity:         {payload.severity}",
        f"Message:          {payload.message}",
        f"Occurrences:      {payload.occurrences}",
        f"Violation Status: {payload.violation_status}",
        f"Updated At:       {payload.updated_at}",
    ]
    if payload.link:
        lines.append(f"LVI Link:         {payload.link}")
    lines.append(f"Correlation Hash: {payload.hash}")
    return "\n".join(lines)


def _get_close_code(snow: Any) -> str:
    """Return the close_code value to use when resolving an incident.

    Priority:
    1. lvi_alerts.close_code in conf/snow_sync_config.yaml (explicit override)
    2. First active choice from SNOW's sys_choice table for incident.close_code
    3. Hardcoded fallback "Solved (Permanently)"

    The result is cached with a TTL of _CACHE_TTL_SECONDS.

    Args:
        snow: The ServiceNowClient to query.

    Returns:
        The close_code value to use.
    """
    global _close_code_cache
    if _close_code_cache is not None and time.monotonic() < _close_code_cache[1]:
        return _close_code_cache[0]
    _close_code_cache = None  # invalidate expired entry

    # Config override takes priority
    try:
        cfg_code = (get_snow_settings().get("lvi_alerts", {}).get("close_code") or "").strip()
        if cfg_code:
            _close_code_cache = (cfg_code, time.monotonic() + _CACHE_TTL_SECONDS)
            logger.info("Using lvi_alerts.close_code from config: %s", cfg_code)
            return cfg_code
    except Exception as exc:
        logger.warning("Could not read lvi_alerts.close_code from config: %s", exc)

    # Query SNOW for valid values
    try:
        choices: List[Dict[str, Any]] = snow.query_table(
            "sys_choice",
            query="name=incident^element=close_code^language=en^inactive=false",
            fields=["value", "label"],
            limit=20,
        )
        if choices:
            code = choices[0]["value"]
            _close_code_cache = (code, time.monotonic() + _CACHE_TTL_SECONDS)
            labels = [c.get("label", c["value"]) for c in choices]
            logger.info("Resolved SNOW close_code from sys_choice: '%s' (available: %s)", code, labels)
            return code
    except Exception as exc:
        logger.warning("Could not query sys_choice for close_code: %s", exc)

    code = "Solved (Permanently)"
    _close_code_cache = (code, time.monotonic() + _CACHE_TTL_SECONDS)
    logger.warning("Falling back to hardcoded close_code: %s", code)
    return code


def _resolve_caller_sys_id(snow: Any) -> Optional[str]:
    """Look up and cache the sys_id of the configured caller user.

    The caller username is read from lvi_alerts.creator_username in
    conf/snow_sync_config.yaml. Successful lookups are cached with a TTL
    of _CACHE_TTL_SECONDS.

    Args:
        snow: The ServiceNowClient to query.

    Returns:
        The caller's sys_id, or None if not configured or not found.
    """
    global _caller_sys_id_cache
    if _caller_sys_id_cache is not None and time.monotonic() < _caller_sys_id_cache[1]:
        return _caller_sys_id_cache[0]
    _caller_sys_id_cache = None  # invalidate expired entry

    username = (get_snow_settings().get("lvi_alerts", {}).get("creator_username") or "").strip()
    if not username:
        return None

    try:
        results = snow.query_table(
            "sys_user",
            query=f"user_name={username}",
            fields=["sys_id", "user_name"],
            limit=1,
        )
        if results:
            sys_id = results[0]["sys_id"]
            _caller_sys_id_cache = (sys_id, time.monotonic() + _CACHE_TTL_SECONDS)
            logger.info("Resolved SNOW caller sys_id for user '%s': %s", username, sys_id)
            return sys_id
        else:
            logger.warning("SNOW user '%s' not found - caller_id will not be set", username)
    except Exception as exc:
        logger.warning("Could not resolve caller sys_id: %s", exc)

    return None


def _find_open_incident(snow: Any, correlation_id: str) -> Optional[Dict[str, Any]]:
    """Search for an open (non-resolved, non-closed) SNOW incident by correlation_id."""
    results = snow.query_table(
        "incident",
        query=f"correlation_id={correlation_id}^state!={_STATE_RESOLVED}^state!=7",
        fields=["sys_id", "number", "state", "short_description"],
        limit=1,
    )
    return results[0] if results else None


def _find_any_incident(snow: Any, correlation_id: str) -> Optional[Dict[str, Any]]:
    """Search for any SNOW incident by correlation_id (any state)."""
    results = snow.query_table(
        "incident",
        query=f"correlation_id={correlation_id}",
        fields=["sys_id", "number", "state", "short_description"],
        limit=1,
    )
    return results[0] if results else None


# ---------------------------------------------------------------------------
# Handler
# ---------------------------------------------------------------------------


class SnowAlertHandler:
    """Alert handler that raises/resolves SNOW incidents from LVI AlertEvents."""

    def __call__(self, event: AlertEvent, ts_out: Optional[datetime] = None) -> Dict[str, Any]:
        """Process one AlertEvent and return a result dict."""
        snow = _get_snow_client()
        snow_dst = os.getenv("SNOW_INSTANCE", "")
        if event.action == "raise":
            result = _handle_raise(snow, event, snow_dst=snow_dst, ts_out=ts_out)
        else:
            result = _handle_resolve(snow, event, snow_dst=snow_dst, ts_out=ts_out)
        # The core route stamps the shared inbound row with this id (UI per-plugin
        # filter) and the incident title (the Description column).
        result["plugin"] = _PLUGIN_ID
        result.setdefault("description", _build_short_description(event))
        return result


_handler: Optional[SnowAlertHandler] = None


def get_alert_handler() -> SnowAlertHandler:
    """Return the module-level singleton alert handler (created on first use)."""
    global _handler
    if _handler is None:
        _handler = SnowAlertHandler()
    return _handler


# ---------------------------------------------------------------------------
# Raise / resolve logic
# ---------------------------------------------------------------------------


def _handle_raise(
    snow: Any,
    payload: AlertEvent,
    snow_dst: str = "",
    ts_out: Optional[datetime] = None,
) -> Dict[str, Any]:
    """Create a new SNOW incident or add a work note to an existing open one."""
    existing = _find_open_incident(snow, payload.hash)

    if existing:
        sys_id = existing["sys_id"]
        number = existing.get("number", sys_id)

        try:
            min_interval = int(get_snow_settings().get("lvi_alerts", {}).get("min_update_minutes", 5))
        except Exception:
            # Broad on purpose: get_snow_settings() reads YAML config, which can fail
            # in varied ways; any read/parse problem defaults the interval to 5.
            min_interval = 5
        if store.should_update(payload.hash, min_interval):
            work_note = (
                f"Ongoing violation detected by LogicVein.\n"
                f"Occurrences: {payload.occurrences}\n"
                f"Violation Status: {payload.violation_status}\n"
                f"Updated At: {payload.updated_at}"
            )
            snow.update_record("incident", sys_id, {"work_notes": work_note})
            _log_event(
                direction="sync mgr→snow",
                action="update",
                node=payload.node,
                correlation_hash=payload.hash,
                severity=_urgency_label(payload.severity),
                result="updated",
                src="Sync Manager",
                dst=snow_dst,
                incident=number,
                status_code=200,
                timestamp=ts_out,
                description=_build_short_description(payload),
            )
            logger.info("Updated existing SNOW incident %s for hash=%s", number, payload.hash)
        else:
            logger.debug(
                "Suppressed work note for incident %s (within %d-min interval) hash=%s",
                number,
                min_interval,
                payload.hash,
            )
            return {"result": "suppressed", "action": "raise", "incident": number, "sys_id": sys_id}
        return {"result": "updated", "incident": number, "sys_id": sys_id}

    urgency = _severity_to_urgency(payload.severity)
    incident_data: Dict[str, Any] = {
        "short_description": _build_short_description(payload),
        "description": _build_description(payload),
        "correlation_id": payload.hash,
        "correlation_display": "LogicVein",
        "category": "Network",
        "subcategory": "Network Monitoring",
        "urgency": str(urgency),
        "impact": str(urgency),
        "state": str(_STATE_NEW),
    }

    caller_sys_id = _resolve_caller_sys_id(snow)
    if caller_sys_id:
        incident_data["caller_id"] = caller_sys_id

    created = snow.create_record("incident", incident_data)
    number = created.get("number", created.get("sys_id", "unknown"))
    sys_id = created.get("sys_id", "")
    _log_event(
        direction="sync mgr→snow",
        action="create",
        node=payload.node,
        correlation_hash=payload.hash,
        severity=_urgency_label(payload.severity),
        result="created",
        src="Sync Manager",
        dst=snow_dst,
        incident=number,
        status_code=201,
        timestamp=ts_out,
        description=_build_short_description(payload),
    )
    logger.info("Created SNOW incident %s for hash=%s", number, payload.hash)
    return {"result": "created", "incident": number, "sys_id": sys_id}


def _handle_resolve(
    snow: Any,
    payload: AlertEvent,
    snow_dst: str = "",
    ts_out: Optional[datetime] = None,
) -> Dict[str, Any]:
    """Resolve an open SNOW incident matching the LVI correlation hash."""
    existing = _find_open_incident(snow, payload.hash)

    if not existing:
        any_inc = _find_any_incident(snow, payload.hash)
        if any_inc:
            number = any_inc.get("number", any_inc["sys_id"])
            logger.info(
                "Resolve webhook received but incident %s is already resolved/closed (hash=%s)",
                number,
                payload.hash,
            )
            _log_event(
                direction="sync mgr→snow",
                action="resolve",
                node=payload.node,
                correlation_hash=payload.hash,
                severity=_urgency_label(payload.severity),
                result="already_resolved",
                src="Sync Manager",
                dst=snow_dst,
                incident=number,
                status_code=200,
                timestamp=ts_out,
                description=_build_short_description(payload),
            )
            return {"result": "already_resolved", "incident": number, "sys_id": any_inc["sys_id"]}

        logger.warning("Resolve webhook received but no SNOW incident found for hash=%s", payload.hash)
        _log_event(
            direction="sync mgr→snow",
            action="resolve",
            node=payload.node,
            correlation_hash=payload.hash,
            severity=_urgency_label(payload.severity),
            result="not_found",
            src="Sync Manager",
            dst=snow_dst,
            status_code=404,
            timestamp=ts_out,
            description=_build_short_description(payload),
        )
        return {"result": "not_found", "hash": payload.hash}

    sys_id = existing["sys_id"]
    number = existing.get("number", sys_id)
    close_code = _get_close_code(snow)
    resolve_data: Dict[str, Any] = {
        "state": str(_STATE_RESOLVED),
        "close_code": close_code,
        "close_notes": (
            f"Alert cleared by LogicVein.\n"
            f"Violation Status: {payload.violation_status}\n"
            f"Updated At: {payload.updated_at}"
        ),
        "work_notes": (
            f"Violation cleared by LogicVein monitoring.\n"
            f"Node: {payload.node}\n"
            f"Updated At: {payload.updated_at}"
        ),
    }

    # Allow instance-specific extra fields to satisfy Business Rules (e.g. a
    # "Known Error article required" rule). Set lvi_alerts.extra_fields in
    # conf/snow_sync_config.yaml to a JSON object string, e.g. '{"known_error":"false"}'.
    extra_fields_raw = (get_snow_settings().get("lvi_alerts", {}).get("extra_fields") or "").strip()
    if extra_fields_raw:
        try:
            extra = json.loads(extra_fields_raw)
            if isinstance(extra, dict):
                resolve_data.update(extra)
                logger.debug("Applied lvi_alerts.extra_fields to resolve payload: %s", list(extra.keys()))
            else:
                logger.warning("lvi_alerts.extra_fields is not a JSON object - ignored")
        except Exception as exc:
            logger.warning("Could not parse lvi_alerts.extra_fields: %s", exc)

    snow.update_record("incident", sys_id, resolve_data)
    store.clear_update_tracking(payload.hash)
    _log_event(
        direction="sync mgr→snow",
        action="resolve",
        node=payload.node,
        correlation_hash=payload.hash,
        severity=_urgency_label(payload.severity),
        result="resolved",
        src="Sync Manager",
        dst=snow_dst,
        incident=number,
        status_code=200,
        timestamp=ts_out,
        description=_build_short_description(payload),
    )
    logger.info("Resolved SNOW incident %s for hash=%s", number, payload.hash)
    return {"result": "resolved", "incident": number, "sys_id": sys_id}
