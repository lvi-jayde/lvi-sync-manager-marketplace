"""Correlation registry bridging the change-runner and the Event Bus watcher.

The change-runner (FastAPI background task) submits a Command Runner job and
wants to know when it finishes. The Event Bus watcher - running in its own
thread - receives a ``client.scheduler.trigger`` event with ``type: complete``
whose ``event.id`` is the LVI job id. This registry lets the change-runner
register a waiter keyed by that job id and block on a ``threading.Event`` until
the watcher resolves it.

It is a best-effort, low-latency signal only: the change-runner always keeps a
``getExecutionDetails`` poll as a safety net, so a missed event (watcher not
running, WebSocket drop, or the event arriving before the waiter is registered
for a very fast job) never loses a completion - it just falls back to polling.
"""

import threading
from typing import Dict, Optional


class JobWaiter:
    """A one-shot completion signal for a single job id."""

    __slots__ = ("event", "result")

    def __init__(self) -> None:
        """Initialize the unset completion event and empty result."""
        self.event = threading.Event()
        self.result: Optional[Dict[str, str]] = None


_waiters: Dict[str, JobWaiter] = {}
_lock = threading.Lock()


def register(job_id: str) -> JobWaiter:
    """Register and return a fresh waiter for *job_id* (replacing any prior one)."""
    waiter = JobWaiter()
    with _lock:
        _waiters[job_id] = waiter
    return waiter


def resolve(job_id: str, result: Optional[Dict[str, str]] = None) -> bool:
    """Signal completion for *job_id*. Returns True if something was waiting."""
    with _lock:
        waiter = _waiters.pop(job_id, None)
    if waiter is None:
        return False
    waiter.result = result or {}
    waiter.event.set()
    return True


def unregister(job_id: str) -> None:
    """Drop any waiter for *job_id* (idempotent; call when done waiting)."""
    with _lock:
        _waiters.pop(job_id, None)
