"""ServiceNow job-completion bridge for LogicVein Event Bus events.

Registered with the core event-bus dispatch, this handler watches for
``client.scheduler.trigger`` ``complete`` events and resolves any change-runner
job waiting on that job id (see :mod:`..event_bus.job_waiters`). It is the only
ServiceNow-specific event-bus consumer; config-change detection itself is handled
by the core :class:`WebsocketChangeDetector`.
"""

import logging
from typing import Any, Dict, Optional

# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import event_bus_client  # pyright: ignore[reportMissingImports]

from . import job_waiters

TOPIC_SCHEDULER_TRIGGER = event_bus_client.TOPIC_SCHEDULER_TRIGGER

logger = logging.getLogger(__name__)


class SnowJobCompletionHandler:
    """Resolve change-runner job waiters on scheduler-completion events."""

    def __call__(self, envelope: Dict[str, Any]) -> None:
        """Consume a raw event-bus envelope (only scheduler.trigger is relevant)."""
        topic = envelope.get("topic", "")
        event = envelope.get("event", {})
        if topic != TOPIC_SCHEDULER_TRIGGER or event.get("type", "") != "complete":
            return

        # event.id is the LVI job id (matches run_command_runner_job's returned id);
        # resolve() is a no-op when nothing is waiting (e.g. a config-change backup).
        job_id = str(event.get("id", ""))
        if job_id:
            job_waiters.resolve(
                job_id,
                {
                    "status": str(event.get("status", "")),
                    "completionState": str(event.get("completionState", "")),
                },
            )


_handler: Optional[SnowJobCompletionHandler] = None


def get_handler() -> SnowJobCompletionHandler:
    """Return the module-level singleton handler (created on first use)."""
    global _handler
    if _handler is None:
        _handler = SnowJobCompletionHandler()
    return _handler
