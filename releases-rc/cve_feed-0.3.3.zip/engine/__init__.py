"""The CVE matching engine, carried over from lvi_cve_feed.

Source: lvi_cve_feed (git@gitlab.home.arpa:jhanley/lvi_cve_feed.git), version
0.52.0, commit d61f262, `src/lvi_cve_feed/`. lvi_cve_feed is frozen as of this copy: engine
fixes are made here from now on.

Changes from the source, kept to what running inside Sync Manager needs:

- Imports rewritten from `lvi_cve_feed.*` to relative imports.
- Not carried over: `__main__.py` (the CLI) and `config.py` (`.env` and
  `conf/settings.yaml`); the plugin's `plugin.py`, `sync.py` and
  `conf/defaults.yaml` replace them.
- `device_inventory.build_client()` removed: the host passes in its own
  LogicVein client.
- `cvefeed_client.CVEFeedClient` waits between retries through its
  `_sleep()` method (`time.sleep`), which the plugin's client overrides to make
  the wait interruptible by Cancel.
- `cvefeed_client.CVEFeedClient._request()` follows the plugin repo's HTTP
  client conventions: failures are logged (warning, standard wording) and
  the response body in the log and in the raised error is bounded to 500
  characters.
- `report.build_device_report()` takes `held`: match kinds to hold for review
  with a reason (a match a reviewer rejected), applied through the existing
  `hold_reason` mechanism, now for hardware too.
- `device_inventory.list_devices()` takes `networks`, the LogicVein networks
  configured in the plugin (empty reads every network, as before).
- `device_inventory.Device` keeps LogicVein's `uuid`, which the plugin keys
  review decisions on.

The design history behind the matching and filtering rules is lvi_cve_feed's
`docs/ARCHITECTURE.md`; most rules exist because of a specific wrong result on
real data, so find a rule's section there before changing it.
"""
