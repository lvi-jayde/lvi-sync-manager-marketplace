"""Reads device inventory from a LogicVein server via lvi-api-client.

Verified against a real LogicVein server (2026-09-11) - see
docs/ARCHITECTURE.md's "Device inventory shape" section for what the raw
fields actually look like and why there's no CPE string to work with.
"""

import re
from collections import Counter
from collections.abc import Collection
from dataclasses import dataclass, field, replace
from datetime import date, datetime, timezone
from typing import Any

from logicvein import LogicVeinAPIClient

from .cpe_field import CUSTOM_FIELDS
from .vendors.arista import AristaDevice
from .vendors.cisco_tables import CiscoTableDevice
from .vendors.extreme import ExtremeDevice
from .vendors.f5 import F5Device
from .vendors.fortinet import FortiDevice
from .vendors.fortinet import parse_version as parse_forti_version
from .vendors.hpe import HPEDevice
from .vendors.hpe import parse_version as parse_hpe_version
from .vendors.juniper import JuniperDevice, parse_release
from .vendors.paloalto import PaloAltoDevice

# LogicVein adapter -> (vendor, product, vendor_type) as cvefeed.io's
# catalog names that adapter's OS. LogicVein's own `osType` often isn't the
# catalog's spelling ("NXOS" vs "Nx os", "PA" vs "Pan os"), and cvefeed.io's
# search needs the separators to find it at all - verified live
# (2026-10-01) that "Cisco nxos" returns zero results while "Cisco nx-os"
# finds "Nx os". Each entry was checked against the live catalog; extend
# only with entries verified the same way. The vendor override matters too:
# a Linux host's `softwareVendor` is its hardware vendor (VMware, Amazon
# EC2, QEMU), which can never score well against the kernel's catalog
# vendor ("Linux") under matcher.py's multiplicative vendor*product score.
_SOFTWARE_CATALOG_NAMES: dict[str, tuple[str, str, str]] = {
    "Cisco::IOS": ("Cisco", "IOS", "o"),
    # LogicVein reports osType "PIX", but an ASA runs ASA software (PIX OS
    # ended at 8.0; the lab ASA 5505 is on 8.2(5)).
    "Cisco::SecurityAppliance": ("Cisco", "adaptive security appliance software", "o"),
    "Cisco::Nexus": ("Cisco", "nx-os", "o"),
    "Paloalto::PA500": ("Palo Alto Networks", "pan-os", "o"),
    "Extreme::XOS": ("Extreme Networks", "extremexos", "o"),
    "Extreme::VSP": ("Extreme Networks", "voss", "o"),
    # BIG-IP is catalogued per module, as applications; LTM is the core
    # module every BIG-IP runs. The bare "big-ip" OS-type search instead
    # returns per-appliance hardware firmware ("Big ip 10350v f firmware").
    "F5::BigIP": ("F5", "big-ip local traffic manager", "a"),
    "Linux::RedHat": ("Linux", "linux kernel", "o"),
    # From LogicVein's full adapter list (2026-10-02), verified the same way
    # - each resolves via match_product() to exactly this catalog entry.
    # Where cvefeed.io splits one product across entries (a rename or vendor
    # change), the entry holding the clear majority of its CVEs is used, and
    # adapters with an even split are left out rather than guessed - see
    # docs/ARCHITECTURE.md.
    "A10::AX1000": ("A10 Networks", "advanced core operating system", "o"),
    # Plus the HP- and HPE-era entries - see _EXTRA_SOFTWARE.
    "Aruba::ArubaOS": ("Arubanetworks", "arubaos", "o"),
    "Adtran::NetVanta": ("Adtran", "aos", "o"),
    "Alcatel::Omniswitch": ("Alcatel-Lucent", "omniswitch firmware", "o"),
    "Aruba::ArubaCX": ("HPE", "arubaos-cx", "o"),
    "Aruba::ArubaEdgeConnect": ("HPE", "edgeconnect operating system", "o"),
    "Brocade::FabricOS": ("Brocade", "fabric os", "o"),
    "Cisco::ACNS": ("Cisco", "application and content networking system software", "a"),
    "Cisco::Airespace": ("Cisco", "wireless lan controller software", "o"),
    "Cisco::CatOS": ("Cisco", "catos", "o"),
    "Cisco::CMX": ("Cisco", "connected mobile experiences", "a"),
    "Cisco::IE": ("Cisco", "IOS", "o"),
    "Cisco::ISE": ("Cisco", "identity services engine", "a"),
    "Cisco::SCE": ("Cisco", "service control engine", "a"),
    "Cisco::SCELite": ("Cisco", "service control engine", "a"),
    "Cisco::Three005": ("Cisco", "vpn 3000 concentrator series software", "o"),
    "Cisco::WAAS": ("Cisco", "wide area application services", "a"),
    "Cisco::WLSE": ("Cisco", "wireless lan solution engine", "o"),
    "Foundry::EdgeIron": ("Foundrynet", "edgeiron", "a"),
    "Foundry::FastIron": ("Brocade", "fastiron", "h"),
    "Furukawa::FX": ("Furukawa Electric", "fitelnet", "h"),
    "Juniper::DX": ("Juniper", "dx", "h"),
    "Kemp::LoadMaster": ("Progress", "loadmaster", "o"),
    "Lenovo::ENOS": ("Lenovo", "enterprise network operating system", "o"),
    "Linux::Cumulus": ("NVIDIA", "cumulus linux", "o"),
    "MikroTik::RouterOS": ("MikroTik", "routeros", "o"),
    "Nortel::Contivity": ("Nortel", "contivity", "h"),
    "SonicWALL::SonicOS": ("SonicWall", "sonicos", "o"),
    # Viptela is Cisco SD-WAN now; its catalog entries are under Cisco, where
    # no name search from "Viptela" can find them. Verified live
    # (2026-10-06): "sd-wan firmware" holds 41 CVEs, the per-model "vedge
    # cloud firmware" another 8, with no overlap.
    "Viptela::ViptelaOS": ("Cisco", "sd-wan firmware", "o"),
    "WatchGuard::Fireware": ("WatchGuard", "fireware", "o"),
    "ZPE::Nodegrid": ("ZPE Systems", "nodegrid os", "o"),
}

# Adapters with no entry in _SOFTWARE_CATALOG_NAMES whose name search (from
# LogicVein's own osType, or the adapter name plus the model) was checked by
# hand against the live catalog and found the right product, so a match from
# them is not reported as unverified. Juniper::JUNOS, Fortinet::FortiGate and
# Arista::EOS resolve at 1.00 to "Junos", "Fortios" and "Eos"; Cisco::Meraki
# needs the hardware model appended and was verified for MX65, MR34 and Z3
# (see software_product_hint). Add an adapter only after the same check.
_VERIFIED_NAME_SEARCH = ("Juniper::JUNOS", "Fortinet::FortiGate", "Arista::EOS", "Cisco::Meraki")

# Adapters whose `adapter_id` suffix is a discovery method, not a platform.
_GENERIC_ADAPTER_PREFIX = "Generic::"

# Classic IOS ended at 15.x; 16.x and 17.x are IOS XE, which LogicVein's
# Cisco::IOS adapter still reports as osType "IOS". Industrial Ethernet
# switches (Cisco::IE) span both too (IE 2000/4000 on IOS 15, IE 3x00 on XE).
_IOS_XE_FIRST_MAJOR = 16
_IOS_ADAPTERS = ("Cisco::IOS", "Cisco::IE")

# More catalog products an adapter's software match also covers: one product
# split across entries by a vendor change, where any single pick drops CVEs.
# Verified live (2026-10-06): ArubaOS is "Arubanetworks Arubaos" (247 CVEs),
# "Hp Arubaos" (10) and "Hpe Arubaos" (3); each query resolves at 1.00.
_EXTRA_SOFTWARE: dict[str, tuple[tuple[str, str, str], ...]] = {
    "Aruba::ArubaOS": (("HP", "arubaos", "o"), ("HPE", "arubaos", "o")),
}

# HP::ProCurve covers two catalog products, told apart by the firmware's
# major version: classic ProCurve software ("H.10.113") and, from 16.x,
# ArubaOS-Switch ("WC.16.11.0020") on Aruba-branded switches. Searching
# "HP ProCurve" instead tied "Procurve switch software" with "Procurve
# access point software" (verified on both labs, 2026-10-06).
_PROCURVE_ADAPTER = "HP::ProCurve"
_ARUBAOS_SWITCH_FIRST_MAJOR = 16
_PROCURVE_VERSION = re.compile(r"^[A-Za-z]+\.(\d+)\.")
_PROCURVE_SOFTWARE = ("HP", "procurve switch software", "o")
_ARUBAOS_SWITCH_SOFTWARE = ("HPE", "arubaos-switch", "o")
# Cisco ISR G2 (1900/2900/3900) part numbers, catalogued as
# "<n> integrated services router": "CISCO2911/K9" alone shares only "2911"
# with it, too little to pass the threshold (verified on the AWS lab).
_CISCO_ISR_G2 = re.compile(r"^CISCO((?:19|29|39)\d\d)(?:/K9)?$", re.IGNORECASE)
# Cisco Catalyst 9000 part numbers written "CISCO9200-48P": the bare number
# alone ranks "Mds 9200" (a Fibre Channel line) above "Catalyst 9200" on name
# length, and "9500 r" above "Catalyst 9500" (verified on the CustDemo lab,
# 2026-10-08). The plain "C9200-24T" spelling already finds its own catalog
# entry, so it is left alone.
_CISCO_CATALYST_9K = re.compile(r"^CISCO(9[2-6]00)[A-Z]{0,2}(?:-[A-Z0-9-]+)?$", re.IGNORECASE)
# Vendors with no CVE source for the gear seen so far, by lower-case vendor
# name. Huawei (checked 2026-10-08, CustDemo lab: S5735 switches on VRP
# V200R022): cvefeed.io's catalog has no S5735 or VRP product, and of
# Huawei's 2,340 CVE records only 41 name a switch (S1700 to S12700, all
# 2014-2021), none the S5735 or a V200R02x release. A match found anyway is a
# look-alike (an "E355" modem), so the report says why instead of "needs review".
_NO_CVE_SOURCE = {
    "huawei": "no catalog product and no Huawei advisory names this model",
}
# openVuln OS types for the other Cisco adapters (IOS / IE follow the IOS
# XE version rule instead).
_CISCO_OS_TYPES = {"Cisco::Nexus": "nxos", "Cisco::SecurityAppliance": "asa"}
# openVuln answers NX-OS and ASA questions per platform family, named by an
# alias from its /platforms list (verified live 2026-10-06): model prefix ->
# alias, first match wins.
_CISCO_PLATFORM_ALIASES = (
    (re.compile(r"^N9K-", re.IGNORECASE), "NEXUS9000"),
    (re.compile(r"^N7K-|^N77-", re.IGNORECASE), "NEXUS7000"),
    (re.compile(r"^N6K-", re.IGNORECASE), "NEXUS6000"),
    (re.compile(r"^N5K-", re.IGNORECASE), "NEXUS5000"),
    (re.compile(r"^N3K-", re.IGNORECASE), "NEXUS3000"),
    (re.compile(r"^DS-C9", re.IGNORECASE), "MDS9000"),
    (re.compile(r"^ASAv", re.IGNORECASE), "ASAV"),
    (re.compile(r"^ASA55\d\d-X", re.IGNORECASE), "ASA5500X"),
    (re.compile(r"^FPR-?1\d", re.IGNORECASE), "FPR1000"),
    (re.compile(r"^FPR-?21", re.IGNORECASE), "FPR2100"),
    (re.compile(r"^FPR-?41", re.IGNORECASE), "FPR4100"),
    (re.compile(r"^FPR-?9", re.IGNORECASE), "FPR9000"),
    (re.compile(r"^ISA-?3000", re.IGNORECASE), "ISA3000"),
)
_CBS_MODEL = re.compile(r"^CBS\d", re.IGNORECASE)
# Model names of virtual appliances - no physical hardware for hardware CVEs
# to apply to. Deliberately specific: some cloud editions *are* catalogued
# as hardware with real CVEs ("vedge cloud router", "9800 cl"), so "cloud"
# or a trailing "v" alone isn't a marker. Each seen on the AWS lab.
_VIRTUAL_MODEL = re.compile(
    r"(?:^|[-_\s])(?:VM\d*|KVM)(?:$|[-_\s])"  # FortiGate-VM64-KVM, PA-VM, EXOS-VM
    r"|virtual edition"  # BIG-IP Virtual Edition
    r"|^ceos"  # Arista cEOSLab
    r"|^N9K-C9\d{3}v$",  # Nexus 9000v
    re.IGNORECASE,
)


# Arista EOS reports "4.33.6M-44999762.4336M (engineering build)": the
# release is the leading "4.33.6M"; the rest is a build id.
_ARISTA_RELEASE = re.compile(r"^\d+(?:\.\d+)+[A-Za-z]?(?=$|[-\s])")
_SYS_DESCR_VERSION = re.compile(r"\bVersion\s+(\d[\w.()\-]*\w\)?)", re.IGNORECASE)
# Where a sysDescr product phrase ends: a run of 2+ spaces, a comma, or a
# version/hardware/firmware label ("...Switch 2000  HW:14  FW:3.6.0.1").
_SYS_DESCR_PHRASE_END = re.compile(r"\s{2,}|,|\s+(?:HW|FW|SW|Version|revision)\b", re.IGNORECASE)


def _sys_descr_product(sys_descr: str | None, model_number: str) -> str | None:
    """Find the product phrase leading a sysDescr's first line.

    The phrase ends at a run of 2+ spaces, a comma, or a version / hardware /
    firmware label. It's only returned if it contains `model_number` as a
    whole word, since sysDescr is free text.

    Args:
        sys_descr: The device's SNMP sysDescr, or None.
        model_number: The bare-number model LogicVein reports, e.g. "2000".

    Returns:
        The phrase (e.g. "Business Policy Switch 2000"), or None.
    """
    first_line = (sys_descr or "").strip().splitlines()[0] if (sys_descr or "").strip() else ""
    phrase = _SYS_DESCR_PHRASE_END.split(first_line, maxsplit=1)[0].strip()
    if phrase and re.search(rf"\b{re.escape(model_number)}\b", phrase):
        return phrase
    return None


_EOX_FIELDS = (
    ("end_of_sale", "hardware end of sale"),
    ("end_of_life", "hardware end of life"),
    ("software_end_of_sale", "software end of sale"),
    ("software_end_of_life", "software end of life"),
)


def _to_date(epoch_ms: int) -> date:
    """Convert LogicVein's epoch milliseconds to a UTC date.

    Args:
        epoch_ms: Milliseconds since the epoch.

    Returns:
        The UTC date.
    """
    return datetime.fromtimestamp(epoch_ms / 1000, tz=timezone.utc).date()


def _iso_date(epoch_ms: int) -> str:
    """Convert LogicVein's epoch milliseconds to an ISO date string.

    Args:
        epoch_ms: Milliseconds since the epoch.

    Returns:
        The UTC date as "YYYY-MM-DD".
    """
    return _to_date(epoch_ms).isoformat()


@dataclass(frozen=True)
class Device:
    ip_address: str
    hostname: str | None
    network: str
    serial_number: str | None
    device_type: str | None
    adapter_id: str | None
    hardware_vendor: str | None
    hardware_model: str | None
    software_vendor: str | None
    os_type: str | None
    os_version: str | None
    # From get_device_hardware(), not search_devices_in_network() - see
    # list_devices()'s docstring. None until enriched.
    hardware_make: str | None = None
    hardware_model_number: str | None = None
    # LogicVein's custom1-custom5, non-empty ones only - see cpe_field.py.
    custom_fields: dict[str, str] = field(default_factory=dict, hash=False, compare=True)
    # The device's SNMP sysDescr - free text, so only used where a field
    # LogicVein parsed falls short (see hardware_match_model, match_os_version).
    sys_descr: str | None = None
    # End-of-sale / end-of-life dates LogicVein holds - from its Cisco EoX
    # integration or a Cisco CSV import (Settings -> Cisco API) - as epoch
    # milliseconds, None where unknown. Verified 2026-10-07: the local lab's
    # Catalyst 2950s have all four, its 2500s the software pair.
    end_of_sale: int | None = None
    end_of_life: int | None = None
    software_end_of_sale: int | None = None
    software_end_of_life: int | None = None
    # LogicVein's own identifier for the device: unlike its network and IP, it
    # survives a readdressing. None where LogicVein gives none.
    uuid: str | None = None

    def eox_dates(self) -> dict[str, str]:
        """Give the known EoX dates as ISO dates, keyed by field name.

        Returns:
            Field name ("end_of_sale", "end_of_life", "software_end_of_sale",
            "software_end_of_life") -> "YYYY-MM-DD", for the dates LogicVein has.
        """
        dates = {name: getattr(self, name) for name, _ in _EOX_FIELDS}
        return {name: _iso_date(ms) for name, ms in dates.items() if ms}

    def end_of_support(self, today: date | None = None) -> str | None:
        """Name the end-of-life dates already past.

        Args:
            today: The date to compare against; None means today (UTC).

        Returns:
            "hardware 2013-10-31, software 2012-03-14" - the end-of-life dates
            already past - or None if neither is.
        """
        today = today or datetime.now(timezone.utc).date()
        past = [
            f"{label} {_iso_date(ms)}"
            for label, ms in (("hardware", self.end_of_life), ("software", self.software_end_of_life))
            if ms and _to_date(ms) <= today
        ]
        return ", ".join(past) or None

    @property
    def hardware_match_vendor(self) -> str | None:
        """The vendor text for the hardware search.

        The catalog's own vendor when `_hardware_catalog()` knows this hardware,
        else the hardware asset's make, else LogicVein's hardwareVendor.
        """
        catalog = self._hardware_catalog()
        return catalog[0] if catalog else self.hardware_make or self.hardware_vendor

    @property
    def hardware_match_model(self) -> str | None:
        """The product text for the hardware search.

        The catalog's own name when `_hardware_catalog()` knows this hardware,
        else the reported model (see `_reported_model()`).
        """
        catalog = self._hardware_catalog()
        return catalog[1] if catalog else self._reported_model()

    @property
    def no_cve_source_note(self) -> str | None:
        """Why this vendor's devices can't get CVEs from any source, or None.

        Only worth showing when no match applied: a Huawei device whose
        hardware does exist in the catalog still matches normally.

        Returns:
            The note (see `_NO_CVE_SOURCE`), or None for other vendors.
        """
        names = (self.hardware_make, self.hardware_vendor, self.software_vendor)
        for vendor, note in _NO_CVE_SOURCE.items():
            if any(vendor in (name or "").lower() for name in names):
                return note
        return None

    @property
    def hardware_skip_reason(self) -> str | None:
        """Why there's no hardware to match at all, or None.

        Verified on the AWS lab (2026-10-06): a FortiGate-VM64-KVM auto-applied
        the physical "Fortigate" appliance's hardware CVEs. A virtual appliance
        (`_VIRTUAL_MODEL`) has no physical hardware for those to apply to.
        """
        if _VIRTUAL_MODEL.search(self._reported_model() or ""):
            return "virtual appliance - no physical hardware"
        return None

    def _hardware_catalog(self) -> tuple[str, str] | None:
        """Name this hardware as cvefeed.io's catalog does, where LogicVein's text can't.

        Each case below was verified live (2026-10-06) to resolve to exactly that
        catalog entry:

        - Viptela "vedge-cloud" -> Cisco "vedge cloud router" (a vendor rename
          name search can't follow).
        - An ArubaOS-Switch (16.x) HP::ProCurve switch, "2930F-48G-4SFP" ->
          Arubanetworks "Aruba 2930F": the catalog has it under Aruba, and "HP"
          found only printers.
        - Cisco ISR G2 "CISCO2911/K9" -> "2911 integrated services router".
        - Cisco Catalyst 9000 "CISCO9200-48P" -> "Catalyst 9200" (verified
          2026-10-08 for 9200, 9300, 9400, 9500 and 9600).

        Returns:
            (vendor, product) as the catalog names this hardware, or None to use
            LogicVein's own text.
        """
        model = (self._reported_model() or "").strip()
        if not model:
            return None
        if self.adapter_id == "Viptela::ViptelaOS" and model.lower().startswith("vedge-"):
            return "Cisco", f"{model.replace('-', ' ')} router"
        if self.adapter_id == _PROCURVE_ADAPTER and (self._procurve_major() or 0) >= _ARUBAOS_SWITCH_FIRST_MAJOR:
            return "Arubanetworks", f"Aruba {model.split('-', 1)[0]}"
        isr = _CISCO_ISR_G2.match(model)
        if self.adapter_id in _IOS_ADAPTERS and isr:
            return "Cisco", f"{isr.group(1)} integrated services router"
        catalyst = _CISCO_CATALYST_9K.match(model)
        if self.adapter_id in _IOS_ADAPTERS and catalyst:
            return "Cisco", f"Catalyst {catalyst.group(1)}"
        return None

    def _reported_model(self) -> str | None:
        """Pick the best available hardware model text for matching.

        `hardware_model_number` (from get_device_hardware()'s CHASSIS asset, e.g.
        "2626-PWR") is closer to cvefeed.io's catalog spelling than
        `hardware_model` (from search_devices_in_network(), e.g. an SNMP
        sysObjectID-derived name like "hpSwitchJ8164A") when it's available -
        verified against a real HP switch where the difference was the entire
        match (see docs/ARCHITECTURE.md).

        A model that's only a number says too little to match on - verified live
        (2026-10-02): a Nortel Business Policy Switch's modelNumber is just
        "2000", which found only "Nortel Succession communication server 2000", a
        telephony server. When the model is a bare number and the first line of
        `sysDescr` names a product containing that same number ("Business Policy
        Switch 2000"), that phrase is used instead. The shared number is what
        makes it safe: sysDescr is free text, and only a phrase that agrees with
        LogicVein's own model is trusted.

        Returns:
            The model text, or None if LogicVein has none.
        """
        model = self.hardware_model_number or self.hardware_model
        if model and model.strip().isdigit():
            return _sys_descr_product(self.sys_descr, model.strip()) or model
        return model

    @property
    def software_product_hint(self) -> str | None:
        """Best guess at a product/platform name for the software match.

        `os_version` (e.g. "12.3(13a)") is a version, not a product name, so it's
        not useful here. `os_type` (e.g. "IOS") is the right field when present;
        when it's null (common on cloud-managed adapters), fall back to the part
        of `adapter_id` after "::" (e.g. "Cisco::Meraki" -> "Meraki") as a rough
        platform name.

        A bare platform name alone is too generic for a cloud-managed adapter,
        though: cvefeed.io's catalog publishes that firmware one entry per
        hardware model ("Meraki mx64 firmware", "Meraki mr34 firmware", ...), all
        of which tie at the same score against a query that only says "Meraki" -
        and, worse, a search that broad doesn't even reliably surface the right
        entry within the first few result pages the search fallback bothers to
        scan (verified live 2026-09-16: an MX65 gateway's software search for bare
        "Meraki" matched "mx64 firmware" - wrong model entirely - while "mx65
        firmware" existed in the catalog but didn't turn up until page 5).
        Appending the hardware model number - already resolved for the hardware
        match, see `hardware_match_model` - to the platform name finds the
        model-specific firmware entry directly: verified live that "Meraki MX65",
        "Meraki MR34", and "Meraki Z3" queries each found exactly their one
        matching catalog entry.

        Software with a known catalog name (`_software_catalog()`) skips all of
        the above and uses that name directly. None when there's nothing to go on
        (a Generic:: adapter's suffix is a discovery method, not a platform).
        """
        catalog = self._software_catalog()
        if catalog:
            return catalog[1]
        if self.os_type:
            return self.os_type
        if self.adapter_id and "::" in self.adapter_id and not self.adapter_id.startswith(_GENERIC_ADAPTER_PREFIX):
            platform = self.adapter_id.split("::", 1)[1]
            if self.hardware_match_model:
                return f"{platform} {self.hardware_match_model}"
            return platform
        return None

    @property
    def software_hold_reason(self) -> str | None:
        """Why a name-search software match must be held for review even at a high score, or None.

        A Cisco::IOS / Cisco::IE device with no version at all can't be told
        apart from IOS XE (see `_is_ios_xe()`), and defaults to the "IOS" catalog
        entry. Verified on the AWS lab (2026-10-06): an ISR 4431 - IOS XE only -
        with no version, model, or sysDescr in LogicVein auto-applied classic IOS
        and got 659 unfiltered CVEs. Likewise an HP::ProCurve device with no
        version can't be told apart from ArubaOS-Switch.
        """
        if self.adapter_id in _IOS_ADAPTERS and not self.match_os_version:
            return "no software version - IOS and IOS XE can't be told apart"
        if self.adapter_id == _PROCURVE_ADAPTER and self._procurve_major() is None:
            return "no software version - ProCurve and ArubaOS-Switch can't be told apart"
        return None

    @property
    def software_extra_queries(self) -> tuple[tuple[str, str, str], ...]:
        """(vendor, product, vendor_type) searches for more catalog products the software match covers.

        See report._build_match. From `_EXTRA_SOFTWARE` per adapter (e.g.
        ArubaOS's HP and HPE entries). Viptela also gets its per-model firmware
        entry: verified live (2026-10-06) that "vedge cloud firmware" holds 8
        CVEs that "sd-wan firmware" (41) doesn't.
        """
        extras = _EXTRA_SOFTWARE.get(self.adapter_id or "", ())
        model = (self._reported_model() or "").strip()
        if self.adapter_id == "Viptela::ViptelaOS" and model.lower().startswith("vedge-"):
            extras += (("Cisco", f"{model.replace('-', ' ')} firmware", "o"),)
        return extras

    @property
    def software_match_vendor(self) -> str | None:
        """The vendor text for the software search.

        The catalog's own vendor when `_software_catalog()` knows this software,
        else LogicVein's softwareVendor.
        """
        catalog = self._software_catalog()
        return catalog[0] if catalog else self.software_vendor

    @property
    def software_match_verified(self) -> bool:
        """Whether this device's software search rests on something checked by hand.

        True when `_software_catalog()` names it (the adapter table, or a
        per-device rule such as IOS XE or ProCurve), or its adapter is in
        `_VERIFIED_NAME_SEARCH`. False means the search is built from
        LogicVein's own text (`osType`, the adapter name, the model) for an
        adapter nobody has checked, and rests on the match score alone.
        """
        return self._software_catalog() is not None or self.adapter_id in _VERIFIED_NAME_SEARCH

    @property
    def software_vendor_type(self) -> str:
        """cvefeed.io vendor_type for the software search.

        'o' (operating system) unless the adapter's catalog entry says otherwise.
        """
        catalog = self._software_catalog()
        return catalog[2] if catalog else "o"

    def _software_catalog(self) -> tuple[str, str, str] | None:
        """Name this device's software as cvefeed.io's catalog does, when known.

        From `_SOFTWARE_CATALOG_NAMES`, with IOS XE, ProCurve/ArubaOS-Switch, and
        Cisco Business (CBS) firmware decided per device.

        Returns:
            (vendor, product, vendor_type), or None to use LogicVein's own text.
        """
        if self.adapter_id == _PROCURVE_ADAPTER:
            major = self._procurve_major()
            return _ARUBAOS_SWITCH_SOFTWARE if (major or 0) >= _ARUBAOS_SWITCH_FIRST_MAJOR else _PROCURVE_SOFTWARE
        if self.adapter_id == "Cisco::SmallBusiness":
            # Catalogued per model: "CBS350-48T-4G" -> "Business 350 48t 4g
            # firmware" (verified live 2026-10-06; the adapter's own name
            # scored it 0.69).
            model = (self.hardware_match_model or "").strip()
            return ("Cisco", f"Business {model[3:]} firmware", "o") if _CBS_MODEL.match(model) else None
        if self.adapter_id in _SOFTWARE_CATALOG_NAMES:
            if self.adapter_id in _IOS_ADAPTERS and self._is_ios_xe():
                return ("Cisco", "IOS XE", "o")
            return _SOFTWARE_CATALOG_NAMES[self.adapter_id]
        return None

    @property
    def cisco_os_type(self) -> str | None:
        """The Cisco PSIRT openVuln OS type for this device's software.

        "ios", "iosxe", "nxos" or "asa" - or None if it isn't one, or has no
        version to ask about.
        """
        if not self.match_os_version:
            return None
        if self.adapter_id in _IOS_ADAPTERS:
            return "iosxe" if self._is_ios_xe() else "ios"
        return _CISCO_OS_TYPES.get(self.adapter_id or "")

    @property
    def juniper_device(self) -> JuniperDevice | None:
        """What Juniper's CVE records are checked against.

        Set for a Junos device whose release parses ("25.4R1.12"), else None.
        """
        if self.adapter_id != "Juniper::JUNOS" or not self.match_os_version:
            return None
        release = parse_release(self.match_os_version)
        if release is None:
            return None
        model = (self.hardware_model_number or self.hardware_model or "").strip()
        return JuniperDevice(release, f"Junos OS {self.match_os_version}", model)

    @property
    def fortinet_device(self) -> FortiDevice | None:
        """What Fortinet's CVE records are checked against.

        A FortiOS device (`Fortinet::FortiGate`) whose release parses
        ("7.6.7"), else None.
        """
        if self.adapter_id != "Fortinet::FortiGate":
            return None
        version = self.match_os_version or ""
        parsed = parse_forti_version(version)
        return None if parsed is None else FortiDevice(parsed, f"FortiOS {version}")

    @property
    def extreme_device(self) -> ExtremeDevice | None:
        """What Extreme's CVE records are checked against.

        An ExtremeXOS switch (`Extreme::XOS`) or a VOSS one (`Extreme::VSP`)
        whose release parses ("33.6.1.14", "9.4.0.0"), else None.
        """
        kind = {"Extreme::XOS": "xos", "Extreme::VSP": "voss"}.get(self.adapter_id or "")
        return None if kind is None else ExtremeDevice.from_release(kind, self.match_os_version or "")

    @property
    def cisco_table_device(self) -> CiscoTableDevice | None:
        """What Cisco's first-fixed-release tables are checked against.

        A Catalyst SD-WAN / vEdge device (`Viptela::ViptelaOS`) whose release
        parses ("20.4.1"), or a Meraki MX / Z / MR (`Cisco::Meraki`) whose
        firmware parses ("wired-18-1-07", "wireless-26-8-3") - else None.
        """
        if self.adapter_id == "Viptela::ViptelaOS":
            return CiscoTableDevice.sdwan(self.match_os_version or "")
        if self.adapter_id == "Cisco::Meraki":
            return CiscoTableDevice.meraki(self._reported_model() or "", self.match_os_version or "")
        return None

    @property
    def f5_device(self) -> F5Device | None:
        """What F5's CVE records are checked against.

        A BIG-IP (`F5::BigIP`) whose release parses ("21.1.0.1"), else None.
        """
        if self.adapter_id != "F5::BigIP":
            return None
        return F5Device.from_release(self.match_os_version or "")

    @property
    def arista_device(self) -> AristaDevice | None:
        """What Arista's CVE records are checked against.

        An EOS switch (`Arista::EOS`) whose release parses ("4.33.6M": the
        release without the build id), with its hardware model ("cEOSLab",
        "DCS-7280SR-48C6") for the records' platform lists - else None.
        """
        if self.adapter_id != "Arista::EOS":
            return None
        return AristaDevice.from_release(self.match_os_version or "", self._reported_model() or "")

    @property
    def paloalto_device(self) -> PaloAltoDevice | None:
        """What Palo Alto's CVE records are checked against.

        A PAN-OS firewall (`Paloalto::PA500`) whose release parses
        ("11.2.10-h13"), else None.
        """
        if self.adapter_id != "Paloalto::PA500":
            return None
        return PaloAltoDevice.from_release(self.match_os_version or "")

    @property
    def hpe_device(self) -> HPEDevice | None:
        """What HPE's CVE records are checked against.

        An ArubaOS device (`Aruba::ArubaOS`), or an `HP::ProCurve` switch on
        ArubaOS-Switch (16.x) firmware, whose release parses - else None.
        """
        version = self.match_os_version or ""
        parsed = parse_hpe_version(version)
        if parsed is None:
            return None
        if self.adapter_id == "Aruba::ArubaOS":
            return HPEDevice("aos", parsed, f"ArubaOS {version}")
        if self.adapter_id == _PROCURVE_ADAPTER and (self._procurve_major() or 0) >= _ARUBAOS_SWITCH_FIRST_MAJOR:
            return HPEDevice("aos-switch", parsed, f"ArubaOS-Switch {version}")
        return None

    @property
    def cisco_platform_alias(self) -> str | None:
        """openVuln's platform alias for this NX-OS / ASA device's model.

        None for other devices, or a model with no known alias - then openVuln
        answers for the release across platforms.
        """
        if self.cisco_os_type not in ("nxos", "asa"):
            return None
        model = (self._reported_model() or "").strip()
        return next((alias for pattern, alias in _CISCO_PLATFORM_ALIASES if pattern.search(model)), None)

    def _procurve_major(self) -> int | None:
        """Read the major version from a ProCurve-style release ("WC.16.11.0020" -> 16).

        Returns:
            The major version, or None if the version doesn't parse.
        """
        match = _PROCURVE_VERSION.match(self.match_os_version or "")
        return int(match.group(1)) if match else None

    @property
    def match_os_version(self) -> str | None:
        """The software version used for version filtering and vendor lookups.

        `os_version`, or when LogicVein has none, the "Version ..." from
        `sysDescr`'s product lines. Verified live (2026-10-02): a Catalyst 6503 on
        the Cisco::IOS adapter had no osVersion, while its sysDescr reads
        "...Software (c6sup2_rp-JK2SV-M), Version 12.1(27b)E4, ...". Only for
        devices on a LogicVein adapter - an unidentified device's sysDescr could
        describe anything. For Arista EOS, just the release ("4.33.6M") without
        the build id.
        """
        if self.adapter_id == "Arista::EOS" and self.os_version:
            release = _ARISTA_RELEASE.match(self.os_version.strip())
            return release.group(0) if release else self.os_version
        if self.os_version or not self.adapter_id:
            return self.os_version
        match = _SYS_DESCR_VERSION.search(self.sys_descr or "")
        return match.group(1) if match else None

    def _is_ios_xe(self) -> bool:
        """Whether this IOS-adapter device runs IOS XE (major version 16 or later).

        Classic IOS ended at 15.x; LogicVein still reports XE as osType "IOS".

        Returns:
            True for a major version of 16 or more.
        """
        major = (self.match_os_version or "").split(".", 1)[0]
        return major.isdigit() and int(major) >= _IOS_XE_FIRST_MAJOR


def _device_from_raw(raw: dict[str, Any]) -> Device:
    """Build a Device from one search_devices_in_network() result.

    Args:
        raw: The device as LogicVein returns it.

    Returns:
        The device, before hardware enrichment (see list_devices()).
    """
    return Device(
        ip_address=raw["ipAddress"],
        hostname=raw.get("hostname"),
        network=raw.get("network") or "Default",
        serial_number=raw.get("serialNumber"),
        device_type=raw.get("deviceType"),
        adapter_id=raw.get("adapterId"),
        hardware_vendor=raw.get("hardwareVendor"),
        hardware_model=raw.get("model"),
        software_vendor=raw.get("softwareVendor"),
        os_type=raw.get("osType"),
        os_version=raw.get("osVersion"),
        sys_descr=raw.get("sysDescr"),
        end_of_sale=raw.get("endOfSale") or None,
        end_of_life=raw.get("endOfLife") or None,
        software_end_of_sale=raw.get("softwareEndOfSale") or None,
        software_end_of_life=raw.get("softwareEndOfLife") or None,
        custom_fields={name: raw[name] for name in CUSTOM_FIELDS if raw.get(name)},
        uuid=raw.get("uuid") or None,
    )


def _hardware_detail(client: LogicVeinAPIClient, device: Device) -> tuple[str | None, str | None]:
    """Get the best available (make, modelNumber) from the device's hardware asset list.

    Prefers the CHASSIS-level asset (the physical unit itself) over child
    assets (memory, power supply, CPU...), which don't represent the device as
    a catalog product. Degrades to (None, None) - never raises - on any lookup
    failure or a device with no usable hardware assets, since one device's
    hardware detail being unavailable shouldn't abort the run; the caller
    falls back to search_devices_in_network()'s plainer fields.

    Args:
        client: The LogicVein API client.
        device: The device.

    Returns:
        (make, modelNumber), or (None, None).
    """
    try:
        assets = client.get_device_hardware(device.ip_address, device.network)
    except Exception:
        return None, None
    candidate = next((a for a in assets if a.get("assetType") == "CHASSIS" and a.get("modelNumber")), None)
    if candidate is None:
        candidate = next((a for a in assets if a.get("modelNumber")), None)
    if candidate is None:
        return None, None
    return candidate.get("make"), candidate.get("modelNumber")


def list_devices(
    client: LogicVeinAPIClient, exclude_adapters: Collection[str] = (), networks: Collection[str] = ()
) -> tuple[list[Device], Counter[str]]:
    """List all devices except those on an excluded adapter, enriched with hardware detail.

    Enrichment is one extra API call per device - see
    Device.hardware_match_model for why it's worth it. Excluded devices are
    dropped before that call, and counted per adapter so the run can say what
    it skipped.

    Args:
        client: The LogicVein API client.
        exclude_adapters: Adapter ids whose devices are skipped.
        networks: LogicVein networks to read; empty reads every network.

    Returns:
        (devices, excluded counts by adapter).
    """
    devices: list[Device] = []
    excluded: Counter[str] = Counter()
    for raw in client.search_devices_in_network(network=list(networks)):
        device = _device_from_raw(raw)
        if device.adapter_id is not None and device.adapter_id in exclude_adapters:
            excluded[device.adapter_id] += 1
            continue
        make, model_number = _hardware_detail(client, device)
        devices.append(replace(device, hardware_make=make, hardware_model_number=model_number))
    return devices, excluded
