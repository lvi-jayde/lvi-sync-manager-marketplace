"""Builds and formats the per-run device-to-CVE match report.

One `DeviceReport` per device, with a separate hardware and software
`DeviceMatch` (see docs/ARCHITECTURE.md - hardware and software CVEs are
tracked distinctly, since a device can have both). A match "auto-applies"
- and only then are its vulnerabilities actually fetched - when its best
candidate scores at or above `Settings.match_confidence_threshold` and
`Settings.match_auto_apply` is on. A candidate below the threshold, or with
auto-apply off, is still reported (never silently dropped) with an empty
`vulnerabilities` list, for manual review.

Every CVE cvefeed.io has for the matched product is fetched - paged and
cached by `cve_cache.CVECache` (see its docstring), up to
`Settings.max_cves_per_product`, the most recent first. A product with more
CVEs than that is reported as truncated (`DeviceMatch.cves_truncated`, with
the real total in `total_cve_count`), never silently cut short.

Auto-applied CVEs are further narrowed by version, when possible: each one
is tagged `{"cve": <raw API dict>, "version_status": "confirmed"|"unknown",
"cisa_kev": {...}}` by checking it against the device's own version
(see version_filter.py for what "confirmed" vs "unknown" actually means and
why it's biased toward "unknown" rather than guessing). A CVE resolved as
definitively NOT applying to this device's version is dropped - counted in
`DeviceMatch.version_filtered_count` so that filtering stays visible in the
report rather than silent. This only runs for the software match (using
`Device.match_os_version`) - hardware CVEs aren't tied to a device version the
same way, and this project's own inventory data has that field empty or
unreliable on the hardware side (see docs/ARCHITECTURE.md). It also only
runs when `Settings.version_filter_enabled` is on: it needs each CVE's
`configurations`, which only the per-CVE detail request
(`/api/vulnerability/{id}/`) returns - cached between runs by `CVECache`.

CISA KEV (Known Exploited Vulnerabilities) status comes free with the
product's CVE list itself: `/api/vulnerability/?product_id=` includes
`cisa_kev_detail` on every item (verified live 2026-10-01 against
CVE-2016-6366, identical to the detail response's), so every CVE - hardware
matches included - is tagged `{"in_kev": bool, ...}`, with
`known_ransomware_campaign_use` and a remediation `due_date` when it is in
KEV.

`find_latest_report()`/`new_cves_since()` compare a fresh run against the
most recent report already sitting in the (timestamped, rotated) report
directory, purely by reading that local file - no extra API cost. Matches
devices by IP address across the two reports; a device that's new to this
run isn't diffed at all, since there's nothing to compare it against.

`to_csv()`/`write_csv_report()` are an optional flat export (one row per
CVE finding, opt-in via `Settings.csv_export_enabled`/`--csv` since it's a
convenience format, not a second source of truth) - a device or match with
no CVEs at all simply has no rows, unlike the JSON report which always
shows every device and match regardless. See `write_csv_report()`.
"""

import csv
import io
import json
import math
from collections import Counter
from collections.abc import Callable, Collection, Mapping, Sequence
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .cpe_field import CPEFieldSettings, FieldCPEs, parse_field
from .cve_cache import CVECache, MatchCache
from .cvefeed_client import CVEFeedAPIError
from .device_inventory import Device
from .matcher import MatchResult, ProductCandidate
from .vendors.arista import AristaAdvisories
from .vendors.cisco import CiscoPSIRT
from .vendors.cisco_tables import CiscoFixedReleases
from .vendors.extreme import ExtremeAdvisories
from .vendors.f5 import F5Advisories
from .vendors.fortinet import FortinetAdvisories
from .vendors.hpe import HPEAdvisories
from .vendors.juniper import JuniperAdvisories
from .vendors.paloalto import PaloAltoAdvisories
from .vendors.verdict import VendorVerdict
from .version_filter import Applicability, Platform, applicability, cpe_product

# A device's vendor verdict per CVE (Cisco PSIRT, Juniper), or None to let
# NVD decide.
VendorSource = Callable[[dict[str, Any]], VendorVerdict | None]

_REPORT_PREFIX = "cve_report_"
_REPORT_SUFFIX = ".json"
_CSV_SUFFIX = ".csv"
# Deliberately not a "cve_report_" name: anything matching
# cve_report_*.json would be taken for a report by find_latest_report().
_NEW_CVES_PREFIX = "new_cves_"
_FILTERED_PREFIX = "filtered_report_"
_TEXT_SUFFIX = ".txt"
# Sortable lexicographically in the same order as chronologically, which is
# what makes a plain filename sort enough to find the oldest reports in
# _rotate() below - no need to parse the timestamp back out.
_TIMESTAMP_FORMAT = "%Y%m%dT%H%M%SZ"


@dataclass
class DeviceMatch:
    kind: str  # "hardware" or "software"
    result: MatchResult
    auto_applied: bool
    # Each entry: {"cve": <raw API dict>, "version_status": "confirmed"|"unknown", "cisa_kev": {...}}.
    vulnerabilities: list[dict[str, Any]] = field(default_factory=list)
    # How many fetched CVEs were dropped as confirmed not to apply to this
    # device's version - 0 whenever version filtering didn't run at all
    # (disabled, no device version, or a hardware match).
    version_filtered_count: int = 0
    # CVEs dropped because NVD limits them to other hardware platforms -
    # each {"id", "platforms": [the NVD hardware it's limited to]}, so the
    # exclusion can be checked. Software matches only.
    platform_excluded: list[dict[str, Any]] = field(default_factory=list)
    # CVEs Cisco's PSIRT says don't affect the device's release - each {"id",
    # "advisories", "release"} (vendors/cisco.py). Software matches only.
    vendor_excluded: list[dict[str, Any]] = field(default_factory=list)
    # cvefeed.io's total for the matched product. When cves_truncated, only
    # the most recent Settings.max_cves_per_product of them were checked.
    total_cve_count: int = 0
    cves_truncated: bool = False
    # CVEs dropped for a CVSS score outside Settings' CVSS range, and how
    # many kept CVEs have no score yet (only counted when a range is set).
    cvss_filtered_count: int = 0
    unscored_count: int = 0
    # CVEs dropped for having no CVSS score yet (cves.cvss.include_unscored off).
    unscored_excluded_count: int = 0
    # "name_search", or "cpe_field" when a CPE in the device's custom field
    # decided the match (cpe_field.py). unresolved_cpe: a CPE from the field
    # that cvefeed.io's catalog doesn't know - name search was used instead.
    source: str = "name_search"
    unresolved_cpe: str | None = None
    # Why a match that scored high enough was still held for review - see
    # _build_match(). None when it applied, or simply scored too low.
    hold_reason: str | None = None
    # Why there was nothing to match (Device.hardware_skip_reason) - no
    # search was made.
    skip_reason: str | None = None
    # More catalog products this match covers, beyond result.best - one
    # product split across entries by a rename (Device.software_extra_queries).
    # Their CVEs are merged into `vulnerabilities`, each CVE once.
    extra_products: list[ProductCandidate] = field(default_factory=list)
    # A software match found by name search from LogicVein's own text, with no
    # verified catalog entry behind it (Device.software_match_verified): it rests
    # on the score alone, so a plausible-looking wrong product can pass.
    unverified: bool = False
    # CVEs whose vendor record or NVD data raised when evaluated: kept as
    # "unknown" (see _enrich_vulnerabilities()).
    unreadable_cves: list[str] = field(default_factory=list)


@dataclass
class DeviceReport:
    device: Device
    hardware: DeviceMatch
    software: DeviceMatch


@dataclass
class DeviceFailure:
    """A device whose report could not be built: an unexpected error while
    processing it. It is left out of the reports, memos, CPE writes and
    run-over-run diff, and listed in the JSON report and on the terminal."""

    device: Device
    error: str  # "KeyError: 'x'"


def _summarize_cisa_kev(vulnerability: dict[str, Any]) -> dict[str, Any]:
    """Pick the bits of a KEV record worth surfacing in the report.

    Verified live against CVE-2021-44228 (Log4Shell) for the populated shape.

    Args:
        vulnerability: The CVE as in a product list (with `cisa_kev_detail`).

    Returns:
        {"in_kev": True, "known_ransomware_campaign_use", "due_date"}, or just
        {"in_kev": False} when the CVE isn't in CISA's catalog at all.
    """
    records = vulnerability.get("cisa_kev_detail") or []
    if not records:
        return {"in_kev": False}
    record = records[0]
    return {
        "in_kev": True,
        "known_ransomware_campaign_use": record.get("known_ransomware_campaign_use"),
        "due_date": record.get("due_date"),
    }


@dataclass
class _Exclusions:
    version: int = 0
    platform: list[dict[str, Any]] = field(default_factory=list)
    vendor: list[dict[str, Any]] = field(default_factory=list)
    unreadable: list[str] = field(default_factory=list)


def _enrich_vulnerabilities(
    cves: CVECache,
    raw_vulnerabilities: list[dict[str, Any]],
    device_version: str | None,
    enabled: bool,
    platform: Platform | None = None,
    vendor: VendorSource | None = None,
    products: Collection[tuple[str, str]] | None = None,
) -> tuple[list[dict[str, Any]], _Exclusions]:
    """Tag each CVE with its version status and CISA KEV status, dropping the ones shown not to apply.

    The vendor's own verdict comes first (Cisco's PSIRT, Juniper's CVE
    records - see `vendor`): "unaffected" excludes the CVE, with evidence
    {"id", "vendor", "advisories", "release", "reason"} and no NVD detail
    fetch at all; "affected" confirms it (`vendor` on the entry), even over an
    NVD version exclusion. NVD's evaluation decides everything else, and its
    platform exclusions stand even when the vendor says affected: a vendor's
    release answer isn't per platform. A failed detail fetch keeps the CVE
    rather than guessing, and so does data that can't be read: if evaluating
    a CVE's vendor record or NVD configurations raises (a null where a list
    belongs, a shape nobody has seen), that CVE is kept as "unknown" and its id
    listed in the exclusions' `unreadable`, instead of failing the device.

    Args:
        cves: The CVE cache, for per-CVE detail.
        raw_vulnerabilities: The CVEs within the CVSS settings.
        device_version: The device's version, or None.
        enabled: Whether version filtering is on (vendor verdicts too).
        platform: The device's platform, or None.
        vendor: The device's vendor verdict source, or None.
        products: The (vendor, product) pairs the software was matched to, so
            NVD's ranges for other products in the same CVE are ignored (see
            version_filter.applicability), or None to count every product.

    Returns:
        (kept, exclusions) - each kept CVE as {"cve", "version_status",
        "cisa_kev"} (+ "vendor" when the vendor confirms it).
    """
    check = enabled and bool(device_version or platform)
    kept: list[dict[str, Any]] = []
    excluded = _Exclusions()
    for vuln in raw_vulnerabilities:
        cve_id = vuln.get("id") or ""
        verdict = None
        if vendor is not None and enabled:
            try:
                verdict = vendor(vuln)
            except Exception:  # deliberately broad - see the docstring
                excluded.unreadable.append(cve_id)
        if verdict is not None and verdict.status == "unaffected":
            excluded.vendor.append(
                {
                    "id": cve_id,
                    "vendor": verdict.vendor,
                    "advisories": list(verdict.advisories),
                    "release": verdict.release,
                    "reason": verdict.reason,
                }
            )
            continue
        result = Applicability("unknown")
        if check and cve_id:
            try:
                detail = cves.vulnerability_detail(vuln)
                result = applicability(device_version, detail.get("configurations"), platform, products)
            except CVEFeedAPIError:
                pass  # detail fetch failed - keep the CVE rather than guess
            except Exception:  # deliberately broad - see the docstring
                if cve_id not in excluded.unreadable:
                    excluded.unreadable.append(cve_id)
        confirmed = verdict is not None and verdict.status == "affected"
        if result.status == "not_applicable" and result.reason == "platform":
            excluded.platform.append({"id": cve_id, "platforms": list(result.platforms)})
            continue
        if result.status == "not_applicable" and not confirmed:
            excluded.version += 1
            continue
        entry = {"cve": vuln, "version_status": result.status, "cisa_kev": _summarize_cisa_kev(vuln)}
        if confirmed:
            assert verdict is not None
            entry["version_status"] = "confirmed"
            entry["vendor"] = {
                "vendor": verdict.vendor,
                "advisories": list(verdict.advisories),
                "release": verdict.release,
            }
        kept.append(entry)
    return kept, excluded


# Said wherever a device past its end-of-life dates is reported: the vendor
# no longer fixes or evaluates it, so its "unknown" CVEs can't be ruled out.
END_OF_SUPPORT_NOTE = (
    "Past end of support ({}): the vendor no longer fixes or evaluates this device's software, so CVEs "
    "marked unknown can't be ruled out."
)
CVEFEED_PAGE = "https://cvefeed.io/vuln/detail/{}"
NVD_PAGE = "https://nvd.nist.gov/vuln/detail/{}"
# How each link kind is labelled where reports show them.
LINK_LABELS = {"cvefeed": "cvefeed.io", "nvd": "NVD", "vendor": "Vendor"}


@dataclass(frozen=True)
class ReportLinks:
    """Which links each reported CVE carries (`reports.links.*`
    settings): its cvefeed.io page, its NVD page, and its vendor's own
    advisories. The vendor's come from the CVE's references tagged "Vendor
    Advisory" - one detail request per CVE not already cached with them."""

    cvefeed: bool = True
    nvd: bool = False
    vendor: bool = False


def cve_links(
    cves: CVECache,
    vulnerability: dict[str, Any],
    links: ReportLinks,
    more_advisories: Callable[[dict[str, Any]], list[str]] | None = None,
) -> dict[str, Any]:
    """Build a reported CVE's links, per the report link settings.

    A failed detail fetch just leaves NVD's vendor links out.

    Args:
        cves: The CVE cache, for vendor advisories.
        vulnerability: The CVE as in a product list.
        links: Which links to include.
        more_advisories: Where the vendor's own record names the advisory page
            (Arista's), a function giving those URLs; they join NVD's.

    Returns:
        {"cvefeed": url, "nvd": url, "vendor": [urls]} - only the enabled
        kinds, and "vendor" only when the CVE has a vendor advisory.
    """
    cve_id = vulnerability.get("id") or ""
    found: dict[str, Any] = {}
    if links.cvefeed:
        url = vulnerability.get("url") or ""
        found["cvefeed"] = url if url.startswith("https://") else CVEFEED_PAGE.format(cve_id)
    if links.nvd:
        found["nvd"] = NVD_PAGE.format(cve_id)
    if links.vendor:
        try:
            advisories = cves.vendor_advisories(vulnerability)
        except CVEFeedAPIError:
            advisories = []
        if more_advisories is not None:
            advisories = list(dict.fromkeys([*advisories, *more_advisories(vulnerability)]))
        if advisories:
            found["vendor"] = advisories
    return found


def link_list(entry: dict[str, Any]) -> list[tuple[str, str]]:
    """List a reported CVE's links as (label, url) pairs, in display order.

    Args:
        entry: A reported CVE entry (with "links").

    Returns:
        cvefeed.io, then NVD, then each vendor advisory - only those present.
    """
    links = entry.get("links") or {}
    pairs = [(LINK_LABELS[kind], links[kind]) for kind in ("cvefeed", "nvd") if links.get(kind)]
    return pairs + [(LINK_LABELS["vendor"], url) for url in links.get("vendor") or []]


@dataclass(frozen=True)
class CVSSRange:
    """Inclusive CVSS score bounds; None on either side means unbounded.

    Unscored CVEs - ones cvefeed.io hasn't scored yet - are kept only with
    `include_unscored` (`cves.cvss.include_unscored`, default off), independent
    of the bounds. They're common: verified live (2026-10-02) that a third
    of the fleet's cached CVEs (732 of 2,205) were unscored - newly
    published, NVD status "Received"/"Awaiting Analysis" - and they come back
    as `cvss_score` 0.0 with severity "NA", not a real 0.0, so they're
    detected and counted separately rather than read as a zero score.
    """

    minimum: float | None = None
    maximum: float | None = None
    include_unscored: bool = False

    @property
    def active(self) -> bool:
        """Whether either bound is set."""
        return self.minimum is not None or self.maximum is not None

    def excludes(self, vulnerability: dict[str, Any]) -> bool:
        """Whether a CVE falls outside this range.

        An unscored CVE is excluded unless `include_unscored`, whatever the
        bounds; a scored one is excluded only by a bound that's set.

        Args:
            vulnerability: The CVE as in a product list.

        Returns:
            True if the CVE should be dropped.
        """
        if _is_unscored(vulnerability):
            return not self.include_unscored
        if not self.active:
            return False
        score = float(vulnerability["cvss_score"])
        return (self.minimum is not None and score < self.minimum) or (
            self.maximum is not None and score > self.maximum
        )


def _is_unscored(vulnerability: dict[str, Any]) -> bool:
    """Whether a CVE has no CVSS score yet.

    cvefeed.io reports those as `cvss_score` 0.0 with severity "NA", not a
    real zero.

    Args:
        vulnerability: The CVE as in a product list.

    Returns:
        True for no score or severity "NA".
    """
    return vulnerability.get("cvss_score") is None or vulnerability.get("severity") in (None, "NA")


def _build_match(
    matches: MatchCache,
    cves: CVECache,
    kind: str,
    vendor_text: str | None,
    product_text: str | None,
    vendor_type: str,
    threshold: float,
    auto_apply_enabled: bool,
    device_version: str | None,
    version_filter_enabled: bool,
    cvss_range: CVSSRange,
    pinned_cpe: str | None = None,
    hold_reason: str | None = None,
    extra_queries: tuple[tuple[str, str, str], ...] = (),
    links: ReportLinks = ReportLinks(),
    platform: Platform | None = None,
    vendor: VendorSource | None = None,
    verified: bool = True,
    more_advisories: Callable[[dict[str, Any]], list[str]] | None = None,
) -> DeviceMatch:
    """Match a device's text to a product and gather its CVEs, if the match applies.

    A CPE pinned in the device's custom field is tried first; if the catalog
    doesn't know it, name search is used (and the CPE reported as
    unresolved). A match applies when auto-apply is on, the best candidate
    passes the threshold, and nothing holds it (see `hold_reason`). An
    applied match's CVEs - merged across any extra products, each once - go
    through the CVSS filter, then vendor and NVD applicability.

    Args:
        matches: The match cache.
        cves: The CVE cache.
        kind: "hardware" or "software".
        vendor_text: The device's vendor text for this kind.
        product_text: The device's product text for this kind.
        vendor_type: cvefeed.io's vendor_type for the search ("h", "o", "a").
        threshold: The confidence threshold.
        auto_apply_enabled: Whether matches may auto-apply at all.
        device_version: The device's version for version filtering, or None
            (hardware matches).
        version_filter_enabled: Whether version filtering is on.
        cvss_range: The CVSS settings.
        pinned_cpe: A CPE from the device's custom field, or None.
        hold_reason: The device's own reason to hold a name-search match (see
            Device.software_hold_reason). A CPE pin is exact, so it's never
            held.
        extra_queries: (vendor, product, vendor_type) searches for more
            catalog products an applied match also covers - each used only if
            it passes the same threshold and tie check.
        links: Which links to give each CVE.
        platform: The device's platform, for NVD's hardware conditions.
        vendor: The device's vendor verdict source, or None.
        verified: Whether a verified catalog entry names this product. False
            marks a name-search match with a candidate as `unverified`.
        more_advisories: Gives a CVE's vendor advisory URLs from the vendor's own
            record, for the vendor link (see cve_links()), or None.

    Returns:
        The match, with its CVEs and counts if it applied.
    """
    source, unresolved_cpe = "name_search", None
    result = matches.match_cpe(pinned_cpe) if pinned_cpe else None
    if result is not None and result.best is not None:
        source = "cpe_field"
    else:
        unresolved_cpe = pinned_cpe
        result = matches.match(vendor_text, product_text, vendor_type)
    best = result.best
    if source == "cpe_field":
        hold_reason = None
    elif hold_reason is None:
        hold_reason = _tie_reason(result)
    passed = best is not None and best.score >= threshold
    auto_applied = bool(auto_apply_enabled and passed and hold_reason is None)
    match = DeviceMatch(
        kind=kind,
        result=result,
        auto_applied=auto_applied,
        source=source,
        unresolved_cpe=unresolved_cpe,
        hold_reason=hold_reason if passed else None,
        unverified=source == "name_search" and not verified and best is not None,
    )
    if auto_applied and best is not None:
        match.extra_products = _extra_products(matches, extra_queries, best, threshold)
        products = [cves.product_vulnerabilities(p.id, p) for p in (best, *match.extra_products)]
        merged = list({v["id"]: v for product in reversed(products) for v in product.vulnerabilities}.values())
        merged = sorted(merged, key=lambda v: (v.get("published") or "", v["id"]), reverse=True)
        # Before the version filter, so out-of-range CVEs never cost a
        # per-CVE detail lookup.
        in_range = []
        for vuln in merged:
            if not cvss_range.excludes(vuln):
                in_range.append(vuln)
            elif _is_unscored(vuln):
                match.unscored_excluded_count += 1
            else:
                match.cvss_filtered_count += 1
        match.vulnerabilities, excluded = _enrich_vulnerabilities(
            cves, in_range, device_version, version_filter_enabled, platform, vendor, _matched_products(best, match)
        )
        match.version_filtered_count = excluded.version
        match.platform_excluded = excluded.platform
        match.vendor_excluded = excluded.vendor
        match.unreadable_cves = excluded.unreadable
        for entry in match.vulnerabilities:
            entry["links"] = cve_links(cves, entry["cve"], links, more_advisories)
        match.unscored_count = sum(1 for v in match.vulnerabilities if _is_unscored(v["cve"]))
        match.cves_truncated = any(product.truncated for product in products)
        # Each CVE once when every list is complete; truncated, the
        # products' own totals are all there is (a CVE in two counts twice).
        match.total_cve_count = sum(product.total for product in products) if match.cves_truncated else len(merged)
    return match


def _matched_products(best: ProductCandidate, match: DeviceMatch) -> frozenset[tuple[str, str]] | None:
    """Name the (vendor, product) pairs a match covers, for NVD's product check.

    Args:
        best: The match's main product.
        match: The match, with any extra products it also covers.

    Returns:
        The pairs read from the products' CPEs, or None if any product has no
        CPE - then nothing can be ruled out by product, so every entry counts.
    """
    pairs = [cpe_product(p.cpe) if p.cpe else None for p in (best, *match.extra_products)]
    return None if any(pair is None for pair in pairs) else frozenset(pair for pair in pairs if pair)


def _extra_products(
    matches: MatchCache, queries: tuple[tuple[str, str, str], ...], best: ProductCandidate, threshold: float
) -> list[ProductCandidate]:
    """Resolve the extra catalog products an applied match also covers.

    Each query must pass the threshold and the tie check, and be a product
    not already covered.

    Args:
        matches: The match cache.
        queries: (vendor, product, vendor_type) searches.
        best: The match's main product.
        threshold: The confidence threshold.

    Returns:
        The extra products, in query order.
    """
    found: list[ProductCandidate] = []
    for vendor, product, vendor_type in queries:
        result = matches.match(vendor, product, vendor_type)
        extra = result.best
        if extra is None or extra.score < threshold or _tie_reason(result) is not None:
            continue
        if extra.id != best.id and all(extra.id != f.id for f in found):
            found.append(extra)
    return found


def _vendor_source(
    device: Device,
    cisco_psirt: CiscoPSIRT | None,
    juniper: JuniperAdvisories | None,
    hpe: HPEAdvisories | None = None,
    fortinet: FortinetAdvisories | None = None,
    extreme: ExtremeAdvisories | None = None,
    paloalto: PaloAltoAdvisories | None = None,
    arista: AristaAdvisories | None = None,
    f5: F5Advisories | None = None,
    cisco_tables: CiscoFixedReleases | None = None,
) -> VendorSource | None:
    """Work out where this device's vendor verdicts come from, if anywhere.

    Cisco's PSIRT for a Cisco device with an OS type and version; Juniper's
    CVE records for a Junos device whose release parses; HPE's CVE records
    for an ArubaOS or ArubaOS-Switch device whose release parses; Fortinet's
    CVE records for a FortiOS device whose release parses; Extreme's CVE
    records for an ExtremeXOS or VOSS device whose release parses; Palo Alto's
    CVE records for a PAN-OS device whose release parses; Arista's CVE records
    for an EOS device whose release parses; F5's CVE records for a BIG-IP whose
    release parses; Cisco's first-fixed-release tables for an SD-WAN or Meraki
    device whose release parses.

    Args:
        device: The device.
        cisco_psirt: The Cisco PSIRT answers, or None (not configured).
        juniper: Juniper's CVE records, or None (turned off).
        hpe: HPE's CVE records, or None (turned off).
        fortinet: Fortinet's CVE records, or None (turned off).
        extreme: Extreme's CVE records, or None (turned off).
        paloalto: Palo Alto's CVE records, or None (turned off).
        arista: Arista's CVE records, or None (turned off).
        f5: F5's CVE records, or None (turned off).
        cisco_tables: Cisco's fixed-release tables, or None (turned off).

    Returns:
        A function giving the vendor's verdict per CVE, or None.
    """
    if cisco_psirt is not None and device.cisco_os_type:
        release = cisco_psirt.verdicts(device.cisco_os_type, device.match_os_version, device.cisco_platform_alias)
        return release.verdict if release is not None else None
    juniper_device = device.juniper_device
    if juniper is not None and juniper_device is not None:
        return lambda vulnerability: juniper.verdict(juniper_device, vulnerability)
    hpe_device = device.hpe_device
    if hpe is not None and hpe_device is not None:
        return lambda vulnerability: hpe.verdict(hpe_device, vulnerability)
    fortinet_device = device.fortinet_device
    if fortinet is not None and fortinet_device is not None:
        return lambda vulnerability: fortinet.verdict(fortinet_device, vulnerability)
    extreme_device = device.extreme_device
    if extreme is not None and extreme_device is not None:
        return lambda vulnerability: extreme.verdict(extreme_device, vulnerability)
    paloalto_device = device.paloalto_device
    if paloalto is not None and paloalto_device is not None:
        return lambda vulnerability: paloalto.verdict(paloalto_device, vulnerability)
    arista_device = device.arista_device
    if arista is not None and arista_device is not None:
        return lambda vulnerability: arista.verdict(arista_device, vulnerability)
    f5_device = device.f5_device
    if f5 is not None and f5_device is not None:
        return lambda vulnerability: f5.verdict(f5_device, vulnerability)
    table_device = device.cisco_table_device
    if cisco_tables is not None and table_device is not None:
        return lambda vulnerability: cisco_tables.verdict(table_device, vulnerability)
    return None


def device_platform(device: Device, hardware: DeviceMatch) -> Platform | None:
    """Describe the device for NVD's hardware conditions.

    Its applied hardware match (CPE product token and catalog name, extra
    products too) and LogicVein's model strings. A hardware match only counts
    once applied: a held candidate may be wrong.

    Args:
        device: The device.
        hardware: The device's hardware match.

    Returns:
        The platform, or None - every platform condition unknown - for a
        virtual appliance or a device with no such data.
    """
    if device.hardware_skip_reason:
        return None
    names: list[str] = []
    if hardware.auto_applied and hardware.result.best is not None:
        for product in (hardware.result.best, *hardware.extra_products):
            if product.cpe:
                names.append(product.cpe.split(":")[4])
            names.append(product.name)
    names += [model for model in (device.hardware_model_number, device.hardware_model) if model]
    return Platform(tuple(dict.fromkeys(names))) if names else None


def _tie_reason(result: MatchResult) -> str | None:
    """Say why a match is held for a tie, if it is.

    A tie for first place between two different catalog products means the
    score can't choose - the winner would just be whichever came first in
    cvefeed.io's results. Verified on both labs (2026-10-06): HP ProCurve
    switches' software matched "Procurve switch software" over "Procurve
    access point software" at an identical 0.85.

    Args:
        result: The match's candidates.

    Returns:
        "tied with <vendor> <product>", or None.
    """
    if len(result.candidates) < 2:
        return None
    first, second = result.candidates[0], result.candidates[1]
    if first.id != second.id and math.isclose(first.score, second.score, abs_tol=1e-9):
        return f"tied with {second.vendor_name} {second.name}"
    return None


def build_device_report(
    matches: MatchCache,
    cves: CVECache,
    device: Device,
    threshold: float,
    auto_apply_enabled: bool,
    version_filter_enabled: bool = True,
    cvss_range: CVSSRange = CVSSRange(),
    cpe_field: CPEFieldSettings | None = None,
    links: ReportLinks = ReportLinks(),
    cisco_psirt: CiscoPSIRT | None = None,
    juniper: JuniperAdvisories | None = None,
    hpe: HPEAdvisories | None = None,
    fortinet: FortinetAdvisories | None = None,
    extreme: ExtremeAdvisories | None = None,
    paloalto: PaloAltoAdvisories | None = None,
    arista: AristaAdvisories | None = None,
    f5: F5Advisories | None = None,
    cisco_tables: CiscoFixedReleases | None = None,
    held: Mapping[str, str] | None = None,
) -> DeviceReport:
    """Build one device's report: its hardware and software matches and their CVEs.

    A virtual appliance gets no hardware search (unless a hardware CPE is
    pinned). The hardware match feeds the platform the software match's NVD
    conditions are checked against.

    Args:
        matches: The match cache.
        cves: The CVE cache.
        device: The device.
        threshold: The confidence threshold.
        auto_apply_enabled: Whether matches may auto-apply at all.
        version_filter_enabled: Whether version filtering is on.
        cvss_range: The CVSS settings.
        cpe_field: The CPE custom field settings, or None (not read).
        held: Match kinds ("hardware"/"software") to hold for review, with the
            reason - a match a reviewer rejected. A held match is still
            searched and reported, but not applied, so its CVEs are not
            fetched; a CPE pin overrides it.
        links: Which links to give each CVE.
        cisco_psirt: Cisco's PSIRT answers, or None.
        juniper: Juniper's CVE records, or None.
        hpe: HPE's CVE records, or None.
        fortinet: Fortinet's CVE records, or None.
        extreme: Extreme's CVE records, or None.
        paloalto: Palo Alto's CVE records, or None.
        arista: Arista's CVE records, or None.
        f5: F5's CVE records, or None.
        cisco_tables: Cisco's fixed-release tables, or None.

    Returns:
        The device's report.

    Raises:
        CVEFeedAPIError: From the caches, when a cvefeed.io request fails.
    """
    pinned = FieldCPEs()
    if cpe_field is not None and cpe_field.read:
        pinned = parse_field(device.custom_fields.get(cpe_field.slot)) or FieldCPEs()
    skip = device.hardware_skip_reason
    if skip and not pinned.hardware:
        hardware = DeviceMatch(
            kind="hardware",
            result=MatchResult(device.hardware_match_vendor, device.hardware_match_model),
            auto_applied=False,
            skip_reason=skip,
        )
    else:
        hardware = _build_match(
            matches,
            cves,
            "hardware",
            device.hardware_match_vendor,
            device.hardware_match_model,
            "h",
            threshold,
            auto_apply_enabled,
            device_version=None,  # see this module's docstring on hardware scope
            version_filter_enabled=version_filter_enabled,
            cvss_range=cvss_range,
            pinned_cpe=pinned.hardware,
            hold_reason=(held or {}).get("hardware"),
            links=links,
        )
    software = _build_match(
        matches,
        cves,
        "software",
        device.software_match_vendor,
        device.software_product_hint,
        device.software_vendor_type,
        threshold,
        auto_apply_enabled,
        device_version=device.match_os_version,
        version_filter_enabled=version_filter_enabled,
        cvss_range=cvss_range,
        pinned_cpe=pinned.software,
        hold_reason=(held or {}).get("software") or device.software_hold_reason,
        extra_queries=device.software_extra_queries,
        links=links,
        platform=device_platform(device, hardware),
        vendor=_vendor_source(device, cisco_psirt, juniper, hpe, fortinet, extreme, paloalto, arista, f5, cisco_tables),
        verified=device.software_match_verified,
        more_advisories=arista.advisory_urls if arista is not None and device.arista_device is not None else None,
    )
    return DeviceReport(device=device, hardware=hardware, software=software)


def report_score(score: float) -> float:
    """Show a match score as reports do: truncated to 2 decimal places.

    Never rounded up - a score that failed a 0.6 threshold must never read as
    0.60. (The small epsilon keeps binary floats like 0.29 from flooring to
    0.28.)

    Args:
        score: The score, 0.0-1.0.

    Returns:
        The truncated score.
    """
    return math.floor(score * 100 + 1e-9) / 100


def to_json(reports: list[DeviceReport], failures: Sequence[DeviceFailure] = ()) -> list[dict[str, Any]]:
    """Convert reports to JSON-ready data, with scores as shown in reports.

    Args:
        reports: The device reports.
        failures: Devices that failed; each is added last as
            {"device": ..., "error": ...}, with no matches.

    Returns:
        One dict per device.
    """
    data = [asdict(report) for report in reports]
    for device in data:
        for kind in ("hardware", "software"):
            for candidate in device[kind]["result"]["candidates"]:
                candidate["score"] = report_score(candidate["score"])
    data += [{"device": asdict(failure.device), "error": failure.error} for failure in failures]
    return data


def find_latest_report(directory: Path) -> Path | None:
    """Find the most recent existing report in `directory`.

    It's the baseline `new_cves_since()` diffs the next report against.

    Args:
        directory: The report directory.

    Returns:
        Its newest cve_report_*.json, or None on a first run (no directory
        yet, or nothing in it).
    """
    if not directory.is_dir():
        return None
    existing = sorted(directory.glob(f"{_REPORT_PREFIX}*{_REPORT_SUFFIX}"))
    return existing[-1] if existing else None


def new_cves_since(previous_path: Path, current_reports: list[DeviceReport]) -> dict[str, list[str]]:
    """Find the CVE ids present now but not in the previous report, per device.

    Only compares devices present in *both* reports: a device new to this run
    has nothing to diff against, which is not the same as "zero new CVEs" and
    isn't reported as either. A previous report that fails to read or parse
    (moved, corrupted, hand-edited) is treated the same as "no baseline" - an
    empty diff, not an error; this is a convenience summary, not something a
    bad file on disk should be able to break the run over.

    Args:
        previous_path: The previous JSON report.
        current_reports: This run's device reports.

    Returns:
        Device IP address -> its new CVE ids (each once, hardware first).
    """
    try:
        previous = json.loads(previous_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}

    # An entry with an "error" is a device that failed that run: no baseline.
    previous_by_ip = {
        entry["device"]["ip_address"]: entry for entry in previous if "device" in entry and "error" not in entry
    }
    new_by_device: dict[str, list[str]] = {}
    for report in current_reports:
        ip = report.device.ip_address
        prev_entry = previous_by_ip.get(ip)
        if prev_entry is None:
            continue
        try:
            prev_ids = {
                v["cve"]["id"]
                for match_key in ("hardware", "software")
                for v in (prev_entry.get(match_key) or {}).get("vulnerabilities") or []
            }
        except (KeyError, TypeError):
            # Verified live (2026-09-15): a previous report written before
            # the CISA KEV enrichment landed stores each vulnerability as
            # the bare CVE dict, not wrapped in {"cve": ..., "version_status":
            # ..., "cisa_kev": ...} - v["cve"]["id"] then raises KeyError.
            # Same "no usable baseline" treatment as a previous report that
            # fails to parse at all (see the docstring above); a schema this
            # tool itself moved on from is just as unusable as a corrupted
            # file, and discovering that per-device rather than for the
            # whole file lets any other, still-comparable devices still get
            # their diff.
            continue
        # dict.fromkeys, not a set: preserves first-seen order (hardware
        # before software) while still deduping a CVE id that legitimately
        # shows up in both - a set here would also dedupe, but drop the
        # ordering for no reason.
        new_ids = list(
            dict.fromkeys(
                v["cve"]["id"]
                for match in (report.hardware, report.software)
                for v in match.vulnerabilities
                if v["cve"]["id"] not in prev_ids
            )
        )
        if new_ids:
            new_by_device[ip] = new_ids
    return new_by_device


def _rotate(directory: Path, retention: int) -> None:
    """Delete the oldest reports beyond `retention`, keeping the newest.

    Only touches files matching this module's own naming convention
    (cve_report_<timestamp>.json/.csv) - never anything else a user might
    have placed in the same directory. JSON is the source of truth for which
    timestamps exist (it's always written; the CSV export is opt-in) - a
    rotated-out JSON's paired CSV and new-CVE file, if any, are deleted with
    it so the directory doesn't accumulate orphans.

    Args:
        directory: The report directory.
        retention: How many reports to keep.
    """
    existing = sorted(directory.glob(f"{_REPORT_PREFIX}*{_REPORT_SUFFIX}"))
    excess = len(existing) - retention
    for stale_report in existing[: max(excess, 0)]:
        stale_report.unlink()
        for paired in (
            stale_report.with_suffix(_CSV_SUFFIX),
            _new_cves_path(stale_report),
            *_filtered_paths(stale_report),
        ):
            if paired.is_file():
                paired.unlink()


def write_report(
    reports: list[DeviceReport], directory: Path, retention: int, failures: Sequence[DeviceFailure] = ()
) -> Path:
    """Write a timestamped JSON report, then rotate out old ones.

    The directory is created if needed; the oldest reports beyond `retention`
    (Settings.report_retention) are deleted so the directory doesn't grow
    without bound.

    Args:
        reports: The device reports.
        directory: The report directory.
        retention: How many reports to keep.
        failures: Devices that failed, listed after the reports (see to_json()).

    Returns:
        The report's path.
    """
    directory.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now(timezone.utc).strftime(_TIMESTAMP_FORMAT)
    path = directory / f"{_REPORT_PREFIX}{timestamp}{_REPORT_SUFFIX}"
    path.write_text(json.dumps(to_json(reports, failures), indent=2, default=str), encoding="utf-8")
    _rotate(directory, retention)
    return path


def to_csv(reports: list[DeviceReport]) -> str:
    """Build a flat CSV of every CVE finding across all devices - one row per CVE.

    A device or match with no CVEs at all (no candidate, below the confidence
    threshold, or an auto-applied match that just has none) simply has no
    rows here - this is a convenience export of the actionable findings, not
    a replacement for the JSON report's complete per-device/per-match
    picture.

    Args:
        reports: The device reports.

    Returns:
        The CSV text, with a header row.
    """
    output = io.StringIO()
    # lineterminator="\n", not csv's own "\r\n" default: the string this
    # builds gets handed to Path.write_text(), whose universal-newline
    # translation on write would otherwise turn each embedded "\r\n"'s "\n"
    # into a second "\r" on Windows (a real "\r\r\n" corruption, not just a
    # cosmetic one) - plain "\n" here is translated safely everywhere.
    writer = csv.writer(output, lineterminator="\n")
    writer.writerow(
        [
            "device_ip",
            "device_hostname",
            "match_kind",
            "matched_vendor",
            "matched_product",
            "match_score",
            "matched_cpe",
            "cve_id",
            "severity",
            "cvss_score",
            "published",
            "version_status",
            "in_cisa_kev",
            "known_ransomware_campaign_use",
            "url",
            "nvd_url",
            "vendor_advisory_url",
            "device_end_of_life",
            "software_end_of_life",
        ]
    )
    for report in reports:
        device = report.device
        for match in (report.hardware, report.software):
            best = match.result.best
            if best is None:
                continue
            for entry in match.vulnerabilities:
                cve = entry["cve"]
                kev = entry.get("cisa_kev") or {}
                writer.writerow(
                    [
                        device.ip_address,
                        device.hostname or "",
                        match.kind,
                        best.vendor_name,
                        best.name,
                        f"{report_score(best.score):.2f}",
                        best.cpe or "",
                        cve.get("id", ""),
                        cve.get("severity", ""),
                        cve.get("cvss_score", ""),
                        cve.get("published", ""),
                        entry.get("version_status", ""),
                        kev.get("in_kev", ""),
                        kev.get("known_ransomware_campaign_use", ""),
                        (entry.get("links") or {}).get("cvefeed", ""),
                        (entry.get("links") or {}).get("nvd", ""),
                        " ".join((entry.get("links") or {}).get("vendor") or []),
                        device.eox_dates().get("end_of_life", ""),
                        device.eox_dates().get("software_end_of_life", ""),
                    ]
                )
    return output.getvalue()


def write_csv_report(reports: list[DeviceReport], json_report_path: Path) -> Path:
    """Write a CSV export alongside an already-written JSON report.

    It shares the JSON's filename (just a different suffix) so the two files
    pair up for `_rotate()` (see `write_report()`) - call this with the
    `Path` `write_report()` just returned.

    Args:
        reports: The device reports.
        json_report_path: The JSON report `write_report()` returned.

    Returns:
        The CSV's path.
    """
    csv_path = json_report_path.with_suffix(_CSV_SUFFIX)
    csv_path.write_text(to_csv(reports), encoding="utf-8")
    return csv_path


def _kev_count(match: DeviceMatch) -> int:
    """Count a match's CVEs that are in CISA KEV.

    Args:
        match: A match.

    Returns:
        The count.
    """
    return sum(1 for v in match.vulnerabilities if (v.get("cisa_kev") or {}).get("in_kev"))


def matched_products(match: DeviceMatch) -> str:
    """Name a match's products: "Vendor Product", plus any extra products.

    Args:
        match: A match with a best candidate.

    Returns:
        e.g. "Arubanetworks Arubaos + Hp Arubaos, Hpe Arubaos".
    """
    best = match.result.best
    assert best is not None
    extras = ", ".join(f"{p.vendor_name} {p.name}" for p in match.extra_products)
    return f"{best.vendor_name} {best.name}" + (f" + {extras}" if extras else "")


def _match_summary(match: DeviceMatch) -> str:
    """Describe one match on one terminal line.

    Args:
        match: A match.

    Returns:
        The match's product, score, status (applied, needs review and why,
        pinned, skipped) and CVE counts, including every kind of exclusion.
    """
    if match.skip_reason:
        return f"{match.kind}: skipped - {match.skip_reason}"
    best = match.result.best
    if best is None:
        return f"{match.kind}: no candidate"
    status = "applied" if match.auto_applied else "needs review"
    if match.hold_reason:
        status += f": {match.hold_reason}"
    if match.source == "cpe_field":
        status += ", pinned by CPE field"
    elif match.unresolved_cpe:
        status += ", CPE field not in catalog"
    if match.unverified:
        status += ", unverified product match"
    excluded = f", {match.version_filtered_count} excluded by version" if match.version_filtered_count else ""
    if match.platform_excluded:
        excluded += f", {len(match.platform_excluded)} excluded by platform"
    by_vendor = Counter(x.get("vendor", "vendor") for x in match.vendor_excluded)
    for name, count in sorted(by_vendor.items()):
        excluded += f", {count} excluded by {name}"
    if match.cvss_filtered_count:
        excluded += f", {match.cvss_filtered_count} outside CVSS range"
    if match.unscored_excluded_count:
        excluded += f", {match.unscored_excluded_count} unscored excluded"
    if match.unscored_count:
        excluded += f", {match.unscored_count} not yet scored"
    kev = _kev_count(match)
    kev_note = f", {kev} in CISA KEV" if kev else ""
    checked = (
        len(match.vulnerabilities)
        + match.version_filtered_count
        + len(match.platform_excluded)
        + len(match.vendor_excluded)
        + match.cvss_filtered_count
        + match.unscored_excluded_count
    )
    truncated = f", only the newest {checked} of {match.total_cve_count} checked" if match.cves_truncated else ""
    return (
        f"{match.kind}: {matched_products(match)} "
        f"(score={report_score(best.score):.2f}, {status}, {len(match.vulnerabilities)} CVEs{excluded}{kev_note}{truncated})"
    )


_GAP_NAMES_SHOWN = 10


def _no_cve_source(report: DeviceReport) -> str | None:
    """Give the vendor's no-CVE-source note, when it explains this device's empty result.

    Args:
        report: The device's report.

    Returns:
        `Device.no_cve_source_note`, but only when neither match applied - a
        device that did match something is reported normally - else None.
    """
    if report.hardware.auto_applied or report.software.auto_applied:
        return None
    return report.device.no_cve_source_note


def coverage_gaps(reports: list[DeviceReport]) -> dict[str, list[str]]:
    """Group the devices that have no applied match, so no CVEs were checked for them.

    A device is in a gap when neither its hardware nor its software match
    applied. Silence there is easy to read as "no CVEs", so the terminal
    summary calls them out.

    Args:
        reports: The device reports.

    Returns:
        Group -> one line per device ("name", or "name (why)" for matches that
        need review). The groups, in order, when present: "unidentified (no
        adapter)", "no catalog product found", "needs review", and a group
        per vendor with no CVE source ("no CVE source: <why>", see
        `Device.no_cve_source_note`), which takes its devices out of the
        other groups.
    """
    gaps: dict[str, list[str]] = {
        "unidentified (no adapter)": [],
        "no catalog product found": [],
        "needs review": [],
    }
    for report in reports:
        hardware, software = report.hardware, report.software
        if hardware.auto_applied or software.auto_applied:
            continue
        device = report.device
        label = device.hostname or device.ip_address
        no_source = _no_cve_source(report)
        if no_source:
            gaps.setdefault(f"no CVE source ({no_source})", []).append(label)
            continue
        candidate = software.result.best or hardware.result.best
        if candidate is None:
            gaps["no catalog product found" if device.adapter_id else "unidentified (no adapter)"].append(label)
            continue
        match = software if software.result.best else hardware
        why = match.hold_reason or f"best candidate {candidate.name}, score {report_score(candidate.score):.2f}"
        gaps["needs review"].append(f"{label} ({why})")
    return {group: names for group, names in gaps.items() if names}


def format_terminal_report(reports: list[DeviceReport]) -> str:
    """Build the terminal summary: each device's matches, then the run's totals.

    Args:
        reports: The device reports.

    Returns:
        The summary text.
    """
    lines: list[str] = []
    needs_review = 0
    total_cves = 0
    total_version_filtered = 0
    total_platform_excluded = 0
    total_vendor_excluded = 0
    unreadable: list[str] = []
    total_cvss_filtered = 0
    total_unscored = 0
    total_unscored_excluded = 0
    total_kev = 0
    truncated = 0
    for report in reports:
        device = report.device
        label = device.hostname or device.ip_address
        support = device.end_of_support()
        lines.append(f"{label} ({device.ip_address})" + (f" - past end of support: {support}" if support else ""))
        no_source = _no_cve_source(report)
        for match in (report.hardware, report.software):
            lines.append(f"  {_match_summary(match)}")
            if not match.auto_applied and not match.skip_reason and not no_source:
                needs_review += 1
            total_cves += len(match.vulnerabilities)
            total_version_filtered += match.version_filtered_count
            total_platform_excluded += len(match.platform_excluded)
            total_vendor_excluded += len(match.vendor_excluded)
            unreadable += match.unreadable_cves
            total_cvss_filtered += match.cvss_filtered_count
            total_unscored += match.unscored_count
            total_unscored_excluded += match.unscored_excluded_count
            total_kev += _kev_count(match)
            truncated += match.cves_truncated
        if no_source:
            lines.append(f"  no CVE source: {no_source} - any candidate above is a look-alike, not a real match")
    lines.append("")
    summary = f"{len(reports)} device(s), {needs_review} match(es) need review, {total_cves} CVE(s) found"
    if total_kev:
        summary += f" ({total_kev} in CISA KEV - actively exploited)"
    if total_version_filtered:
        summary += f", {total_version_filtered} more excluded by version"
    if total_platform_excluded:
        summary += f", {total_platform_excluded} more excluded by platform"
    if total_vendor_excluded:
        summary += f", {total_vendor_excluded} more excluded by vendor advisories"
    if total_cvss_filtered:
        summary += f", {total_cvss_filtered} more outside the CVSS range"
    if total_unscored_excluded:
        summary += f", {total_unscored_excluded} more not yet scored (excluded; cvss_include_unscored is off)"
    if total_unscored:
        summary += f" ({total_unscored} kept CVE(s) not yet scored)"
    lines.append(summary)
    if unreadable:
        unique = list(dict.fromkeys(unreadable))
        more = f" and {len(unique) - _GAP_NAMES_SHOWN} more" if len(unique) > _GAP_NAMES_SHOWN else ""
        lines.append(
            f"{len(unique)} CVE(s) had vendor or NVD data that could not be read and were kept as unknown: "
            f"{', '.join(unique[:_GAP_NAMES_SHOWN])}{more}"
        )
    gaps = coverage_gaps(reports)
    if gaps:
        uncovered = sum(len(names) for names in gaps.values())
        lines.append(
            f"{uncovered} of {len(reports)} device(s) have no applied match, so no CVEs were checked for them:"
        )
        for group, names in gaps.items():
            shown = ", ".join(names[:_GAP_NAMES_SHOWN])
            more = f" and {len(names) - _GAP_NAMES_SHOWN} more" if len(names) > _GAP_NAMES_SHOWN else ""
            lines.append(f"  {len(names)} {group}: {shown}{more}")
    if truncated:
        lines.append(
            f"{truncated} match(es) had more CVEs than max_cves_per_product allows - only the newest were "
            "checked (see each match's line above)."
        )
    return "\n".join(lines)


def _new_cves_path(json_report_path: Path) -> Path:
    """Name the new-CVE file paired with a JSON report.

    Args:
        json_report_path: The JSON report.

    Returns:
        new_cves_<timestamp>.json beside it.
    """
    timestamp = json_report_path.name.removeprefix(_REPORT_PREFIX).removesuffix(_REPORT_SUFFIX)
    return json_report_path.with_name(f"{_NEW_CVES_PREFIX}{timestamp}{_REPORT_SUFFIX}")


def _matched_cpes(report: DeviceReport | None) -> dict[str, str | None]:
    """Give a device's applied matches' CPEs, for the new-CVE file.

    Args:
        report: The device's report.

    Returns:
        {"hardware": cpe or None, "software": cpe or None}.
    """
    cpes: dict[str, str | None] = {"hardware": None, "software": None}
    if report is not None:
        for match in (report.hardware, report.software):
            if match.auto_applied and match.result.best is not None:
                cpes[match.kind] = match.result.best.cpe
    return cpes


def write_new_cves(
    reports: list[DeviceReport],
    new_by_device: dict[str, list[str]],
    json_report_path: Path,
    previous_report_path: Path,
) -> Path:
    """Write `new_cves_since()`'s result - the CVE ids themselves - to a file.

    `format_new_cves()` deliberately keeps the ids off stdout. The file sits
    next to the JSON report `write_report()` just returned, sharing its
    timestamp, with each device's matched CPEs alongside its new ids. Written
    whenever there was a previous report to diff against, even with nothing
    new, so "checked, none" is on disk too.

    Args:
        reports: This run's device reports.
        new_by_device: `new_cves_since()`'s result.
        json_report_path: This run's JSON report.
        previous_report_path: The report diffed against.

    Returns:
        The file's path.
    """
    by_ip = {r.device.ip_address: r for r in reports}
    path = _new_cves_path(json_report_path)
    data = {
        "previous_report": previous_report_path.name,
        "total": sum(len(ids) for ids in new_by_device.values()),
        "devices": [
            {
                "ip_address": ip,
                "hostname": by_ip[ip].device.hostname if ip in by_ip else None,
                # The products these CVEs came from: each auto-applied match's CPE.
                "matched_cpes": _matched_cpes(by_ip.get(ip)),
                "new_cve_ids": ids,
            }
            for ip, ids in new_by_device.items()
        ],
    }
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return path


def format_new_cves(reports: list[DeviceReport], new_by_device: dict[str, list[str]]) -> str:
    """Summarize `new_cves_since()`'s result for humans: counts per device.

    Never the CVE ids themselves - with every CVE fetched per product, a run
    can turn up thousands, which don't belong on stdout (`write_new_cves()`
    puts them in a file). Always says something - "nothing new" is a real,
    useful answer too, not silence.

    Args:
        reports: This run's device reports.
        new_by_device: `new_cves_since()`'s result.

    Returns:
        The summary text.
    """
    if not new_by_device:
        return "No new CVEs since the last report."
    labels = {r.device.ip_address: (r.device.hostname or r.device.ip_address) for r in reports}
    total = sum(len(ids) for ids in new_by_device.values())
    lines = [f"{total} new CVE(s) since the last report, on {len(new_by_device)} device(s):"]
    for ip, ids in new_by_device.items():
        lines.append(f"  {labels.get(ip, ip)} ({ip}): {len(ids)} new")
    return "\n".join(lines)


# -- Filtered report -------------------------------------------------------


@dataclass(frozen=True)
class ReportCriteria:
    """What a filtered report kept: matches at or above `threshold` (that
    auto-applied) and, within them, CVEs inside `cvss_range`."""

    threshold: float
    cvss_range: CVSSRange


def _filtered_paths(json_report_path: Path) -> tuple[Path, Path]:
    """Name the filtered reports paired with a JSON report.

    Args:
        json_report_path: The JSON report.

    Returns:
        (filtered_report_<timestamp>.json, filtered_report_<timestamp>.txt).
    """
    timestamp = json_report_path.name.removeprefix(_REPORT_PREFIX).removesuffix(_REPORT_SUFFIX)
    base = json_report_path.with_name(f"{_FILTERED_PREFIX}{timestamp}")
    return base.with_suffix(_REPORT_SUFFIX), base.with_suffix(_TEXT_SUFFIX)


def qualifying_matches(report: DeviceReport) -> list[DeviceMatch]:
    """List a device's matches that belong in the filtered reports and memo.

    Those that auto-applied (passed the confidence threshold) and kept at
    least one CVE after the CVSS and version filters.

    Args:
        report: The device's report.

    Returns:
        The qualifying matches, hardware first.
    """
    return [m for m in (report.hardware, report.software) if m.auto_applied and m.vulnerabilities]


def cve_sort_key(entry: dict[str, Any]) -> tuple[int, float, str]:
    """Order reported CVEs: CISA KEV first, then highest CVSS score, then id.

    Args:
        entry: A reported CVE entry.

    Returns:
        A sort key.
    """
    cve = entry["cve"]
    in_kev = bool((entry.get("cisa_kev") or {}).get("in_kev"))
    return (0 if in_kev else 1, -float(cve.get("cvss_score") or 0.0), cve.get("id", ""))


def _criteria_dict(criteria: ReportCriteria) -> dict[str, Any]:
    """Record the criteria a filtered report used.

    Args:
        criteria: The report criteria.

    Returns:
        The threshold and CVSS settings, by their setting names.
    """
    return {
        "match_confidence_threshold": criteria.threshold,
        "cvss_score_min": criteria.cvss_range.minimum,
        "cvss_score_max": criteria.cvss_range.maximum,
        "cvss_include_unscored": criteria.cvss_range.include_unscored,
    }


def to_filtered_json(reports: list[DeviceReport], criteria: ReportCriteria) -> dict[str, Any]:
    """Build the filtered JSON report: only qualifying matches and their CVEs.

    Devices with nothing qualifying are left out.

    Args:
        reports: The device reports.
        criteria: The criteria used.

    Returns:
        {"criteria", "total_cves", "devices"} - each device with its support
        dates and matches (product, CPE, score, source, extra products, CVEs).
    """
    devices: list[dict[str, Any]] = []
    for report in reports:
        matches = qualifying_matches(report)
        if not matches:
            continue
        devices.append(
            {
                "ip_address": report.device.ip_address,
                "hostname": report.device.hostname,
                "network": report.device.network,
                "support": {
                    **report.device.eox_dates(),
                    "past_end_of_support": report.device.end_of_support(),
                },
                "matches": [
                    {
                        "kind": m.kind,
                        "vendor": m.result.best.vendor_name if m.result.best else None,
                        "product": m.result.best.name if m.result.best else None,
                        "cpe": m.result.best.cpe if m.result.best else None,
                        "score": report_score(m.result.best.score) if m.result.best else None,
                        "source": m.source,
                        "also": [{"vendor": p.vendor_name, "product": p.name, "cpe": p.cpe} for p in m.extra_products],
                        "cves": sorted(m.vulnerabilities, key=cve_sort_key),
                    }
                    for m in matches
                ],
            }
        )
    return {
        "criteria": _criteria_dict(criteria),
        "total_cves": sum(len(m.vulnerabilities) for r in reports for m in qualifying_matches(r)),
        "devices": devices,
    }


def cvss_text(criteria: ReportCriteria) -> str:
    """Describe the CVSS settings in words.

    Args:
        criteria: The report criteria.

    Returns:
        e.g. "CVSS 7-10, unscored CVEs excluded" or "any CVSS score, unscored
        CVEs included".
    """
    r = criteria.cvss_range
    if r.minimum is None and r.maximum is None:
        bounds = "any CVSS score"
    else:
        bounds = f"CVSS {r.minimum if r.minimum is not None else 0:g}-{r.maximum if r.maximum is not None else 10:g}"
    return f"{bounds}, unscored CVEs {'included' if r.include_unscored else 'excluded'}"


def cve_title(cve: dict[str, Any]) -> str:
    """Give a CVE's title without the repeated id.

    cvefeed.io titles repeat the id ("CVE-2026-1 - Title") - drop it, and the
    " - [Actively Exploited]" suffix KEV CVEs carry (the KEV flag says so).

    Args:
        cve: The CVE as in a product list.

    Returns:
        The title.
    """
    title = (cve.get("title") or "").strip()
    prefix = f"{cve.get('id', '')} - "
    title = title[len(prefix) :] if title.startswith(prefix) else title
    # KEV CVEs' titles end with this; the [KEV] flag already says so.
    return title.removesuffix(" - [Actively Exploited]")


def cve_flags(entry: dict[str, Any]) -> list[str]:
    """Give the bracketed flags shown after a CVE: in CISA KEV, version confirmed.

    Args:
        entry: A reported CVE entry.

    Returns:
        The flags that apply, e.g. ["KEV", "version confirmed"].
    """
    flags = []
    if (entry.get("cisa_kev") or {}).get("in_kev"):
        flags.append("KEV")
    if entry.get("version_status") == "confirmed":
        flags.append("version confirmed")
    return flags


def format_device_text(report: DeviceReport) -> str:
    """Build one device's section of the filtered text report.

    (Until the memo got its own format, this text was also what went to the
    device's LogicVein memo; lvi_memo.py builds that now.)

    Args:
        report: The device's report.

    Returns:
        The section, or "" if nothing qualified.
    """
    matches = qualifying_matches(report)
    if not matches:
        return ""
    device = report.device
    lines = [f"{device.hostname or device.ip_address} ({device.ip_address})"]
    support = device.end_of_support()
    if support:
        lines.append(f"  {END_OF_SUPPORT_NOTE.format(support)}")
    for m in matches:
        best = m.result.best
        assert best is not None  # auto-applied matches always have one
        pinned = ", from CPE field" if m.source == "cpe_field" else ""
        pinned += ", unverified product match" if m.unverified else ""
        kev = sum(1 for v in m.vulnerabilities if (v.get("cisa_kev") or {}).get("in_kev"))
        lines.append(
            f"  {m.kind.capitalize()}: {matched_products(m)} " f"(confidence {report_score(best.score):.2f}{pinned})"
        )
        for cpe in (best.cpe, *(p.cpe for p in m.extra_products)):
            if cpe:
                lines.append(f"    {cpe}")
        lines.append(
            f"    {len(m.vulnerabilities)} CVE(s)" + (f", {kev} in CISA KEV (actively exploited)" if kev else "")
        )
        for entry in sorted(m.vulnerabilities, key=cve_sort_key):
            cve = entry["cve"]
            score = cve.get("cvss_score")
            severity = cve.get("severity") or ""
            scored = (
                f"{severity} {float(score):.1f}" if severity not in ("", "NA") and score is not None else "not scored"
            )
            flags = cve_flags(entry)
            flag_text = f" [{', '.join(flags)}]" if flags else ""
            lines.append(f"    - {cve.get('id', '?')}  {scored}{flag_text}  {cve_title(cve)}")
            lines += [f"        {label}: {url}" for label, url in link_list(entry)]
    return "\n".join(lines)


def format_filtered_text(reports: list[DeviceReport], criteria: ReportCriteria, generated_at: datetime) -> str:
    """Build the filtered text report: a header with the criteria and totals, then each device.

    Args:
        reports: The device reports.
        criteria: The criteria used.
        generated_at: When the run happened.

    Returns:
        The report text.
    """
    sections = [text for text in (format_device_text(r) for r in reports) if text]
    total = sum(len(m.vulnerabilities) for r in reports for m in qualifying_matches(r))
    kev = sum(
        1
        for r in reports
        for m in qualifying_matches(r)
        for v in m.vulnerabilities
        if (v.get("cisa_kev") or {}).get("in_kev")
    )
    header = [
        f"CVE report - {generated_at.strftime('%Y-%m-%d %H:%M UTC')}",
        f"Criteria: match confidence {criteria.threshold:.2f} or higher; {cvss_text(criteria)}",
        f"{len(sections)} device(s), {total} CVE(s), {kev} in CISA KEV (actively exploited)",
    ]
    body = sections or ["No device has a match and CVEs meeting these criteria."]
    return "\n".join(header) + "\n\n" + "\n\n".join(body) + "\n"


def report_run_time(json_report_path: Path) -> datetime:
    """Read when a run happened from its report's filename timestamp.

    Args:
        json_report_path: A cve_report_<timestamp>.json path.

    Returns:
        The run's time (UTC).
    """
    stamp = json_report_path.name.removeprefix(_REPORT_PREFIX).removesuffix(_REPORT_SUFFIX)
    return datetime.strptime(stamp, _TIMESTAMP_FORMAT).replace(tzinfo=timezone.utc)


def write_filtered_reports(
    reports: list[DeviceReport], json_report_path: Path, criteria: ReportCriteria
) -> tuple[Path, Path]:
    """Write the filtered JSON and text reports beside the run's full JSON report.

    They share its timestamp and are rotated out with it. Not named
    `cve_report_...`, so find_latest_report() never takes them for a full
    report.

    Args:
        reports: The device reports.
        json_report_path: The run's JSON report.
        criteria: The criteria used.

    Returns:
        (filtered JSON path, filtered text path).
    """
    json_path, text_path = _filtered_paths(json_report_path)
    json_path.write_text(json.dumps(to_filtered_json(reports, criteria), indent=2, default=str), encoding="utf-8")
    text_path.write_text(format_filtered_text(reports, criteria, report_run_time(json_report_path)), encoding="utf-8")
    return json_path, text_path
