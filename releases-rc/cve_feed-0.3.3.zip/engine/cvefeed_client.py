"""Client for the cvefeed.io API.

Verified against the live OpenAPI schema at https://cvefeed.io/api/schema/
(human-readable docs at https://cvefeed.io/api/docs/, login required) and a
real account's token. See docs/CVEFEED_API.md for the full endpoint
reference this was written against.

Auth: `Authorization: Bearer <token>`, where the token has the form
`cvefeed_XXXXXXXX_...` (a per-project API token, created in the CVEFeed.io
dashboard under a project's API tokens settings - there is no API endpoint
to list or discover a project's own id or tokens without already having
one). Endpoints marked PRO in docs/CVEFEED_API.md return an authenticated
but paid-tier error for accounts below that subscription tier; this was
verified working against an account with PRO access - a lower-tier account
may see failures on those specific calls.

Rate limiting: cvefeed.io throttles (`HTTP 429`, confirmed repeatedly - see
docs/ARCHITECTURE.md/docs/CVEFEED_API.md) with no documented window/quota
and, per manual header inspection, no `Retry-After` header on the 429
either - the only signal at all is the response body's own English text
(`{"detail": "Request was throttled. Expected available in N seconds."}`).
`_request()` retries a 429 by parsing that text, falling back to a fixed
wait if the text doesn't match (API wording could change) - see
`_retry_after()`. Every other error status still raises immediately;
retrying a 429 is safe (the request never went through), retrying anything
else risks a duplicate side effect for no good reason.

Network failures (connection reset, timeout) are retried too, with
exponential backoff - but only for GET, which is safe to repeat; a POST
that may or may not have reached the server is not. Found live
(2026-10-01): a long first `sync` against an empty CVE cache (see
cve_cache.py) died 25 minutes in on a single "Connection reset by peer".
Once retries run out a network failure raises `CVEFeedAPIError` like any
other failed request, so callers that already tolerate one (a failed
per-CVE version lookup is kept as "unknown") tolerate this too. Every
request also has a timeout - without one, a stalled connection could hang a
run indefinitely.
"""

import logging
import re
import time
from typing import Any

import requests

logger = logging.getLogger(__name__)

BASE_URL = "https://cvefeed.io"
# How much of an error response body to log and carry in the raised error:
# the head, where an API's message sits; a body can run to many KB.
_ERROR_BODY_CHARS = 500

# "Request was throttled. Expected available in 27 seconds." - the only
# place the actual wait time is exposed (see module docstring).
_RETRY_AFTER_TEXT = re.compile(r"available in\s+(\d+(?:\.\d+)?)\s*seconds?", re.I)
_IDEMPOTENT_METHODS = {"GET"}
_REQUEST_TIMEOUT_SECONDS = 30.0


class CVEFeedAPIError(Exception):
    """Raised when the cvefeed.io API returns an error response."""


class CVEFeedClient:
    def __init__(
        self,
        api_key: str,
        base_url: str = BASE_URL,
        verify_ssl: bool = True,
        max_retries: int = 5,
        max_wait_seconds: float = 60.0,
    ) -> None:
        """Set up the client; no request is made until the first call.

        Args:
            api_key: The cvefeed.io API key, sent as a bearer token.
            base_url: The API's base URL.
            verify_ssl: Whether to verify the server's TLS certificate.
            max_retries: How many times to retry a 429, or a connection failure on
                an idempotent request, before giving up.
            max_wait_seconds: The longest single wait between retries.
        """
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._session = requests.Session()
        self._session.verify = verify_ssl
        self._max_retries = max_retries
        self._max_wait_seconds = max_wait_seconds

    def _sleep(self, seconds: float) -> None:
        """Wait between retries. A subclass overrides it to make the wait
        interruptible (the plugin's Cancel Sync).

        Args:
            seconds: How long to wait.
        """
        time.sleep(seconds)

    def _retry_after(self, response: requests.Response) -> float:
        """Work out how long to wait before retrying a 429, best-effort.

        Prefers a standard `Retry-After` header, in case a future response
        actually carries one (none has been seen live so far - see module
        docstring). Falls back to parsing the throttle message's own text, and
        finally to a fixed guess if neither is present or parses - always a real,
        if imperfect, number, never a failure to retry at all just because the
        wait time is unknown.

        Args:
            response: The 429 response.

        Returns:
            Seconds to wait.
        """
        header = response.headers.get("Retry-After")
        if header:
            try:
                return float(header)
            except ValueError:
                pass
        try:
            detail = response.json().get("detail", "")
        except ValueError:
            detail = ""
        match = _RETRY_AFTER_TEXT.search(detail)
        if match:
            return float(match.group(1))
        return 5.0  # unparseable message: a short guess beats not retrying

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        """Send one API request, retrying rate limits and dropped connections.

        A 429 is retried after the wait _retry_after() works out; a connection
        reset or timeout is retried with exponential backoff, but only for
        idempotent methods. Both are capped at max_retries attempts and
        max_wait_seconds per wait.

        Args:
            method: The HTTP method.
            path: The API path, e.g. "/api/product/".
            **kwargs: Passed on to requests (params, json, headers, ...).

        Returns:
            The JSON response.

        Raises:
            CVEFeedAPIError: A connection failure that can't be retried, or any
                unsuccessful response once retries are used up.
        """
        headers = kwargs.pop("headers", {})
        headers.setdefault("Authorization", f"Bearer {self._api_key}")
        url = f"{self._base_url}/{path.lstrip('/')}"
        attempt = 0
        while True:
            try:
                response = self._session.request(
                    method, url, headers=headers, timeout=_REQUEST_TIMEOUT_SECONDS, **kwargs
                )
            except (requests.ConnectionError, requests.Timeout) as exc:
                if method.upper() in _IDEMPOTENT_METHODS and attempt < self._max_retries:
                    attempt += 1
                    self._sleep(min(2.0**attempt, self._max_wait_seconds))
                    continue
                # Warning, not error: the engine keeps going past some failed
                # fetches (a CVE's detail, its advisory links).
                logger.warning("Request error: %s", exc)
                raise CVEFeedAPIError(f"{method} {path} failed: {exc}") from exc
            if response.status_code == 429 and attempt < self._max_retries:
                wait = min(self._retry_after(response), self._max_wait_seconds)
                attempt += 1
                self._sleep(wait)
                continue
            if not response.ok:
                body = response.text[:_ERROR_BODY_CHARS]
                logger.warning("HTTP error: %s - %s", response.status_code, body)
                raise CVEFeedAPIError(f"{method} {path} failed: HTTP {response.status_code}: {body}")
            return response.json()

    def _get(self, path: str, **params: Any) -> dict[str, Any]:
        """GET an API path, leaving out parameters that are None.

        Args:
            path: The API path.
            **params: Query parameters; None values are dropped.

        Returns:
            The JSON response.

        Raises:
            CVEFeedAPIError: From _request(), when the request fails.
        """
        params = {k: v for k, v in params.items() if v is not None}
        return self._request("GET", path, params=params)

    # -- Vendor --------------------------------------------------------

    def list_vendors(
        self, name: str | None = None, part: str | None = None, starts_with: str | None = None, page: int | None = None
    ) -> dict[str, Any]:
        """List vendors (`/api/vendor/`).

        Args:
            name: Filter by name (substring).
            part: 'a' (application), 'o' (operating system), or 'h' (hardware).
            starts_with: Filter by name prefix.
            page: The page to fetch (10 results per page, fixed by cvefeed.io), or None for the first.

        Returns:
            The JSON response.

        Raises:
            CVEFeedAPIError: From _request(), when the request fails.
        """
        return self._get("/api/vendor/", name=name, part=part, starts_with=starts_with, page=page)

    def get_vendor(self, vendor_id: int) -> dict[str, Any]:
        """Get one vendor (`/api/vendor/{id}/`).

        Args:
            vendor_id: The cvefeed.io vendor id.

        Returns:
            The JSON response.

        Raises:
            CVEFeedAPIError: From _request(), when the request fails.
        """
        return self._get(f"/api/vendor/{vendor_id}/")

    def list_vendor_products(self, vendor_id: int, page: int | None = None) -> dict[str, Any]:
        """List a vendor's products (`/api/vendor/{id}/products/`).

        This list has no name filter, so for a big vendor page 1 is an arbitrary slice (see matcher.py).

        Args:
            vendor_id: The cvefeed.io vendor id.
            page: The page to fetch (10 results per page, fixed by cvefeed.io), or None for the first.

        Returns:
            The JSON response.

        Raises:
            CVEFeedAPIError: From _request(), when the request fails.
        """
        return self._get(f"/api/vendor/{vendor_id}/products/", page=page)

    def list_vendors_by_cpe(self, cpe: str, page: int | None = None) -> dict[str, Any]:
        """List the vendors a CPE names (`/api/vendor/list-by-cpe`). PRO tier.

        Args:
            cpe: A CPE 2.3 string.
            page: The page to fetch (10 results per page, fixed by cvefeed.io), or None for the first.

        Returns:
            The JSON response.

        Raises:
            CVEFeedAPIError: From _request(), when the request fails.
        """
        return self._get("/api/vendor/list-by-cpe", cpe=cpe, page=page)

    # -- Product ---------------------------------------------------------

    def list_products(
        self,
        name: str | None = None,
        starts_with: str | None = None,
        vendor_type: str | None = None,
        page: int | None = None,
    ) -> dict[str, Any]:
        """Search products by name (`/api/product/`).

        Args:
            name: Full-text name search, e.g. "Cisco 2500".
            starts_with: Filter by name prefix.
            vendor_type: 'a' (application), 'o' (operating system), or 'h' (hardware).
            page: The page to fetch (10 results per page, fixed by cvefeed.io), or None for the first.

        Returns:
            The JSON response.

        Raises:
            CVEFeedAPIError: From _request(), when the request fails.
        """
        return self._get("/api/product/", name=name, starts_with=starts_with, vendor_type=vendor_type, page=page)

    def get_product(self, product_id: int) -> dict[str, Any]:
        """Get one product (`/api/product/{id}/`).

        Args:
            product_id: The cvefeed.io product id.

        Returns:
            The JSON response.

        Raises:
            CVEFeedAPIError: From _request(), when the request fails.
        """
        return self._get(f"/api/product/{product_id}/")

    def list_product_vulnerabilities(self, product_id: int, page: int | None = None) -> dict[str, Any]:
        """List a product's CVEs (`/api/product/{id}/vulnerabilities/`).

        Args:
            product_id: The cvefeed.io product id.
            page: The page to fetch (10 results per page, fixed by cvefeed.io), or None for the first.

        Returns:
            The JSON response.

        Raises:
            CVEFeedAPIError: From _request(), when the request fails.
        """
        return self._get(f"/api/product/{product_id}/vulnerabilities/", page=page)

    def list_products_by_cpe(self, cpe: str, page: int | None = None) -> dict[str, Any]:
        """Find the catalog product a CPE names (`/api/product/list-by-cpe`). PRO tier.

        Args:
            cpe: A CPE 2.3 string; the version part is ignored by cvefeed.io.
            page: The page to fetch (10 results per page, fixed by cvefeed.io), or None for the first.

        Returns:
            The JSON response.

        Raises:
            CVEFeedAPIError: From _request(), when the request fails.
        """
        return self._get("/api/product/list-by-cpe", cpe=cpe, page=page)

    # -- Vulnerability -----------------------------------------------------

    def list_vulnerabilities(
        self,
        id: str | None = None,
        product_id: int | None = None,
        product_name: str | None = None,
        severity: str | None = None,
        cvss_score_min: float | None = None,
        cvss_score_max: float | None = None,
        status: str | None = None,
        is_rejected: bool | None = None,
        is_remote: bool | None = None,
        source_identifier: str | None = None,
        published_after: str | None = None,
        published_before: str | None = None,
        last_modified_after: str | None = None,
        last_modified_before: str | None = None,
        cisa_date_added_after: str | None = None,
        cisa_date_added_before: str | None = None,
        known_ransomware_campaign_use: str | None = None,
        ransomware_known_since_after: str | None = None,
        ransomware_known_since_before: str | None = None,
        page: int | None = None,
    ) -> dict[str, Any]:
        """List CVEs matching filters (`/api/vulnerability/`).

        Results come newest-published first; each carries `cisa_kev_detail`.

        Args:
            id: A CVE id.
            product_id: A cvefeed.io product id.
            product_name: A product name.
            severity: One of CRITICAL, HIGH, MEDIUM, LOW.
            cvss_score_min: Lowest CVSS score.
            cvss_score_max: Highest CVSS score.
            status: NVD status, e.g. "Analyzed".
            is_rejected: Rejected CVEs only (or not).
            is_remote: Remotely exploitable only (or not).
            source_identifier: The CVE's source, e.g. "psirt@cisco.com".
            published_after: ISO 8601 date.
            published_before: ISO 8601 date.
            last_modified_after: ISO 8601 date - used for incremental refresh.
            last_modified_before: ISO 8601 date.
            cisa_date_added_after: ISO 8601 date (CISA KEV).
            cisa_date_added_before: ISO 8601 date (CISA KEV).
            known_ransomware_campaign_use: CISA KEV's ransomware flag.
            ransomware_known_since_after: ISO 8601 date.
            ransomware_known_since_before: ISO 8601 date.
            page: The page to fetch (10 results per page, fixed by cvefeed.io), or None for the first.

        Returns:
            The JSON response.

        Raises:
            CVEFeedAPIError: From _request(), when the request fails.
        """
        return self._get(
            "/api/vulnerability/",
            id=id,
            product_id=product_id,
            product_name=product_name,
            severity=severity,
            cvss_score_min=cvss_score_min,
            cvss_score_max=cvss_score_max,
            status=status,
            is_rejected=is_rejected,
            is_remote=is_remote,
            source_identifier=source_identifier,
            published_after=published_after,
            published_before=published_before,
            last_modified_after=last_modified_after,
            last_modified_before=last_modified_before,
            cisa_date_added_after=cisa_date_added_after,
            cisa_date_added_before=cisa_date_added_before,
            known_ransomware_campaign_use=known_ransomware_campaign_use,
            ransomware_known_since_after=ransomware_known_since_after,
            ransomware_known_since_before=ransomware_known_since_before,
            page=page,
        )

    def get_vulnerability(self, cve_id: str) -> dict[str, Any]:
        """Get one CVE's full detail (`/api/vulnerability/{id}/`).

        Args:
            cve_id: The CVE id.

        Returns:
            The detail, including `configurations` and `references`, which list responses lack.

        Raises:
            CVEFeedAPIError: From _request(), when the request fails.
        """
        return self._get(f"/api/vulnerability/{cve_id}/")

    def get_vulnerability_change_history(self, cve_id: str, page: int | None = None) -> dict[str, Any]:
        """Get one CVE's change history (`/api/vulnerability/{id}/change-history/`).

        Args:
            cve_id: The CVE id.
            page: The page to fetch (10 results per page, fixed by cvefeed.io), or None for the first.

        Returns:
            The JSON response.

        Raises:
            CVEFeedAPIError: From _request(), when the request fails.
        """
        return self._get(f"/api/vulnerability/{cve_id}/change-history/", page=page)

    def list_vulnerabilities_by_cpe(self, cpe: str, page: int | None = None) -> dict[str, Any]:
        """List the CVEs for a CPE (`/api/vulnerability/list-by-cpe`). PRO tier.

        Args:
            cpe: A CPE 2.3 string.
            page: The page to fetch (10 results per page, fixed by cvefeed.io), or None for the first.

        Returns:
            The JSON response.

        Raises:
            CVEFeedAPIError: From _request(), when the request fails.
        """
        return self._get("/api/vulnerability/list-by-cpe", cpe=cpe, page=page)

    # -- CVEQL (cvefeed.io's own CVE query language) ------------------------

    def cveql_search(self, query: str, page: int | None = None, page_size: int | None = None) -> dict[str, Any]:
        """Run a CVEQL query (cvefeed.io's own CVE query language).

        Args:
            query: The CVEQL query.
            page: The page to fetch, or None for the first.
            page_size: Results per page, or None for the API's default.

        Returns:
            The JSON response.

        Raises:
            CVEFeedAPIError: From _request(), when the request fails.
        """
        body: dict[str, Any] = {"query": query}
        if page is not None:
            body["page"] = page
        if page_size is not None:
            body["page_size"] = page_size
        return self._request("POST", "/api/cveql/search/", json=body)

    def cveql_validate(self, query: str) -> dict[str, Any]:
        """Check a CVEQL query without running it.

        Args:
            query: The CVEQL query.

        Returns:
            The JSON response.

        Raises:
            CVEFeedAPIError: From _request(), when the request fails.
        """
        return self._request("POST", "/api/cveql/validate/", json={"query": query})

    def cveql_suggestions(self, field: str, search: str | None = None, page: int | None = None) -> dict[str, Any]:
        """Get value suggestions for a CVEQL field.

        Args:
            field: The CVEQL field.
            search: Text to narrow the suggestions, or None.
            page: The page to fetch (10 results per page, fixed by cvefeed.io), or None for the first.

        Returns:
            The JSON response.

        Raises:
            CVEFeedAPIError: From _request(), when the request fails.
        """
        return self._get("/api/cveql/suggestions/", field=field, search=search, page=page)

    def cveql_introspect(self) -> dict[str, Any]:
        """Describe CVEQL's fields and operators.

        Returns:
            The JSON response.

        Raises:
            CVEFeedAPIError: From _request(), when the request fails.
        """
        return self._get("/api/cveql/introspect/")
