"""Decides whether a specific device version is covered by a CVE's affected-version data.

Motivation: `report.py` matches a device to a cvefeed.io *product* (e.g.
"Cisco Ios") and, today, reports every CVE ever filed against that product -
a device on IOS 12.3(13a) sees the identical list as one on IOS 15.x, even
though many CVEs only affect specific version ranges. This module adds the
missing piece: per-CVE, per-device version applicability.

The data comes from `/api/vulnerability/{id}/`'s `configurations` field -
NOT present on the lighter list responses (`list_product_vulnerabilities()`
returns `BaseVulnerability`, with no `configurations`), so using this means
one extra API request per CVE. Verified live (2026-09-14) against
CVE-2024-3094 (the xz backdoor):

    "configurations": [{"nodes": [{"cpeMatch": [
        {"criteria": "cpe:2.3:a:tukaani:xz:5.6.0:*:*:*:*:*:*:*", "vulnerable": true},
        {"criteria": "cpe:2.3:a:tukaani:xz:5.6.1:*:*:*:*:*:*:*", "vulnerable": true},
    ]}]}]

- also confirmed live that plenty of CVEs carry `"configurations": {}` (empty
  - e.g. CVE-2026-20311, a Cisco PSIRT advisory) with no version data at all.

Platforms too (`applicability()`, added 2026-10-06): NVD combines entries
with AND/OR - e.g. CVE-2020-3426 is "Cisco IOS (any version) AND running on
an 807/809/829 industrial ISR or a 1120/1240 CGR". Hardware (`h`) entries
are platform conditions, checked against the device's `Platform` (its
applied hardware match and LogicVein model strings), so that CVE is
excluded on a Catalyst 2950 - with the reason recorded. Each condition is
three-valued (true / false / unknown), and unknown never excludes.

Deliberately conservative: this is security tooling, and a false
"not_applicable" (hiding a CVE that does apply) is a worse failure than a
false "unknown" (keeping one that didn't need review). Every path that can't
resolve cleanly returns "unknown" rather than guessing - see
`applicability()`'s docstring for the three-way outcome and exactly what
"resolves cleanly" means.
"""

import re
from collections.abc import Collection
from dataclasses import dataclass, replace
from typing import Any, Literal

from .matcher import normalize

VersionStatus = Literal["confirmed", "not_applicable", "unknown"]
# True / False / None (unknown) - the value of one condition.
_Tri = bool | None
_MODEL_NUMBER = re.compile(r"\d{3,}")


@dataclass(frozen=True)
class Platform:
    """What a device is, for NVD's hardware conditions: names from its
    applied hardware match (CPE product token, catalog name) and the model
    strings LogicVein reports. More names only make a match more likely -
    never an exclusion - so noisy ones (an SNMP part number) are harmless."""

    names: tuple[str, ...]

    def matches(self, cpe_product: str) -> _Tri:
        """Whether this device could be the NVD hardware product `cpe_product`.

        True on an exact name or a shared model number - a family number like
        "2900" covers "2911" - False only when both sides have model numbers and
        none fit, otherwise None.

        Args:
            cpe_product: The CPE's product token, e.g.
                "807_industrial_integrated_services_router".

        Returns:
            True, False, or None (can't tell).
        """
        if cpe_product.lower() in {name.lower() for name in self.names}:
            return True
        theirs = set(_MODEL_NUMBER.findall(cpe_product))
        ours = {number for name in self.names for number in _MODEL_NUMBER.findall(name)}
        if not theirs or not ours:
            return None
        return any(_same_model(mine, listed) for mine in ours for listed in theirs)


def _same_model(device_number: str, listed: str) -> bool:
    """Whether a device's model number is a listed one, or in a listed family.

    "2900" is a family (the 2900 series) covering "2911": a trailing-zero
    number of the same length whose leading digits match.

    Args:
        device_number: The device's model number, e.g. "2911".
        listed: A model number from NVD's data, e.g. "2900".

    Returns:
        True if they match.
    """
    if device_number == listed:
        return True
    family = listed.rstrip("0")  # "2900" -> "29": the 2900 series
    return family != listed and len(device_number) == len(listed) and device_number.startswith(family)


@dataclass(frozen=True)
class Applicability:
    """A CVE's verdict for one device. `reason` says what excluded a
    "not_applicable" CVE - "version" or "platform" - and `platforms` lists
    the NVD hardware it's limited to, as evidence."""

    status: VersionStatus
    reason: str | None = None
    platforms: tuple[str, ...] = ()


# Dotted numbers with at most one trailing letter - a release train or
# rebuild label on the same numbered release: Arista "4.33.6M", IOS XE
# "17.15.4d". Anything else ("12.3(13a)", "25.4R1.12") stays unparsed.
_NUMERIC_VERSION = re.compile(r"^(\d+(?:\.\d+)*)([A-Za-z])?$")
_RANGE_KEYS = ("versionStartIncluding", "versionStartExcluding", "versionEndIncluding", "versionEndExcluding")


def _parse_numeric(version: str) -> tuple[tuple[int, ...], str] | None:
    """Parse a dotted-numeric version as (comparable tuple, trailing letter or "").

    "5.6.0" -> ((5, 6, 0), ""), "4.33.6M" -> ((4, 33, 6), "m"). None for
    anything else. Deliberately strict: this project's own device inventory
    has version strings like "12.3(13a)" or "wired-18-1-07" (see
    device_inventory.py) that are not safely comparable as numeric ranges -
    parsing those loosely (e.g. stripping the "(13a)") would compare the
    wrong thing and could produce a wrong verdict silently. A single trailing
    letter is the exception: it labels a build of the same numbered release,
    so the number orders it against any *other* number (see `_compare()` for
    equal ones).

    Args:
        version: The version text.

    Returns:
        (tuple of numbers, lowercase letter or ""), or None.
    """
    match = _NUMERIC_VERSION.match(version)
    if not match:
        return None
    return tuple(int(part) for part in match.group(1).split(".")), (match.group(2) or "").lower()


def _compare(device: tuple[tuple[int, ...], str], bound: tuple[tuple[int, ...], str]) -> int | None:
    """Order a device version against a bound.

    When the same number carries different letters ("4.33.6M" against
    "4.33.6"), whether a train or rebuild letter sorts before or after is
    vendor specific, so that's left unresolved rather than guessed.

    Args:
        device: The device's parsed version.
        bound: The bound's parsed version.

    Returns:
        -1 / 0 / 1 for device below / equal to / above bound, or None when
        the same number carries different letters.
    """
    if device[0] != bound[0]:
        return -1 if device[0] < bound[0] else 1
    return 0 if device[1] == bound[1] else None


def _cpe_version(criteria: str) -> str | None:
    """Take the version field (6th colon-separated segment) of a CPE 2.3 URI.

    E.g. "cpe:2.3:a:tukaani:xz:5.6.0:*:*:*:*:*:*:*" -> "5.6.0".

    Args:
        criteria: A CPE 2.3 URI.

    Returns:
        The version field, or None if the URI is too short.
    """
    parts = criteria.split(":")
    return parts[5] if len(parts) > 5 else None


def _match_status(device_version: str | None, match: dict[str, Any]) -> Literal["confirmed", "not_applicable"] | None:
    """Resolve one software cpeMatch entry against device_version.

    A range is checked bound by bound; an exact version must equal the
    device's (by number when both parse, else as text - and then a different
    string proves nothing, since NVD's exact lists for such products are often
    release trains or incomplete). A "*" or "-" version with no range covers
    any version.

    Args:
        device_version: The device's version, or None.
        match: One cpeMatch entry.

    Returns:
        "confirmed" or "not_applicable" - or None, not a status, when this
        specific entry can't be resolved (no device version, or a range bound
        or the device version isn't cleanly numeric): "this entry has nothing
        to say", not "not applicable", since other entries in the same CVE may
        still resolve.
    """
    criteria = match.get("criteria", "")
    cpe_version = _cpe_version(criteria)
    range_bounds = {key: match[key] for key in _RANGE_KEYS if key in match}

    if range_bounds:
        device_tuple = _parse_numeric(device_version or "")
        if device_tuple is None:
            return None
        for key, value in range_bounds.items():
            bound = _parse_numeric(str(value))
            if bound is None:
                return None
            order = _compare(device_tuple, bound)
            if order is None:
                return None
            if key == "versionStartIncluding" and not order >= 0:
                return "not_applicable"
            if key == "versionStartExcluding" and not order > 0:
                return "not_applicable"
            if key == "versionEndIncluding" and not order <= 0:
                return "not_applicable"
            if key == "versionEndExcluding" and not order < 0:
                return "not_applicable"
        return "confirmed"

    if cpe_version in (None, "*", "-"):
        # No specific version pin and no range: this criteria applies to any
        # version of the product.
        return "confirmed"

    if not device_version:
        return None
    device_parsed, cpe_parsed = _parse_numeric(device_version), _parse_numeric(cpe_version)
    if device_parsed is not None and cpe_parsed is not None:
        order = _compare(device_parsed, cpe_parsed)
        return None if order is None else ("confirmed" if order == 0 else "not_applicable")
    # Either side isn't a plain number ("12.4(6)T", "25.4R1.12", "12.4mda"):
    # the same string confirms, but a different one proves nothing. NVD's
    # exact-version lists for such products are often release trains or
    # incomplete - verified live (2026-10-06): 62 CVEs that Cisco's own
    # advisories list for IOS 12.4(6)T were excluded because NVD pinned
    # only "12.4mda", "12.2yd" and the like.
    device_norm, cpe_norm = normalize(device_version), normalize(cpe_version)
    if not device_norm or not cpe_norm:
        return None
    return "confirmed" if device_norm == cpe_norm else None


def version_status(device_version: str | None, configurations: Any) -> VersionStatus:
    """Run `applicability()` with no platform information - version only.

    Args:
        device_version: The device's version, or None.
        configurations: The CVE's NVD `configurations`.

    Returns:
        "confirmed", "not_applicable" or "unknown".
    """
    return applicability(device_version, configurations).status


def applicability(
    device_version: str | None,
    configurations: Any,
    platform: Platform | None = None,
    products: Collection[tuple[str, str]] | None = None,
) -> Applicability:
    """Whether a CVE's NVD `configurations` cover this device.

    - "confirmed": some configuration is satisfied - its software entries
      cover `device_version` and any platform conditions match `platform`.
    - "not_applicable": every configuration is definitely unsatisfied. The
      reason is "platform" when the version alone would not have ruled it out
      (re-evaluated with every platform condition taken as met), else
      "version".
    - "unknown": anything else - no data, an entry that can't be resolved, an
      OS or application context condition ("running with X"), or platform
      conditions with no `platform` to check them against.

    With `products`, only software entries for those products count: a CVE's
    configurations often list several products (CVE-2025-25255 has FortiProxy
    7.0.1 to <7.6.4 beside FortiOS 7.6.0 to <7.6.4), and another product's
    version range says nothing about this device - without this, a FortiOS
    7.4.3 was "confirmed" by FortiProxy's range. A range for another product
    is simply not a match. A CVE with no entry for any of the products at
    all is "unknown", never an exclusion: the product may be catalogued under
    a different name.

    Args:
        device_version: The device's version, or None.
        configurations: The CVE's NVD `configurations` (from the per-CVE
            detail).
        platform: The device's platform, or None.
        products: The (vendor, product) pairs the device's software was
            matched to - from their CPEs, e.g. ("fortinet", "fortios") - or
            None to count every product's entries.

    Returns:
        The verdict, with the reason and the NVD hardware it's limited to for
        a platform exclusion.
    """
    if not configurations or not isinstance(configurations, list):
        return Applicability("unknown")
    wanted = (
        None
        if products is None
        else frozenset(same for same in (_same_product(pair) for pair in products) if same is not None)
    )
    if wanted is not None and not _names_a_product(configurations, wanted):
        return Applicability("unknown")
    subject = _Subject(device_version, platform, wanted)
    verdict = _any_config(configurations, subject)
    if verdict is True:
        return Applicability("confirmed")
    if verdict is None:
        return Applicability("unknown")
    if _any_config(configurations, replace(subject, platforms_met=True)) is False:
        return Applicability("not_applicable", "version")
    return Applicability("not_applicable", "platform", _hardware_products(configurations))


@dataclass(frozen=True)
class _Subject:
    """What a CVE's configurations are evaluated for: the device's version and
    platform, the products its software matched (None: any), and whether to
    take every platform condition as met (to tell platform from version)."""

    version: str | None
    platform: Platform | None
    products: frozenset[tuple[str, str]] | None
    platforms_met: bool = False


def cpe_product(criteria: str) -> tuple[str, str] | None:
    """Read the (vendor, product) from a CPE 2.3 criteria string.

    Args:
        criteria: e.g. "cpe:2.3:o:fortinet:fortios:*:*:...".

    Returns:
        ("fortinet", "fortios"), or None if the string is too short.
    """
    parts = criteria.split(":")
    return (parts[3].lower(), parts[4].lower()) if len(parts) > 4 else None


def _same_product(pair: tuple[str, str] | None) -> tuple[str, str] | None:
    """Reduce a (vendor, product) pair to what identifies it across spellings.

    The catalog's CPE and NVD's write the same product differently:
    `palo_alto_networks` and `paloaltonetworks`, `fabric_engine_voss` and
    `fabric_engine_\\(voss\\)`. Only letters and digits are compared.

    Args:
        pair: A (vendor, product) pair from `cpe_product`, or None.

    Returns:
        The pair with everything but lowercase letters and digits removed,
        or None if `pair` is None.
    """
    if pair is None:
        return None
    return tuple(re.sub(r"[^a-z0-9]", "", name) for name in pair)  # type: ignore[return-value]


def _names_a_product(configurations: list[Any], products: frozenset[tuple[str, str]]) -> bool:
    """Whether any software entry in the configurations is for one of the products.

    Args:
        configurations: The CVE's NVD `configurations`.
        products: The (vendor, product) pairs to look for.

    Returns:
        True if some non-hardware entry, vulnerable or not, names one.
    """
    return any(
        _same_product(cpe_product(match.get("criteria", ""))) in products
        for config in configurations
        if isinstance(config, dict)
        for node in _all_nodes(config.get("nodes", []))
        for match in node.get("cpeMatch", [])
        if match.get("criteria", "").split(":")[2:3] != ["h"]
    )


def _any_config(configurations: list[Any], subject: _Subject) -> _Tri:
    """Evaluate configurations: a CVE applies if any configuration does.

    Args:
        configurations: The CVE's NVD `configurations`.
        subject: What they're evaluated for.

    Returns:
        True, False, or None (unknown).
    """
    return _either(
        _negated(
            c,
            _combine(c.get("operator"), [_node(n, subject, _is_and(c)) for n in c.get("nodes", [])]),
        )
        for c in configurations
        if isinstance(c, dict)
    )


def _node(node: dict[str, Any], subject: _Subject, in_and: bool) -> _Tri:
    """Evaluate one node: its entries and children, combined by its operator.

    Args:
        node: An NVD configuration node.
        subject: What it's evaluated for.
        in_and: Whether an enclosing configuration or node is an AND - then a
            non-vulnerable software entry is a condition, not a listing.

    Returns:
        True, False, or None (unknown), after the node's `negate`.
    """
    in_and = in_and or _is_and(node)
    values = [_entry(m, subject, in_and) for m in node.get("cpeMatch", [])]
    values += [_node(child, subject, in_and) for child in node.get("children", [])]
    return _negated(node, _combine(node.get("operator"), values))


def _is_and(item: dict[str, Any]) -> bool:
    """Whether a configuration or node combines with AND (OR if unset).

    Args:
        item: An NVD configuration or node.

    Returns:
        True for AND.
    """
    return (item.get("operator") or "OR").upper() == "AND"


def _entry(match: dict[str, Any], subject: _Subject, in_and: bool) -> _Tri:
    """Evaluate one cpeMatch entry.

    A hardware entry is a platform condition, checked against the platform.
    A non-vulnerable software entry under an AND is a "running with"
    condition (unknown); in a plain list it just names something that isn't
    vulnerable (false). A vulnerable software entry for a product the device
    wasn't matched to is false. Any other software entry is resolved against
    the version.

    Args:
        match: One cpeMatch entry.
        subject: What it's evaluated for.
        in_and: Whether an enclosing configuration or node is an AND.

    Returns:
        True, False, or None (unknown).
    """
    parts = match.get("criteria", "").split(":")
    if len(parts) > 4 and parts[2] == "h":
        if subject.platforms_met:
            return True
        return subject.platform.matches(parts[4]) if subject.platform is not None else None
    if match.get("vulnerable", True) is False:
        # Under an AND it's a condition - "running with" some other
        # software, not checkable here. In a plain list it just names
        # something that isn't vulnerable.
        return None if in_and else False
    if subject.products is not None and _same_product(cpe_product(match.get("criteria", ""))) not in subject.products:
        return False  # another product's version range says nothing about this device
    status = _match_status(subject.version, match)
    return None if status is None else status == "confirmed"


def _combine(operator: str | None, values: list[_Tri]) -> _Tri:
    """Combine values with a configuration's or node's operator.

    Args:
        operator: "AND" or "OR" (None means OR).
        values: The values to combine.

    Returns:
        The combined value.
    """
    return _all(values) if (operator or "OR").upper() == "AND" else _either(values)


def _either(values: Any) -> _Tri:
    """Three-valued OR.

    Args:
        values: The values (any iterable).

    Returns:
        True if any is True; else None if any is None or there are none;
        else False.
    """
    values = list(values)
    if any(v is True for v in values):
        return True
    return None if not values or any(v is None for v in values) else False


def _all(values: list[_Tri]) -> _Tri:
    """Three-valued AND.

    Args:
        values: The values.

    Returns:
        False if any is False; else None if any is None or there are none;
        else True.
    """
    if any(v is False for v in values):
        return False
    return None if not values or any(v is None for v in values) else True


def _negated(item: dict[str, Any], value: _Tri) -> _Tri:
    """Apply a configuration's or node's `negate` (unknown stays unknown).

    Args:
        item: An NVD configuration or node.
        value: Its evaluated value.

    Returns:
        The value, flipped if `negate` is set.
    """
    return (not value) if item.get("negate") and value is not None else value


def _hardware_products(configurations: list[Any]) -> tuple[str, ...]:
    """List the hardware products a CVE's configurations name, as evidence.

    Args:
        configurations: The CVE's NVD `configurations`.

    Returns:
        The CPE product tokens of every hardware entry, each once, in order.
    """
    products = (
        match.get("criteria", "").split(":")[4]
        for config in configurations
        if isinstance(config, dict)
        for node in _all_nodes(config.get("nodes", []))
        for match in node.get("cpeMatch", [])
        if match.get("criteria", "").split(":")[2:3] == ["h"]
    )
    return tuple(dict.fromkeys(products))


def _all_nodes(nodes: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Flatten nodes and their nested children.

    Args:
        nodes: A configuration's nodes.

    Returns:
        Every node, parents before children.
    """
    return [n for node in nodes for n in (node, *_all_nodes(node.get("children", [])))]
