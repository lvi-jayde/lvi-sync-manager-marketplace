"""Where each cache lives under the cache directory (`.cve_cache/`), named for
the source it holds, and the one-time move from the earlier folder names.

```
.cve_cache/
  matches.json                 this tool's own device-to-product matches
  cvefeed.io/
    products/<id>.json         each matched product's CVE list
    nvd_configurations/<CVE>.json   NVD's version ranges and advisory links, via cvefeed.io
  cve_services/<CVE>.json      CNA records from cveawg.mitre.org (Juniper, HPE, Fortinet)
  cisco_openvuln/              Cisco openVuln answers (index.json, releases/)
  cisco_advisories/<id>.json   the first-fixed-release tables of Cisco advisory pages (SD-WAN, Meraki)
```
"""

import os
from pathlib import Path

CVEFEED_DIR = "cvefeed.io"
CVE_SERVICES_DIR = "cve_services"
CISCO_DIR = "cisco_openvuln"
CISCO_ADVISORIES_DIR = "cisco_advisories"

# Earlier name -> current name, both relative to the cache directory.
_RENAMES = (
    ("products", f"{CVEFEED_DIR}/products"),
    ("details", f"{CVEFEED_DIR}/nvd_configurations"),
    ("cve_records", CVE_SERVICES_DIR),
    ("cisco_psirt", CISCO_DIR),
)


def migrate_cache_layout(cache_dir: Path) -> list[str]:
    """Move caches from the earlier folder names to the current ones.

    Whole folders are renamed, so nothing cached is refetched. A folder is
    left alone when the new name already exists, so this never overwrites or
    merges, and running it again does nothing.

    Args:
        cache_dir: The cache directory.

    Returns:
        The earlier names that were moved, e.g. `["details"]`.
    """
    moved = []
    for old, new in _RENAMES:
        source, target = cache_dir / old, cache_dir / new
        if source.is_dir() and not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            os.rename(source, target)
            moved.append(old)
    return moved
