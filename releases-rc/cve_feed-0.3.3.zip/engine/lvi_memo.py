"""A compact CVE summary kept in each device's LogicVein memo.

Uses lvi-api-client's memo methods (0.1.17+): the memo lives in
LogicVein's Memo service, separate from the device record, so writing it
can't touch other device properties.

This tool owns one clearly marked section of the memo (`MEMO_START` ...
`MEMO_END`), always replaced on write. Text outside it is someone else's
(the local lab's c1800 has "Main lab router"): with
`logicvein.memo.preserve_existing` on (the default) it's kept and the section
sits below it; off, the memo becomes just the section. A device with
nothing qualifying gets no new memo, and a section of ours from an earlier
run is removed. LogicVein's memo dialog caps text at 1,000 characters, so
the section shrinks to fit `MEMO_LIMIT` (counting any preserved text) by
listing fewer actively exploited CVE ids, never by dropping the counts.

The memo is HTML: LogicVein's GUI renders it as such (and strips HTML for
the device's memo summary), so plain newlines - stored faithfully, verified
live - display as one run-on line. The section is written as escaped text
with `<br>` line breaks and `&nbsp;` indentation (`_to_html()`). A section
written in the earlier plain-text form is still found by its markers and
replaced.

With `logicvein.memo.verbose` on, the section is instead the full list: every
qualifying CVE, grouped by severity, each followed by its links - cvefeed.io, NVD, and
the vendor's advisory, per the `reports.links.*` settings
(`verbose_memo_section()`). The 1,000-character cap is the GUI's memo
dialog only. The Memo service itself takes up to 20,000,000 characters,
verified live (2026-10-06): 19,999,511 round-tripped exactly and 20,000,243
was rejected with HTTP 400 - a limit on characters, not request bytes.
The verbose section is held to `VERBOSE_MEMO_LIMIT` (100,000, counting
any preserved text) by leaving out the lowest-priority CVEs - lowest
severity first, then non-KEV, then lowest score - with the counts and
severity headers still giving the true totals and a "+N more" line per
match. The same check found the dialog rebuilds the memo keeping only
paragraphs, bold and italic: `<a>` is stripped to its text and bare URLs
aren't linked. So each URL is written as visible text (copyable in the
GUI) inside an `<a>` (clickable anywhere else the HTML is rendered).
Inline `style` colors do survive (on `<span>`/`<strong>`; `<font>` and
`<hr>` don't, verified live), so severity headers are bold and colored,
each CVE's title is in its severity's color, and each URL is styled as a
link (blue, underlined - the dialog turns `text-decoration` into `<ins>`).

In both forms: the whole section is 10px text (one wrapping `<span>`
sizes every line, verified live; the dialog's default is 11px), the
start/end markers and the HARDWARE:/SOFTWARE: labels are bold, each label
on its own line, and a dashed line separates the hardware and software
blocks. `split_memo()` takes the tags wrapping the markers along with
the section, so replacing it leaves no stray tags behind.
"""

import html
import re
from collections import Counter
from typing import Any

from .report import (
    DeviceMatch,
    DeviceReport,
    ReportCriteria,
    cve_flags,
    cve_sort_key,
    cve_title,
    cvss_text,
    link_list,
    matched_products,
    qualifying_matches,
    report_score,
)

MEMO_START = "=== CVE report ==="
# Header written before 0.21.2; still recognised so those sections are
# replaced rather than left behind beside a new one.
_LEGACY_STARTS = ("=== CVE report (lvi-cve-feed) ===",)
MEMO_END = "=== end CVE report ==="
MEMO_LIMIT = 1000
VERBOSE_MEMO_LIMIT = 100_000
_SEVERITY_ORDER = ("CRITICAL", "HIGH", "MEDIUM", "LOW")
_NOT_SCORED = "NOT SCORED"
# Severity header colors in the verbose memo - dark enough to read on
# LogicVein's white memo dialog.
_SEVERITY_COLORS = {
    "CRITICAL": "#c00000",
    "HIGH": "#e06000",
    "MEDIUM": "#b8860b",
    "LOW": "#2e7d32",
    _NOT_SCORED: "#666666",
}
# Between the hardware and software blocks. Plain text: the memo dialog
# drops <hr>.
_SEPARATOR = "-" * 40
_FONT_SIZE = "10px"
_LINK_STYLE = "color:#0645ad;text-decoration:underline"
# Tags directly around a marker - ours (the size span, bold), or the
# paragraphs the GUI's editor rewrites a memo into - belong to the section.
_TAGS_BEFORE = re.compile(r"(?:<(?:span|strong|b|p)\b[^>]*>\s*)+$", re.IGNORECASE)
_TAGS_AFTER = re.compile(r"^(?:\s*</(?:span|strong|b|p)>)+", re.IGNORECASE)
_BREAK = "<br>"
# Whitespace and <br> line breaks at the edges of the text kept outside our
# section, left behind when an earlier section is removed.
_EDGE_BREAKS = re.compile(r"^(?:\s|<br\s*/?>)+|(?:\s|<br\s*/?>)+$", re.IGNORECASE)


class _Html(str):
    """A line whose text is already HTML - `_to_html()` doesn't escape it."""


def _to_html(lines: list[str]) -> str:
    """Render plain lines as memo HTML.

    Lines are escaped (unless already `_Html`), leading spaces are kept as
    &nbsp;, and lines are joined with <br>.

    Args:
        lines: The section's lines.

    Returns:
        The HTML.
    """
    rendered = []
    for line in lines:
        body = line.lstrip(" ")
        text = body if isinstance(line, _Html) else html.escape(body, quote=False)
        rendered.append("&nbsp;" * (len(line) - len(body)) + text)
    return _BREAK.join(rendered)


def split_memo(text: str | None) -> tuple[str, str | None]:
    """Separate this tool's section from the rest of a memo.

    The section runs from MEMO_START (or a legacy header) to MEMO_END, taking
    any tags directly around the markers with it - ours, or the paragraphs
    LogicVein's editor rewrites a memo into - so replacing it leaves nothing
    behind. Leftover whitespace and <br>s at the edges of the other text are
    trimmed.

    Args:
        text: The memo's current text, or None.

    Returns:
        (text outside our section, our section or None).
    """
    text = text or ""
    starts = [i for i in (text.find(marker) for marker in (MEMO_START, *_LEGACY_STARTS)) if i != -1]
    start = min(starts) if starts else -1
    if start == -1:
        return _EDGE_BREAKS.sub("", text), None
    end = text.find(MEMO_END, start)
    end = len(text) if end == -1 else end + len(MEMO_END)
    before = _TAGS_BEFORE.search(text[:start])
    start -= len(before.group(0)) if before else 0
    after = _TAGS_AFTER.match(text[end:])
    end += len(after.group(0)) if after else 0
    return _EDGE_BREAKS.sub("", text[:start] + text[end:]), text[start:end]


def merged_memo(current: str | None, section: str | None, preserve: bool) -> str:
    """Build the memo's new full text.

    `section` replaces any earlier one; the memo's other text is kept when
    `preserve` - or when there's no section to replace it with.

    Args:
        current: The memo's current text, or None.
        section: The new section, or None if there's nothing to report.
        preserve: Whether to keep the memo's non-CVE text.

    Returns:
        The new text; an empty string means the memo should end up empty.
    """
    outside, _ = split_memo(current)
    kept = outside if (preserve or section is None) else ""
    return (_BREAK * 2).join(part for part in (kept, section) if part)


def _severity(entry: dict[str, Any]) -> str:
    """Give a reported CVE's severity group.

    Args:
        entry: A reported CVE entry.

    Returns:
        "CRITICAL", "HIGH", "MEDIUM" or "LOW", else "NOT SCORED".
    """
    severity = (entry["cve"].get("severity") or "").upper()
    return severity if severity in _SEVERITY_ORDER else _NOT_SCORED


def _severity_counts(match: DeviceMatch) -> str:
    """Count a match's CVEs by severity.

    Args:
        match: A qualifying match.

    Returns:
        "2 critical, 5 high, 1 not scored" - severities with no CVEs left out.
    """
    severities = Counter(_severity(v) for v in match.vulnerabilities)
    return ", ".join(f"{severities[s]} {s.lower()}" for s in (*_SEVERITY_ORDER, _NOT_SCORED) if severities[s])


def _section_html(header: str, body: list[str], report_name: str, support: str | None = None) -> str:
    """Render the section's lines as memo HTML.

    Bold markers, 10px throughout, and a bold red end-of-support line under
    the header when `support` is set.

    Args:
        header: The run date and criteria line.
        body: The match blocks' lines.
        report_name: The full report's file name, for the closing line.
        support: The device's end-of-support summary, or None.

    Returns:
        The section's HTML, wrapped in one 10px span.
    """
    notice = (
        [
            _Html(
                f'<strong style="color:{_SEVERITY_COLORS["CRITICAL"]}">PAST END OF SUPPORT: {html.escape(support)}</strong>'
            )
        ]
        if support
        else []
    )
    lines = [_Html(f"<strong>{MEMO_START}</strong>"), header, *notice, *body, f"Full report: {report_name}"]
    lines.append(_Html(f"<strong>{MEMO_END}</strong>"))
    return f'<span style="font-size:{_FONT_SIZE}">{_to_html(lines)}</span>'


def _header(run_date: str, criteria: ReportCriteria) -> str:
    """Build the section's header line: the run date and the criteria used.

    Args:
        run_date: The run's date and time.
        criteria: The report criteria.

    Returns:
        e.g. "2026-10-06 00:00 UTC: confidence 0.80+, CVSS 0-10, unscored CVEs excluded".
    """
    return f"{run_date}: confidence {criteria.threshold:.2f}+, {cvss_text(criteria)}"


def _match_label(match: DeviceMatch) -> list[str]:
    """Label a match block: "HARDWARE:" (bold) on its own line, then the matched product.

    Args:
        match: A qualifying match.

    Returns:
        The label's two lines.
    """
    best = match.result.best
    assert best is not None  # qualifying matches always have one
    return [
        _Html(f"<strong>{match.kind.upper()}:</strong>"),
        f"{matched_products(match)} (confidence {report_score(best.score):.2f})",
    ]


def _separated(blocks: list[list[str]]) -> list[str]:
    """Join match blocks with `_SEPARATOR` between them.

    Args:
        blocks: Each match block's lines.

    Returns:
        The match blocks' lines, with `_SEPARATOR` between blocks.
    """
    lines: list[str] = []
    for block in blocks:
        if lines:
            lines.append(_SEPARATOR)
        lines += block
    return lines


def _match_lines(match: DeviceMatch, kev_limit: int | None) -> list[str]:
    """Build one match's lines for the compact section.

    Args:
        match: A qualifying match.
        kev_limit: The most actively exploited (KEV) CVE ids to list; None for
            all. The rest are counted ("+N more").

    Returns:
        The label, the CVE counts by severity, and the KEV line if any.
    """
    counts = _severity_counts(match)
    kev = [
        v["cve"].get("id", "?")
        for v in sorted(match.vulnerabilities, key=lambda v: -float(v["cve"].get("cvss_score") or 0))
        if (v.get("cisa_kev") or {}).get("in_kev")
    ]
    lines = [*_match_label(match), f"  {len(match.vulnerabilities)} CVE(s): {counts}"]
    if kev:
        shown = kev if kev_limit is None else kev[:kev_limit]
        listed = ", ".join(shown) + (f" (+{len(kev) - len(shown)} more)" if len(shown) < len(kev) else "")
        lines.append(f"  Actively exploited (CISA KEV): {listed if shown else len(kev)}")
    return lines


def memo_section(
    report: DeviceReport, criteria: ReportCriteria, run_date: str, report_name: str, budget: int
) -> str | None:
    """Build this device's compact CVE section within `budget` characters.

    The section shrinks to fit by listing fewer actively exploited CVE ids,
    never by dropping the counts; at its smallest it may still be over budget.

    Args:
        report: The device's report.
        criteria: The report criteria, for the header.
        run_date: The run's date and time.
        report_name: The full report's file name.
        budget: The most characters the section may use.

    Returns:
        The section's HTML, or None if no match qualified (see
        report.qualifying_matches).
    """
    matches = qualifying_matches(report)
    if not matches:
        return None
    most_kev = max(sum(1 for v in m.vulnerabilities if (v.get("cisa_kev") or {}).get("in_kev")) for m in matches)
    section = ""
    for kev_limit in [None, *range(most_kev - 1, -1, -1)]:
        body = _separated([_match_lines(match, kev_limit) for match in matches])
        section = _section_html(_header(run_date, criteria), body, report_name, report.device.end_of_support())
        if len(section) <= budget:
            break
    return section  # at the smallest, still the honest counts even if over budget


def _link(url: str) -> str | None:
    """Render a URL as a link whose text is the URL itself.

    LogicVein's dialog shows only the text (see the module docstring). Only
    http(s) URLs, so CVE data can't inject another scheme.

    Args:
        url: The URL.

    Returns:
        The link's HTML, or None for anything other than http(s).
    """
    if not url.startswith(("https://", "http://")):
        return None
    url = html.escape(url)
    return f'<a href="{url}" target="_blank" rel="noopener" style="{_LINK_STYLE}">{url}</a>'


def _verbose_match_lines(match: DeviceMatch, shown: set[int] | None = None) -> list[str]:
    """Build one match's full listing for the verbose section.

    Args:
        match: A qualifying match.
        shown: With a size budget, the id()s of the CVE entries to list; None
            for all. The rest are counted on a closing "+N more" line.

    Returns:
        The match's lines: label, CPEs, counts, and each CVE by severity with
        its links.
    """
    best = match.result.best
    assert best is not None  # qualifying matches always have one
    kev = sum(1 for v in match.vulnerabilities if (v.get("cisa_kev") or {}).get("in_kev"))
    lines = _match_label(match)
    for cpe in (best.cpe, *(p.cpe for p in match.extra_products)):
        if cpe:
            lines.append(f"  {cpe}")
    lines.append(
        f"  {len(match.vulnerabilities)} CVE(s): {_severity_counts(match)}"
        + (f"; {kev} in CISA KEV (actively exploited)" if kev else "")
    )
    for severity in (*_SEVERITY_ORDER, _NOT_SCORED):
        entries = sorted((v for v in match.vulnerabilities if _severity(v) == severity), key=cve_sort_key)
        if not entries:
            continue
        color = _SEVERITY_COLORS[severity]
        lines.append(_Html(f'  <strong style="color:{color}">{severity} ({len(entries)})</strong>'))
        for entry in entries:
            if shown is not None and id(entry) not in shown:
                continue
            cve = entry["cve"]
            score = f"  {float(cve['cvss_score']):.1f}" if severity != _NOT_SCORED and cve.get("cvss_score") else ""
            flags = cve_flags(entry)
            flag_text = f"  [{', '.join(flags)}]" if flags else ""
            line = html.escape(f"- {cve.get('id') or '?'}{score}{flag_text}", quote=False)
            title = cve_title(cve)
            if title:
                line += f'  <span style="color:{color}">{html.escape(title, quote=False)}</span>'
            lines.append(_Html(f"    {line}"))
            for label, url in link_list(entry):
                link = _link(url)
                if link:
                    lines.append(_Html(f"      {html.escape(label)}: {link}"))
    hidden = 0 if shown is None else sum(1 for v in match.vulnerabilities if id(v) not in shown)
    if hidden:
        lines.append(f"  +{hidden} more CVE(s) not shown (memo limit) - see the full report")
    return lines


def _priority(entry: dict[str, Any]) -> tuple[int, tuple[int, float, str]]:
    """Rank a CVE for a size-limited memo.

    By severity, then as listed within one (KEV first, highest score).

    Args:
        entry: A reported CVE entry.

    Returns:
        A sort key; lower is kept first.
    """
    return ((*_SEVERITY_ORDER, _NOT_SCORED).index(_severity(entry)), cve_sort_key(entry))


def verbose_memo_section(
    report: DeviceReport,
    criteria: ReportCriteria,
    run_date: str,
    report_name: str,
    budget: int = VERBOSE_MEMO_LIMIT,
) -> str | None:
    """Build this device's full CVE section within `budget` characters.

    Every qualifying CVE, by severity, each linked. Over budget, the most
    CVEs that fit are listed, in `_priority()` order, found by bisection (see
    the module docstring).

    Args:
        report: The device's report.
        criteria: The report criteria, for the header.
        run_date: The run's date and time.
        report_name: The full report's file name.
        budget: The most characters the section may use.

    Returns:
        The section's HTML, or None if no match qualified.
    """
    matches = qualifying_matches(report)
    if not matches:
        return None

    def render(shown: set[int] | None) -> str:
        """Render the section listing only some CVEs.

        Args:
            shown: The id()s of the CVE entries to list, or None for all.

        Returns:
            The section's HTML.
        """
        body = _separated([_verbose_match_lines(match, shown) for match in matches])
        return _section_html(_header(run_date, criteria), body, report_name, report.device.end_of_support())

    section = render(None)
    if len(section) <= budget:
        return section
    ranked = sorted((v for m in matches for v in m.vulnerabilities), key=_priority)
    low, high = 0, len(ranked) - 1  # the most CVEs that fit lies in [low, high]
    while low < high:
        mid = (low + high + 1) // 2
        if len(render({id(v) for v in ranked[:mid]})) <= budget:
            low = mid
        else:
            high = mid - 1
    return render({id(v) for v in ranked[:low]})


def update_device_memo(
    client: Any,
    report: DeviceReport,
    criteria: ReportCriteria,
    run_date: str,
    report_name: str,
    preserve: bool,
    verbose: bool = False,
) -> str:
    """Bring one device's memo up to date - the compact section, or with `verbose` the full one.

    Text outside the section counts against the budget when it's preserved.
    Failures are counted, never raised: a memo that can't be written
    shouldn't stop the run.

    Args:
        client: The LogicVein API client.
        report: The device's report.
        criteria: The report criteria.
        run_date: The run's date and time.
        report_name: The full report's file name.
        preserve: Whether to keep the memo's non-CVE text.
        verbose: Whether to write the full section rather than the compact one.

    Returns:
        The outcome for counting: "created", "updated", "deleted",
        "unchanged", or "failed".
    """
    device = report.device
    try:
        memo = client.get_device_memo(device.ip_address, device.network)
        current = memo.get("memo") if memo else None
        outside, _ = split_memo(current)
        kept = len(outside) + len(_BREAK) * 2 if preserve and outside else 0
        if verbose:
            section = verbose_memo_section(report, criteria, run_date, report_name, VERBOSE_MEMO_LIMIT - kept)
        else:
            section = memo_section(report, criteria, run_date, report_name, MEMO_LIMIT - kept)
        new_text = merged_memo(current, section, preserve)
        if new_text == (current or "").strip():
            return "unchanged"
        return str(client.set_device_memo(device.ip_address, device.network, new_text))
    except Exception:  # deliberately broad - a memo that can't be written shouldn't stop the run
        return "failed"
