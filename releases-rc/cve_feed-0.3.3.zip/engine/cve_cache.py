"""cvefeed.io lookups cached on disk between runs: device-to-product matches,
and every CVE for a matched product.

**Matches** (`matches.json`, `MatchCache`): a device's cvefeed.io product
candidates, keyed on the exact (vendor text, product text, vendor_type)
query. Devices with identical text share one search within a run, and a
saved match is reused across runs while it's younger than
`matching.cache_ttl_days` in the settings file (so catalog additions still get picked up) and was
made by the current matcher - saved matches are keyed to a hash of
matcher.py's code (docstrings and comments ignored), so any change to
search or scoring invalidates them
all automatically. (Not the package version: in an editable install that
comes from install-time metadata and lags the VERSION file.)

**CVEs** (`CVECache`):

cvefeed.io's list endpoints return a fixed 10 results per page (`page_size`
is accepted but ignored - verified live 2026-10-01), so a heavily-catalogued
product means a lot of requests: "Cisco Ios" is 659 CVEs (66 pages), the
Linux kernel over 25,000. Version filtering adds one detail request per CVE
on top of that. Doing all of it on every run, against an API already known
to rate-limit (see docs/CVEFEED_API.md), isn't viable - so both are cached
on disk between runs:

- **Product CVE lists** (`cvefeed.io/products/<id>.json`) refresh incrementally:
  `/api/vulnerability/?product_id=<id>&last_modified_after=<last fetch>`
  returns only what changed (verified live: 4 Cisco IOS CVEs in a week),
  merged into the cached list. A cheap total-count check (page 1 of the
  unfiltered list) catches anything incremental refresh can't see - e.g. a
  CVE whose product association was removed - and falls back to a full
  refetch on any mismatch.
- **Per-CVE detail** (`cvefeed.io/nvd_configurations/<cve>.json`: the `configurations` the
  version filter needs, and the vendor advisory URLs for
  `reports.links.vendor_feed`) is reused as long as the CVE's
  `last_modified` in the product list still matches; written one CVE at a
  time, so a first run interrupted partway (rate limiting, Ctrl-C) resumes
  where it stopped. An entry cached before vendor advisories were kept is
  fetched again the first time they're asked for.

`max_cves` caps how many of a product's CVEs are fetched at all - the most
recently published ones, which are the first pages (the list endpoint
sorts newest-published first - verified live 2026-10-01 across pages 1, 2
and 50 of both "Cisco Ios" and the Linux kernel). Only an outlier product like the Linux kernel
should ever hit it; when it does, `ProductCVEs.total` keeps the real count
so the report can say so rather than silently under-report. A capped
product can't be refreshed incrementally (there's no way to tell an edit
inside the cap from one outside it), so its head is simply refetched.
"""

import ast
import hashlib
import json
import os
import re
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from . import matcher
from .cache_layout import CVEFEED_DIR
from .cvefeed_client import CVEFeedClient
from .matcher import MatchResult, ProductCandidate, match_product

_PAGE_SIZE = 10  # fixed server-side; see the module docstring
# Re-fetch a little before the last fetch time, so a CVE modified while that
# fetch was in flight (or any clock skew against cvefeed.io's server) isn't
# missed. Re-fetching a few already-cached CVEs is harmless - merged by id.
_REFRESH_OVERLAP = timedelta(hours=1)
_CVE_ID = re.compile(r"^CVE-\d{4}-\d+$")


@dataclass
class ProductCVEs:
    vulnerabilities: list[dict[str, Any]]  # most recently published first
    total: int  # cvefeed.io's own count, which can exceed len(vulnerabilities)

    @property
    def truncated(self) -> bool:
        """Whether only part of the product's CVEs were fetched (cves.max_per_product)."""
        return len(self.vulnerabilities) < self.total


class CVECache:
    def __init__(self, client: CVEFeedClient, directory: Path, max_cves: int) -> None:
        """Set up the cache; nothing is read or fetched until first asked.

        Args:
            client: The cvefeed.io client.
            directory: The cache directory; product lists go under
                `cvefeed.io/products/`, per-CVE detail under
                `cvefeed.io/nvd_configurations/`.
            max_cves: The most CVEs to fetch per product, newest first.
        """
        self._client = client
        self._products_dir = directory / CVEFEED_DIR / "products"
        self._details_dir = directory / CVEFEED_DIR / "nvd_configurations"
        self._max_cves = max_cves
        # Refreshed at most once per run, however many devices share a product.
        self._this_run: dict[int, ProductCVEs] = {}

    def product_vulnerabilities(self, product_id: int, product: ProductCandidate | None = None) -> ProductCVEs:
        """Get a product's CVEs, refreshed once per run and shared by every device on it.

        Args:
            product_id: The cvefeed.io product id.
            product: When given, labels the cache file with the product's vendor,
                name, and CPE - for a reader, not used here.

        Returns:
            The product's CVEs, newest first, and cvefeed.io's total for it.

        Raises:
            CVEFeedAPIError: From the client, when a fetch fails.
        """
        if product_id not in self._this_run:
            self._this_run[product_id] = self._refresh(product_id, product)
        return self._this_run[product_id]

    def vulnerability_detail(self, vulnerability: dict[str, Any]) -> dict[str, Any]:
        """Get the parts of `/api/vulnerability/{id}/` this tool uses for one CVE.

        That's `configurations` and `vendor_advisories`, for a CVE from a product
        list - from disk if this CVE hasn't changed since it was cached.

        Args:
            vulnerability: The CVE as in a product list (needs "id" and
                "last_modified").

        Returns:
            {"id", "last_modified", "configurations", "vendor_advisories"}.

        Raises:
            CVEFeedAPIError: On a failed fetch, like the client itself.
        """
        return self._detail(vulnerability, "configurations")

    def vendor_advisories(self, vulnerability: dict[str, Any]) -> list[str]:
        """Get the CVE's references tagged "Vendor Advisory".

        That's the vendor's own page for it, e.g. Cisco's cisco-sa-20190109-tcp
        for CVE-2018-0282 (verified live 2026-10-06). Third-party aggregators NVD
        mis-tags that way (_AGGREGATOR_HOSTS) are left out here, on read, so the
        cache keeps NVD's own list.

        Args:
            vulnerability: The CVE as in a product list (needs "id" and
                "last_modified").

        Returns:
            The advisory URLs - empty if it has none.

        Raises:
            CVEFeedAPIError: On a failed fetch, like the client itself.
        """
        urls = self._detail(vulnerability, "vendor_advisories")["vendor_advisories"]
        return [url for url in urls if not _is_aggregator(url)]

    def _detail(self, vulnerability: dict[str, Any], needed: str) -> dict[str, Any]:
        """Get a CVE's detail record, from disk if fresh and holding `needed`.

        A record is fetched again when the CVE's `last_modified` in the product
        list has changed, or when the cached record lacks `needed` (a record
        cached before vendor advisories were kept). A non-CVE id is fetched but
        never used as a cache filename.

        Args:
            vulnerability: The CVE as in a product list.
            needed: The field the caller needs, e.g. "vendor_advisories".

        Returns:
            The detail record (see _detail_record()).

        Raises:
            CVEFeedAPIError: On a failed fetch, from the client.
        """
        cve_id = vulnerability["id"]
        if not _CVE_ID.match(cve_id):
            # Never used as a cache filename unless it's a plain CVE id.
            return _detail_record(cve_id, None, self._client.get_vulnerability(cve_id))
        path = self._details_dir / f"{cve_id}.json"
        cached = _read_json(path)
        if (
            cached is not None
            and cached.get("last_modified") == vulnerability.get("last_modified")
            and needed in cached
        ):
            return cached
        # The product list's last_modified, not the detail's: it's what the
        # next run compares against.
        record = _detail_record(cve_id, vulnerability.get("last_modified"), self._client.get_vulnerability(cve_id))
        _write_json(path, record)
        return record

    def _refresh(self, product_id: int, product: ProductCandidate | None) -> ProductCVEs:
        """Refresh one product's CVE list and save it.

        Incremental refresh (only what changed since the last fetch) is used when
        the cached list is complete and within the cap; otherwise, or if it
        drifts, the list is refetched in full.

        Args:
            product_id: The cvefeed.io product id.
            product: The matched product, to label the cache file, or None.

        Returns:
            The product's CVEs and total.

        Raises:
            CVEFeedAPIError: From the client, when a fetch fails.
        """
        path = self._products_dir / f"{product_id}.json"
        cached = _read_json(path)
        started = datetime.now(timezone.utc)
        first_page = self._client.list_vulnerabilities(product_id=product_id)
        total = first_page.get("count", 0)

        result: ProductCVEs | None = None
        if cached is not None and cached.get("complete") and total <= self._max_cves:
            result = self._incremental(product_id, cached, first_page, total)
        if result is None:
            result = self._full(product_id, first_page, total)

        complete = not result.truncated
        _write_json(
            path,
            {
                "product_id": product_id,
                "vendor": product.vendor_name if product else None,
                "name": product.name if product else None,
                "cpe": product.cpe if product else None,
                # Incremental refresh is only sound from a complete list.
                "complete": complete,
                "fetched_at": started.isoformat(),
                "total": result.total,
                "vulnerabilities": result.vulnerabilities,
            },
        )
        return result

    def _incremental(
        self, product_id: int, cached: dict[str, Any], first_page: dict[str, Any], total: int
    ) -> ProductCVEs | None:
        """Update a complete cached list with what changed since it was fetched.

        Changes are fetched with `last_modified_after` (less a small overlap),
        merged by CVE id, and checked against cvefeed.io's total.

        Args:
            product_id: The cvefeed.io product id.
            cached: The cached list.
            first_page: Page 1 of the unfiltered list, already fetched.
            total: cvefeed.io's current total for the product.

        Returns:
            The updated CVEs, or None if the merged list doesn't match the total
            - drifted in a way incremental refresh can't see, so the caller
            refetches everything.

        Raises:
            CVEFeedAPIError: From the client, when a fetch fails.
        """
        since = datetime.fromisoformat(cached["fetched_at"]) - _REFRESH_OVERLAP
        by_id = {v["id"]: v for v in cached.get("vulnerabilities", [])}
        by_id.update({v["id"]: v for v in first_page.get("results", [])})
        for vuln in self._pages(product_id, last_modified_after=since.isoformat()):
            by_id[vuln["id"]] = vuln
        if len(by_id) != total:
            return None  # drifted in a way incremental refresh can't see - refetch everything
        return ProductCVEs(_newest_first(by_id.values()), total)

    def _full(self, product_id: int, first_page: dict[str, Any], total: int) -> ProductCVEs:
        """Fetch a product's CVE list from the start, up to the cap.

        Args:
            product_id: The cvefeed.io product id.
            first_page: Page 1, already fetched.
            total: cvefeed.io's total for the product.

        Returns:
            The newest max_cves CVEs, and a total that never claims fewer CVEs
            exist than were actually fetched (count is a snapshot; the list can
            grow while it's being paged through).

        Raises:
            CVEFeedAPIError: From the client, when a fetch fails.
        """
        by_id = {v["id"]: v for v in first_page.get("results", [])}
        if first_page.get("next") and len(by_id) < self._max_cves:
            max_pages = -(-self._max_cves // _PAGE_SIZE)
            for vuln in self._pages(product_id, start_page=2, max_pages=max_pages):
                by_id[vuln["id"]] = vuln
        vulnerabilities = _newest_first(by_id.values())[: self._max_cves]
        # Never claim fewer CVEs exist than we actually hold (count is a
        # snapshot; the list can grow while it's being paged through).
        return ProductCVEs(vulnerabilities, max(total, len(by_id)))

    def _pages(self, product_id: int, start_page: int = 1, max_pages: int | None = None, **filters: Any):
        """Page through a product's CVE list (10 per page, fixed by cvefeed.io).

        Args:
            product_id: The cvefeed.io product id.
            start_page: The first page to fetch.
            max_pages: The last page to fetch, or None for all.
            **filters: Extra list filters, e.g. last_modified_after.

        Yields:
            Each CVE, page by page, until there's no next page.

        Raises:
            CVEFeedAPIError: From the client, when a fetch fails.
        """
        page = start_page
        while max_pages is None or page <= max_pages:
            data = self._client.list_vulnerabilities(product_id=product_id, page=page, **filters)
            yield from data.get("results", [])
            if not data.get("next"):
                return
            page += 1


_MatchKey = tuple[str | None, str | None, str | None]


def _code_fingerprint(path: Path) -> str:
    """Fingerprint a module's code, ignoring its docstrings and comments.

    Saved matches are keyed to it, so any change to search or scoring
    invalidates them - but a documentation-only change doesn't (until
    0.35.0 the hash was of the raw source, so a docstring edit discarded
    every saved match).

    Args:
        path: The module's source file.

    Returns:
        A short hash of the module's syntax tree with docstrings removed.
    """
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        body = getattr(node, "body", None)
        if isinstance(body, list) and body and _is_docstring(body[0]):
            setattr(node, "body", body[1:] or [ast.Pass()])
    return hashlib.sha256(ast.dump(tree).encode()).hexdigest()[:16]


def _is_docstring(statement: ast.AST) -> bool:
    """Whether a statement is a docstring: a bare string expression.

    Args:
        statement: The first statement of a module, class or function body.

    Returns:
        True if it's a string literal on its own.
    """
    return (
        isinstance(statement, ast.Expr)
        and isinstance(statement.value, ast.Constant)
        and isinstance(statement.value.value, str)
    )


_MATCHER_FINGERPRINT = _code_fingerprint(Path(matcher.__file__))


class MatchCache:
    """`match_product()`, shared across devices within a run and saved
    between runs - see the module docstring.

    Within a run: verified live (2026-10-02) that the 92 devices across both
    LogicVein labs reduce to about 64 distinct queries (8 Arista cEOS
    devices, 5 identical IOS XE routers, ...). A failed search raises and
    is never saved. `path=None` keeps it to the current run only.
    """

    def __init__(
        self, client: CVEFeedClient, path: Path | None = None, ttl: timedelta = timedelta(0), refresh: bool = False
    ) -> None:
        """Set up the cache, loading saved matches unless refreshing.

        Saved matches are used only if made by the current matcher (the file's
        "matcher" fingerprint matches _MATCHER_FINGERPRINT).

        Args:
            client: The cvefeed.io client.
            path: The saved-matches file, or None to keep matches to this run.
            ttl: How long a saved match is reused.
            refresh: Ignore saved matches and search afresh (they're still
                replaced as searches complete).
        """
        self._client = client
        self._path = path
        self._ttl = ttl
        self._this_run: dict[_MatchKey, MatchResult] = {}
        self._saved: dict[str, dict[str, Any]] = {}
        if path is not None and not refresh:
            saved = _read_json(path)
            if saved is not None and saved.get("matcher") == _MATCHER_FINGERPRINT:
                self._saved = saved.get("entries") or {}

    def match(self, vendor_text: str | None, product_text: str | None, vendor_type: str | None) -> MatchResult:
        """Match device text to catalog products, once per distinct query.

        A query already matched this run, or saved and younger than the TTL, isn't
        searched again. Each device gets its own result object, so nothing can
        mutate one device's match through another's.

        Args:
            vendor_text: The device's vendor text.
            product_text: The device's product text.
            vendor_type: "h", "o" or "a", or None.

        Returns:
            The candidates, best first.

        Raises:
            CVEFeedAPIError: From match_product(), when a search fails (never
                saved).
        """
        key = (vendor_text, product_text, vendor_type)
        if key not in self._this_run:
            self._this_run[key] = self._from_disk(key) or self._search(key)
        cached = self._this_run[key]
        # Each device gets its own result object, so nothing can mutate one
        # device's match through another's.
        return MatchResult(cached.query_vendor, cached.query_product, list(cached.candidates))

    def match_cpe(self, cpe: str) -> MatchResult:
        """Find the catalog product a CPE names, via `/api/product/list-by-cpe`.

        The lookup is exact, so its candidates score 1.0. Shared and saved like
        name matches (under a ("cpe", <cpe>, None) key).

        Args:
            cpe: A CPE 2.3 string, e.g. from a LogicVein custom field.

        Returns:
            The product as a 1.0 candidate; an empty result means the catalog has
            no such product.

        Raises:
            CVEFeedAPIError: From the client, when the lookup fails.
        """
        key: _MatchKey = ("cpe", cpe, None)
        if key not in self._this_run:
            found = self._from_disk(key)
            if found is None:
                results = self._client.list_products_by_cpe(cpe).get("results", [])
                found = MatchResult(
                    None,
                    cpe,
                    [
                        ProductCandidate(
                            id=r["id"],
                            name=r["name"],
                            vendor_id=(r.get("vendor") or {}).get("id"),
                            vendor_name=(r.get("vendor") or {}).get("name", ""),
                            score=1.0,
                            cpe=cpe,
                        )
                        for r in results
                    ],
                )
                self._save(key, found)
            self._this_run[key] = found
        cached = self._this_run[key]
        return MatchResult(cached.query_vendor, cached.query_product, list(cached.candidates))

    def _from_disk(self, key: _MatchKey) -> MatchResult | None:
        """Get a saved match if it's younger than the TTL.

        Args:
            key: The query: (vendor text, product text, vendor_type), or ("cpe",
                <cpe>, None).

        Returns:
            The saved result, or None if there's none, it's stale, or it's damaged
            (a damaged entry just means searching again).
        """
        entry = self._saved.get(json.dumps(key))
        if entry is None:
            return None
        try:
            age = datetime.now(timezone.utc) - datetime.fromisoformat(entry["matched_at"])
            if age >= self._ttl:
                return None
            candidates = [ProductCandidate(**c) for c in entry["candidates"]]
        except (KeyError, TypeError, ValueError):
            return None  # a damaged entry just means searching again
        if key[0] == "cpe":
            return MatchResult(None, key[1], candidates)
        return MatchResult(key[0], key[1], candidates)

    def _search(self, key: _MatchKey) -> MatchResult:
        """Search the catalog for a query and save the result.

        Args:
            key: The query: (vendor text, product text, vendor_type).

        Returns:
            The candidates, best first.

        Raises:
            CVEFeedAPIError: From match_product(), when a search fails.
        """
        result = match_product(self._client, key[0], key[1], vendor_type=key[2])
        self._save(key, result)
        return result

    def _save(self, key: _MatchKey, result: MatchResult) -> None:
        """Save a match to disk, if this cache has a file.

        Args:
            key: The query.
            result: Its candidates.
        """
        if self._path is None:
            return
        self._saved[json.dumps(key)] = {
            "matched_at": datetime.now(timezone.utc).isoformat(),
            "candidates": [asdict(c) for c in result.candidates],
        }
        _write_json(self._path, {"matcher": _MATCHER_FINGERPRINT, "entries": self._saved})


def _detail_record(cve_id: str, last_modified: str | None, detail: dict[str, Any]) -> dict[str, Any]:
    """Build the cached detail record for one CVE.

    Args:
        cve_id: The CVE id.
        last_modified: The CVE's `last_modified` from the product list - not
            the detail's: it's what the next run compares against.
        detail: The `/api/vulnerability/{id}/` response.

    Returns:
        {"id", "last_modified", "configurations", "vendor_advisories"}.
    """
    return {
        "id": cve_id,
        "last_modified": last_modified,
        "configurations": detail.get("configurations"),
        "vendor_advisories": _vendor_advisory_urls(detail),
    }


def _vendor_advisory_urls(detail: dict[str, Any]) -> list[str]:
    """Pick a detail response's references tagged "Vendor Advisory".

    Only http(s) URLs, each once, in order - NVD lists most twice, once per
    source.

    Args:
        detail: The `/api/vulnerability/{id}/` response.

    Returns:
        The advisory URLs.
    """
    urls = (
        ref.get("url") or "" for ref in detail.get("references") or [] if "Vendor Advisory" in (ref.get("tags") or [])
    )
    return list(dict.fromkeys(url for url in urls if url.startswith(("https://", "http://"))))


# Third-party vulnerability aggregators - most long defunct - that NVD's older
# records tag "Vendor Advisory". Not the vendor's own page, so never offered
# as one. Seen on the local lab (2026-10-06): 29 of 326 vendor-tagged links
# across 329 CVEs. Filtered on read, so the cache keeps NVD's own list.
_AGGREGATOR_HOSTS = ("secunia.com", "securityfocus.com", "vupen.com", "ciac.org", "ciac.llnl.gov", "iss.net")


def _is_aggregator(url: str) -> bool:
    """Whether a URL is on a third-party aggregator's host (_AGGREGATOR_HOSTS).

    Args:
        url: A reference URL.

    Returns:
        True for an aggregator host or a subdomain of one.
    """
    host = url.split("/")[2].lower() if url.count("/") >= 2 else ""
    return any(host == h or host.endswith("." + h) for h in _AGGREGATOR_HOSTS)


def _newest_first(vulnerabilities: Any) -> list[dict[str, Any]]:
    """Sort CVEs newest-published first, by id for ties.

    Args:
        vulnerabilities: CVEs as in a product list.

    Returns:
        The CVEs, newest first.
    """
    return sorted(vulnerabilities, key=lambda v: (v.get("published") or "", v["id"]), reverse=True)


def _read_json(path: Path) -> dict[str, Any] | None:
    """Read a cache entry.

    A damaged cache file just means refetching, never a failed run.

    Args:
        path: The cache file.

    Returns:
        The entry, or None if missing or unreadable.
    """
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None


def _write_json(path: Path, data: dict[str, Any]) -> None:
    # Write-then-rename, so an interrupted run never leaves a half-written
    # entry behind for the next run to trust.
    """Write a cache entry, indented, by writing then renaming.

    An interrupted run never leaves a half-written entry behind for the next
    run to trust.

    Args:
        path: The cache file; its directory is created if needed.
        data: The entry.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    os.replace(tmp, path)
