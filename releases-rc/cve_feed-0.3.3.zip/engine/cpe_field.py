"""CPEs kept in a LogicVein device custom field - read to pin a device's
match, written to record the match the tool made.

The field holds space-separated CPE 2.3 strings (CPEs contain no spaces),
at most one per match kind: a `h` (hardware) CPE for the hardware match, an
`o` or `a` CPE for the software match - e.g.
`cpe:2.3:h:cisco:router_2500:*:*:*:*:*:*:*:* cpe:2.3:o:cisco:ios:*:*:*:*:*:*:*:*`.

cvefeed.io's CPE lookup ignores the version (verified live 2026-10-02:
`cisco:ios:12.3(13a)` and `cisco:ios:*` both return all 659 IOS CVEs), so a
CPE here identifies a *product*, not a release - the version filter still
uses LogicVein's own, self-updating `osVersion`. Written CPEs are
version-wildcard for that reason.

Reading only trusts a field that holds nothing but well-formed CPE 2.3
strings (`parse_field()`); anything else - another use of the field, a
typo - is ignored and counted, never guessed at. Only auto-applied matches
are ever written, never ones held for review. What happens to the field's
existing value depends on `logicvein.cpe_field.overwrite_existing`
(`value_to_write()`): on (the default), the field is set to exactly the
device's current CPEs, whatever it held - including a value used for
something else (on the local lab, `custom1` holds "active" on one device);
off, only empty or CPE-only fields are filled, and an existing CPE is never
replaced.
"""

import re
from dataclasses import dataclass
from typing import Any

CUSTOM_FIELDS = ("custom1", "custom2", "custom3", "custom4", "custom5")
_HARDWARE_PARTS = ("h",)
_SOFTWARE_PARTS = ("o", "a")
# CPE 2.3 formatted string: "cpe", "2.3", then 11 components - part,
# vendor, product, version, update, edition, language, sw_edition,
# target_sw, target_hw, other. Colons inside a component are escaped (\:).
_UNESCAPED_COLON = re.compile(r"(?<!\\):")
_NAME_COMPONENT = re.compile(r"^(?:\\.|[A-Za-z0-9._~!-])+$")
_OTHER_COMPONENT = re.compile(r"^(?:\\.|[^\s\\:])+$")


@dataclass(frozen=True)
class CPEFieldSettings:
    slot: str  # one of CUSTOM_FIELDS
    read: bool
    write: bool
    overwrite: bool = True


@dataclass(frozen=True)
class FieldCPEs:
    hardware: str | None = None
    software: str | None = None


def is_valid_cpe(token: str) -> bool:
    """Check that a token is a well-formed CPE 2.3 formatted string.

    It must name a real vendor and product, not a wildcard.

    Args:
        token: One whitespace-separated token from a custom field.

    Returns:
        True if the token is a well-formed CPE 2.3 string with a concrete vendor and product.
    """
    parts = _UNESCAPED_COLON.split(token)
    if len(parts) != 13 or parts[0] != "cpe" or parts[1] != "2.3":
        return False
    part, vendor, product, *rest = parts[2:]
    if part not in _HARDWARE_PARTS + _SOFTWARE_PARTS:
        return False
    if not all(_NAME_COMPONENT.match(name) and name not in ("*", "-") for name in (vendor, product)):
        return False
    return all(_OTHER_COMPONENT.match(component) for component in rest)


def parse_field(value: str | None) -> FieldCPEs | None:
    """Read the CPEs in a custom field's value.

    The value must hold nothing but well-formed CPEs, at most one per match
    kind. Anything else - another use of the field, or a typo - is never read.

    Args:
        value: The custom field's current value, or None.

    Returns:
        The field's hardware and software CPEs (FieldCPEs() for an empty
        field), or None if the value is anything but well-formed CPEs, at
        most one per match kind.
    """
    hardware = software = None
    for token in (value or "").split():
        if not is_valid_cpe(token):
            return None
        part = token.split(":")[2]
        if part in _HARDWARE_PARTS and hardware is None:
            hardware = token
        elif part in _SOFTWARE_PARTS and software is None:
            software = token
        else:
            return None  # two CPEs for one match kind: ambiguous
    return FieldCPEs(hardware, software)


def value_to_write(
    current: str | None, hardware_cpe: str | None, software_cpe: str | None, overwrite: bool = True
) -> str | None:
    """Work out a CPE field's new value.

    overwrite=True: exactly this device's CPEs, replacing whatever the field
    holds - but never clearing it when there's nothing to record.
    overwrite=False: only adds CPEs to an empty or CPE-only field, keeping
    any CPE already there; a field holding anything else is left alone.

    Args:
        current: The field's current value, or None.
        hardware_cpe: The applied hardware match's CPE, or None.
        software_cpe: The applied software match's CPE, or None.
        overwrite: Whether to replace whatever the field holds (see above).

    Returns:
        The field's new value, or None if it shouldn't be written.
    """
    if overwrite:
        value = " ".join(cpe for cpe in (hardware_cpe, software_cpe) if cpe)
        return value if value and value != (current or "").strip() else None
    existing = parse_field(current)
    if existing is None:
        return None
    hardware = existing.hardware or hardware_cpe
    software = existing.software or software_cpe
    if (hardware, software) == (existing.hardware, existing.software):
        return None
    return " ".join(cpe for cpe in (hardware, software) if cpe)


def write_field(client: Any, ip_address: str, network: str, slot: str, value: str) -> bool:
    """Set one custom field on a device.

    A field that can't be written (permissions, a device gone mid-run)
    shouldn't stop the run, so any failure is reported as False rather than
    raised.

    Args:
        client: The LogicVein API client.
        ip_address: The device's IP address.
        network: The device's LogicVein network.
        slot: The custom field to set, one of CUSTOM_FIELDS.
        value: The value to write.

    Returns:
        True if LogicVein accepted the write, False on any failure.
    """
    try:
        return bool(client.update_custom_fields(ip_address, network=network, custom_fields={slot: value}))
    except Exception:  # deliberately broad - see docstring
        return False
