"""Fuzzy-matches LogicVein device vendor/product text against cvefeed.io's catalog.

LogicVein device data has no CPE string (see docs/ARCHITECTURE.md), so
matching goes through cvefeed.io's free-text vendor/product name search,
scored by string similarity against the device's own text. This is a
heuristic, not an exact lookup - vendor/product naming conventions differ
between LogicVein adapters and cvefeed.io's catalog (seen already: "Dell"
vs "Dell Inc."), so a low score is expected and normal, not a bug.

The confidence "dial" (Settings.match_confidence_threshold, a plain 0.0-1.0
float) is applied by the caller (report.py), not here: this module only
computes and ranks candidates. A caller with the dial turned down accepts
lower-scoring matches as authoritative; turned up, only near-exact matches
auto-apply and everything else is kept for manual review rather than
silently dropped.

Verified against the live API (2026-09-11) that `/api/product/{id}/` is
NOT relevance-sorted and `/api/vendor/{id}/products/` has no name filter at
all - for a vendor with thousands of products (Cisco: ~1700-3900 depending
on part), reading only page 1 of either returns an essentially arbitrary
slice with no relation to the device being matched. `/api/product/?name=`
IS a real (if imperfect) full-text search: querying `name="<vendor>
<product>"` together, rather than product text alone, reliably narrows
results to a small, relevant set (verified: "Cisco 2500" -> 8 results
including the correct "Cisco Router 2500" catalog entry, on one page). That
combined-query search is this module's primary strategy; a bounded
multi-page scan and a vendor-scoped product browse are fallbacks for when
it comes up empty, not the primary path.

Also verified: this search wants real word boundaries, not just a
substring match - compact part-number-style model text with no internal
spaces (Cisco "ASA5505", "WS-C2950-24") returns zero results even though
the corresponding catalog entry exists ("Cisco Asa 5505", "Cisco Catalyst
2950") and even a bare digit substring of it ("Cisco 5505", "Cisco 2950")
finds it. A digit-run fallback (`_longest_digit_run`) handles this: when
the fuller queries find nothing, retry with just the model text's longest
digit run.
"""

import re
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from typing import Any

from .cvefeed_client import CVEFeedClient

_PUNCTUATION = re.compile(r"[^\w\s]")
_CORPORATE_SUFFIXES = re.compile(r"\b(inc|incorporated|corp|corporation|ltd|limited|llc|co|company)\b")
_WHITESPACE = re.compile(r"\s+")
_DIGIT_RUN = re.compile(r"\d{3,}")

# A candidate scoring at or above this short-circuits further pagination -
# good enough that spending more requests looking for something better
# isn't worth it. Below the module's own scope: report.py's separately
# configurable auto-apply threshold decides what counts as a usable match.
_GOOD_ENOUGH_SCORE = 0.85


def normalize(text: str | None) -> str:
    """Lowercase, strip punctuation and corporate suffixes, collapse whitespace.

    Written so "Dell Inc." and "Dell" normalize to the same string - the
    single most common source of vendor-name mismatch seen in real data.

    Args:
        text: Free text, or None.

    Returns:
        The normalized text ("" for None or empty).
    """
    if not text:
        return ""
    lowered = _PUNCTUATION.sub(" ", text.lower())
    lowered = _CORPORATE_SUFFIXES.sub(" ", lowered)
    return _WHITESPACE.sub(" ", lowered).strip()


def similarity(a: str | None, b: str | None) -> float:
    """Score the similarity of two free-text strings, order-independent.

    A substring match (either normalized string fully contains the other) is
    treated as at least as strong as a 0.85 ratio - common when one side is
    abbreviated (e.g. device model "2500" vs catalog name "Cisco 2500 Series
    Routers").

    Args:
        a: One string, or None.
        b: The other string, or None.

    Returns:
        0.0-1.0; 0.0 if either is empty.
    """
    a_n, b_n = normalize(a), normalize(b)
    if not a_n or not b_n:
        return 0.0
    ratio = SequenceMatcher(None, a_n, b_n).ratio()
    if a_n in b_n or b_n in a_n:
        ratio = max(ratio, 0.85)
    return ratio


def _longest_digit_run(text: str) -> str | None:
    """Find the longest run of 3+ digits in some text.

    Args:
        text: The text, e.g. "WS-C2950-24".

    Returns:
        The run (e.g. "2950"), or None if there's none.
    """
    runs = _DIGIT_RUN.findall(text)
    return max(runs, key=len) if runs else None


def _digit_run_similarity(digit_run: str, candidate_name: str) -> float:
    """Score a bare digit run (e.g. "2500") against a candidate catalog name.

    Deliberately NOT `similarity()`: that function's flat 0.85 substring floor
    is right for whole product-text comparisons, but wrong here - verified
    live (2026-09-15) that it let every candidate containing a device's digit
    run tie at exactly 0.85 regardless of how much of the candidate name that
    digit run actually accounts for, so a Cisco 2500 router matched "Cisco
    Firepower management center 2500 firmware" (score 0.85) exactly as well
    as the correct "Cisco Router 2500" (also 0.85) - the tie broke arbitrarily
    and, that run, wrongly. Scaling the bonus by the digit run's share of the
    (normalized) candidate name instead - half credit just for containment,
    up to full credit as the run approaches the whole name - reproduces the
    same three candidates' plain SequenceMatcher ratios' correct relative
    order (0.18 / 0.53 / 0.25) while still crediting containment more than an
    unbonused ratio would for a short, mostly-numeric candidate like "Router
    2500".

    Args:
        digit_run: The device's digit run.
        candidate_name: A catalog product name.

    Returns:
        0.0-1.0.
    """
    a_n, b_n = normalize(digit_run), normalize(candidate_name)
    if not a_n or not b_n:
        return 0.0
    ratio = SequenceMatcher(None, a_n, b_n).ratio()
    if a_n in b_n:
        coverage = len(a_n) / len(b_n)
        ratio = max(ratio, 0.5 + 0.4 * coverage)
    return ratio


@dataclass(frozen=True)
class VendorCandidate:
    id: int
    name: str
    score: float


@dataclass(frozen=True)
class ProductCandidate:
    id: int
    name: str
    vendor_id: int | None
    vendor_name: str
    score: float
    # Version-wildcard CPE for this catalog product, when derivable - see
    # product_cpe().
    cpe: str | None = None


@dataclass
class MatchResult:
    query_vendor: str | None
    query_product: str | None
    candidates: list[ProductCandidate] = field(default_factory=list)

    @property
    def best(self) -> ProductCandidate | None:
        """The top candidate, or None if there are none."""
        return self.candidates[0] if self.candidates else None


def _product_similarity(product_text: str, candidate_name: str) -> float:
    """Score product text against a candidate, crediting its digit run too.

    similarity(), but also credits product_text's digit run (if it has one)
    against the candidate - not just the full string.

    Reuses the same "a compact part number's digit run is what actually
    identifies the product" reasoning `match_product()`'s search fallback
    already relies on (see its docstring), now applied to scoring too.
    Necessary, not just consistent: verified live (2026-09-15) that without
    this, a device whose only available model text is a noisy part number
    (`hardware_match_model` preferring `get_device_hardware()`'s
    `modelNumber`, e.g. "WS-C2950-24") scored its own correct match too low to
    auto-apply - the digit-run fallback had found "Catalyst 2950" via the
    search, but the score still compared the *whole* noisy "WS-C2950-24"
    against "Catalyst 2950" (no shared substring at all) instead of crediting
    the "2950" that actually matched.

    A model that is *only* a number gets the digit-run scoring outright, not
    `similarity()`'s flat substring floor - otherwise any candidate that
    merely contains the number scores 0.85. Verified live (2026-10-01): a
    Nortel BPS 2000 switch (modelNumber "2000") auto-applied "Nortel
    Succession communication server 2000", a telephony server.

    Args:
        product_text: The device's product text.
        candidate_name: A catalog product name.

    Returns:
        0.0-1.0.
    """
    if normalize(product_text).isdigit():
        return _digit_run_similarity(product_text, candidate_name)
    score = similarity(product_text, candidate_name)
    digit_run = _longest_digit_run(product_text)
    if digit_run and digit_run != product_text:
        score = max(score, _digit_run_similarity(digit_run, candidate_name))
    return score


_CPE_TOKEN = re.compile(r"^[a-z0-9_.\-]+$")


def product_cpe(product: dict[str, Any]) -> str | None:
    """Derive the version-wildcard CPE for a cvefeed.io product dict.

    The CPE is `cpe:2.3:<part>:<vendor>:<product>:*:...`. cvefeed.io's product
    data has no CPE field, but its web URLs carry the exact CPE tokens -
    verified live (2026-10-02): a vendor URL is
    `/vuln/vendor/<id>/<part>-<vendor token>/` and a product URL is
    `/vuln/product/<id>/<vendor token><product token>/`, hyphens and
    underscores intact ("cisconx-os", "f5big-ip_local_traffic_manager",
    "palo_alto_networkspan-os"). Search results include both. Anything that
    doesn't parse cleanly gives None rather than a guessed CPE.

    Args:
        product: A product from a cvefeed.io search result.

    Returns:
        The CPE, or None if it can't be derived exactly.
    """
    vendor = product.get("vendor") or {}
    part = vendor.get("part")
    vendor_slug = _last_path_segment(vendor.get("get_absolute_url"))
    product_slug = _last_path_segment(product.get("get_absolute_url"))
    if part not in ("a", "o", "h") or not vendor_slug or not product_slug:
        return None
    if not vendor_slug.startswith(f"{part}-"):
        return None
    vendor_token = vendor_slug[len(part) + 1 :]
    if not product_slug.startswith(vendor_token):
        return None
    product_token = product_slug[len(vendor_token) :]
    if not (_CPE_TOKEN.match(vendor_token) and _CPE_TOKEN.match(product_token)):
        return None
    return f"cpe:2.3:{part}:{vendor_token}:{product_token}:*:*:*:*:*:*:*:*"


def _last_path_segment(url: str | None) -> str | None:
    """Take the last segment of a URL path.

    Args:
        url: A URL or path, or None.

    Returns:
        The last non-empty segment, or None.
    """
    if not url:
        return None
    return url.strip("/").rsplit("/", 1)[-1] or None


def _score_products(
    vendor_text: str | None, product_text: str, raw_products: list[dict[str, Any]]
) -> list[ProductCandidate]:
    """Score search results against the device's text.

    The score is vendor similarity x product similarity - multiplicative, so
    a match is only as trustworthy as its weakest half (see the comment in
    the body for the VMware/Oracle case that made it so). No vendor text at
    all scores the vendor half 1.0 rather than penalizing a comparison that
    can't be made.

    Args:
        vendor_text: The device's vendor text, or None.
        product_text: The device's product text.
        raw_products: Products from a cvefeed.io search.

    Returns:
        One candidate per product, unsorted.
    """
    candidates = []
    for p in raw_products:
        v: dict[str, Any] = p.get("vendor") or {}
        product_score = _product_similarity(product_text, p["name"])
        # No vendor text to compare at all (rare - most devices have some
        # vendor string): don't penalize for a comparison that can't be
        # made, just fall through to the product score alone.
        vendor_score = similarity(vendor_text, v.get("name")) if vendor_text else 1.0
        # Multiplicative, not blended into one string and scored as a
        # whole (the original approach): a match is only as trustworthy as
        # its weakest half. Verified live (2026-09-15) that blending lets a
        # strong product-name match paper over a vendor that doesn't match
        # at all - a VMware ESXi host's software ("VMware, Inc." / "Linux")
        # scored 0.67 against the catalog's "Oracle Linux" (both share the
        # generic word "Linux"; "VMware" and "Oracle" have nothing to do
        # with each other) and crossed the 0.6 auto-apply threshold as a
        # false positive. Multiplying drops that specific case to 0.33 (the
        # vendor mismatch alone), while a real match with a weak vendor
        # score but strong product score - or vice versa - still needs
        # both to be reasonable, which is the point.
        score = vendor_score * product_score
        candidates.append(
            ProductCandidate(
                id=p["id"],
                name=p["name"],
                vendor_id=v.get("id"),
                vendor_name=v.get("name", ""),
                score=score,
                cpe=product_cpe(p),
            )
        )
    return candidates


def _search_products(
    client: CVEFeedClient,
    vendor_text: str | None,
    product_text: str,
    name_query: str,
    vendor_type: str | None,
    max_pages: int,
) -> list[ProductCandidate]:
    """Search products by name, page by page, scoring as it goes.

    Stops early once a candidate scores at least _GOOD_ENOUGH_SCORE, at the
    last page, or after `max_pages`.

    Args:
        client: The cvefeed.io client.
        vendor_text: The device's vendor text, for scoring.
        product_text: The device's product text, for scoring.
        name_query: The text to search for.
        vendor_type: 'a', 'o' or 'h' to narrow the search, or None.
        max_pages: The most result pages to read.

    Returns:
        Every candidate seen; empty if page 1 found nothing.
    """
    all_candidates: list[ProductCandidate] = []
    page = 1
    while page <= max_pages:
        data = client.list_products(name=name_query, vendor_type=vendor_type, page=page)
        results = data.get("results", [])
        all_candidates.extend(_score_products(vendor_text, product_text, results))
        if not all_candidates:
            return []
        best_so_far = max(c.score for c in all_candidates)
        if best_so_far >= _GOOD_ENOUGH_SCORE or not data.get("next"):
            break
        page += 1
    return all_candidates


def _best_vendors(
    client: CVEFeedClient, vendor_text: str, vendor_type: str | None, limit: int
) -> list[VendorCandidate]:
    """Find the catalog vendors most like the device's vendor text.

    Searches by the normalized text's first word, then ranks by similarity to
    the whole text.

    Args:
        client: The cvefeed.io client.
        vendor_text: The device's vendor text.
        vendor_type: 'a', 'o' or 'h' to narrow the search, or None.
        limit: The most vendors to return.

    Returns:
        The best-matching vendors, best first.
    """
    keyword = normalize(vendor_text).split(" ")[0] if normalize(vendor_text) else vendor_text
    data = client.list_vendors(name=keyword, part=vendor_type, page=1)
    candidates = [
        VendorCandidate(id=v["id"], name=v["name"], score=similarity(vendor_text, v["name"]))
        for v in data.get("results", [])
    ]
    candidates.sort(key=lambda c: c.score, reverse=True)
    return candidates[:limit]


def _browse_vendor_products(
    client: CVEFeedClient, vendor_text: str, product_text: str, vendor_type: str | None, limit: int
) -> list[ProductCandidate]:
    """Score whatever the best-matching vendor's product list happens to have on hand.

    Last resort: no product-name-search hit at all. This is a weak signal -
    see the module docstring - and only reached when the stronger name-search
    strategy found literally nothing. Needs a vendor scoring at least 0.5.

    Args:
        client: The cvefeed.io client.
        vendor_text: The device's vendor text.
        product_text: The device's product text.
        vendor_type: 'a', 'o' or 'h' to narrow the vendor search, or None.
        limit: The most vendors to consider.

    Returns:
        Candidates from page 1 of the vendor's products, or none.
    """
    vendor_candidates = _best_vendors(client, vendor_text, vendor_type, limit=limit)
    if not vendor_candidates or vendor_candidates[0].score < 0.5:
        return []
    vendor = vendor_candidates[0]
    data = client.list_vendor_products(vendor.id, page=1)
    results = [{**p, "vendor": {"id": vendor.id, "name": vendor.name}} for p in data.get("results", [])]
    return _score_products(vendor_text, product_text, results)


# Device-class words that appear across unrelated products ("Ethernet
# routing switch", "Succession communication server"), so sharing one is no
# evidence of the same product.
_GENERIC_WORDS = frozenset(
    "switch switches router routers server servers firewall appliance controller gateway access point "
    "wireless series system systems software firmware network networks managed port ports gigabit ethernet "
    "edition platform device module".split()
)


def _descriptive_words(product_text: str, vendor_text: str | None) -> set[str]:
    """Find the words in a device's product text that name *this* product.

    All letters, 3+ long, not the vendor's own name, not a generic
    device-class word. Part numbers ("WS-C2950-24", "ASA5505") have none.

    Args:
        product_text: The device's product text.
        vendor_text: The device's vendor text, or None.

    Returns:
        The normalized descriptive words.
    """
    vendor_words = set(normalize(vendor_text).split())
    return {
        word
        for word in normalize(product_text).split()
        if word.isalpha() and len(word) >= 3 and word not in _GENERIC_WORDS and word not in vendor_words
    }


def _sharing_a_descriptive_word(
    candidates: list[ProductCandidate], product_text: str, vendor_text: str | None
) -> list[ProductCandidate]:
    """Keep only weak-fallback candidates that share a descriptive word with the device.

    For the weak fallback stages - a digit-run search or a browse of the
    vendor's catalog - which find candidates without the device's own words:
    when the device's text has descriptive words, keep only candidates
    sharing at least one. Verified live (2026-10-02): a Nortel "Business
    Policy Switch 2000" digit-run search found only "Succession communication
    server 2000", a telephony server sharing nothing but the number - and
    cvefeed.io's catalog has no Business Policy Switch at all, so "no
    candidate" is the true answer, not a wrong one held for review.

    Args:
        candidates: The fallback stage's candidates.
        product_text: The device's product text.
        vendor_text: The device's vendor text, or None.

    Returns:
        The candidates sharing a word - all of them if the device's text has
        no descriptive words.
    """
    words = _descriptive_words(product_text, vendor_text)
    if not words:
        return candidates
    return [c for c in candidates if _shares_a_word(words, _descriptive_words(c.name, None))]


def _shares_a_word(device_words: set[str], candidate_words: set[str]) -> bool:
    """Whether two word sets share a word: equal words, or one inside the other.

    Device text often runs words together. Verified live (2026-10-02): a Cisco
    Small Business switch's software search text is "SmallBusiness
    CBS350-48T-4G" (the adapter's name), and its correct match is "Business
    350 48t 4g firmware".

    Args:
        device_words: The device's descriptive words.
        candidate_words: A candidate's descriptive words.

    Returns:
        True if any pair matches.
    """
    return any(d == c or d in c or c in d for d in device_words for c in candidate_words)


def match_product(
    client: CVEFeedClient,
    vendor_text: str | None,
    product_text: str | None,
    vendor_type: str | None = None,
    limit: int = 5,
    max_pages: int = 5,
) -> MatchResult:
    """Find cvefeed.io product candidates for a device's vendor/product text.

    Tries, in order, until one finds anything: the combined "<vendor>
    <product>" search, the product text alone, the vendor plus the longest
    digit run, and a browse of the best vendor's products (the last two
    filtered by _sharing_a_descriptive_word()).

    Args:
        client: The cvefeed.io client.
        vendor_text: The device's vendor text, or None.
        product_text: The device's product text, or None (then no search).
        vendor_type: Narrows the cvefeed.io search to 'a' (application), 'o'
            (operating system), or 'h' (hardware) when the caller knows which
            kind of match this is (report.py passes 'h' for hardware, 'o' for
            software).
        limit: The most candidates to keep.
        max_pages: The most result pages to read per search.

    Returns:
        The query and its top candidates, best first.

    Raises:
        CVEFeedAPIError: From the client, when a search fails.
    """
    result = MatchResult(query_vendor=vendor_text, query_product=product_text)
    if not product_text:
        return result

    combined_query = f"{vendor_text} {product_text}".strip() if vendor_text else product_text
    candidates = _search_products(client, vendor_text, product_text, combined_query, vendor_type, max_pages)

    if not candidates and vendor_text:
        # The combined query can come up empty when the vendor text is noisy
        # (e.g. "Network Engineering Software Systems") - product text alone
        # is a looser but still meaningful retry.
        candidates = _search_products(client, vendor_text, product_text, product_text, vendor_type, max_pages)

    if not candidates:
        # Compact part-number-style model text ("ASA5505", "WS-C2950-24")
        # matches nothing above even though it names a real product - see
        # the module docstring. Its longest digit run alone often does.
        digit_run = _longest_digit_run(product_text)
        if digit_run and digit_run != product_text:
            query = f"{vendor_text} {digit_run}".strip() if vendor_text else digit_run
            candidates = _search_products(client, vendor_text, product_text, query, vendor_type, max_pages)
            candidates = _sharing_a_descriptive_word(candidates, product_text, vendor_text)

    if not candidates and vendor_text:
        candidates = _browse_vendor_products(client, vendor_text, product_text, vendor_type, limit)
        candidates = _sharing_a_descriptive_word(candidates, product_text, vendor_text)

    candidates.sort(key=lambda c: c.score, reverse=True)
    result.candidates = candidates[:limit]
    return result
