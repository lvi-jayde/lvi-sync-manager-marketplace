"""Admin maintenance: resetting what the plugin has cached, matched or decided.

Every action changes only what the next sync starts from; none of them touches
the current report. The cache actions and Re-match act at once. Clearing the
CPE custom field needs a LogicVein client, which only a sync has, so it is
queued in `maintenance.json` and done by the next sync before it matches.

A sync and a maintenance action never overlap: the sync holds `RUN_LOCK` for
its whole run, and an action takes it only if it is free (`exclusive()`),
otherwise refusing with `Busy`. Both run in the app's own process, so the lock
cannot be left behind by a crash.

What is shared, and so reaches further than the devices chosen:

- a saved match belongs to the search text (vendor and product text), not
  to a device: forgetting one device's matches makes every device reporting
  the same text search again;
- a cached CVE list belongs to a cvefeed.io product: refreshing it refreshes
  it for every device matched to that product.
"""

import dataclasses
import json
import os
import shutil
import tempfile
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Set

from .engine.cache_layout import CVEFEED_DIR
from .engine.device_inventory import Device

RUN_LOCK = threading.Lock()


class Busy(RuntimeError):
    """A sync is running, so a maintenance action must wait."""


@contextmanager
def exclusive() -> Iterator[None]:
    """Hold the run lock for a maintenance action, or refuse.

    Raises:
        Busy: A sync is running.
    """
    if not RUN_LOCK.acquire(blocking=False):
        raise Busy("A sync is running")
    try:
        yield
    finally:
        RUN_LOCK.release()


def cache_dir(data_dir: Path) -> Path:
    """The response cache under the plugin's data directory."""
    return data_dir / "cache"


def delete_cache(data_dir: Path) -> None:
    """Delete every cached response: matches, CVE lists, CVE details, vendor data."""
    shutil.rmtree(cache_dir(data_dir), ignore_errors=True)


def forget_matches(data_dir: Path) -> None:
    """Delete every saved match, keeping the cached CVE lists and details."""
    (cache_dir(data_dir) / "matches.json").unlink(missing_ok=True)


def device_from_row(row: Dict[str, Any]) -> Device:
    """Rebuild the engine's Device from a report devices.jsonl row.

    Args:
        row: The row (the device's fields plus its summary).

    Returns:
        The device.
    """
    names = {f.name for f in dataclasses.fields(Device)}
    return Device(**{k: v for k, v in row.items() if k in names})


def search_texts(device: Device) -> Set[tuple]:
    """The (vendor text, product text) pairs a device's matches search with."""
    texts = {
        (device.hardware_match_vendor, device.hardware_match_model),
        (device.software_match_vendor, device.software_product_hint),
    }
    texts.update((vendor, product) for vendor, product, _ in device.software_extra_queries)
    return {t for t in texts if t[0] or t[1]}


def forget_device_matches(data_dir: Path, devices: Iterable[Device]) -> int:
    """Delete the saved matches the given devices' searches use.

    Args:
        data_dir: The plugin's data directory.
        devices: The devices.

    Returns:
        How many saved matches were deleted.
    """
    path = cache_dir(data_dir) / "matches.json"
    try:
        saved = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return 0
    texts: Set[tuple] = set()
    for device in devices:
        texts |= search_texts(device)
    entries = saved.get("entries") or {}
    gone = [key for key in entries if tuple(json.loads(key)[:2]) in texts]
    for key in gone:
        del entries[key]
    if gone:
        _write_json(path, {**saved, "entries": entries})
    return len(gone)


def refresh_products(data_dir: Path, product_ids: Iterable[int]) -> int:
    """Delete the cached CVE lists of the given cvefeed.io products.

    The next sync fetches each list in full again. Per-CVE details are kept:
    they are reused only while the CVE is unchanged anyway.

    Args:
        data_dir: The plugin's data directory.
        product_ids: The products.

    Returns:
        How many cached lists were deleted.
    """
    deleted = 0
    for product_id in set(product_ids):
        path = cache_dir(data_dir) / CVEFEED_DIR / "products" / f"{int(product_id)}.json"
        if path.exists():
            path.unlink()
            deleted += 1
    return deleted


def _pending_path(data_dir: Path) -> Path:
    return data_dir / "maintenance.json"


def pending_cpe_clears(data_dir: Path) -> List[str]:
    """Device keys whose CPE custom field the next sync clears."""
    try:
        data = json.loads(_pending_path(data_dir).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    keys = data.get("clear_cpe") if isinstance(data, dict) else None
    return [str(k) for k in keys] if isinstance(keys, list) else []


def queue_cpe_clears(data_dir: Path, keys: Iterable[str]) -> None:
    """Have the next sync clear these devices' CPE custom field."""
    merged = list(dict.fromkeys([*pending_cpe_clears(data_dir), *keys]))
    _write_json(_pending_path(data_dir), {"clear_cpe": merged})


def done_cpe_clears(data_dir: Path, keys: Iterable[str]) -> None:
    """Drop devices whose CPE field has been cleared from the queue."""
    done = set(keys)
    left = [k for k in pending_cpe_clears(data_dir) if k not in done]
    _write_json(_pending_path(data_dir), {"clear_cpe": left})


def _write_json(path: Path, data: Dict[str, Any]) -> None:
    """Write a JSON file atomically: a temporary file, then a rename."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.stem}-", suffix=".json")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(data, handle)
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise
