"""CVE Feed plugin: CVEs that apply to LogicVein devices, from cvefeed.io and the vendors."""

from .plugin import CveFeedPlugin

__all__ = ["CveFeedPlugin"]
