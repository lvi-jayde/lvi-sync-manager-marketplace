"""Match-review decisions: kept across syncs, applied by the engine on the next one.

A reviewer can accept one candidate for a device's hardware or software match,
or reject the match. Decisions live in `reviews.json` in the plugin's data
directory - outside the report, which every sync replaces, so they are never
lost to a sync - and take effect on the next sync:

- accepted: the candidate's CPE is pinned for that match, the same way a CPE
  in the device's LogicVein custom field pins it (engine/cpe_field.py), so the
  match is exact and applied.
- rejected: the match is held for review instead of applied, so its CVEs are
  not reported for the device (engine build_device_report(held=...)).

A device's decisions are keyed on its LogicVein uuid (`review_key()`), so they
follow the device through a change of IP address or network; a decision made
before the uuid was kept (keyed "<network>|<ip>") moves to the uuid the first
time a sync sees that device there (`ReviewStore.migrate()`).

A decision is made either for one device or for a group: every device whose
match searches with the same text (the vendor and product text LogicVein
reports, see `group_key()`), including devices that appear with that text
later. A device's own decision takes precedence over its group's.

With CPE write-back on, an accepted candidate's CPE is also written to the
device's LogicVein custom field (writeback.py), since the match is then applied.

File format (version 2):

    {"version": 2,
     "devices": {<device key>: {<role>: <decision>}},
     "groups": {<group key>: <decision>}}

A version 1 file (just the devices mapping) is read as device decisions.
"""

import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

from .engine.device_inventory import Device

ROLES = ("hardware", "software")
ACCEPTED = "accepted"
REJECTED = "rejected"
DEVICE = "device"
GROUP = "group"
# The hold reason the engine records for a rejected match.
REJECTED_REASON = "rejected in review"

Reviews = Dict[str, Any]


def review_key(uuid: Optional[str], network: Optional[str], ip_address: Optional[str]) -> str:
    """The key a device's decisions are kept under.

    Args:
        uuid: The device's LogicVein uuid, if known.
        network: Its LogicVein network.
        ip_address: Its management IP address.

    Returns:
        "uuid:<uuid>", or "<network>|<ip>" for a device without one.
    """
    return f"uuid:{uuid}" if uuid else f"{network or ''}|{ip_address or ''}"


def device_review_key(device: Device) -> str:
    """review_key() for an engine Device."""
    return review_key(device.uuid, device.network, device.ip_address)


def match_text(device: Device) -> Dict[str, Dict[str, Optional[str]]]:
    """The vendor and product text each of a device's matches searches with.

    The same text the engine's matcher queries cvefeed.io with (and caches
    matches under), so devices with equal text get the same candidates.

    Args:
        device: The device as LogicVein reports it.

    Returns:
        role -> {"vendor": ..., "product": ...}.
    """
    return {
        "hardware": {"vendor": device.hardware_match_vendor, "product": device.hardware_match_model},
        "software": {"vendor": device.software_match_vendor, "product": device.software_product_hint},
    }


def text_changed(was: Optional[Dict[str, Optional[str]]], now: Optional[Dict[str, Optional[str]]]) -> bool:
    """Whether a device's match text differs from what it was when a decision was made.

    Args:
        was: The text recorded with the decision (None for a decision made
            before it was recorded - never flagged).
        now: The text the device reports now.

    Returns:
        True when both are known and differ.
    """
    if was is None or now is None:
        return False
    return any((was.get(k) or "").strip() != (now.get(k) or "").strip() for k in ("vendor", "product"))


def describe_text(text: Optional[Dict[str, Optional[str]]]) -> str:
    """Match text as people read it, e.g. "Cisco IOS"."""
    return " ".join(v for v in ((text or {}).get("vendor"), (text or {}).get("product")) if v) or "-"


def group_key(role: str, text: Dict[str, Optional[str]]) -> Optional[str]:
    """The key of the group of devices whose *role* match searches with *text*.

    Args:
        role: "hardware" or "software".
        text: {"vendor": ..., "product": ...} (see match_text()).

    Returns:
        The key, or None when either text is missing - such a match cannot
        be decided for a group.
    """
    vendor, product = (text.get("vendor") or "").strip(), (text.get("product") or "").strip()
    if not vendor or not product:
        return None
    return json.dumps([role, vendor, product])


def group_keys(device: Device) -> Dict[str, Optional[str]]:
    """A device's group key per role (see group_key())."""
    return {role: group_key(role, text) for role, text in match_text(device).items()}


def describe_group(key: str) -> str:
    """A group key as people read it, e.g. "cisco ios"."""
    _, vendor, product = json.loads(key)
    return f"{vendor} {product}"


class ReviewStore:
    """The review decisions file."""

    def __init__(self, path: Path) -> None:
        """Use *path* (normally <plugin data dir>/reviews.json).

        Args:
            path: The decisions file.
        """
        self.path = path

    def load(self) -> Reviews:
        """All decisions.

        Returns:
            {"devices": device key -> role -> decision, "groups": group key ->
            decision}; empty when the file is missing or unreadable (a damaged
            file must not stop a sync - it reverts to no decisions).
        """
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            data = {}
        if not isinstance(data, dict):
            data = {}
        if data.get("version") != 2:  # version 1: the devices mapping itself
            data = {"devices": data, "groups": {}}
        return {"devices": dict(data.get("devices") or {}), "groups": dict(data.get("groups") or {})}

    def _save(self, reviews: Reviews) -> None:
        """Write the file atomically: a temporary file, then a rename."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=self.path.parent, prefix=".reviews-", suffix=".json")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump({"version": 2, **reviews}, handle, indent=2, sort_keys=True)
            os.replace(tmp, self.path)
        except BaseException:
            Path(tmp).unlink(missing_ok=True)
            raise

    def accept(
        self,
        key: str,
        role: str,
        candidate: Dict[str, Any],
        by: str,
        group: Optional[str] = None,
        accepted_for: Optional[Dict[str, Optional[str]]] = None,
    ) -> None:
        """Accept one candidate for a device's match, or for its whole group.

        Args:
            key: The device's review key.
            role: "hardware" or "software".
            candidate: The candidate (id, name, vendor_name, score, cpe).
            by: Who decided.
            group: The device's group key, to decide for the group instead.
                The device's own decision for this role, if any, is removed
                so the group decision applies to it too.
            accepted_for: The text the device's match searched with when it
                was accepted (a device decision only; see match_text()).

        Raises:
            ValueError: Unknown role, or the candidate has no CPE to pin.
        """
        if role not in ROLES:
            raise ValueError(f"Unknown role {role!r}")
        if not candidate.get("cpe"):
            raise ValueError("The candidate has no CPE, so it cannot be pinned")
        decision = {
            "decision": ACCEPTED,
            "product_id": candidate.get("id"),
            "name": candidate.get("name"),
            "vendor": candidate.get("vendor_name"),
            "cpe": candidate["cpe"],
            "by": by,
            "at": datetime.now(timezone.utc).isoformat(),
        }
        if accepted_for is not None and group is None:
            decision["accepted_for"] = accepted_for
        self._set(key, role, decision, group)

    def reject(self, key: str, role: str, by: str, group: Optional[str] = None) -> None:
        """Reject a device's match, or its whole group's: hold it for review instead of applying it.

        Args:
            key: The device's review key.
            role: "hardware" or "software".
            by: Who decided.
            group: The device's group key, to decide for the group instead.

        Raises:
            ValueError: Unknown role.
        """
        if role not in ROLES:
            raise ValueError(f"Unknown role {role!r}")
        self._set(key, role, {"decision": REJECTED, "by": by, "at": datetime.now(timezone.utc).isoformat()}, group)

    def clear(self, key: str, role: str, group: Optional[str] = None) -> None:
        """Forget a decision: the device's own, or with *group*, the group's.

        Args:
            key: The device's review key.
            role: "hardware" or "software".
            group: A group key, to clear that group's decision.
        """
        reviews = self.load()
        if group is not None:
            changed = reviews["groups"].pop(group, None) is not None
        else:
            changed = reviews["devices"].get(key, {}).pop(role, None) is not None
            if changed and not reviews["devices"][key]:
                del reviews["devices"][key]
        if changed:
            self._save(reviews)

    def _set(self, key: str, role: str, decision: Dict[str, Any], group: Optional[str]) -> None:
        reviews = self.load()
        if group is not None:
            reviews["groups"][group] = {**decision, "role": role}
            own = reviews["devices"].get(key, {})
            if own.pop(role, None) is not None and not own:
                del reviews["devices"][key]
        else:
            reviews["devices"].setdefault(key, {})[role] = decision
        self._save(reviews)

    def migrate(self, moves: Dict[str, str]) -> int:
        """Move device decisions to new keys (old "<network>|<ip>" keys to uuids).

        A decision already kept under the new key wins; the old one is dropped.

        Args:
            moves: old key -> new key.

        Returns:
            How many devices' decisions moved.
        """
        reviews = self.load()
        devices = reviews["devices"]
        moved, changed = 0, False
        for old, new in moves.items():
            if old == new or old not in devices:
                continue
            decisions = devices.pop(old)
            changed = True
            if new not in devices:
                devices[new] = decisions
                moved += 1
        if changed:
            self._save(reviews)
        return moved

    @staticmethod
    def resolve(reviews: Reviews, key: str, keys: Dict[str, Optional[str]]) -> Dict[str, Dict[str, Any]]:
        """The decisions that apply to one device: its own, else its group's.

        Args:
            reviews: All decisions (load()).
            key: The device's review key.
            keys: The device's group key per role (group_keys()).

        Returns:
            role -> decision, each with "scope" ("device" or "group") and, for
            a group decision, "group" (its key).
        """
        own = reviews["devices"].get(key, {})
        resolved = {}
        for role in ROLES:
            if role in own:
                resolved[role] = {**own[role], "scope": DEVICE}
            elif keys.get(role) and keys[role] in reviews["groups"]:
                resolved[role] = {**reviews["groups"][keys[role]], "scope": GROUP, "group": keys[role]}
        return resolved

    @staticmethod
    def pins(decisions: Dict[str, Dict[str, Any]]) -> Dict[str, str]:
        """A device's accepted CPEs, role -> CPE, from its decisions."""
        return {role: d["cpe"] for role, d in decisions.items() if d.get("decision") == ACCEPTED and d.get("cpe")}

    @staticmethod
    def holds(decisions: Dict[str, Dict[str, Any]]) -> Dict[str, str]:
        """A device's rejected matches, role -> hold reason, from its decisions."""
        return {role: REJECTED_REASON for role, d in decisions.items() if d.get("decision") == REJECTED}
