"""The cvefeed.io client as the plugin uses it: the engine's client, made cancellable.

Cancel Sync has to stop a run within seconds, but a run spends most of its time
inside cvefeed.io requests - paging through a product's CVEs, and waiting out
the 429 throttle (up to a minute per wait). So every request checks for
cancellation before it is sent, and every retry wait checks every half second.
"""

import time
from dataclasses import dataclass
from typing import Any, Callable, Optional

import requests

from .engine.cvefeed_client import CVEFeedClient

# How often a retry wait checks for cancellation.
_WAIT_SLICE_SECONDS = 0.5


class CancellableCVEFeedClient(CVEFeedClient):
    """CVEFeedClient whose requests and retry waits honour Cancel Sync."""

    def __init__(self, api_key: str, **kwargs: Any) -> None:
        """Set up the client; no request is made until the first call.

        Args:
            api_key: The cvefeed.io API key.
            **kwargs: Passed on to CVEFeedClient.
        """
        super().__init__(api_key, **kwargs)
        self._check_cancelled: Optional[Callable[[], None]] = None

    def set_cancel_check(self, check: Callable[[], None]) -> None:
        """Set the callable that raises when the run has been cancelled.

        Args:
            check: Raises SyncCancelled once Cancel Sync is requested.
        """
        self._check_cancelled = check

    def _sleep(self, seconds: float) -> None:
        """Wait *seconds*, checking for cancellation every half second.

        Args:
            seconds: How long to wait.
        """
        deadline = time.monotonic() + seconds
        while True:
            if self._check_cancelled is not None:
                self._check_cancelled()
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return
            time.sleep(min(_WAIT_SLICE_SECONDS, remaining))

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        """Send one API request, after checking for cancellation.

        Args:
            method: The HTTP method.
            path: The API path.
            **kwargs: Passed on to CVEFeedClient._request().

        Returns:
            The JSON response.
        """
        if self._check_cancelled is not None:
            self._check_cancelled()
        return super()._request(method, path, **kwargs)

    def test_connection(self) -> bool:
        """Make one cheap authenticated request: the first page of vendors.

        Returns:
            True if cvefeed.io accepted the key.
        """
        self.list_vendors()
        return True


class CancellableSession(requests.Session):
    """A requests session that checks for cancellation before every request.

    Given to the vendor sources (Cisco openVuln, CVE Services, Cisco's advisory
    pages), whose constructors take a session. A request already in flight is
    not interrupted, so Cancel waits for at most that one request.
    """

    def __init__(self, check: Callable[[], None]) -> None:
        """Set up the session.

        Args:
            check: Raises SyncCancelled once Cancel Sync is requested.
        """
        super().__init__()
        self._check_cancelled = check

    def request(self, method: Any, url: Any, *args: Any, **kwargs: Any) -> requests.Response:  # type: ignore[override]
        """Check for cancellation, then send the request."""
        self._check_cancelled()
        return super().request(method, url, *args, **kwargs)


@dataclass
class CveFeedTarget:
    """What the plugin's create_client() returns: the cvefeed.io client, plus
    the optional Cisco API client credentials for the Cisco openVuln source."""

    cvefeed: CancellableCVEFeedClient
    cisco_client_id: str = ""
    cisco_client_secret: str = ""

    def test_connection(self) -> bool:
        """Check the cvefeed.io key with one cheap request.

        Returns:
            True if cvefeed.io accepted the key.
        """
        return self.cvefeed.test_connection()
