"""Writing results back to LogicVein: the CPE custom field and the device memo.

Both are optional and off by default (`logicvein.cpe_field.write`,
`logicvein.memo.write`), and both run per device, right after the device's
report is stored. A write that fails is counted, never raised: one device
LogicVein refuses must not stop the run. The rules for what is written are the
engine's (engine/cpe_field.py, engine/lvi_memo.py), carried over from
lvi_cve_feed unchanged; write_cpes() is its CLI's helper of the same job.

The writes are not undone if the run is later cancelled or fails, so LogicVein
can hold results from a run whose report was discarded; the next successful
run brings both back in line.
"""

from collections import Counter
from dataclasses import dataclass, field
from typing import Any, List

# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import get_product_name  # pyright: ignore[reportMissingImports]

from .engine.cpe_field import CPEFieldSettings, parse_field, value_to_write, write_field
from .engine.lvi_memo import update_device_memo
from .engine.report import DeviceReport, ReportCriteria

# The memo's closing line names where the full report is (the CLI named its file).
REPORT_NAME = "the CVE Report tab in Sync Manager"


@dataclass
class WriteBackSettings:
    """What to write back, from the plugin config."""

    cpe: CPEFieldSettings
    memo: bool = False
    memo_preserve: bool = True
    memo_verbose: bool = False


@dataclass
class WriteBackCounts:
    """Outcomes over a run, for the run's notes."""

    cpe: Counter = field(default_factory=Counter)
    memo: Counter = field(default_factory=Counter)

    def notes(self, slot: str) -> List[str]:
        """Run notes for the Sync Reports tab: what was written and what failed.

        Args:
            slot: The CPE custom field.

        Returns:
            Zero, one or two lines.
        """
        notes = []
        if self.cpe:
            line = (
                f"CPE field {slot}: {self.cpe['written']} written, {self.cpe['unchanged']} unchanged,"
                f" {self.cpe['other data']} left alone (the field holds other data), {self.cpe['failed']} failed"
            )
            notes.append(line)
        if self.memo:
            line = f"{get_product_name()} memos: " + ", ".join(
                f"{self.memo[k]} {k}" for k in ("created", "updated", "deleted", "unchanged", "failed")
            )
            if self.memo["failed"]:
                line += " (writing a memo needs the org.ziptie.memos.administer permission)"
            notes.append(line)
        return notes


def write_cpes(client: Any, report: DeviceReport, cpe: CPEFieldSettings) -> str:
    """Record a device's applied match CPEs in its CPE custom field.

    lvi_cve_feed's CLI helper (`_write_cpes`), unchanged; see engine/cpe_field.py
    for the rules.

    Args:
        client: The LogicVein API client.
        report: The device's report, with its matches.
        cpe: The CPE field settings.

    Returns:
        "written", "unchanged", "other data" (the field holds something else and
        overwriting is off), or "failed".
    """
    device = report.device
    current = device.custom_fields.get(cpe.slot)
    if not cpe.overwrite and parse_field(current) is None:
        return "other data"
    hardware, software = (
        match.result.best.cpe if match.auto_applied and match.result.best else None
        for match in (report.hardware, report.software)
    )
    value = value_to_write(current, hardware, software, overwrite=cpe.overwrite)
    if value is None:
        return "unchanged"
    return "written" if write_field(client, device.ip_address, device.network, cpe.slot, value) else "failed"


def write_back(
    client: Any,
    report: DeviceReport,
    settings: WriteBackSettings,
    criteria: ReportCriteria,
    run_date: str,
    counts: WriteBackCounts,
) -> List[str]:
    """Write one device's CPEs and memo, as configured.

    Args:
        client: The LogicVein API client.
        report: The device's report.
        settings: What to write.
        criteria: The run's threshold and CVSS range (the memo states them).
        run_date: The run's date and time, for the memo.
        counts: The run's counts, updated in place.

    Returns:
        Notes for the device's Sync Reports line, e.g. ["CPE written", "memo failed"].
    """
    notes = []
    if settings.cpe.write:
        outcome = write_cpes(client, report, settings.cpe)
        counts.cpe[outcome] += 1
        if outcome in ("written", "failed"):
            notes.append(f"CPE {outcome}")
    if settings.memo:
        outcome = update_device_memo(
            client, report, criteria, run_date, REPORT_NAME, settings.memo_preserve, settings.memo_verbose
        )
        counts.memo[outcome] += 1
        if outcome != "unchanged":
            notes.append(f"memo {outcome}")
    return notes
