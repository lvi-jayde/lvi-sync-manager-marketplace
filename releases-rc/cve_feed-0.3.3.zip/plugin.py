"""CVE Feed plugin - the SyncPlugin entry point."""

import copy
import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import (  # pyright: ignore[reportMissingImports]
    SyncPlugin,
    load_plugin_config,
    normalize_networks,
    t,
)

from .client import CancellableCVEFeedClient, CveFeedTarget
from .engine.cpe_field import CUSTOM_FIELDS
from .engine.vendors.cisco import CiscoPSIRTClient
from .sync import CveFeedSync

logger = logging.getLogger(__name__)


def _number(config: Dict[str, Any], path: str, low: float, high: float, whole: bool = False) -> None:
    """Check one numeric setting in place: a number within [low, high].

    Args:
        config: The config (modified in place: the value is coerced).
        path: The dotted path of the setting.
        low: The smallest allowed value.
        high: The largest allowed value.
        whole: Whether the value must be a whole number.

    Raises:
        ValueError: The value is missing, not a number, or out of range.
    """
    *parents, leaf = path.split(".")
    node = config
    for part in parents:
        node = node.setdefault(part, {})
    value = node.get(leaf)
    if value is None:
        raise ValueError(f"{path} must be set")
    try:
        number = float(value)
    except (TypeError, ValueError):
        raise ValueError(f"{path} must be a number, not {value!r}") from None
    if whole and number != int(number):
        raise ValueError(f"{path} must be a whole number, not {value!r}")
    if not low <= number <= high:
        raise ValueError(f"{path} must be between {low:g} and {high:g}, not {value!r}")
    node[leaf] = int(number) if whole else number


def validate_config(yaml_config: Dict[str, Any]) -> Dict[str, Any]:
    """Return a checked copy of the plugin's config for the engine.

    Args:
        yaml_config: The plugin's YAML config.

    Returns:
        A copy with numeric settings coerced to their types.

    Raises:
        ValueError: A setting is out of range.
    """
    config = copy.deepcopy(dict(yaml_config))
    _number(config, "matching.confidence_threshold", 0, 1)
    _number(config, "matching.cache_ttl_days", 0, 36500, whole=True)
    _number(config, "cves.max_per_product", 1, 1_000_000, whole=True)
    _number(config, "cves.cvss.min", 0, 10)
    _number(config, "cves.cvss.max", 0, 10)
    _number(config, "sync.watchdog_timeout_minutes", 0, 100_000, whole=True)
    cvss = config["cves"]["cvss"]
    if cvss["min"] > cvss["max"]:
        raise ValueError(f"cves.cvss.min ({cvss['min']:g}) must not be above cves.cvss.max ({cvss['max']:g})")
    slot = config.get("logicvein", {}).get("cpe_field", {}).get("slot", "custom1")
    if slot not in CUSTOM_FIELDS:
        raise ValueError(f"logicvein.cpe_field.slot must be one of {', '.join(CUSTOM_FIELDS)}, not {slot!r}")
    return config


def _check_cisco(client_id: str, client_secret: str) -> Tuple[bool, str]:
    """Check a Cisco API client: get a token, then make one tiny openVuln call.

    The token alone is not enough: a client for the Support (EoX) APIs only
    gets a token but is refused by openVuln (403).

    Args:
        client_id: The Cisco API client ID.
        client_secret: The Cisco API client secret.

    Returns:
        (success, detail).
    """
    try:
        response = CiscoPSIRTClient(client_id, client_secret)._get("/all", {"pageIndex": 1, "pageSize": 1})
    except Exception as exc:
        return False, str(exc)
    if response.status_code == 403:
        return False, "the client is refused (HTTP 403) - its Cisco app needs the PSIRT openVuln API enabled"
    if not response.ok:
        return False, f"HTTP {response.status_code}"
    return True, "ok"


class CveFeedPlugin(SyncPlugin):
    """Match LogicVein devices to cvefeed.io products and report their CVEs."""

    def __init__(self) -> None:
        """Load identity and config metadata from manifest.json."""
        self.config = load_plugin_config(Path(__file__).parent)

    def create_client(self, credentials: Dict[str, Any]) -> CveFeedTarget:
        """Build the cvefeed.io client and collect the optional Cisco credentials.

        Values from the Credentials tab win; the CVEFEED_API_KEY /
        CISCO_API_CLIENT_ID / CISCO_API_CLIENT_SECRET environment variables
        fill in what is missing, unless the caller asked to ignore them.

        Args:
            credentials: The saved credential values.

        Returns:
            The target for the sync engine.
        """
        use_env = not credentials.get("ignore_env_vars")

        def value(name: str, env_var: str) -> str:
            return str(credentials.get(name) or (os.getenv(env_var, "") if use_env else "")).strip()

        return CveFeedTarget(
            cvefeed=CancellableCVEFeedClient(value("api_key", "CVEFEED_API_KEY")),
            cisco_client_id=value("cisco_client_id", "CISCO_API_CLIENT_ID"),
            cisco_client_secret=value("cisco_client_secret", "CISCO_API_CLIENT_SECRET"),
        )

    def create_sync_engine(self, lvi_client: Any, target_client: Any, sync_config: Dict[str, Any]) -> CveFeedSync:
        """Build the engine for one run.

        Args:
            lvi_client: The host's LogicVein client for this run.
            target_client: The CveFeedTarget from create_client().
            sync_config: The config from build_sync_config().

        Returns:
            The sync engine.
        """
        return CveFeedSync(lvi_client, target_client, sync_config)

    def build_sync_config(self, yaml_config: Dict[str, Any], timestamp: Optional[str] = None) -> Dict[str, Any]:
        """Check the YAML config and pass it to the engine, which reads its sections directly.

        Args:
            yaml_config: The plugin's YAML config.
            timestamp: Unused (no archive files).

        Returns:
            The config for the engine.

        Raises:
            ValueError: A setting is out of range - the run fails with this
                message rather than syncing on a setting it would misread.
        """
        return validate_config(yaml_config)

    def test_connection(self, credentials: Dict[str, Any]) -> Tuple[bool, str]:
        """Check the cvefeed.io API key for the Credentials tab's Test button.

        Args:
            credentials: The credential values to test.

        Returns:
            (success, message).
        """
        target = self.create_client(credentials)
        if not target.cvefeed._api_key:
            return False, "No cvefeed.io API key"
        try:
            target.test_connection()
        except Exception as exc:
            return False, f"cvefeed.io rejected the request: {exc}"
        if bool(target.cisco_client_id) != bool(target.cisco_client_secret):
            return False, "Connected to cvefeed.io; the Cisco API client needs both an ID and a secret"
        if not target.cisco_client_id:
            return True, "Connected to cvefeed.io (Cisco openVuln not configured)"
        ok, detail = _check_cisco(target.cisco_client_id, target.cisco_client_secret)
        if not ok:
            return False, f"Connected to cvefeed.io; Cisco openVuln: {detail}"
        return True, "Connected to cvefeed.io and Cisco openVuln"

    def get_status_detail(self, config: Dict[str, Any]) -> str:
        """One-line summary for the sync tab header."""
        networks = normalize_networks(config.get("logicvein", {}).get("networks", "all"))
        return f"Network: {', '.join(networks) if networks else 'all'}"

    def get_extra_tabs(self) -> List[tuple]:
        """The plugin's own tabs: the CVE report.

        Returns:
            [(label, icon, render_fn)].
        """
        from .tabs import render_report_tab, render_review_tab  # NiceGUI only when the UI renders

        return [
            (t("cve_feed.report.title", plugin="cve_feed"), "security", render_report_tab),
            (t("cve_feed.review.title", plugin="cve_feed"), "fact_check", render_review_tab),
        ]

    def supports_cancellation(self) -> bool:
        """Return True - the engine checks for cancellation per device and per request."""
        return True
