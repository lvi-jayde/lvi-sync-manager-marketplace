"""The CVE Feed plugin's own tabs: CVE Report and Match Review.

The CVE Report tab shows the report from the last successful sync (see
store.py): a header with the run's facts and downloads, then three views -
devices, CVEs, and CVEs new since the previous sync. Every list comes from a
precomputed table, so the tab never scans the device x CVE rows to draw a
list; opening one CVE's devices does (about a second at 10,000 devices).
"""

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional
from urllib.parse import urlparse

from nicegui import app, ui

# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import (  # pyright: ignore[reportMissingImports]
    current_username,
    get_config,
    get_plugin_data_dir,
    get_product_name,
    has_role,
    require_role,
    t,
)

from . import maintenance
from .reviews import ACCEPTED, GROUP, REJECTED, ReviewStore, describe_group, describe_text
from .store import ReportReader, ReportStore

PLUGIN_ID = "cve_feed"
_SEVERITY_ORDER = ("critical", "high", "medium", "low", "na")
# The CVE's preview card, shown above a CVE id or link when the pointer rests
# on it. Its text comes ready-made in the row (_preview()); the sites linked
# to cannot be shown in a frame (they forbid it), so this is the report's own
# record of the CVE.
_PREVIEW = (
    '<q-tooltip v-if="props.row.preview" :delay="600" anchor="top middle" self="bottom middle"'
    ' max-width="32rem" class="text-body2 bg-grey-9 shadow-4">'
    '<div class="text-weight-bold">{{ props.row.preview.heading }}</div>'
    '<div v-if="props.row.preview.title" class="q-mt-xs">{{ props.row.preview.title }}</div>'
    '<div v-if="props.row.preview.description" class="q-mt-xs" style="opacity: 0.85">'
    "{{ props.row.preview.description }}</div>"
    '<div v-for="fact in props.row.preview.facts" :key="fact" class="text-caption q-mt-xs">{{ fact }}</div>'
    "</q-tooltip>"
)
# @click.stop: a link opens its page without also opening the row's dialog.
_LINK_SLOT = (
    '<q-td :props="props"><a v-if="props.row.url" :href="props.row.url" target="_blank" '
    'rel="noopener" class="text-primary" @click.stop>{{ props.value }}' + _PREVIEW + "</a>"
    "<span v-else>{{ props.value }}" + _PREVIEW + "</span></q-td>"
)
_LINKS_SLOT = (
    '<q-td :props="props"><a v-for="link in props.row.links" :key="link.url" :href="link.url" '
    'target="_blank" rel="noopener" class="text-primary q-mr-sm" @click.stop>{{ link.label }}'
    + _PREVIEW
    + "</a></q-td>"
)
# How much of a description the card shows; the CVE's dialog has all of it.
_PREVIEW_CHARS = 400


# Quasar caps a dialog's content at 560px wide; the report dialogs hold
# whole tables, so they take most of the window instead.
_WIDE_DIALOG = "width: 95vw; max-width: 95vw"


def _t(key: str, **kwargs: Any) -> str:
    """Translate one of this plugin's strings."""
    return t(f"cve_feed.report.{key}", plugin=PLUGIN_ID, **kwargs)


def _store() -> ReportStore:
    return ReportStore(get_plugin_data_dir(PLUGIN_ID) / "report")


def _age(finished_at: str) -> str:
    """Describe how long ago a run finished, e.g. "3 h ago"."""
    try:
        finished = datetime.fromisoformat(finished_at)
    except (TypeError, ValueError):
        return "?"
    minutes = int((datetime.now(timezone.utc) - finished).total_seconds() // 60)
    if minutes < 60:
        return _t("age_minutes", n=minutes)
    if minutes < 48 * 60:
        return _t("age_hours", n=minutes // 60)
    return _t("age_days", n=minutes // (24 * 60))


def _when(iso: Optional[str]) -> str:
    """An ISO timestamp as "YYYY-MM-DD HH:MM UTC"."""
    try:
        return datetime.fromisoformat(str(iso)).astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    except (TypeError, ValueError):
        return "?"


def _cvss_text(value: Any) -> str:
    return f"{value:.1f}" if isinstance(value, (int, float)) else "-"


def _device_label(row: Dict[str, Any]) -> str:
    return row.get("hostname") or row.get("ip_address") or row.get("device_key", "")


def _device_notes(row: Dict[str, Any]) -> str:
    """The short status a device row carries: error, gap, unverified match, end of support."""
    notes = []
    if row.get("error"):
        notes.append(_t("note_failed", error=row["error"]))
    if row.get("coverage"):
        notes.append(_t("note_gap", group=row["coverage"]))
    if row.get("unverified"):
        notes.append(_t("note_unverified"))
    if row.get("end_of_support"):
        notes.append(_t("note_eos", dates=row["end_of_support"]))
    return "; ".join(notes)


def _device_table_rows(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return [
        {
            "device_key": row["device_key"],
            "device": _device_label(row),
            "ip_address": row.get("ip_address"),
            "network": row.get("network"),
            "vendor": row.get("software_vendor") or row.get("hardware_vendor") or "",
            "software": row.get("software_product") or "",
            "hardware": row.get("hardware_product") or "",
            "cpe": " ".join(c for c in (row.get("software_cpe"), row.get("hardware_cpe")) if c),
            "critical": row.get("critical", 0),
            "high": row.get("high", 0),
            "medium": row.get("medium", 0),
            "low": row.get("low", 0),
            "kev": row.get("kev_count", 0),
            "new": row.get("new_count", 0),
            "max_cvss": row.get("max_cvss"),
            "max_cvss_text": _cvss_text(row.get("max_cvss")),
            "notes": _device_notes(row),
        }
        for row in rows
    ]


def _link_list(cve_id: str, links: Optional[Dict[str, Any]]) -> List[Dict[str, str]]:
    """A CVE's links as the report settings chose them, for display: cvefeed.io,
    NVD, then each vendor advisory labelled by its host.

    A report from before links were kept per CVE (`links` is None) falls back
    to the cvefeed.io page.
    """
    if links is None:
        return [{"label": "cvefeed.io", "url": f"https://cvefeed.io/vuln/detail/{cve_id}"}]
    found = []
    if links.get("cvefeed"):
        found.append({"label": "cvefeed.io", "url": links["cvefeed"]})
    if links.get("nvd"):
        found.append({"label": "NVD", "url": links["nvd"]})
    for url in links.get("vendor") or []:
        found.append({"label": urlparse(url).netloc or url, "url": url})
    return found


def _link_fields(cve_id: str, links: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """The row fields a CVE's links fill: its first link on the CVE id, all of them in Links."""
    found = _link_list(cve_id, links)
    return {"url": found[0]["url"] if found else "", "links": found}


def _date(value: Any) -> str:
    """An ISO timestamp's date part, or "" when there is none."""
    return str(value or "")[:10]


def _number(value: Any) -> Optional[float]:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _preview(
    cve_id: str,
    title: Any,
    description: Any,
    severity: Any,
    cvss: Any,
    cvss_version: Any,
    kev_due: Optional[str],
    in_kev: bool,
    published: Any,
    modified: Any,
    status: Optional[str] = None,
) -> Dict[str, Any]:
    """The preview card for one CVE, as ready-to-show text (see _PREVIEW).

    Args:
        cve_id: The CVE.
        title: Its title.
        description: Its description, cut to _PREVIEW_CHARS.
        severity: Its severity, e.g. "HIGH".
        cvss: Its CVSS score.
        cvss_version: e.g. "CVSS 3.1".
        kev_due: CISA's remediation due date, when it is in KEV.
        in_kev: Whether it is in CISA KEV.
        published: When it was published.
        modified: When it last changed.
        status: Its version status on this device, where there is one.

    Returns:
        {"heading", "title", "description", "facts"}.
    """
    level = str(severity or "").lower()
    score = _number(cvss)
    parts = [cve_id]
    if level in _SEVERITY_ORDER and level != "na":
        parts.append(_t("sev_" + level))
    if score:
        parts.append(f"CVSS {score:.1f}" + (f" ({cvss_version})" if cvss_version else ""))
    else:
        parts.append(_t("preview_unscored"))
    text = str(title or "")
    if text.startswith(f"{cve_id} - "):
        text = text[len(cve_id) + 3 :]
    desc = str(description or "")
    if len(desc) > _PREVIEW_CHARS:
        desc = desc[:_PREVIEW_CHARS].rsplit(" ", 1)[0] + "..."
    facts = []
    if in_kev:
        facts.append(_t("preview_kev", date=_date(kev_due)) if kev_due else _t("preview_kev_nodate"))
    if published:
        facts.append(_t("preview_published", date=_date(published)))
    if modified:
        facts.append(_t("preview_modified", date=_date(modified)))
    if status:
        facts.append(_t("preview_status", status=status))
    return {"heading": " - ".join(parts), "title": text, "description": desc, "facts": facts}


def _summary_preview(row: Dict[str, Any]) -> Dict[str, Any]:
    """_preview() for a cve_summary.jsonl row (the CVE and New views)."""
    return _preview(
        row["cve_id"],
        row.get("title"),
        row.get("description"),
        row.get("severity"),
        row.get("cvss"),
        row.get("cvss_version"),
        row.get("kev_due"),
        bool(row.get("kev")),
        row.get("published"),
        row.get("last_modified"),
    )


def _saved_columns(table_id: str, kind: str = "columns") -> Optional[List[str]]:
    """A column list this user last set for a table, if any (kept in their session storage).

    Args:
        table_id: The table.
        kind: "columns" (the ones shown) or "order" (the order they appear in).
    """
    try:
        value = app.storage.user.get(f"{PLUGIN_ID}.{kind}.{table_id}")
    except (RuntimeError, AssertionError):  # no user storage in this context
        return None
    return value if isinstance(value, list) else None


def _save_columns(table_id: str, names: List[str], kind: str = "columns") -> None:
    try:
        app.storage.user[f"{PLUGIN_ID}.{kind}.{table_id}"] = names
    except (RuntimeError, AssertionError):
        pass


# Header cells that can be dragged onto one another to reorder the columns.
# Clicking still sorts: q-th with props keeps its sort handling and icon.
_DRAG_HEADER_SLOT = (
    '<q-th :props="props" draggable="true" style="cursor: grab"'
    " @dragstart=\"e => e.dataTransfer.setData('text/plain', props.col.name)\""
    " @dragover.prevent"
    " @drop.prevent=\"e => $parent.$emit('column_drop',"
    " {from: e.dataTransfer.getData('text/plain'), to: props.col.name})\">"
    "{{ props.col.label }}</q-th>"
)


def _move(names: List[str], source: str, target: str) -> List[str]:
    """*names* with *source* moved to where *target* is."""
    if source == target or source not in names or target not in names:
        return names
    moved = [n for n in names if n != source]
    moved.insert(names.index(target), source)
    return moved


def _column_chooser(table: ui.table, columns: List[Dict[str, Any]], table_id: str, hidden: Iterable[str] = ()) -> None:
    """Let the user choose and arrange a table's columns.

    A button's menu shows or hides each column (the first column always
    shows), and dragging a column header onto another moves it there. Both
    are kept per user, per table.

    Args:
        table: The table.
        columns: Its columns.
        table_id: A stable name for the table, for the saved choice.
        hidden: Columns hidden until the user shows them.
    """
    names = [c["name"] for c in columns]
    columns[0]["required"] = True
    saved = _saved_columns(table_id)
    hidden = set(hidden)
    visible = [n for n in names if (n in saved if saved is not None else n not in hidden) or n == names[0]]
    by_name = {c["name"]: c for c in columns}
    saved_order = _saved_columns(table_id, "order") or []
    order = [n for n in saved_order if n in by_name] + [n for n in names if n not in saved_order]

    def apply() -> None:
        table.columns = [by_name[n] for n in order]
        table.props["visible-columns"] = [n for n in order if n in visible]
        table.update()

    def toggle(name: str, on: bool) -> None:
        if on and name not in visible:
            visible.append(name)
        elif not on and name in visible:
            visible.remove(name)
        _save_columns(table_id, [n for n in order if n in visible])
        apply()

    def dropped(event: Any) -> None:
        args = event.args or {}
        moved = _move(order, str(args.get("from", "")), str(args.get("to", "")))
        if moved != order:
            order[:] = moved
            _save_columns(table_id, list(order), "order")
            apply()

    table.add_slot("header-cell", _DRAG_HEADER_SLOT)
    table.on("column_drop", dropped)
    with ui.button(icon="view_column").props("flat dense").tooltip(_t("columns")):
        with ui.menu():
            for column in columns[1:]:
                ui.checkbox(
                    column["label"],
                    value=column["name"] in visible,
                    on_change=lambda e, n=column["name"]: toggle(n, e.value),
                ).props("dense").classes("px-2")
    apply()


def _export(reader: ReportReader, new_only: bool) -> None:
    """Write a CSV of the current report into the plugin's data directory and download it."""
    exports = get_plugin_data_dir(PLUGIN_ID) / "exports"
    exports.mkdir(parents=True, exist_ok=True)
    stamp = _when(reader.run().get("finished_at")).replace(" ", "_").replace(":", "")
    name = f"cve_feed_{'new_' if new_only else ''}{stamp}.csv"
    path = exports / name
    for old in exports.glob("cve_feed_*.csv"):  # one file per kind is enough
        if old.name != name and old.name.startswith("cve_feed_new_") == new_only:
            old.unlink(missing_ok=True)
    reader.export_csv(path, new_only=new_only)
    ui.download(Path(path), filename=name)


def _in(host: ui.element, build: Callable[[], None]) -> None:
    """Build UI (a dialog) inside *host*, the tab's own container - so it has
    a place in the page however the handler that calls this was invoked."""
    with host:
        build()


def _open_device(reader: ReportReader, key: str, row: Dict[str, Any]) -> None:
    """Show one device's matches, CVEs and exclusions in a dialog."""
    cves = reader.device_cves(key)
    exclusions = reader.device_exclusions(key)
    with ui.dialog() as dialog, ui.card().style(_WIDE_DIALOG):
        with ui.row().classes("items-center w-full"):
            ui.label(f"{row['device']} ({row.get('ip_address')}, {row.get('network')})").classes("text-lg font-bold")
            ui.space()
            ui.button(icon="close", on_click=dialog.close).props("flat dense round size=sm")
        for role in ("software", "hardware"):
            if row.get(role):
                ui.label(f"{_t('role_' + role)}: {row[role]}").classes("text-sm")
        if row.get("notes"):
            ui.label(row["notes"]).classes("text-sm text-orange-700")
        columns: List[Dict[str, Any]] = [
            {"name": "cve", "label": "CVE", "field": "cve", "sortable": True, "align": "left"},
            {"name": "severity", "label": _t("col_severity"), "field": "severity", "sortable": True, "align": "left"},
            {"name": "cvss", "label": "CVSS", "field": "cvss", "sortable": True},
            {"name": "kev", "label": "KEV", "field": "kev", "sortable": True},
            {"name": "status", "label": _t("col_version_status"), "field": "status", "align": "left"},
            {"name": "vendor", "label": _t("col_vendor_verdict"), "field": "vendor", "align": "left"},
            {"name": "title", "label": _t("col_title"), "field": "title", "align": "left"},
            {"name": "links", "label": _t("col_links"), "field": "links", "align": "left"},
        ]
        table_rows = []
        for item in cves:
            record = item.get("record") or {}
            vendor = item.get("vendor") or {}
            table_rows.append(
                {
                    "id": f"{item['role']}|{item['cve_id']}",
                    "cve": item["cve_id"],
                    **_link_fields(item["cve_id"], item.get("links") or {}),
                    "preview": _preview(
                        item["cve_id"],
                        record.get("title"),
                        record.get("description"),
                        record.get("severity"),
                        record.get("cvss_score"),
                        record.get("cvss_version"),
                        (item.get("cisa_kev") or {}).get("due_date"),
                        bool((item.get("cisa_kev") or {}).get("in_kev")),
                        record.get("published"),
                        record.get("last_modified"),
                        item.get("version_status"),
                    ),
                    "severity": str(record.get("severity") or ""),
                    "cvss": record.get("cvss_score") or "",
                    "kev": _t("yes") if (item.get("cisa_kev") or {}).get("in_kev") else "",
                    "status": item.get("version_status") or "",
                    "vendor": " ".join(str(v) for v in (vendor.get("vendor"), vendor.get("release")) if v),
                    "title": record.get("title") or "",
                }
            )
        with ui.row().classes("items-center w-full mt-2"):
            ui.label(_t("device_cves", n=len(table_rows))).classes("text-sm font-bold")
            ui.space()
            chooser = ui.row()
        table = ui.table(columns=columns, rows=table_rows, row_key="id", pagination=20).classes("w-full")
        table.props("dense flat bordered")
        table.add_slot("body-cell-cve", _LINK_SLOT)
        table.add_slot("body-cell-links", _LINKS_SLOT)
        with chooser:
            _column_chooser(table, columns, "device_cves")
        if exclusions:
            with ui.expansion(_t("exclusions", n=len(exclusions))).classes("w-full"):
                for item in exclusions:
                    detail = (
                        _t("excluded_platform", platforms=", ".join(item.get("platforms") or []))
                        if item.get("reason") == "platform"
                        else _t("excluded_vendor", release=item.get("release", ""), reason=item.get("reason", ""))
                    )
                    ui.label(f"{item['cve_id']}: {detail}").classes("text-xs")
    dialog.open()


def _open_cve(reader: ReportReader, row: Dict[str, Any]) -> None:
    """Show the devices one CVE applies to in a dialog."""
    hits = reader.cve_devices(row["cve"])
    with ui.dialog() as dialog, ui.card().style(_WIDE_DIALOG):
        with ui.row().classes("items-center w-full"):
            if row.get("url"):
                ui.link(row["cve"], row["url"], new_tab=True).classes("text-lg font-bold")
            else:
                ui.label(row["cve"]).classes("text-lg font-bold")
            ui.space()
            ui.button(icon="close", on_click=dialog.close).props("flat dense round size=sm")
        if row.get("title"):
            ui.label(row["title"]).classes("text-sm")
        if row.get("description"):
            ui.label(row["description"]).classes("text-sm text-gray-600")
        columns: List[Dict[str, Any]] = [
            {"name": "device", "label": _t("col_device"), "field": "device", "sortable": True, "align": "left"},
            {"name": "ip", "label": "IP", "field": "ip", "sortable": True, "align": "left"},
            {"name": "network", "label": _t("col_network"), "field": "network", "align": "left"},
            {"name": "role", "label": _t("col_match"), "field": "role", "align": "left"},
            {"name": "status", "label": _t("col_version_status"), "field": "status", "align": "left"},
        ]
        rows = [
            {
                "id": f"{hit['device_key']}|{hit['role']}",
                "device": hit.get("hostname") or hit.get("ip_address"),
                "ip": hit.get("ip_address"),
                "network": hit.get("network"),
                "role": _t("role_" + hit["role"]),
                "status": hit.get("version_status") or "",
            }
            for hit in hits
        ]
        for link in row.get("links") or []:
            ui.link(link["label"], link["url"], new_tab=True).classes("text-sm mr-3")
        with ui.row().classes("items-center w-full mt-2"):
            ui.label(_t("cve_devices", n=len({h["device_key"] for h in hits}))).classes("text-sm font-bold")
            ui.space()
            chooser = ui.row()
        table = ui.table(columns=columns, rows=rows, row_key="id", pagination=20).classes("w-full")
        table.props("dense flat bordered")
        with chooser:
            _column_chooser(table, columns, "cve_devices")
    dialog.open()


def _devices_view(reader: ReportReader, run: Dict[str, Any], host: ui.element, on_change: Callable[[], None]) -> None:
    rows = _device_table_rows(reader.device_rows())
    vendors = sorted({r["vendor"] for r in rows if r["vendor"]})
    columns: List[Dict[str, Any]] = [
        {"name": "device", "label": _t("col_device"), "field": "device", "sortable": True, "align": "left"},
        {"name": "ip_address", "label": "IP", "field": "ip_address", "sortable": True, "align": "left"},
        {"name": "network", "label": _t("col_network"), "field": "network", "sortable": True, "align": "left"},
        {"name": "vendor", "label": _t("col_vendor"), "field": "vendor", "sortable": True, "align": "left"},
        {"name": "software", "label": _t("col_software"), "field": "software", "sortable": True, "align": "left"},
        {"name": "hardware", "label": _t("col_hardware"), "field": "hardware", "sortable": True, "align": "left"},
        {"name": "cpe", "label": "CPE", "field": "cpe", "sortable": True, "align": "left"},
        {"name": "critical", "label": _t("sev_critical"), "field": "critical", "sortable": True},
        {"name": "high", "label": _t("sev_high"), "field": "high", "sortable": True},
        {"name": "medium", "label": _t("sev_medium"), "field": "medium", "sortable": True},
        {"name": "low", "label": _t("sev_low"), "field": "low", "sortable": True},
        {"name": "kev", "label": "KEV", "field": "kev", "sortable": True},
        {"name": "new", "label": _t("col_new"), "field": "new", "sortable": True},
        {"name": "max_cvss", "label": _t("col_max_cvss"), "field": "max_cvss_text", "sortable": True},
        {"name": "notes", "label": _t("col_notes"), "field": "notes", "align": "left"},
    ]
    state: Dict[str, Any] = {"vendor": None, "kev": False, "new": False}
    with ui.row().classes("items-center gap-4 w-full"):
        search = ui.input(placeholder=_t("search")).props("dense clearable").classes("w-64")
        vendor = ui.select([_t("all_vendors"), *vendors], value=_t("all_vendors"), label=_t("col_vendor")).props(
            "dense"
        )
        kev = ui.checkbox(_t("kev_only"))
        new = ui.checkbox(_t("new_only"))
        ui.space()
        chooser = ui.row()
    admin = has_role("admin")
    actions = ui.row().classes("items-center gap-2 w-full")
    table = ui.table(
        columns=columns,
        rows=rows,
        row_key="device_key",
        pagination=25,
        selection="multiple" if admin else None,
    ).classes("w-full")
    table.props("dense flat bordered")
    search.bind_value_to(table, "filter")
    with chooser:
        _column_chooser(table, columns, "devices", hidden=("cpe",))
    with actions:
        _report_tools(reader, run, host, on_change)
        if admin:
            _device_actions(reader, host, table, on_change)

    def apply_filters() -> None:
        state.update(vendor=None if vendor.value == _t("all_vendors") else vendor.value, kev=kev.value, new=new.value)
        table.rows = [
            r
            for r in rows
            if (state["vendor"] is None or r["vendor"] == state["vendor"])
            and (not state["kev"] or r["kev"])
            and (not state["new"] or r["new"])
        ]
        table.update()

    for control in (vendor, kev, new):
        control.on_value_change(lambda _: apply_filters())
    table.on("rowClick", lambda e: _in(host, lambda: _open_device(reader, e.args[1]["device_key"], e.args[1])))


def _cves_view(reader: ReportReader, run: Dict[str, Any], host: ui.element, on_change: Callable[[], None]) -> None:
    rows = [
        {
            "cve": row["cve_id"],
            **_link_fields(row["cve_id"], row.get("links")),
            "preview": _summary_preview(row),
            "description": row.get("description") or "",
            "severity": row.get("severity") or "na",
            "severity_text": _t("sev_" + (row.get("severity") or "na")),
            "severity_rank": _SEVERITY_ORDER.index(row.get("severity") or "na"),
            "cvss": row.get("cvss"),
            "cvss_text": _cvss_text(row.get("cvss")),
            "kev": _t("yes") if row.get("kev") else "",
            "devices": row.get("device_count", 0),
            "published": str(row.get("published") or "")[:10],
            "title": row.get("title") or "",
        }
        for row in reader.cve_rows()
    ]
    rows.sort(key=lambda r: (r["severity_rank"], -(r["cvss"] or 0), -r["devices"]))
    columns: List[Dict[str, Any]] = [
        {"name": "cve", "label": "CVE", "field": "cve", "sortable": True, "align": "left"},
        {"name": "severity", "label": _t("col_severity"), "field": "severity_text", "align": "left"},
        {"name": "cvss", "label": "CVSS", "field": "cvss_text", "sortable": True},
        {"name": "kev", "label": "KEV", "field": "kev", "sortable": True},
        {"name": "devices", "label": _t("col_devices"), "field": "devices", "sortable": True},
        {"name": "published", "label": _t("col_published"), "field": "published", "sortable": True},
        {"name": "title", "label": _t("col_title"), "field": "title", "align": "left"},
        {"name": "links", "label": _t("col_links"), "field": "links", "align": "left"},
    ]
    severity_options = {s: _t("sev_" + s) for s in _SEVERITY_ORDER}
    with ui.row().classes("items-center gap-4 w-full"):
        search = ui.input(placeholder=_t("search")).props("dense clearable").classes("w-64")
        severities = (
            ui.select(severity_options, value=list(_SEVERITY_ORDER), multiple=True, label=_t("col_severity"))
            .props("dense use-chips")
            .classes("min-w-[16rem]")
        )
        kev = ui.checkbox(_t("kev_only"))
        low = ui.number(_t("cvss_min"), value=0.0, min=0, max=10, step=0.1, precision=1).props("dense").classes("w-28")
        high = (
            ui.number(_t("cvss_max"), value=10.0, min=0, max=10, step=0.1, precision=1).props("dense").classes("w-28")
        )
        ui.space()
        chooser = ui.row()
    with ui.row().classes("items-center gap-2 w-full"):
        _report_tools(reader, run, host, on_change)
    table = ui.table(columns=columns, rows=rows, row_key="cve", pagination=25).classes("w-full")
    table.props("dense flat bordered")
    table.add_slot("body-cell-cve", _LINK_SLOT)
    table.add_slot("body-cell-links", _LINKS_SLOT)
    search.bind_value_to(table, "filter")
    with chooser:
        _column_chooser(table, columns, "cves")

    def apply_filters() -> None:
        chosen = set(severities.value or [])
        lo, hi = float(low.value or 0), float(high.value if high.value is not None else 10)
        table.rows = [
            r
            for r in rows
            if r["severity"] in chosen and (not kev.value or r["kev"]) and (r["cvss"] is None or lo <= r["cvss"] <= hi)
        ]
        table.update()

    for control in (severities, kev, low, high):
        control.on_value_change(lambda _: apply_filters())
    table.on("rowClick", lambda e: _in(host, lambda: _open_cve(reader, e.args[1])))


def _new_view(reader: ReportReader, run: Dict[str, Any], host: ui.element, on_change: Callable[[], None]) -> None:
    with ui.row().classes("items-center gap-2 w-full"):
        _report_tools(reader, run, host, on_change)
    if not run.get("baseline_finished_at"):
        ui.label(_t("no_baseline")).classes("text-gray-500")
        return
    devices = {row["device_key"]: row for row in reader.device_rows()}
    cves = {row["cve_id"]: row for row in reader.cve_rows()}
    rows = []
    for item in reader.new_cves():
        device, cve = devices.get(item["device_key"], {}), cves.get(item["cve_id"], {})
        rows.append(
            {
                "id": f"{item['device_key']}|{item['cve_id']}",
                "device": _device_label(device),
                "ip": device.get("ip_address"),
                "cve": item["cve_id"],
                **_link_fields(item["cve_id"], cve.get("links")),
                "preview": _summary_preview(cve) if cve else None,
                "severity": _t("sev_" + (cve.get("severity") or "na")),
                "cvss": _cvss_text(cve.get("cvss")),
                "kev": _t("yes") if cve.get("kev") else "",
                "title": cve.get("title") or "",
            }
        )
    with ui.row().classes("items-center w-full"):
        ui.label(_t("new_since", when=_when(run["baseline_finished_at"]), n=len(rows))).classes("text-sm")
        ui.space()
        chooser = ui.row()
    columns: List[Dict[str, Any]] = [
        {"name": "device", "label": _t("col_device"), "field": "device", "sortable": True, "align": "left"},
        {"name": "ip", "label": "IP", "field": "ip", "sortable": True, "align": "left"},
        {"name": "cve", "label": "CVE", "field": "cve", "sortable": True, "align": "left"},
        {"name": "severity", "label": _t("col_severity"), "field": "severity", "sortable": True, "align": "left"},
        {"name": "cvss", "label": "CVSS", "field": "cvss", "sortable": True},
        {"name": "kev", "label": "KEV", "field": "kev", "sortable": True},
        {"name": "title", "label": _t("col_title"), "field": "title", "align": "left"},
        {"name": "links", "label": _t("col_links"), "field": "links", "align": "left"},
    ]
    table = ui.table(columns=columns, rows=rows, row_key="id", pagination=25).classes("w-full")
    table.props("dense flat bordered")
    table.add_slot("body-cell-cve", _LINK_SLOT)
    table.add_slot("body-cell-links", _LINKS_SLOT)
    with chooser:
        _column_chooser(table, columns, "new")


def _criteria_notes(criteria: Optional[Dict[str, Any]]) -> List[str]:
    """What a report was built with, as run notes: the match threshold, the
    CVSS range, and whether unscored CVEs were kept. None for a report from
    before these were recorded."""
    if not criteria:
        return []
    notes = [_t("criteria_threshold", threshold=f"{float(criteria.get('confidence_threshold', 0)):.2f}")]
    if criteria.get("auto_apply") is False:
        notes.append(_t("criteria_no_auto_apply"))
    low, high = criteria.get("cvss_min"), criteria.get("cvss_max")
    notes.append(
        _t(
            "criteria_cvss",
            min=f"{float(low if low is not None else 0):.1f}",
            max=f"{float(high if high is not None else 10):.1f}",
        )
    )
    notes.append(_t("criteria_unscored_in" if criteria.get("include_unscored") else "criteria_unscored_out"))
    return notes


# ---------------------------------------------------------------------------
# Maintenance (admins): see maintenance.py
# ---------------------------------------------------------------------------


def _mt(key: str, **kwargs: Any) -> str:
    """Translate one of the maintenance strings."""
    return t(f"cve_feed.maint.{key}", plugin=PLUGIN_ID, **kwargs)


def _cpe_slot() -> str:
    """The CPE custom field the plugin is configured to use."""
    try:
        config = get_config(Path("conf/cve_feed_sync_config.yaml"), Path(__file__).parent / "conf" / "defaults.yaml")
        return str(config.get("logicvein", {}).get("cpe_field", {}).get("slot") or "custom1")
    except Exception:  # an unreadable config still allows the action; name the default
        return "custom1"


def _run_action(action: Callable[[], str], on_change: Callable[[], None]) -> None:
    """Run a maintenance action unless a sync is running, and say how it went."""
    if not require_role("admin"):
        return
    try:
        with maintenance.exclusive():
            message = action()
    except maintenance.Busy:
        ui.notify(_mt("busy"), type="warning")
        return
    ui.notify(message, type="positive")
    on_change()


def _maintenance_menu(reader: ReportReader, host: ui.element, on_change: Callable[[], None]) -> None:
    """The admin actions on the whole cache, as a menu beside the downloads."""
    data_dir = get_plugin_data_dir(PLUGIN_ID)
    texts = set()
    for row in reader.device_rows():
        texts |= maintenance.search_texts(maintenance.device_from_row(row))

    def run_delete_cache() -> str:
        maintenance.delete_cache(data_dir)
        return _mt("done_delete_cache")

    def run_forget() -> str:
        maintenance.forget_matches(data_dir)
        return _mt("done_forget")

    def delete_cache() -> None:
        _confirm(
            host,
            _mt("delete_cache_title"),
            [_mt("delete_cache_text"), _mt("delete_cache_kept"), _mt("next_sync")],
            lambda: _run_action(run_delete_cache, on_change),
            danger=True,
        )

    def forget() -> None:
        _confirm(
            host,
            _mt("forget_matches_title"),
            [_mt("forget_matches_text", n=len(texts)), _mt("forget_matches_kept"), _mt("next_sync")],
            lambda: _run_action(run_forget, on_change),
        )

    with ui.dropdown_button(_mt("title"), icon="build").props("outline dense"):
        # A card gives the menu's text a solid, theme-aware background.
        with ui.card().props("flat").classes("p-0 gap-0 max-w-sm"):
            ui.label(_mt("intro")).classes("text-xs text-gray-500 px-4 pt-2")
            ui.item(_mt("forget_matches"), on_click=forget).mark("cve-feed-forget-matches")
            ui.item(_mt("delete_cache"), on_click=delete_cache).classes("text-negative").mark("cve-feed-delete-cache")
            ui.label(_mt("select_hint")).classes("text-xs text-gray-500 px-4 pb-2")


def _report_tools(reader: ReportReader, run: Dict[str, Any], host: ui.element, on_change: Callable[[], None]) -> None:
    """The tools above every report table: the CSV downloads and, for admins, Maintenance."""
    ui.button(_t("download_csv"), icon="download", on_click=lambda: _export(reader, False)).props("outline dense")
    new_csv = ui.button(_t("download_new_csv"), icon="download", on_click=lambda: _export(reader, True)).props(
        "outline dense"
    )
    if not run.get("baseline_finished_at"):
        new_csv.disable()
    if has_role("admin"):
        _maintenance_menu(reader, host, on_change)


def _device_actions(reader: ReportReader, host: ui.element, table: ui.table, on_change: Callable[[], None]) -> None:
    """The Devices view's admin actions on the selected devices."""
    data_dir = get_plugin_data_dir(PLUGIN_ID)
    rows = {row["device_key"]: row for row in reader.device_rows()}
    products = reader.applied_products()
    review_keys = reader.review_keys()

    def chosen() -> List[str]:
        keys = [row["device_key"] for row in table.selected or []]
        if not keys:
            ui.notify(_mt("select_first"), type="warning")
        return keys

    def rematch() -> None:
        keys = chosen()
        if not keys:
            return
        devices = [maintenance.device_from_row(rows[k]) for k in keys if k in rows]
        texts = set()
        for device in devices:
            texts |= maintenance.search_texts(device)
        others = [
            k
            for k, row in rows.items()
            if k not in keys and maintenance.search_texts(maintenance.device_from_row(row)) & texts
        ]
        own = ReviewStore(data_dir / "reviews.json").load()["devices"]
        decisions = sum(len(own.get(review_keys.get(k, k), {})) for k in keys)
        lines = [_mt("rematch_text", n=len(keys))]
        if others:
            lines.append(_mt("rematch_shared", m=len(others)))
        if decisions:
            lines.append(_mt("rematch_decisions", d=decisions))
        lines += [_mt("rematch_kept"), _mt("next_sync")]

        def run() -> str:
            removed = maintenance.forget_device_matches(data_dir, devices)
            store = ReviewStore(data_dir / "reviews.json")
            for key in keys:
                for role in ("hardware", "software"):
                    store.clear(review_keys.get(key, key), role)
            return _mt("done_rematch", n=len(keys), m=removed)

        _confirm(host, _mt("rematch_title", n=len(keys)), lines, lambda: _run_action(run, on_change))

    def refresh() -> None:
        keys = chosen()
        if not keys:
            return
        ids = {pid for k in keys for pid in products.get(k, [])}
        if not ids:
            ui.notify(_mt("refresh_none"), type="warning")
            return
        others = [k for k, pids in products.items() if k not in keys and set(pids) & ids]
        lines = [_mt("refresh_text", n=len(keys), p=len(ids))]
        if others:
            lines.append(_mt("refresh_shared", m=len(others)))
        lines += [_mt("refresh_kept"), _mt("next_sync")]
        _confirm(
            host,
            _mt("refresh_title", n=len(keys)),
            lines,
            lambda: _run_action(lambda: _mt("done_refresh", p=maintenance.refresh_products(data_dir, ids)), on_change),
        )

    def clear_cpe() -> None:
        keys = chosen()
        if not keys:
            return
        slot = _cpe_slot()

        def run() -> str:
            maintenance.queue_cpe_clears(data_dir, [review_keys.get(k, k) for k in keys])
            return _mt("done_clear_cpe", n=len(keys))

        _confirm(
            host,
            _mt("clear_cpe_title", n=len(keys)),
            [
                _mt("clear_cpe_text", n=len(keys), slot=slot, product=get_product_name()),
                _mt("clear_cpe_effects"),
                _mt("next_sync"),
            ],
            lambda: _run_action(run, on_change),
            danger=True,
        )

    ui.button(_mt("rematch"), icon="manage_search", on_click=rematch).props("outline dense")
    ui.button(_mt("refresh"), icon="refresh", on_click=refresh).props("outline dense")
    ui.button(_mt("clear_cpe"), icon="backspace", on_click=clear_cpe).props("outline dense color=negative")
    pending = maintenance.pending_cpe_clears(data_dir)
    if pending:
        ui.label(_mt("pending_cpe", n=len(pending))).classes("text-xs text-orange-700")


def render_report_tab() -> Callable[[], None]:
    """Render the CVE Report tab; returns the refresh run on each visit.

    Returns:
        A callable that reloads the tab from the current report.
    """
    container = ui.column().classes("w-full")
    view = {"name": "devices"}

    def refresh() -> None:
        container.clear()
        reader = _store().reader()
        with container:
            if reader is None:
                ui.label(_t("empty")).classes("text-gray-500")
                return
            run = reader.run()

            def show(name: str) -> None:
                view["name"] = name
                refresh()

            ui.toggle(
                {"devices": _t("view_devices"), "cves": _t("view_cves"), "new": _t("view_new")},
                value=view["name"],
                on_change=lambda e: show(e.value),
            )
            # The run's facts, collapsed so the table starts near the top:
            # what it covered, what is new, what it was built with, and notes.
            notes = [
                _t(
                    "summary",
                    when=_when(run.get("finished_at")),
                    age=_age(run.get("finished_at", "")),
                    devices=run.get("device_count", 0),
                    failed=run.get("failed_count", 0),
                    cves=run.get("cve_count", 0),
                    kev=run.get("kev_cve_count", 0),
                )
            ]
            if run.get("baseline_finished_at"):
                notes.append(_t("new_summary", n=run.get("new_cve_count", 0), when=_when(run["baseline_finished_at"])))
            notes += [*_criteria_notes(run.get("criteria")), *(run.get("notes") or [])]
            with ui.expansion(_t("run_notes", n=len(notes)), icon="info").props("dense").classes("w-full"):
                with ui.column().classes("gap-0"):
                    for note in notes:
                        ui.label(note).classes("text-sm")
            if run.get("errors"):
                with (
                    ui.expansion(_t("run_errors", n=len(run["errors"])), icon="warning")
                    .props("dense")
                    .classes("w-full text-negative")
                ):
                    with ui.column().classes("gap-0"):
                        for error in run["errors"]:
                            ui.label(error).classes("text-sm")
            if view["name"] == "devices":
                _devices_view(reader, run, container, refresh)
            elif view["name"] == "cves":
                _cves_view(reader, run, container, refresh)
            else:
                _new_view(reader, run, container, refresh)

    refresh()
    return refresh


# ---------------------------------------------------------------------------
# Match Review
# ---------------------------------------------------------------------------


def _rt(key: str, **kwargs: Any) -> str:
    """Translate one of the Match Review tab's strings."""
    return t(f"cve_feed.review.{key}", plugin=PLUGIN_ID, **kwargs)


def _reviews() -> ReviewStore:
    return ReviewStore(get_plugin_data_dir(PLUGIN_ID) / "reviews.json")


def _reason_text(reason: str) -> str:
    if reason in ("below_threshold", "unverified", "decided", "changed"):
        return _rt("reason_" + reason)
    return reason  # an engine hold reason (a tie, a held release, "rejected in review")


def _decision_text(decision: Optional[Dict[str, Any]]) -> str:
    if not decision:
        return ""
    who = decision.get("by") or "?"
    if decision.get("decision") == ACCEPTED:
        text = _rt("decision_accepted", name=decision.get("name") or decision.get("cpe"), by=who)
    else:
        text = _rt("decision_rejected", by=who)
    if decision.get("scope") == GROUP and decision.get("group"):
        text += " " + _rt("decision_group_suffix", text=describe_group(decision["group"]))
    return text


def _confirm(
    host: ui.element, title: str, lines: List[str], on_confirm: Callable[[], None], danger: bool = False
) -> None:
    """Ask before an action that reaches further than the item in view.

    Args:
        host: The tab's container (see _in()).
        title: The question.
        lines: What will happen, one paragraph each.
        on_confirm: Run when confirmed.
        danger: Show the confirm button in the warning colour.
    """

    def build() -> None:
        with ui.dialog() as dialog, ui.card().classes("w-full max-w-2xl"):
            ui.label(title).classes("text-lg font-bold")
            for line in lines:
                ui.label(line).classes("text-sm")
            with ui.row().classes("w-full justify-end gap-2 mt-2"):
                ui.button(_rt("cancel"), on_click=dialog.close).props("flat")

                def go() -> None:
                    dialog.close()
                    on_confirm()

                ui.button(_rt("confirm"), on_click=go).props("color=negative" if danger else "color=primary")
        dialog.open()

    _in(host, build)


def _open_review(item: Dict[str, Any], reader: ReportReader, host: ui.element, on_change: Callable[[], None]) -> None:
    """Show one match's candidates, with the reviewer's actions."""
    store = _reviews()
    can_decide = has_role("admin")
    key, role = item.get("review_key") or item["device_key"], item["role"]
    role_name = _t("role_" + role)
    group = item.get("group_key")
    decision = item.get("decision") or {}

    def members_with_own_decision() -> int:
        own = store.load()["devices"]
        review_keys = reader.review_keys()
        members = {review_keys.get(m, m) for m in reader.group_members(group or "")}
        return sum(1 for member in members if member != key and role in own.get(member, {}))

    def act(action: Callable[[], None], message: str) -> None:
        if not require_role("admin"):
            return
        action()
        ui.notify(message, type="positive")
        dialog.close()
        on_change()

    def decide(kind: str, candidate: Optional[Dict[str, Any]] = None) -> None:
        """Accept *candidate* or reject, for this device or (when chosen) its group."""
        by = current_username()
        if not (group and for_group.value):
            if kind == ACCEPTED and candidate is not None:
                act(
                    lambda: store.accept(key, role, candidate, by, accepted_for=item.get("match_text")),
                    _rt("accepted", name=candidate.get("name")),
                )
            else:
                act(lambda: store.reject(key, role, by), _rt("rejected"))
            return
        text, size = describe_group(group), item.get("group_size", 0)
        overrides = members_with_own_decision()
        if kind == ACCEPTED and candidate is not None:
            lines = [_rt("group_confirm_accept", name=candidate.get("name"), role=role_name, text=text, n=size)]
            run = lambda: act(  # noqa: E731
                lambda: store.accept(key, role, candidate, by, group=group), _rt("accepted", name=candidate.get("name"))
            )
        else:
            lines = [_rt("group_confirm_reject", role=role_name, text=text, n=size)]
            run = lambda: act(lambda: store.reject(key, role, by, group=group), _rt("rejected"))  # noqa: E731
        if overrides:
            lines.append(_rt("group_overrides", m=overrides))
        lines.append(_rt("group_undo"))
        _confirm(host, _rt("group_confirm_title", n=size), lines, run)

    def clear() -> None:
        if decision.get("scope") != GROUP:
            act(lambda: store.clear(key, role), _rt("cleared"))
            return
        text, size = describe_group(decision["group"]), item.get("group_size", 0)
        _confirm(
            host,
            _rt("clear_group", n=size),
            [_rt("clear_group_confirm", text=text, n=size)],
            lambda: act(lambda: store.clear(key, role, group=decision["group"]), _rt("cleared")),
        )

    with ui.dialog() as dialog, ui.card().classes("w-full max-w-4xl"):
        with ui.row().classes("items-center w-full"):
            label = item.get("hostname") or item.get("ip_address") or item["device_key"]
            ui.label(f"{label} - {role_name}").classes("text-lg font-bold")
            ui.space()
            ui.button(icon="close", on_click=dialog.close).props("flat dense round size=sm")
        ui.label(_rt("why", reason=_reason_text(item["reason"]))).classes("text-sm")
        if item.get("changed"):
            ui.label(
                _rt(
                    "changed_detail",
                    was=describe_text(item["changed"]["was"]),
                    now=describe_text(item["changed"]["now"]),
                )
            ).classes("text-sm text-orange-700")
        if decision:
            ui.label(_decision_text(decision)).classes("text-sm font-bold")
        if not item["candidates"]:
            ui.label(_rt("no_candidates")).classes("text-sm text-gray-500")
        for_group = ui.checkbox(
            _rt("group_option", n=item.get("group_size", 0), role=role_name, text=describe_group(group))
            if group
            else ""
        ).props("dense")
        for_group.set_visibility(bool(group) and can_decide)
        for candidate in item["candidates"]:
            score = candidate.get("score")
            with ui.row().classes("items-center w-full gap-4 border-b py-1"):
                ui.label(
                    f"{candidate.get('vendor_name', '')} {candidate.get('name', '')}" f" ({score:.2f})"
                    if isinstance(score, (int, float))
                    else candidate.get("name", "")
                ).classes("min-w-[18rem]")
                ui.label(candidate.get("cpe") or "-").classes("text-xs text-gray-600")
                ui.space()
                if can_decide and candidate.get("cpe"):
                    ui.button(_rt("accept"), icon="check", on_click=lambda c=candidate: decide(ACCEPTED, c)).props(
                        "outline dense color=positive"
                    )
        if can_decide:
            with ui.row().classes("gap-2 mt-2"):
                ui.button(_rt("reject"), icon="block", on_click=lambda: decide(REJECTED)).props(
                    "outline dense color=negative"
                )
                if decision:
                    ui.button(
                        (
                            _rt("clear_group", n=item.get("group_size", 0))
                            if decision.get("scope") == GROUP
                            else _rt("clear")
                        ),
                        icon="undo",
                        on_click=clear,
                    ).props("outline dense")
        else:
            ui.label(_rt("admin_only")).classes("text-xs text-gray-500 mt-2")
    dialog.open()


def render_review_tab() -> Callable[[], None]:
    """Render the Match Review tab; returns the refresh run on each visit.

    Returns:
        A callable that reloads the tab.
    """
    container = ui.column().classes("w-full")
    view = {"name": "open"}

    def refresh() -> None:
        container.clear()
        reader = _store().reader()
        with container:
            if reader is None:
                ui.label(_t("empty")).classes("text-gray-500")
                return
            items = reader.review_items(_reviews().load())
            ui.label(_rt("intro")).classes("text-sm")
            changed = sum(1 for i in items if i.get("changed"))
            if changed:
                ui.label(_rt("changed_count", n=changed)).classes("text-sm text-orange-700 font-bold")
            criteria = reader.run().get("criteria") or {}
            if criteria:
                ui.label(_rt("threshold", threshold=f"{float(criteria.get('confidence_threshold', 0)):.2f}")).classes(
                    "text-sm font-bold"
                )
                if criteria.get("auto_apply") is False:
                    ui.label(_t("criteria_no_auto_apply")).classes("text-sm")

            def show(name: str) -> None:
                view["name"] = name
                refresh()

            with ui.row().classes("items-center w-full"):
                ui.toggle(
                    {"open": _rt("view_open"), "decided": _rt("view_decided"), "all": _rt("view_all")},
                    value=view["name"],
                    on_change=lambda e: show(e.value),
                )
                ui.space()
                chooser = ui.row()
            if view["name"] == "open":
                # A pin whose device has changed needs a look even though it is decided.
                items = [i for i in items if not i.get("decision") or i.get("changed")]
            elif view["name"] == "decided":
                items = [i for i in items if i.get("decision")]
            rows = []
            for item in items:
                best = item.get("best") or {}
                score = best.get("score")
                rows.append(
                    {
                        "id": f"{item['device_key']}|{item['role']}",
                        "device": item.get("hostname") or item.get("ip_address") or item["device_key"],
                        "ip": item.get("ip_address"),
                        "role": _t("role_" + item["role"]),
                        "why": _reason_text(item["reason"]),
                        "best": f"{best.get('vendor_name', '')} {best.get('name', '')}".strip(),
                        "score": f"{score:.2f}" if isinstance(score, (int, float)) else "",
                        "applied": _t("yes") if item["applied"] else "",
                        "decision": _decision_text(item.get("decision")),
                    }
                )
            columns: List[Dict[str, Any]] = [
                {"name": "device", "label": _t("col_device"), "field": "device", "sortable": True, "align": "left"},
                {"name": "ip", "label": "IP", "field": "ip", "sortable": True, "align": "left"},
                {"name": "role", "label": _t("col_match"), "field": "role", "sortable": True, "align": "left"},
                {"name": "why", "label": _rt("col_why"), "field": "why", "align": "left"},
                {"name": "best", "label": _rt("col_best"), "field": "best", "align": "left"},
                {"name": "score", "label": _rt("col_score"), "field": "score", "sortable": True},
                {"name": "applied", "label": _rt("col_applied"), "field": "applied"},
                {"name": "decision", "label": _rt("col_decision"), "field": "decision", "align": "left"},
            ]
            if not rows:
                ui.label(_rt("nothing")).classes("text-gray-500")
                return
            table = ui.table(columns=columns, rows=rows, row_key="id", pagination=25).classes("w-full")
            table.props("dense flat bordered")
            with chooser:
                _column_chooser(table, columns, "review")
            by_id = {f"{i['device_key']}|{i['role']}": i for i in items}
            table.on(
                "rowClick",
                lambda e: _in(container, lambda: _open_review(by_id[e.args[1]["id"]], reader, container, refresh)),
            )

    refresh()
    return refresh
