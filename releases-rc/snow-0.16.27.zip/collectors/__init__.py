"""ServiceNow plugin collectors subsystem."""
