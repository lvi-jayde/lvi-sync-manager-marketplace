"""Background services contributed by the Jira plugin.

The Jira plugin is a *subscriber*: it registers the alert handler for the core
``/webhook/lvi-alert`` route and, when config-change detection is enabled
(features.change_detection), the config-change issue creator. It does not start a
detection backend - that is a single core-owned service (the universal emitter),
so installing both the ServiceNow and Jira plugins does not double-detect changes.
"""

from typing import Any, List


def build_services() -> List[Any]:
    """Register the Jira handlers (no backend - the core owns the emitter).

    Reentrant: the host calls it again when settings change; registrations are
    idempotent by identity. Returns no services - the Jira plugin only subscribes
    to the core-owned config-change emitter via register_change_handler.
    """
    # src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
    from src.plugin_api import get_app_settings  # pyright: ignore[reportMissingImports]

    from .settings import get_change_detection_settings

    # LVI alert handler (capability "alerts"); the core /webhook/lvi-alert route
    # fans events out to it.
    if get_app_settings().get("features", {}).get("alerts", True):
        # src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
        from src.plugin_api import register_alert_handler  # pyright: ignore[reportMissingImports]

        from .webhook.alert_handler import get_alert_handler

        register_alert_handler(get_alert_handler())

    cfg = get_change_detection_settings()
    if not cfg.get("enabled", False):
        return []

    # Subscribe to the core-owned config-change emitter: our issue creator opens a
    # Jira issue for each ConfigChangeEvent (in either detection mode).
    # src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
    from src.plugin_api import register_change_handler  # pyright: ignore[reportMissingImports]

    from .change_detection.issue import get_change_creator

    register_change_handler(get_change_creator())

    return []
