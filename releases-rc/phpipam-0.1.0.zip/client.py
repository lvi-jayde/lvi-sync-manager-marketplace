"""phpIPAM REST API client (sections, subnets, addresses, custom fields).

Authenticates with phpIPAM's session-token flow: ``POST /api/<app_id>/user/``
with HTTP Basic auth returns a ``token`` (~6h TTL), sent as the
``phpipam-token`` header on every subsequent request. The token is acquired
lazily on first use and re-acquired once on a 401, mirroring how every other
plugin's client handles auth expiry.

Every behaviour here was verified live against a real phpIPAM 1.8.2 instance -
see ``docs/dev_notes/PHPIPAM_PLUGIN_PLAN.md`` in the sibling app repo for the
raw probe transcript. Two gotchas specific to phpIPAM's API, both confirmed
live and centralised here so ``sync.py`` never has to special-case them:

- phpIPAM returns HTTP 404 for both "no such route" and "no data yet" (e.g.
  ``{"code":404,"message":"No addresses found"}`` for a genuinely empty
  result). :meth:`_request` treats a 404 whose message matches that shape as
  an empty result, not an error.
- Custom field values round-trip as flat ``custom_<fieldname>`` keys directly
  on the object (e.g. an address's ``custom_lvi_managed``), not nested.
"""

import logging
import os
import re
from typing import Any, Dict, List, Optional

import requests

# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import build_retry_adapter, make_json_request  # pyright: ignore[reportMissingImports]

logger = logging.getLogger(__name__)

# How much of an HTTP error body to log - see other plugin clients for the
# same bounded-truncation rationale (an error body is unbounded in principle).
_ERROR_BODY_CHARS = 500

# phpIPAM's shape for "empty result", not "route missing" - e.g.
# {"code":404,"message":"No addresses found"} / "No custom fields defined" /
# "No devices configured" / "No vrfs configured". Confirmed live across every
# list-type endpoint this client calls.
_EMPTY_RESULT_RE = re.compile(r"^No .+ (configured|found|defined)$", re.IGNORECASE)

# The marker field this plugin's stale-address cleanup relies on. Field
# *definitions* are UI-only in phpIPAM (no API to create one) - see
# get_custom_fields()'s docstring and sync.py's startup guard.
MARKER_FIELD = "custom_lvi_managed"


class PhpIpamApiError(Exception):
    """Raised for a genuine phpIPAM API error (not the empty-result 404 case)."""


class PhpIpamClient:
    """Thin REST client for phpIPAM's Sections/Subnets/Addresses API."""

    def __init__(
        self,
        host: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        app_id: Optional[str] = None,
        app_code: Optional[str] = None,
        verify_ssl: Optional[bool] = None,
        timeout: Optional[int] = None,
        ignore_env_vars: bool = False,
    ) -> None:
        """Resolve connection settings and build the underlying HTTP session.

        Args:
            host: phpIPAM host (no scheme), or None to use PHPIPAM_HOST.
            username: phpIPAM username, or None to use PHPIPAM_USERNAME.
            password: phpIPAM password, or None to use PHPIPAM_PASSWORD.
            app_id: The API app's app_id URL segment, or None to use
                PHPIPAM_APP_ID.
            app_code: Optional static app code (only meaningful in
                static-token app-security mode; unused in the User-token
                mode this client targets).
            verify_ssl: Whether to verify the phpIPAM TLS certificate.
            timeout: Request timeout in seconds.
            ignore_env_vars: If True, use only the supplied values - no env
                or stored-settings fallback at all.
        """
        if ignore_env_vars:
            self.host = host or ""
            self.username = username or ""
            self.password = password or ""
            self.app_id = app_id or ""
            self.app_code = app_code or ""
            self.verify_ssl = bool(verify_ssl) if verify_ssl is not None else False
            self.timeout = timeout if timeout is not None else 120
        else:
            self.host = host or os.getenv("PHPIPAM_HOST") or ""
            self.username = username or os.getenv("PHPIPAM_USERNAME") or ""
            self.password = password or os.getenv("PHPIPAM_PASSWORD") or ""
            self.app_id = app_id or os.getenv("PHPIPAM_APP_ID") or ""
            self.app_code = app_code or os.getenv("PHPIPAM_APP_CODE") or ""
            if verify_ssl is not None and timeout is not None:
                self.verify_ssl = bool(verify_ssl)
                self.timeout = timeout
            else:
                from .settings import get_phpipam_settings

                settings = get_phpipam_settings().get("phpipam", {})
                self.verify_ssl = (
                    bool(verify_ssl) if verify_ssl is not None else bool(settings.get("verify_ssl", False))
                )
                self.timeout = timeout if timeout is not None else int(settings.get("timeout", 120))

        self.host = self.host.replace("https://", "").replace("http://", "").rstrip("/")
        scheme = "https" if self.verify_ssl else "http"
        self.base_url = f"{scheme}://{self.host}/api/{self.app_id}"

        self.session = requests.Session()
        self.session.verify = self.verify_ssl
        if not self.verify_ssl:
            import urllib3

            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        adapter = build_retry_adapter()
        self.session.mount("https://", adapter)
        self.session.mount("http://", adapter)

        self._token: Optional[str] = None

        # Per-run caches, populated lazily. Address "tag" (state) ids are
        # per-instance configurable - confirmed live - so they are resolved
        # by name at runtime and cached here, never hardcoded.
        self._tag_ids_by_name: Optional[Dict[str, int]] = None

    # ------------------------------------------------------------------ #
    # Auth / low-level request plumbing                                    #
    # ------------------------------------------------------------------ #

    def _authenticate(self) -> None:
        """Acquire a fresh session token via HTTP Basic auth.

        Raises:
            PhpIpamApiError: If authentication fails.
        """
        # HTTP Basic auth is per-request via `auth=`, not a stored session
        # header, since it's only needed for this one call - every other
        # request authenticates via the phpipam-token header instead.
        url = f"{self.base_url}/user/"
        resp = self.session.post(url, auth=(self.username, self.password), timeout=self.timeout, verify=self.verify_ssl)
        body = self._parse_json(resp)
        if resp.status_code != 200 or not body.get("success"):
            message = body.get("message", f"HTTP {resp.status_code}")
            raise PhpIpamApiError(f"phpIPAM authentication failed: {message}")
        self._token = body["data"]["token"]

    @staticmethod
    def _parse_json(resp: requests.Response) -> Dict[str, Any]:
        try:
            return resp.json()
        except ValueError:
            return {}

    def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        _retried: bool = False,
    ) -> Optional[Any]:
        """Issue one authenticated request, returning the ``data`` payload.

        Args:
            method: HTTP method.
            endpoint: Path under the app_id base, e.g. "sections/" or
                "addresses/42/".
            params: Optional query string parameters.
            data: Optional form-encoded body.
            _retried: Internal - set on the single 401 re-auth retry so a
                second failure doesn't loop forever.

        Returns:
            The response's "data" value, True for a bodyless success, or
            None when phpIPAM reports an empty result (see _EMPTY_RESULT_RE).

        Raises:
            PhpIpamApiError: On a genuine API error.
        """
        if self._token is None:
            self._authenticate()

        url = f"{self.base_url}/{endpoint}"
        resp = make_json_request(
            self.session,
            method,
            url,
            logger=logger,
            params=params,
            data=data,
            headers={"phpipam-token": self._token or ""},
            timeout=self.timeout,
            suppress_errors=True,
            error_body_chars=_ERROR_BODY_CHARS,
        )

        if resp.status_code == 401 and not _retried:
            logger.debug("phpIPAM token expired/invalid, re-authenticating once")
            self._token = None
            return self._request(method, endpoint, params=params, data=data, _retried=True)

        body = self._parse_json(resp)
        message = str(body.get("message", ""))

        if resp.status_code == 404 and _EMPTY_RESULT_RE.match(message):
            return None

        if not body.get("success", False):
            raise PhpIpamApiError(f"phpIPAM API error ({resp.status_code}) on {method} {endpoint}: {message}")

        return body.get("data", True)

    # ------------------------------------------------------------------ #
    # Connection test                                                      #
    # ------------------------------------------------------------------ #

    def test_connection(self) -> bool:
        """Return True if authentication succeeds against this instance.

        Returns:
            True if a session token was obtained.
        """
        try:
            self._authenticate()
            return True
        except Exception as exc:
            logger.error("phpIPAM connection test failed: %s", exc)
            return False

    # ------------------------------------------------------------------ #
    # Sections                                                             #
    # ------------------------------------------------------------------ #

    def get_sections(self) -> List[Dict[str, Any]]:
        """List every Section.

        Returns:
            The sections, or an empty list if none exist.
        """
        return self._request("GET", "sections/") or []

    def get_section_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        """Find a Section by exact (case-sensitive) name.

        Args:
            name: The Section name to look up.

        Returns:
            The section dict, or None if no section has that name.
        """
        for section in self.get_sections():
            if section.get("name") == name:
                return section
        return None

    # ------------------------------------------------------------------ #
    # Subnets                                                              #
    # ------------------------------------------------------------------ #

    def get_subnets_in_section(self, section_id: str) -> List[Dict[str, Any]]:
        """List every Subnet under a Section.

        Args:
            section_id: The Section's id.

        Returns:
            The subnets, or an empty list if none exist.
        """
        return self._request("GET", f"sections/{section_id}/subnets/") or []

    def create_subnet(self, subnet: str, mask: str, section_id: str, description: str = "") -> str:
        """Create a Subnet under a Section.

        Args:
            subnet: The network address, e.g. "10.10.5.0".
            mask: The prefix length, e.g. "24".
            section_id: The Section this subnet belongs to.
            description: Optional description.

        Returns:
            The new subnet's id.

        Raises:
            PhpIpamApiError: On failure.
        """
        result = self._request(
            "POST",
            "subnets/",
            data={"subnet": subnet, "mask": mask, "sectionId": section_id, "description": description},
        )
        return str(result)

    # ------------------------------------------------------------------ #
    # Addresses                                                            #
    # ------------------------------------------------------------------ #

    def get_addresses_in_subnet(self, subnet_id: str) -> List[Dict[str, Any]]:
        """List every Address in a Subnet.

        Args:
            subnet_id: The Subnet's id.

        Returns:
            The addresses, or an empty list if none exist.
        """
        return self._request("GET", f"subnets/{subnet_id}/addresses/") or []

    def search_address_by_ip(self, ip_address: str) -> Optional[Dict[str, Any]]:
        """Find an existing Address by IP, anywhere in the instance.

        Args:
            ip_address: The IP address to look up.

        Returns:
            The first matching address dict, or None if not found.
        """
        results = self._request("GET", f"addresses/search/{ip_address}/")
        if not results:
            return None
        return results[0]

    def create_address(
        self,
        ip_address: str,
        subnet_id: str,
        hostname: str = "",
        description: str = "",
        mac: str = "",
        tag_id: Optional[int] = None,
        custom_fields: Optional[Dict[str, str]] = None,
    ) -> str:
        """Create an Address.

        Args:
            ip_address: The IP address.
            subnet_id: The containing Subnet's id.
            hostname: Hostname to set.
            description: Description to set.
            mac: MAC address to set, or "" to omit.
            tag_id: The address state's id (see get_address_tags), or None
                to leave at phpIPAM's default.
            custom_fields: Extra ``custom_<name>: value`` fields to set.

        Returns:
            The new address's id.

        Raises:
            PhpIpamApiError: On failure.
        """
        data: Dict[str, Any] = {
            "ip": ip_address,
            "subnetId": subnet_id,
            "hostname": hostname,
            "description": description,
        }
        if mac:
            data["mac"] = mac
        if tag_id is not None:
            data["tag"] = tag_id
        if custom_fields:
            data.update(custom_fields)
        result = self._request("POST", "addresses/", data=data)
        return str(result)

    def update_address(self, address_id: str, **fields: Any) -> None:
        """Update an existing Address's fields.

        Args:
            address_id: The address's id.
            **fields: Fields to set (e.g. hostname=, description=, mac=,
                custom_lvi_managed=).

        Raises:
            PhpIpamApiError: On failure.
        """
        self._request("PATCH", f"addresses/{address_id}/", data=fields)

    def delete_address(self, address_id: str) -> None:
        """Delete an Address.

        Args:
            address_id: The address's id.

        Raises:
            PhpIpamApiError: On failure.
        """
        self._request("DELETE", f"addresses/{address_id}/")

    def search_address_by_mac(self, mac_address: str) -> List[Dict[str, Any]]:
        """Find every Address carrying the given MAC.

        Args:
            mac_address: The MAC address to look up.

        Returns:
            Matching addresses, or an empty list if none/if the endpoint
            doesn't behave as documented (logged, not raised - see the
            design doc's "docs only, unverified" note for this endpoint).
        """
        try:
            return self._request("GET", f"addresses/search_mac/{mac_address}/") or []
        except PhpIpamApiError as exc:
            logger.warning("phpIPAM MAC search unavailable (%s) - MAC-duplicate detection degraded this run", exc)
            return []

    # ------------------------------------------------------------------ #
    # Address states ("tags")                                             #
    # ------------------------------------------------------------------ #

    def get_address_tags(self) -> Dict[str, int]:
        """Resolve address state names to ids, cached for this client's lifetime.

        State ids are per-instance configurable (confirmed live) - never
        hardcode one.

        Returns:
            A dict of state name -> id, e.g. {"Used": 2, "Offline": 1, ...}.
        """
        if self._tag_ids_by_name is None:
            tags = self._request("GET", "addresses/tags/") or []
            self._tag_ids_by_name = {t["type"]: int(t["id"]) for t in tags}
        return self._tag_ids_by_name

    # ------------------------------------------------------------------ #
    # Custom fields                                                        #
    # ------------------------------------------------------------------ #

    def get_custom_fields(self) -> Dict[str, Any]:
        """List custom fields defined on the Address object.

        Field *definitions* are UI-only in phpIPAM - there is no API to
        create one. See sync.py's startup guard, which uses this to confirm
        the marker field exists before any run.

        Returns:
            A dict keyed by field name (e.g. "custom_lvi_managed"), or an
            empty dict if none are defined.
        """
        return self._request("GET", "addresses/custom_fields/") or {}
