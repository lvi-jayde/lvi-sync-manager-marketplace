"""The CVE report store: the last successful sync's results, as files on disk.

Layout, under the plugin's data directory:

    report/current/          the report the tabs show
    report/previous/         the one before it, for "new since last sync"
    report/.building-<ts>/   a sync in progress

Each report directory holds one JSON Lines file per future SQLite table, each
line one row with the column names that table will use, so moving to SQLite
changes only this module:

    run.json            the run (single object)
    devices.jsonl       device
    matches.jsonl       device x role (hardware / software)
    candidates.jsonl    match candidate
    cves.jsonl          distinct CVE: its cvefeed.io record, CISA KEV status
                        and links, once
    device_cves.jsonl   device x CVE that applies: only what is particular to
                        the device (role, version status, vendor verdict)
    excluded.jsonl      device x CVE excluded by platform or vendor data: only
                        what is particular to the device (reason, and for a
                        vendor exclusion its advisories and release)
    cve_platforms.jsonl distinct platform-limited CVE: the NVD hardware it is
                        limited to, once
    coverage.jsonl      device with no applied match, and why (its gap group)
    cve_summary.jsonl   distinct CVE: severity, CVSS, KEV, title, published and
                        how many devices it applies to (for the CVE list)
    new_cves.jsonl      device x CVE that applies now but did not in the
                        previous report (devices in both, not failed in it)
    index.json          byte ranges: each device's block of device_cves rows
                        and of excluded rows, each CVE's row in cves.jsonl,
                        and each CVE's row in cve_platforms.jsonl

Each devices.jsonl row also carries the device's summary (CVE counts by
severity, KEV count, highest CVSS, matched products), so the device list
reads one small table rather than every device x CVE row.

Rows are written per device as it finishes, so a run never holds the whole
report in memory, and each device's device_cves rows form one contiguous
block - which is what lets index.json point straight at them, so reading one
device's CVEs is a seek rather than a scan (the role a SQL index would play).
A report replaces `current` only when the run succeeds; a failed or cancelled
run leaves `current` untouched.
"""

import csv
import dataclasses
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, BinaryIO, Dict, Iterator, List, Optional, Set, Tuple, cast

from .engine.device_inventory import Device
from .engine.report import DeviceFailure, DeviceReport, coverage_gaps, to_json

TABLES = ("devices", "matches", "candidates", "cves", "device_cves", "excluded", "cve_platforms", "coverage")
ROLES = ("hardware", "software")
# Per-CVE fields of a vulnerability entry: the same for every device the CVE
# applies to, so they live in cves.jsonl rather than on every device_cves row.
_CVE_LEVEL_FIELDS = ("cisa_kev", "links")


def device_key(device: Dict[str, Any]) -> str:
    """Return the store's key for a device: its network and management IP.

    Args:
        device: The device, as `asdict(Device)`.

    Returns:
        "<network>|<ip_address>".
    """
    return f"{device.get('network', '')}|{device.get('ip_address', '')}"


_SEVERITIES = ("critical", "high", "medium", "low")
# lvi_cve_feed's CSV report columns (engine/report.py to_csv()), in its order.
_CSV_COLUMNS = (
    "device_ip",
    "device_hostname",
    "match_kind",
    "matched_vendor",
    "matched_product",
    "match_score",
    "matched_cpe",
    "cve_id",
    "severity",
    "cvss_score",
    "published",
    "version_status",
    "in_cisa_kev",
    "known_ransomware_campaign_use",
    "url",
    "nvd_url",
    "vendor_advisory_url",
    "device_end_of_life",
    "software_end_of_life",
)


def _new_device_summary() -> Dict[str, Any]:
    """The summary fields every devices.jsonl row carries, zeroed."""
    return {
        "cve_count": 0,
        **{severity: 0 for severity in _SEVERITIES},
        "na": 0,
        "kev_count": 0,
        "max_cvss": None,
        "hardware_product": None,
        "hardware_vendor": None,
        "hardware_cpe": None,
        "software_product": None,
        "software_vendor": None,
        "software_cpe": None,
        "unverified": False,
        "coverage": None,
        "end_of_support": None,
    }


def _severity(cve: Dict[str, Any]) -> str:
    """A CVE's severity as a summary column: critical/high/medium/low, or "na"
    (cvefeed.io reports unscored CVEs as severity "NA")."""
    severity = str(cve.get("severity") or "").lower()
    return severity if severity in _SEVERITIES else "na"


def _cvss(cve: Dict[str, Any]) -> Optional[float]:
    """A CVE's CVSS score as a number, or None when unscored (cvefeed.io sends
    it as a string, and an unscored CVE as 0.0 with severity "NA")."""
    value = cve.get("cvss_score")
    if _severity(cve) == "na" or value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _line(row: Dict[str, Any]) -> bytes:
    """Serialise one row as a JSON line (dates and other non-JSON values become strings)."""
    return (json.dumps(row, default=str, separators=(",", ":")) + "\n").encode("utf-8")


class ReportWriter:
    """Writes one run's report into a building directory, then swaps it in."""

    def __init__(self, root: Path, started_at: datetime) -> None:
        """Open a building directory for a new run.

        Args:
            root: The store's `report/` directory.
            started_at: When the run started (names the building directory).
        """
        self._root = root
        self._started_at = started_at
        self._dir = root / f".building-{started_at.strftime('%Y%m%dT%H%M%S%fZ')}"
        self._dir.mkdir(parents=True)
        # Binary, so tell() gives the exact byte offsets index.json records.
        self._files: Dict[str, BinaryIO] = {name: (self._dir / f"{name}.jsonl").open("wb") for name in TABLES}
        self._device_index: Dict[str, Tuple[int, int]] = {}
        self._excluded_index: Dict[str, Tuple[int, int]] = {}
        self._cve_index: Dict[str, Tuple[int, int]] = {}
        self._platform_index: Dict[str, Tuple[int, int]] = {}
        self._cve_summary: Dict[str, Dict[str, Any]] = {}
        self.device_count = 0
        self.failed_count = 0

    def _write(self, table: str, row: Dict[str, Any]) -> Tuple[int, int]:
        """Append a row; return its (offset, length) in bytes."""
        handle = self._files[table]
        data = _line(row)
        offset = handle.tell()
        handle.write(data)
        return offset, len(data)

    def add_device(self, report: DeviceReport) -> None:
        """Write one device's rows.

        Args:
            report: The device's report from the engine.
        """
        data = to_json([report])[0]
        key = device_key(data["device"])
        summary = _new_device_summary()
        seen: Set[str] = set()
        block_start = self._files["device_cves"].tell()
        excluded_start = self._files["excluded"].tell()
        for role in ROLES:
            match = data[role]
            candidates = match["result"].pop("candidates", [])
            vulnerabilities = match.pop("vulnerabilities", [])
            platform_excluded = match.pop("platform_excluded", [])
            vendor_excluded = match.pop("vendor_excluded", [])
            best = candidates[0] if candidates else None
            if match.get("auto_applied") and best:
                summary[f"{role}_product"] = best.get("name")
                summary[f"{role}_vendor"] = best.get("vendor_name")
                summary[f"{role}_cpe"] = best.get("cpe")
                summary["unverified"] = summary["unverified"] or bool(match.get("unverified"))
            self._write(
                "matches",
                {
                    "device_key": key,
                    "role": role,
                    **match,
                    "best": best,
                    "cve_count": len(vulnerabilities),
                    "kev_count": sum(1 for v in vulnerabilities if (v.get("cisa_kev") or {}).get("in_kev")),
                },
            )
            for rank, candidate in enumerate(candidates):
                self._write("candidates", {"device_key": key, "role": role, "rank": rank, **candidate})
            for entry in vulnerabilities:
                cve = entry.get("cve") or {}
                cve_id = cve.get("id")
                if not cve_id:
                    continue
                if cve_id not in self._cve_index:
                    self._cve_index[cve_id] = self._write(
                        "cves",
                        {"cve_id": cve_id, **{f: entry.get(f) for f in _CVE_LEVEL_FIELDS}, "record": cve},
                    )
                rest = {k: v for k, v in entry.items() if k != "cve" and k not in _CVE_LEVEL_FIELDS}
                self._write("device_cves", {"device_key": key, "role": role, "cve_id": cve_id, **rest})
                if cve_id not in seen:  # a CVE can apply through both roles; count it once
                    seen.add(cve_id)
                    self._count(summary, cve_id, cve, entry)
            for reason, items in (("platform", platform_excluded), ("vendor", vendor_excluded)):
                for item in items:
                    cve_id = item.get("id")
                    if reason == "platform" and cve_id and cve_id not in self._platform_index:
                        self._platform_index[cve_id] = self._write(
                            "cve_platforms", {"cve_id": cve_id, "platforms": item.get("platforms") or []}
                        )
                    rest = {k: v for k, v in item.items() if k not in ("id", "platforms")}
                    self._write(
                        "excluded", {"device_key": key, "role": role, "cve_id": cve_id, "reason": reason, **rest}
                    )
        block_end = self._files["device_cves"].tell()
        if block_end > block_start:
            self._device_index[key] = (block_start, block_end - block_start)
        excluded_end = self._files["excluded"].tell()
        if excluded_end > excluded_start:
            self._excluded_index[key] = (excluded_start, excluded_end - excluded_start)
        for group, labels in coverage_gaps([report]).items():
            summary["coverage"] = summary["coverage"] or group
            for label in labels:
                self._write("coverage", {"device_key": key, "group": group, "detail": label})
        summary["end_of_support"] = report.device.end_of_support()
        self._write("devices", {"device_key": key, **data["device"], **summary, "error": None})
        self.device_count += 1

    def _count(self, summary: Dict[str, Any], cve_id: str, cve: Dict[str, Any], entry: Dict[str, Any]) -> None:
        """Add one applicable CVE to a device's summary and to the CVE summary."""
        severity = _severity(cve)
        cvss = _cvss(cve)
        kev = bool((entry.get("cisa_kev") or {}).get("in_kev"))
        summary["cve_count"] += 1
        summary[severity] += 1
        summary["kev_count"] += kev
        if cvss is not None and (summary["max_cvss"] is None or cvss > summary["max_cvss"]):
            summary["max_cvss"] = cvss
        item = self._cve_summary.get(cve_id)
        if item is None:
            item = self._cve_summary[cve_id] = {
                "cve_id": cve_id,
                "severity": severity,
                "cvss": cvss,
                "kev": kev,
                "title": cve.get("title"),
                "published": cve.get("published"),
                "device_count": 0,
            }
        item["device_count"] += 1

    def add_failure(self, failure: DeviceFailure) -> None:
        """Write a device whose report could not be built.

        Args:
            failure: The device and its error.
        """
        data = to_json([], [failure])[0]
        self._write(
            "devices",
            {
                "device_key": device_key(data["device"]),
                **data["device"],
                **_new_device_summary(),
                "error": data["error"],
            },
        )
        self.failed_count += 1

    def _close(self) -> None:
        for handle in self._files.values():
            handle.close()

    def commit(self, run: Dict[str, Any]) -> None:
        """Finish the run and make it the current report.

        `current` becomes `previous` (the old `previous` is deleted) and the
        building directory becomes `current`.

        Args:
            run: Run-level facts for run.json (counts, settings, errors).
        """
        self._close()
        with (self._dir / "cve_summary.jsonl").open("wb") as handle:
            for item in self._cve_summary.values():
                handle.write(_line(item))
        new_count, baseline = self._write_new_cves()
        index = {
            "device_cves": self._device_index,
            "excluded": self._excluded_index,
            "cves": self._cve_index,
            "cve_platforms": self._platform_index,
        }
        (self._dir / "index.json").write_text(json.dumps(index, separators=(",", ":")), encoding="utf-8")
        run = {
            **run,
            "started_at": self._started_at.isoformat(),
            "finished_at": datetime.now(timezone.utc).isoformat(),
            "device_count": self.device_count,
            "failed_count": self.failed_count,
            "cve_count": len(self._cve_index),
            "kev_cve_count": sum(1 for item in self._cve_summary.values() if item["kev"]),
            "new_cve_count": new_count,
            "baseline_finished_at": baseline,
        }
        (self._dir / "run.json").write_text(json.dumps(run, default=str, indent=2), encoding="utf-8")
        current, previous = self._root / "current", self._root / "previous"
        if previous.exists():
            shutil.rmtree(previous)
        if current.exists():
            current.rename(previous)
        self._dir.rename(current)

    def _write_new_cves(self) -> Tuple[int, Optional[str]]:
        """Write new_cves.jsonl: CVEs that apply now but did not in the current
        (soon previous) report, for devices in both and not failed in it.

        Compares one device's block at a time through both indexes, so it never
        holds either report's device x CVE rows in memory.

        Returns:
            (rows written, the baseline report's finished_at - None when there
            is no baseline).
        """
        baseline_dir = self._root / "current"
        written = 0
        with (self._dir / "new_cves.jsonl").open("wb") as out:
            if not (baseline_dir / "index.json").exists():
                return 0, None
            baseline = ReportReader(baseline_dir)
            usable = {row["device_key"] for row in baseline._rows("devices") if not row.get("error")}
            baseline_spans = baseline._load_index()["device_cves"]
            current = ReportReader(self._dir)
            for key, span in self._device_index.items():
                if key not in usable:
                    continue  # new to this run (or failed last time): nothing to diff against
                before = {row["cve_id"] for row in baseline._block("device_cves", baseline_spans.get(key))}
                for cve_id in dict.fromkeys(row["cve_id"] for row in current._block("device_cves", list(span))):
                    if cve_id not in before:
                        out.write(_line({"device_key": key, "cve_id": cve_id}))
                        written += 1
            return written, baseline.run().get("finished_at")

    def abort(self) -> None:
        """Discard the run: `current` is left as it was."""
        self._close()
        shutil.rmtree(self._dir, ignore_errors=True)


class ReportStore:
    """The report directory: start runs, and read the current report."""

    def __init__(self, root: Path) -> None:
        """Use *root* (the store's `report/` directory), creating it if needed.

        Args:
            root: The store's `report/` directory.
        """
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)

    def recover(self) -> None:
        """Tidy up after a crash: drop leftover building directories, and
        restore `current` from `previous` if a crash fell between the two
        renames in ReportWriter.commit()."""
        for leftover in self.root.glob(".building-*"):
            shutil.rmtree(leftover, ignore_errors=True)
        current, previous = self.root / "current", self.root / "previous"
        if not current.exists() and previous.exists():
            previous.rename(current)

    def start_run(self, started_at: Optional[datetime] = None) -> ReportWriter:
        """Begin writing a new report.

        Args:
            started_at: When the run started; now if omitted.

        Returns:
            The writer for this run.
        """
        self.recover()
        return ReportWriter(self.root, started_at or datetime.now(timezone.utc))

    def reader(self, which: str = "current") -> Optional["ReportReader"]:
        """Return a reader for the current (or previous) report, if there is one.

        Args:
            which: "current" or "previous".

        Returns:
            The reader, or None when that report doesn't exist.
        """
        path = self.root / which
        return ReportReader(path) if (path / "run.json").exists() else None


class ReportReader:
    """Read-only, query-shaped access to one report directory.

    The methods are the queries the tabs need; they are what a SQLite store
    would implement with SQL.
    """

    def __init__(self, path: Path) -> None:
        """Read the report at *path*.

        Args:
            path: A report directory (current or previous).
        """
        self.path = path
        self._index: Optional[Dict[str, Dict[str, List[int]]]] = None

    def _rows(self, table: str) -> Iterator[Dict[str, Any]]:
        with (self.path / f"{table}.jsonl").open(encoding="utf-8") as handle:
            for line in handle:
                if line.strip():
                    yield json.loads(line)

    def _load_index(self) -> Dict[str, Dict[str, List[int]]]:
        if self._index is None:
            self._index = json.loads((self.path / "index.json").read_text(encoding="utf-8"))
        return self._index

    def run(self) -> Dict[str, Any]:
        """Return the run's facts (run.json)."""
        return json.loads((self.path / "run.json").read_text(encoding="utf-8"))

    def _optional_rows(self, table: str) -> Iterator[Dict[str, Any]]:
        """Rows of a table that older reports may not have; none if absent."""
        if (self.path / f"{table}.jsonl").exists():
            yield from self._rows(table)

    def new_cves(self) -> List[Dict[str, Any]]:
        """CVEs that apply now but did not in the previous report.

        Returns:
            Rows with device_key and cve_id.
        """
        return list(self._optional_rows("new_cves"))

    def device_rows(self) -> List[Dict[str, Any]]:
        """One row per device: identity, matched products, CVE counts by
        severity, KEV count, highest CVSS, new-since-last-sync count, coverage
        gap, end of support, error.

        Returns:
            The devices.jsonl rows, each with `new_count` added.
        """
        new_counts: Dict[str, int] = {}
        for row in self.new_cves():
            new_counts[row["device_key"]] = new_counts.get(row["device_key"], 0) + 1
        rows = list(self._rows("devices"))
        for row in rows:
            row["new_count"] = new_counts.get(row["device_key"], 0)
        return rows

    def cve_rows(self) -> List[Dict[str, Any]]:
        """One row per CVE that applies to any device: severity, CVSS, KEV,
        title, published, and how many devices it applies to.

        Returns:
            The cve_summary.jsonl rows.
        """
        return list(self._optional_rows("cve_summary"))

    def cve_devices(self, cve_id: str) -> List[Dict[str, Any]]:
        """The devices one CVE applies to, with how (role, version status).

        Scans device_cves.jsonl once - about a second at 10,000 devices - so it
        is for opening one CVE, not for building a list.

        Args:
            cve_id: The CVE id.

        Returns:
            Rows with the device's key, hostname, IP and network, and the
            device_cves fields.
        """
        hits = [row for row in self._rows("device_cves") if row["cve_id"] == cve_id]
        devices = {row["device_key"]: row for row in self._rows("devices")} if hits else {}
        result = []
        for row in hits:
            device = devices.get(row["device_key"], {})
            result.append(
                {
                    **row,
                    "hostname": device.get("hostname"),
                    "ip_address": device.get("ip_address"),
                    "network": device.get("network"),
                }
            )
        return result

    def device_cves(self, key: str) -> List[Dict[str, Any]]:
        """The CVEs that apply to one device, each with its per-CVE fields.

        Reads only the device's own block of device_cves rows, and each of
        its CVEs' rows, through index.json.

        Args:
            key: The device's store key.

        Returns:
            The device's CVE rows, each with `record`, `cisa_kev` and `links`
            added from cves.jsonl.
        """
        index = self._load_index()
        rows = self._block("device_cves", index["device_cves"].get(key))
        cve_spans = index["cves"]
        result = []
        with (self.path / "cves.jsonl").open("rb") as handle:
            for row in rows:
                cve_span = cve_spans.get(row["cve_id"])
                cve: Dict[str, Any] = {}
                if cve_span is not None:
                    handle.seek(cve_span[0])
                    cve = json.loads(handle.read(cve_span[1]))
                result.append({**row, "record": cve.get("record"), **{f: cve.get(f) for f in _CVE_LEVEL_FIELDS}})
        return result

    def _block(self, table: str, span: Optional[List[int]]) -> List[Dict[str, Any]]:
        """Read the rows in one byte range of a table (an index.json entry)."""
        if span is None:
            return []
        with (self.path / f"{table}.jsonl").open("rb") as handle:
            handle.seek(span[0])
            return [json.loads(line) for line in handle.read(span[1]).splitlines() if line.strip()]

    def device_exclusions(self, key: str) -> List[Dict[str, Any]]:
        """The CVEs excluded for one device, platform exclusions with their NVD platforms.

        Args:
            key: The device's store key.

        Returns:
            The device's excluded rows; a platform exclusion has `platforms` added.
        """
        index = self._load_index()
        rows = self._block("excluded", index.get("excluded", {}).get(key))
        spans = index.get("cve_platforms", {})
        for row in rows:
            if row.get("reason") == "platform":
                found = self._block("cve_platforms", spans.get(row["cve_id"]))
                row["platforms"] = found[0]["platforms"] if found else []
        return rows

    def export_csv(self, path: Path, new_only: bool = False) -> int:
        """Write the report as CSV: one row per device x applicable CVE.

        The first 19 columns are lvi_cve_feed's CSV report's, in its order, so
        a spreadsheet built on that file keeps working; device_network and
        new_since_last_sync follow. Streams device_cves.jsonl, holding only the
        devices, their best matches and the CVE records in memory.

        Args:
            path: Where to write the CSV.
            new_only: Only the CVEs new since the previous report.

        Returns:
            The number of CVE rows written.
        """
        devices = {row["device_key"]: row for row in self._rows("devices")}
        best = {(row["device_key"], row["role"]): row.get("best") for row in self._rows("matches")}
        cves = {row["cve_id"]: row for row in self._rows("cves")}
        new = {(row["device_key"], row["cve_id"]) for row in self.new_cves()}
        device_fields = [f.name for f in dataclasses.fields(Device)]
        eox: Dict[str, Dict[str, str]] = {}
        written = 0
        with path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.writer(handle, lineterminator="\n")
            writer.writerow([*_CSV_COLUMNS, "device_network", "new_since_last_sync"])
            for row in self._rows("device_cves"):
                key, cve_id = row["device_key"], row["cve_id"]
                is_new = (key, cve_id) in new
                if new_only and not is_new:
                    continue
                device = devices.get(key, {})
                if key not in eox:
                    eox[key] = (
                        Device(**cast(Dict[str, Any], {f: device.get(f) for f in device_fields})).eox_dates()
                        if device
                        else {}
                    )
                match = best.get((key, row["role"])) or {}
                cve_row = cves.get(cve_id, {})
                record = cve_row.get("record") or {}
                kev = cve_row.get("cisa_kev") or {}
                links = cve_row.get("links") or {}
                writer.writerow(
                    [
                        device.get("ip_address", ""),
                        device.get("hostname") or "",
                        row["role"],
                        match.get("vendor_name", ""),
                        match.get("name", ""),
                        f"{match['score']:.2f}" if isinstance(match.get("score"), (int, float)) else "",
                        match.get("cpe") or "",
                        cve_id,
                        record.get("severity", ""),
                        record.get("cvss_score", ""),
                        record.get("published", ""),
                        row.get("version_status", ""),
                        kev.get("in_kev", ""),
                        kev.get("known_ransomware_campaign_use", ""),
                        links.get("cvefeed", ""),
                        links.get("nvd", ""),
                        " ".join(links.get("vendor") or []),
                        eox[key].get("end_of_life", ""),
                        eox[key].get("software_end_of_life", ""),
                        device.get("network", ""),
                        is_new,
                    ]
                )
                written += 1
        return written

    def review_items(self, decisions: Dict[str, Dict[str, Dict[str, Any]]]) -> List[Dict[str, Any]]:
        """The matches a reviewer should look at, with their candidates.

        A match needs review when it has a best candidate but was not applied
        (score below the threshold, a tie, a held release), or was applied on
        a name search alone with no verified catalog entry behind it
        (unverified). A match that already has a decision is listed too, so
        the decision can be seen and undone.

        Args:
            decisions: reviews.json's decisions (device_key -> role -> decision).

        Returns:
            One row per device x role: device identity, role, why it is listed,
            whether it was applied, the candidates (best first) and the
            decision, if any.
        """
        wanted: Dict[Tuple[str, str], Dict[str, Any]] = {}
        for row in self._rows("matches"):
            key, role = row["device_key"], row["role"]
            decision = decisions.get(key, {}).get(role)
            best = row.get("best")
            held = best is not None and not row.get("auto_applied")
            unverified = bool(row.get("auto_applied") and row.get("unverified"))
            if not (held or unverified or decision):
                continue
            if row.get("hold_reason"):
                reason = row["hold_reason"]
            elif held:
                reason = "below_threshold"
            elif unverified:
                reason = "unverified"
            else:
                reason = "decided"
            wanted[(key, role)] = {
                "device_key": key,
                "role": role,
                "reason": reason,
                "applied": bool(row.get("auto_applied")),
                "source": row.get("source"),
                "best": best,
                "candidates": [],
                "decision": decision,
            }
        if not wanted:
            return []
        for row in self._rows("candidates"):
            item = wanted.get((row["device_key"], row["role"]))
            if item is not None:
                item["candidates"].append({k: v for k, v in row.items() if k not in ("device_key", "role")})
        devices = {row["device_key"]: row for row in self._rows("devices")}
        for item in wanted.values():
            device = devices.get(item["device_key"], {})
            item.update(
                hostname=device.get("hostname"), ip_address=device.get("ip_address"), network=device.get("network")
            )
            item["candidates"].sort(key=lambda c: c.get("rank", 0))
        return list(wanted.values())

    def cve_ids_by_device(self) -> Dict[str, Set[str]]:
        """Every device's applicable CVE ids, for "new since last sync".

        Returns:
            device_key -> set of CVE ids.
        """
        result: Dict[str, Set[str]] = {}
        for row in self._rows("device_cves"):
            result.setdefault(row["device_key"], set()).add(row["cve_id"])
        return result
