"""The CVE Feed plugin's own tabs: CVE Report and Match Review.

The CVE Report tab shows the report from the last successful sync (see
store.py): a header with the run's facts and downloads, then three views -
devices, CVEs, and CVEs new since the previous sync. Every list comes from a
precomputed table, so the tab never scans the device x CVE rows to draw a
list; opening one CVE's devices does (about a second at 10,000 devices).
"""

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from nicegui import ui

# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import (  # pyright: ignore[reportMissingImports]
    current_username,
    get_plugin_data_dir,
    has_role,
    require_role,
    t,
)

from .reviews import ACCEPTED, ReviewStore
from .store import ReportReader, ReportStore

PLUGIN_ID = "cve_feed"
_SEVERITY_ORDER = ("critical", "high", "medium", "low", "na")
_LINK_SLOT = (
    '<q-td :props="props"><a v-if="props.row.url" :href="props.row.url" target="_blank" '
    'rel="noopener" class="text-primary">{{ props.value }}</a><span v-else>{{ props.value }}</span></q-td>'
)


def _t(key: str, **kwargs: Any) -> str:
    """Translate one of this plugin's strings."""
    return t(f"cve_feed.report.{key}", plugin=PLUGIN_ID, **kwargs)


def _store() -> ReportStore:
    return ReportStore(get_plugin_data_dir(PLUGIN_ID) / "report")


def _age(finished_at: str) -> str:
    """Describe how long ago a run finished, e.g. "3 h ago"."""
    try:
        finished = datetime.fromisoformat(finished_at)
    except (TypeError, ValueError):
        return "?"
    minutes = int((datetime.now(timezone.utc) - finished).total_seconds() // 60)
    if minutes < 60:
        return _t("age_minutes", n=minutes)
    if minutes < 48 * 60:
        return _t("age_hours", n=minutes // 60)
    return _t("age_days", n=minutes // (24 * 60))


def _when(iso: Optional[str]) -> str:
    """An ISO timestamp as "YYYY-MM-DD HH:MM UTC"."""
    try:
        return datetime.fromisoformat(str(iso)).astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    except (TypeError, ValueError):
        return "?"


def _cvss_text(value: Any) -> str:
    return f"{value:.1f}" if isinstance(value, (int, float)) else "-"


def _device_label(row: Dict[str, Any]) -> str:
    return row.get("hostname") or row.get("ip_address") or row.get("device_key", "")


def _device_notes(row: Dict[str, Any]) -> str:
    """The short status a device row carries: error, gap, unverified match, end of support."""
    notes = []
    if row.get("error"):
        notes.append(_t("note_failed", error=row["error"]))
    if row.get("coverage"):
        notes.append(_t("note_gap", group=row["coverage"]))
    if row.get("unverified"):
        notes.append(_t("note_unverified"))
    if row.get("end_of_support"):
        notes.append(_t("note_eos", dates=row["end_of_support"]))
    return "; ".join(notes)


def _device_table_rows(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return [
        {
            "device_key": row["device_key"],
            "device": _device_label(row),
            "ip_address": row.get("ip_address"),
            "network": row.get("network"),
            "vendor": row.get("software_vendor") or row.get("hardware_vendor") or "",
            "software": row.get("software_product") or "",
            "hardware": row.get("hardware_product") or "",
            "critical": row.get("critical", 0),
            "high": row.get("high", 0),
            "medium": row.get("medium", 0),
            "low": row.get("low", 0),
            "kev": row.get("kev_count", 0),
            "new": row.get("new_count", 0),
            "max_cvss": row.get("max_cvss"),
            "max_cvss_text": _cvss_text(row.get("max_cvss")),
            "notes": _device_notes(row),
        }
        for row in rows
    ]


def _cve_url(cve_id: str, links: Optional[Dict[str, Any]] = None) -> str:
    return (links or {}).get("cvefeed") or f"https://cvefeed.io/vuln/detail/{cve_id}"


def _export(reader: ReportReader, new_only: bool) -> None:
    """Write a CSV of the current report into the plugin's data directory and download it."""
    exports = get_plugin_data_dir(PLUGIN_ID) / "exports"
    exports.mkdir(parents=True, exist_ok=True)
    stamp = _when(reader.run().get("finished_at")).replace(" ", "_").replace(":", "")
    name = f"cve_feed_{'new_' if new_only else ''}{stamp}.csv"
    path = exports / name
    for old in exports.glob("cve_feed_*.csv"):  # one file per kind is enough
        if old.name != name and old.name.startswith("cve_feed_new_") == new_only:
            old.unlink(missing_ok=True)
    reader.export_csv(path, new_only=new_only)
    ui.download(Path(path), filename=name)


def _in(host: ui.element, build: Callable[[], None]) -> None:
    """Build UI (a dialog) inside *host*, the tab's own container - so it has
    a place in the page however the handler that calls this was invoked."""
    with host:
        build()


def _open_device(reader: ReportReader, key: str, row: Dict[str, Any]) -> None:
    """Show one device's matches, CVEs and exclusions in a dialog."""
    cves = reader.device_cves(key)
    exclusions = reader.device_exclusions(key)
    with ui.dialog() as dialog, ui.card().classes("w-full max-w-6xl"):
        with ui.row().classes("items-center w-full"):
            ui.label(f"{row['device']} ({row.get('ip_address')}, {row.get('network')})").classes("text-lg font-bold")
            ui.space()
            ui.button(icon="close", on_click=dialog.close).props("flat dense round size=sm")
        for role in ("software", "hardware"):
            if row.get(role):
                ui.label(f"{_t('role_' + role)}: {row[role]}").classes("text-sm")
        if row.get("notes"):
            ui.label(row["notes"]).classes("text-sm text-orange-700")
        columns: List[Dict[str, Any]] = [
            {"name": "cve", "label": "CVE", "field": "cve", "sortable": True, "align": "left"},
            {"name": "severity", "label": _t("col_severity"), "field": "severity", "sortable": True, "align": "left"},
            {"name": "cvss", "label": "CVSS", "field": "cvss", "sortable": True},
            {"name": "kev", "label": "KEV", "field": "kev", "sortable": True},
            {"name": "status", "label": _t("col_version_status"), "field": "status", "align": "left"},
            {"name": "vendor", "label": _t("col_vendor_verdict"), "field": "vendor", "align": "left"},
            {"name": "title", "label": _t("col_title"), "field": "title", "align": "left"},
        ]
        table_rows = []
        for item in cves:
            record = item.get("record") or {}
            vendor = item.get("vendor") or {}
            table_rows.append(
                {
                    "id": f"{item['role']}|{item['cve_id']}",
                    "cve": item["cve_id"],
                    "url": _cve_url(item["cve_id"], item.get("links")),
                    "severity": str(record.get("severity") or ""),
                    "cvss": record.get("cvss_score") or "",
                    "kev": _t("yes") if (item.get("cisa_kev") or {}).get("in_kev") else "",
                    "status": item.get("version_status") or "",
                    "vendor": " ".join(str(v) for v in (vendor.get("vendor"), vendor.get("release")) if v),
                    "title": record.get("title") or "",
                }
            )
        ui.label(_t("device_cves", n=len(table_rows))).classes("text-sm font-bold mt-2")
        table = ui.table(columns=columns, rows=table_rows, row_key="id", pagination=20).classes("w-full")
        table.props("dense flat bordered")
        table.add_slot("body-cell-cve", _LINK_SLOT)
        if exclusions:
            with ui.expansion(_t("exclusions", n=len(exclusions))).classes("w-full"):
                for item in exclusions:
                    detail = (
                        _t("excluded_platform", platforms=", ".join(item.get("platforms") or []))
                        if item.get("reason") == "platform"
                        else _t("excluded_vendor", release=item.get("release", ""), reason=item.get("reason", ""))
                    )
                    ui.label(f"{item['cve_id']}: {detail}").classes("text-xs")
    dialog.open()


def _open_cve(reader: ReportReader, row: Dict[str, Any]) -> None:
    """Show the devices one CVE applies to in a dialog."""
    hits = reader.cve_devices(row["cve"])
    with ui.dialog() as dialog, ui.card().classes("w-full max-w-4xl"):
        with ui.row().classes("items-center w-full"):
            ui.link(row["cve"], row["url"], new_tab=True).classes("text-lg font-bold")
            ui.space()
            ui.button(icon="close", on_click=dialog.close).props("flat dense round size=sm")
        if row.get("title"):
            ui.label(row["title"]).classes("text-sm")
        columns: List[Dict[str, Any]] = [
            {"name": "device", "label": _t("col_device"), "field": "device", "sortable": True, "align": "left"},
            {"name": "ip", "label": "IP", "field": "ip", "sortable": True, "align": "left"},
            {"name": "network", "label": _t("col_network"), "field": "network", "align": "left"},
            {"name": "role", "label": _t("col_match"), "field": "role", "align": "left"},
            {"name": "status", "label": _t("col_version_status"), "field": "status", "align": "left"},
        ]
        rows = [
            {
                "id": f"{hit['device_key']}|{hit['role']}",
                "device": hit.get("hostname") or hit.get("ip_address"),
                "ip": hit.get("ip_address"),
                "network": hit.get("network"),
                "role": _t("role_" + hit["role"]),
                "status": hit.get("version_status") or "",
            }
            for hit in hits
        ]
        ui.label(_t("cve_devices", n=len({h["device_key"] for h in hits}))).classes("text-sm font-bold mt-2")
        ui.table(columns=columns, rows=rows, row_key="id", pagination=20).classes("w-full").props("dense flat bordered")
    dialog.open()


def _devices_view(reader: ReportReader, host: ui.element) -> None:
    rows = _device_table_rows(reader.device_rows())
    vendors = sorted({r["vendor"] for r in rows if r["vendor"]})
    columns: List[Dict[str, Any]] = [
        {"name": "device", "label": _t("col_device"), "field": "device", "sortable": True, "align": "left"},
        {"name": "ip_address", "label": "IP", "field": "ip_address", "sortable": True, "align": "left"},
        {"name": "network", "label": _t("col_network"), "field": "network", "sortable": True, "align": "left"},
        {"name": "vendor", "label": _t("col_vendor"), "field": "vendor", "sortable": True, "align": "left"},
        {"name": "software", "label": _t("col_software"), "field": "software", "sortable": True, "align": "left"},
        {"name": "hardware", "label": _t("col_hardware"), "field": "hardware", "sortable": True, "align": "left"},
        {"name": "critical", "label": _t("sev_critical"), "field": "critical", "sortable": True},
        {"name": "high", "label": _t("sev_high"), "field": "high", "sortable": True},
        {"name": "medium", "label": _t("sev_medium"), "field": "medium", "sortable": True},
        {"name": "low", "label": _t("sev_low"), "field": "low", "sortable": True},
        {"name": "kev", "label": "KEV", "field": "kev", "sortable": True},
        {"name": "new", "label": _t("col_new"), "field": "new", "sortable": True},
        {"name": "max_cvss", "label": _t("col_max_cvss"), "field": "max_cvss_text", "sortable": True},
        {"name": "notes", "label": _t("col_notes"), "field": "notes", "align": "left"},
    ]
    state: Dict[str, Any] = {"vendor": None, "kev": False, "new": False}
    with ui.row().classes("items-center gap-4 w-full"):
        search = ui.input(placeholder=_t("search")).props("dense clearable").classes("w-64")
        vendor = ui.select([_t("all_vendors"), *vendors], value=_t("all_vendors"), label=_t("col_vendor")).props(
            "dense"
        )
        kev = ui.checkbox(_t("kev_only"))
        new = ui.checkbox(_t("new_only"))
    table = ui.table(columns=columns, rows=rows, row_key="device_key", pagination=25).classes("w-full")
    table.props("dense flat bordered")
    search.bind_value_to(table, "filter")

    def apply_filters() -> None:
        state.update(vendor=None if vendor.value == _t("all_vendors") else vendor.value, kev=kev.value, new=new.value)
        table.rows = [
            r
            for r in rows
            if (state["vendor"] is None or r["vendor"] == state["vendor"])
            and (not state["kev"] or r["kev"])
            and (not state["new"] or r["new"])
        ]
        table.update()

    for control in (vendor, kev, new):
        control.on_value_change(lambda _: apply_filters())
    table.on("rowClick", lambda e: _in(host, lambda: _open_device(reader, e.args[1]["device_key"], e.args[1])))


def _cves_view(reader: ReportReader, host: ui.element) -> None:
    rows = [
        {
            "cve": row["cve_id"],
            "url": _cve_url(row["cve_id"]),
            "severity": row.get("severity") or "na",
            "severity_text": _t("sev_" + (row.get("severity") or "na")),
            "severity_rank": _SEVERITY_ORDER.index(row.get("severity") or "na"),
            "cvss": row.get("cvss"),
            "cvss_text": _cvss_text(row.get("cvss")),
            "kev": _t("yes") if row.get("kev") else "",
            "devices": row.get("device_count", 0),
            "published": str(row.get("published") or "")[:10],
            "title": row.get("title") or "",
        }
        for row in reader.cve_rows()
    ]
    rows.sort(key=lambda r: (r["severity_rank"], -(r["cvss"] or 0), -r["devices"]))
    columns: List[Dict[str, Any]] = [
        {"name": "cve", "label": "CVE", "field": "cve", "sortable": True, "align": "left"},
        {"name": "severity", "label": _t("col_severity"), "field": "severity_text", "align": "left"},
        {"name": "cvss", "label": "CVSS", "field": "cvss_text", "sortable": True},
        {"name": "kev", "label": "KEV", "field": "kev", "sortable": True},
        {"name": "devices", "label": _t("col_devices"), "field": "devices", "sortable": True},
        {"name": "published", "label": _t("col_published"), "field": "published", "sortable": True},
        {"name": "title", "label": _t("col_title"), "field": "title", "align": "left"},
    ]
    severity_options = {s: _t("sev_" + s) for s in _SEVERITY_ORDER}
    with ui.row().classes("items-center gap-4 w-full"):
        search = ui.input(placeholder=_t("search")).props("dense clearable").classes("w-64")
        severities = (
            ui.select(severity_options, value=list(_SEVERITY_ORDER), multiple=True, label=_t("col_severity"))
            .props("dense use-chips")
            .classes("min-w-[16rem]")
        )
        kev = ui.checkbox(_t("kev_only"))
        low = ui.number(_t("cvss_min"), value=0.0, min=0, max=10, step=0.1, precision=1).props("dense").classes("w-28")
        high = (
            ui.number(_t("cvss_max"), value=10.0, min=0, max=10, step=0.1, precision=1).props("dense").classes("w-28")
        )
    table = ui.table(columns=columns, rows=rows, row_key="cve", pagination=25).classes("w-full")
    table.props("dense flat bordered")
    table.add_slot("body-cell-cve", _LINK_SLOT)
    search.bind_value_to(table, "filter")

    def apply_filters() -> None:
        chosen = set(severities.value or [])
        lo, hi = float(low.value or 0), float(high.value if high.value is not None else 10)
        table.rows = [
            r
            for r in rows
            if r["severity"] in chosen and (not kev.value or r["kev"]) and (r["cvss"] is None or lo <= r["cvss"] <= hi)
        ]
        table.update()

    for control in (severities, kev, low, high):
        control.on_value_change(lambda _: apply_filters())
    table.on("rowClick", lambda e: _in(host, lambda: _open_cve(reader, e.args[1])))


def _new_view(reader: ReportReader, run: Dict[str, Any]) -> None:
    if not run.get("baseline_finished_at"):
        ui.label(_t("no_baseline")).classes("text-gray-500")
        return
    devices = {row["device_key"]: row for row in reader.device_rows()}
    cves = {row["cve_id"]: row for row in reader.cve_rows()}
    rows = []
    for item in reader.new_cves():
        device, cve = devices.get(item["device_key"], {}), cves.get(item["cve_id"], {})
        rows.append(
            {
                "id": f"{item['device_key']}|{item['cve_id']}",
                "device": _device_label(device),
                "ip": device.get("ip_address"),
                "cve": item["cve_id"],
                "url": _cve_url(item["cve_id"]),
                "severity": _t("sev_" + (cve.get("severity") or "na")),
                "cvss": _cvss_text(cve.get("cvss")),
                "kev": _t("yes") if cve.get("kev") else "",
                "title": cve.get("title") or "",
            }
        )
    ui.label(_t("new_since", when=_when(run["baseline_finished_at"]), n=len(rows))).classes("text-sm")
    columns: List[Dict[str, Any]] = [
        {"name": "device", "label": _t("col_device"), "field": "device", "sortable": True, "align": "left"},
        {"name": "ip", "label": "IP", "field": "ip", "sortable": True, "align": "left"},
        {"name": "cve", "label": "CVE", "field": "cve", "sortable": True, "align": "left"},
        {"name": "severity", "label": _t("col_severity"), "field": "severity", "sortable": True, "align": "left"},
        {"name": "cvss", "label": "CVSS", "field": "cvss", "sortable": True},
        {"name": "kev", "label": "KEV", "field": "kev", "sortable": True},
        {"name": "title", "label": _t("col_title"), "field": "title", "align": "left"},
    ]
    table = ui.table(columns=columns, rows=rows, row_key="id", pagination=25).classes("w-full")
    table.props("dense flat bordered")
    table.add_slot("body-cell-cve", _LINK_SLOT)


def render_report_tab() -> Callable[[], None]:
    """Render the CVE Report tab; returns the refresh run on each visit.

    Returns:
        A callable that reloads the tab from the current report.
    """
    container = ui.column().classes("w-full")
    view = {"name": "devices"}

    def refresh() -> None:
        container.clear()
        reader = _store().reader()
        with container:
            if reader is None:
                ui.label(_t("empty")).classes("text-gray-500")
                return
            run = reader.run()
            with ui.card().classes("w-full"):
                ui.label(_t("title")).classes("text-lg font-bold")
                ui.label(
                    _t(
                        "summary",
                        when=_when(run.get("finished_at")),
                        age=_age(run.get("finished_at", "")),
                        devices=run.get("device_count", 0),
                        failed=run.get("failed_count", 0),
                        cves=run.get("cve_count", 0),
                        kev=run.get("kev_cve_count", 0),
                    )
                )
                if run.get("baseline_finished_at"):
                    ui.label(
                        _t("new_summary", n=run.get("new_cve_count", 0), when=_when(run["baseline_finished_at"]))
                    ).classes("text-sm")
                if run.get("errors"):
                    with ui.expansion(_t("run_errors", n=len(run["errors"])), icon="warning").classes("w-full"):
                        for error in run["errors"]:
                            ui.label(error).classes("text-sm")
                if run.get("notes"):
                    with ui.expansion(_t("run_notes", n=len(run["notes"])), icon="info").classes("w-full"):
                        for note in run["notes"]:
                            ui.label(note).classes("text-sm")
                with ui.row().classes("gap-2 mt-2"):
                    ui.button(_t("download_csv"), icon="download", on_click=lambda: _export(reader, False)).props(
                        "outline dense"
                    )
                    new_btn = ui.button(
                        _t("download_new_csv"), icon="download", on_click=lambda: _export(reader, True)
                    ).props("outline dense")
                    if not run.get("baseline_finished_at"):
                        new_btn.disable()

            def show(name: str) -> None:
                view["name"] = name
                refresh()

            ui.toggle(
                {"devices": _t("view_devices"), "cves": _t("view_cves"), "new": _t("view_new")},
                value=view["name"],
                on_change=lambda e: show(e.value),
            )
            if view["name"] == "devices":
                _devices_view(reader, container)
            elif view["name"] == "cves":
                _cves_view(reader, container)
            else:
                _new_view(reader, run)

    refresh()
    return refresh


# ---------------------------------------------------------------------------
# Match Review
# ---------------------------------------------------------------------------


def _rt(key: str, **kwargs: Any) -> str:
    """Translate one of the Match Review tab's strings."""
    return t(f"cve_feed.review.{key}", plugin=PLUGIN_ID, **kwargs)


def _reviews() -> ReviewStore:
    return ReviewStore(get_plugin_data_dir(PLUGIN_ID) / "reviews.json")


def _reason_text(reason: str) -> str:
    if reason in ("below_threshold", "unverified", "decided"):
        return _rt("reason_" + reason)
    return reason  # an engine hold reason (a tie, a held release, "rejected in review")


def _decision_text(decision: Optional[Dict[str, Any]]) -> str:
    if not decision:
        return ""
    who = decision.get("by") or "?"
    if decision.get("decision") == ACCEPTED:
        return _rt("decision_accepted", name=decision.get("name") or decision.get("cpe"), by=who)
    return _rt("decision_rejected", by=who)


def _open_review(item: Dict[str, Any], on_change: Callable[[], None]) -> None:
    """Show one match's candidates, with the reviewer's actions."""
    store = _reviews()
    can_decide = has_role("admin")

    def act(action: Callable[[], None], message: str) -> None:
        if not require_role("admin"):
            return
        action()
        ui.notify(message, type="positive")
        dialog.close()
        on_change()

    key, role = item["device_key"], item["role"]
    with ui.dialog() as dialog, ui.card().classes("w-full max-w-4xl"):
        with ui.row().classes("items-center w-full"):
            label = item.get("hostname") or item.get("ip_address") or key
            ui.label(f"{label} - {_t('role_' + role)}").classes("text-lg font-bold")
            ui.space()
            ui.button(icon="close", on_click=dialog.close).props("flat dense round size=sm")
        ui.label(_rt("why", reason=_reason_text(item["reason"]))).classes("text-sm")
        if item.get("decision"):
            ui.label(_decision_text(item["decision"])).classes("text-sm font-bold")
        if not item["candidates"]:
            ui.label(_rt("no_candidates")).classes("text-sm text-gray-500")
        for candidate in item["candidates"]:
            score = candidate.get("score")
            with ui.row().classes("items-center w-full gap-4 border-b py-1"):
                ui.label(
                    f"{candidate.get('vendor_name', '')} {candidate.get('name', '')}" f" ({score:.2f})"
                    if isinstance(score, (int, float))
                    else candidate.get("name", "")
                ).classes("min-w-[18rem]")
                ui.label(candidate.get("cpe") or "-").classes("text-xs text-gray-600")
                ui.space()
                if can_decide and candidate.get("cpe"):
                    ui.button(
                        _rt("accept"),
                        icon="check",
                        on_click=lambda c=candidate: act(
                            lambda: store.accept(key, role, c, current_username()),
                            _rt("accepted", name=c.get("name")),
                        ),
                    ).props("outline dense color=positive")
        if can_decide:
            with ui.row().classes("gap-2 mt-2"):
                ui.button(
                    _rt("reject"),
                    icon="block",
                    on_click=lambda: act(lambda: store.reject(key, role, current_username()), _rt("rejected")),
                ).props("outline dense color=negative")
                if item.get("decision"):
                    ui.button(
                        _rt("clear"), icon="undo", on_click=lambda: act(lambda: store.clear(key, role), _rt("cleared"))
                    ).props("outline dense")
        else:
            ui.label(_rt("admin_only")).classes("text-xs text-gray-500 mt-2")
    dialog.open()


def render_review_tab() -> Callable[[], None]:
    """Render the Match Review tab; returns the refresh run on each visit.

    Returns:
        A callable that reloads the tab.
    """
    container = ui.column().classes("w-full")
    view = {"name": "open"}

    def refresh() -> None:
        container.clear()
        reader = _store().reader()
        with container:
            if reader is None:
                ui.label(_t("empty")).classes("text-gray-500")
                return
            items = reader.review_items(_reviews().load())
            ui.label(_rt("intro")).classes("text-sm")

            def show(name: str) -> None:
                view["name"] = name
                refresh()

            ui.toggle(
                {"open": _rt("view_open"), "decided": _rt("view_decided"), "all": _rt("view_all")},
                value=view["name"],
                on_change=lambda e: show(e.value),
            )
            if view["name"] == "open":
                items = [i for i in items if not i.get("decision")]
            elif view["name"] == "decided":
                items = [i for i in items if i.get("decision")]
            rows = []
            for item in items:
                best = item.get("best") or {}
                score = best.get("score")
                rows.append(
                    {
                        "id": f"{item['device_key']}|{item['role']}",
                        "device": item.get("hostname") or item.get("ip_address") or item["device_key"],
                        "ip": item.get("ip_address"),
                        "role": _t("role_" + item["role"]),
                        "why": _reason_text(item["reason"]),
                        "best": f"{best.get('vendor_name', '')} {best.get('name', '')}".strip(),
                        "score": f"{score:.2f}" if isinstance(score, (int, float)) else "",
                        "applied": _t("yes") if item["applied"] else "",
                        "decision": _decision_text(item.get("decision")),
                    }
                )
            columns: List[Dict[str, Any]] = [
                {"name": "device", "label": _t("col_device"), "field": "device", "sortable": True, "align": "left"},
                {"name": "ip", "label": "IP", "field": "ip", "sortable": True, "align": "left"},
                {"name": "role", "label": _t("col_match"), "field": "role", "sortable": True, "align": "left"},
                {"name": "why", "label": _rt("col_why"), "field": "why", "align": "left"},
                {"name": "best", "label": _rt("col_best"), "field": "best", "align": "left"},
                {"name": "score", "label": _rt("col_score"), "field": "score", "sortable": True},
                {"name": "applied", "label": _rt("col_applied"), "field": "applied"},
                {"name": "decision", "label": _rt("col_decision"), "field": "decision", "align": "left"},
            ]
            if not rows:
                ui.label(_rt("nothing")).classes("text-gray-500")
                return
            table = ui.table(columns=columns, rows=rows, row_key="id", pagination=25).classes("w-full")
            table.props("dense flat bordered")
            by_id = {f"{i['device_key']}|{i['role']}": i for i in items}
            table.on(
                "rowClick",
                lambda e: _in(container, lambda: _open_review(by_id[e.args[1]["id"]], refresh)),
            )

    refresh()
    return refresh
