"""NetBox API client for DCIM and device management."""

import logging
import os
import re
from typing import Dict, List, Optional

import requests
import urllib3

# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import build_retry_adapter, make_json_request  # pyright: ignore[reportMissingImports]

logger = logging.getLogger(__name__)

# How much of an HTTP error body to log. Bounded because an error body is
# unbounded in principle - an HTML error page or an API that echoes the
# rejected payload can both run to tens of KB. The head, not the tail: for
# a JSON API the message sits at the front ({"error":{"message":...}}), and
# when a body is HTML rather than JSON the opening tag is itself the
# diagnosis.
_ERROR_BODY_CHARS = 500

# Matches NetBox's DRF validation message for a custom field name it doesn't
# recognize for the object type being written - see _missing_custom_fields.
_MISSING_CUSTOM_FIELD_RE = re.compile(r"^Custom field '.+' does not exist for this object type\.$")


def generate_slug(name: str) -> str:
    """Generate a valid NetBox slug from a name.

    Slugs must contain only lowercase letters, numbers, underscores, or hyphens.

    Args:
        name: The name to convert to a slug

    Returns:
        A valid slug string
    """
    # Convert to lowercase
    slug = name.lower()
    # Replace spaces and underscores with hyphens
    slug = slug.replace(" ", "-").replace("_", "-")
    # Remove any characters that are not alphanumeric or hyphens
    slug = re.sub(r"[^a-z0-9-]", "", slug)
    # Remove consecutive hyphens
    slug = re.sub(r"-+", "-", slug)
    # Remove leading/trailing hyphens
    slug = slug.strip("-")
    # Ensure slug is not empty
    return slug if slug else "unknown"


class NetBoxClient:
    """
    Native Python client for NetBox REST API.

    Supports DCIM operations: devices, manufacturers, platforms, device roles,
    sites, locations, racks, and more.
    """

    def __init__(
        self,
        host: Optional[str] = None,
        api_token: Optional[str] = None,
        verify_ssl: Optional[bool] = None,
        timeout: Optional[int] = None,
        ignore_env_vars: bool = False,
    ) -> None:
        """Initialize NetBox client.

        Args:
            host: NetBox host URL or hostname (e.g., https://netbox.example.com or netbox.example.com or 192.168.1.54).
                  If not provided, uses NETBOX_HOST env var.
            api_token: NetBox API token. If not provided, uses NETBOX_API_TOKEN env var.
            verify_ssl: Verify TLS certificates. Defaults to conf/netbox_sync_config.yaml
                        netbox.verify_ssl, or False.
            timeout: Request timeout in seconds. Defaults to conf/netbox_sync_config.yaml
                     netbox.timeout, or 120.
            ignore_env_vars: If True, do not fall back to environment variables.
        """
        if ignore_env_vars:
            self.host = host
            self.api_token = api_token
            self.verify_ssl = verify_ssl if verify_ssl is not None else False
            self.timeout = timeout or 120
        else:
            self.host = host or os.getenv("NETBOX_HOST")
            self.api_token = api_token or os.getenv("NETBOX_API_TOKEN")
            if verify_ssl is not None and timeout is not None:
                self.verify_ssl = verify_ssl
                self.timeout = timeout
            else:
                from .settings import get_netbox_settings

                netbox_cfg = get_netbox_settings().get("netbox", {})
                self.verify_ssl = verify_ssl if verify_ssl is not None else bool(netbox_cfg.get("verify_ssl", False))
                self.timeout = timeout if timeout is not None else int(netbox_cfg.get("timeout", 120))

        # Normalize host - remove protocol if present
        if self.host and self.host.startswith(("http://", "https://")):
            self.host = self.host.split("://", 1)[1]

        self.base_url = f"https://{self.host}/api"

        # Session for connection pooling
        self.session = requests.Session()
        self.session.headers.update(
            {
                "Authorization": self._auth_header_value(),
                "Content-Type": "application/json",
                "Accept": "application/json",
            }
        )
        self.session.verify = self.verify_ssl
        if not self.verify_ssl:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        _adapter = build_retry_adapter()
        self.session.mount("https://", _adapter)
        self.session.mount("http://", _adapter)

    def _auth_header_value(self) -> str:
        """Build the Authorization header, tolerant of either token generation.

        NetBox v1 tokens are plaintext and use "Authorization: Token <token>";
        v2 tokens are "nbt_<key>.<secret>" and use "Authorization: Bearer
        <token>" (see
        https://netbox.readthedocs.io/en/stable/integrations/rest-api/#v1-and-v2-tokens).
        v1 is deprecated but still supported, so both must keep working. A
        token supplied (GUI or env var) with an explicit "Token "/"Bearer "
        prefix is honored as-is; a bare token is auto-detected from its
        "nbt_" marker, defaulting to v1 ("Token") when absent.
        """
        token = self.api_token
        if not token:
            return f"Token {token}"
        lowered = token.lower()
        if lowered.startswith("bearer "):
            return f"Bearer {token[len('Bearer '):].strip()}"
        if lowered.startswith("token "):
            return f"Token {token[len('Token '):].strip()}"
        scheme = "Bearer" if token.startswith("nbt_") else "Token"
        return f"{scheme} {token}"

    def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict] = None,
        json_data: Optional[Dict] = None,
        suppress_errors: bool = False,
    ) -> requests.Response:
        """Make HTTP request to NetBox API."""
        url = f"{self.base_url}/{endpoint}"
        return make_json_request(
            self.session,
            method,
            url,
            logger=logger,
            params=params,
            json_data=json_data,
            timeout=self.timeout,
            suppress_errors=suppress_errors,
            error_body_chars=_ERROR_BODY_CHARS,
        )

    def test_connection(self) -> bool:
        """Test connectivity to NetBox API."""
        try:
            response = self._request("GET", "dcim/devices/?limit=1")
            return response.status_code == 200
        except Exception as e:
            logger.error("NetBox connection test failed: %s", e)
            return False

    # ==================== Devices ====================

    def get_devices(self, filters: Optional[Dict] = None, limit: int = 50) -> List[Dict]:
        """
        Get devices from NetBox.

        Args:
            filters: Query filters (e.g., {'name': 'router1', 'site': 'site1'})
            limit: Results per page (NetBox default: 50)

        Returns:
            List of device dictionaries
        """
        params = {"limit": limit}
        if filters:
            params.update(filters)

        all_devices = []
        offset = 0

        while True:
            params["offset"] = offset
            response = self._request("GET", "dcim/devices/", params=params)
            data = response.json()

            all_devices.extend(data.get("results", []))

            # Check if there are more results
            if not data.get("next"):
                break
            offset += limit

        return all_devices

    def get_device_by_name(self, name: str) -> Optional[Dict]:
        """Get device by name."""
        devices = self.get_devices(filters={"name": name})
        return devices[0] if devices else None

    def create_device(
        self,
        device_data: Dict,
        auto_create_custom_fields: bool = False,
        custom_field_types: Optional[Dict[str, str]] = None,
    ) -> Dict:
        """Create a new device in NetBox."""
        return self._write_device("POST", "dcim/devices/", device_data, auto_create_custom_fields, custom_field_types)

    def update_device(
        self,
        device_id: int,
        device_data: Dict,
        auto_create_custom_fields: bool = False,
        custom_field_types: Optional[Dict[str, str]] = None,
    ) -> Dict:
        """Update an existing device."""
        return self._write_device(
            "PATCH", f"dcim/devices/{device_id}/", device_data, auto_create_custom_fields, custom_field_types
        )

    def _write_device(
        self,
        method: str,
        endpoint: str,
        device_data: Dict,
        auto_create_custom_fields: bool,
        custom_field_types: Optional[Dict[str, str]],
    ) -> Dict:
        """POST/PATCH a device, optionally recovering from a missing-custom-field 400.

        NetBox rejects a write outright if device_data['custom_fields'] names
        a field that doesn't exist yet for dcim.device - a common first-sync
        error, since the four lifecycle fields and any generic/LVI custom
        field mapping are all admin-configured names that must otherwise be
        created by hand in NetBox first. When auto_create_custom_fields is
        on, create exactly the fields NetBox actually rejected (parsed from
        its own error body, not guessed from device_data) and retry once -
        a second failure propagates normally rather than looping.
        """
        try:
            response = self._request(method, endpoint, json_data=device_data)
            return response.json()
        except requests.exceptions.HTTPError as e:
            resp = e.response
            if not auto_create_custom_fields or resp is None or resp.status_code != 400:
                raise
            missing = self._missing_custom_fields(resp)
            if not missing:
                raise
            types = custom_field_types or {}
            for name in missing:
                field_type = types.get(name, "text")
                logger.info("Auto-creating missing NetBox custom field '%s' (type=%s)", name, field_type)
                try:
                    created = self.create_custom_field(name, field_type, ["dcim.device"])
                    logger.info(
                        "Created NetBox custom field '%s' (id=%s, object_types=%s)",
                        name,
                        created.get("id"),
                        created.get("object_types"),
                    )
                except requests.exceptions.HTTPError as create_err:
                    create_resp = create_err.response
                    detail = create_resp.text[:_ERROR_BODY_CHARS] if create_resp is not None else str(create_err)
                    logger.error("Could not create NetBox custom field '%s': %s", name, detail)
                    # One field failing to create doesn't stop the others -
                    # each is independent, and the retry below still runs so
                    # any field that DID succeed takes effect this run.
            response = self._request(method, endpoint, json_data=device_data)
            return response.json()

    def delete_device(self, device_id: int) -> bool:
        """Delete a device."""
        response = self._request("DELETE", f"dcim/devices/{device_id}/")
        return response.status_code == 204

    # ==================== Device Types ====================

    def get_device_types(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Get device types."""
        params = {"limit": 50}
        if filters:
            params.update(filters)

        all_device_types = []
        offset = 0

        while True:
            params["offset"] = offset
            response = self._request("GET", "dcim/device-types/", params=params)
            data = response.json()

            all_device_types.extend(data.get("results", []))

            if not data.get("next"):
                break
            offset += 50

        return all_device_types

    def get_device_type_by_model(self, model: str) -> Optional[Dict]:
        """Get device type by model name."""
        types = self.get_device_types(filters={"model__ic": model})
        return types[0] if types else None

    def create_device_type(self, model: str, manufacturer_id: int, slug: Optional[str] = None) -> Dict:
        """Create a new device type.

        Args:
            model: Device model name (e.g., "ISR4321", "2500")
            manufacturer_id: ID of the manufacturer
            slug: URL-friendly slug (auto-generated from model if not provided)

        Returns:
            Created device type dictionary
        """
        if not slug:
            slug = generate_slug(model)
        data = {"model": model, "manufacturer": manufacturer_id, "slug": slug}
        response = self._request("POST", "dcim/device-types/", json_data=data)
        return response.json()

    def get_or_create_device_type(self, model: str, manufacturer_name: str) -> Optional[Dict]:
        """Get device type by model, or create it if it doesn't exist.

        Args:
            model: Device model name
            manufacturer_name: Manufacturer name (will be created if missing)

        Returns:
            Device type dictionary, or None on error
        """
        # Try to find existing device type
        device_type = self.get_device_type_by_model(model)
        if device_type:
            return device_type

        # Get or create manufacturer
        manufacturer = self.get_manufacturer_by_name(manufacturer_name)
        slug = generate_slug(manufacturer_name)
        if not manufacturer:
            # A name variant that slugifies the same as an existing
            # manufacturer (different case/punctuation, e.g. "HP" vs
            # "H.P.") misses the exact-name lookup above but collides on
            # create anyway - NetBox's real uniqueness constraint is the
            # slug, not the name (confirmed live: "manufacturer with this
            # slug already exists"). Try the slug before creating.
            manufacturer = self.get_manufacturer_by_slug(slug)
        if not manufacturer:
            manufacturer = self.create_manufacturer(manufacturer_name, slug)

        manufacturer_id = manufacturer.get("id")
        if not manufacturer_id:
            return None

        # Create device type
        return self.create_device_type(model, manufacturer_id)

    # ==================== Manufacturers ====================

    def get_manufacturers(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Get manufacturers."""
        params = {"limit": 50}
        if filters:
            params.update(filters)

        all_manufacturers = []
        offset = 0

        while True:
            params["offset"] = offset
            response = self._request("GET", "dcim/manufacturers/", params=params)
            data = response.json()

            all_manufacturers.extend(data.get("results", []))

            if not data.get("next"):
                break
            offset += 50

        return all_manufacturers

    def get_manufacturer_by_name(self, name: str) -> Optional[Dict]:
        """Get manufacturer by name."""
        manufacturers = self.get_manufacturers(filters={"name": name})
        return manufacturers[0] if manufacturers else None

    def get_manufacturer_by_slug(self, slug: str) -> Optional[Dict]:
        """Get manufacturer by slug - NetBox's real uniqueness constraint, unlike name."""
        manufacturers = self.get_manufacturers(filters={"slug": slug})
        return manufacturers[0] if manufacturers else None

    def create_manufacturer(self, name: str, slug: str) -> Dict:
        """Create a new manufacturer."""
        data = {"name": name, "slug": slug}
        response = self._request("POST", "dcim/manufacturers/", json_data=data)
        return response.json()

    # ==================== Device Roles ====================

    def get_device_roles(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Get device roles."""
        params = {"limit": 50}
        if filters:
            params.update(filters)

        all_device_roles = []
        offset = 0

        while True:
            params["offset"] = offset
            response = self._request("GET", "dcim/device-roles/", params=params)
            data = response.json()

            all_device_roles.extend(data.get("results", []))

            if not data.get("next"):
                break
            offset += 50

        return all_device_roles

    def get_device_role_by_name(self, name: str) -> Optional[Dict]:
        """Get device role by name."""
        roles = self.get_device_roles(filters={"name": name})
        return roles[0] if roles else None

    def get_device_role_by_slug(self, slug: str) -> Optional[Dict]:
        """Get device role by slug - NetBox's real uniqueness constraint, unlike name."""
        roles = self.get_device_roles(filters={"slug": slug})
        return roles[0] if roles else None

    def create_device_role(self, name: str, slug: str, color: str = "3f51b5") -> Dict:
        """Create a new device role."""
        data = {"name": name, "slug": slug, "color": color}
        response = self._request("POST", "dcim/device-roles/", json_data=data)
        return response.json()

    def get_or_create_device_role(self, name: str) -> Optional[Dict]:
        """Get device role by name, or create it if it doesn't exist.

        Args:
            name: Device role name (e.g., "Router", "Switch")

        Returns:
            Device role dictionary, or None on error
        """
        role = self.get_device_role_by_name(name)
        if role:
            return role

        # A name variant that slugifies the same as an existing role
        # misses the exact-name lookup above but collides on create -
        # NetBox's real uniqueness constraint is the slug, not the name
        # (same class of bug confirmed live for manufacturers). Try the
        # slug before creating.
        slug = generate_slug(name)
        role = self.get_device_role_by_slug(slug)
        if role:
            return role

        return self.create_device_role(name, slug)

    # ==================== Platforms ====================

    def get_platforms(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Get platforms."""
        params = {"limit": 50}
        if filters:
            params.update(filters)

        all_platforms = []
        offset = 0

        while True:
            params["offset"] = offset
            response = self._request("GET", "dcim/platforms/", params=params)
            data = response.json()

            all_platforms.extend(data.get("results", []))

            if not data.get("next"):
                break
            offset += 50

        return all_platforms

    def get_platform_by_name(self, name: str) -> Optional[Dict]:
        """Get platform by name."""
        platforms = self.get_platforms(filters={"name": name})
        return platforms[0] if platforms else None

    def get_platform_by_slug(self, slug: str) -> Optional[Dict]:
        """Get platform by slug - NetBox's real uniqueness constraint, unlike name."""
        platforms = self.get_platforms(filters={"slug": slug})
        return platforms[0] if platforms else None

    def create_platform(self, name: str, slug: str, napalm_driver: Optional[str] = None) -> Dict:
        """Create a new platform."""
        data = {"name": name, "slug": slug}
        if napalm_driver:
            data["napalm_driver"] = napalm_driver
        response = self._request("POST", "dcim/platforms/", json_data=data)
        return response.json()

    def get_or_create_platform(self, name: str) -> Optional[Dict]:
        """Get platform by name, or create it if it doesn't exist.

        Args:
            name: Platform name (e.g., "IOS", "JunOS", "Linux")

        Returns:
            Platform dictionary, or None on error
        """
        platform = self.get_platform_by_name(name)
        if platform:
            return platform

        # Same class of bug as manufacturers/device roles: a name variant
        # that slugifies the same as an existing platform misses the
        # exact-name lookup but collides on create. Try the slug first.
        slug = generate_slug(name)
        platform = self.get_platform_by_slug(slug)
        if platform:
            return platform

        return self.create_platform(name, slug)

    # ==================== Sites ====================

    def get_sites(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Get sites."""
        params = {"limit": 50}
        if filters:
            params.update(filters)

        all_sites = []
        offset = 0

        while True:
            params["offset"] = offset
            response = self._request("GET", "dcim/sites/", params=params)
            data = response.json()

            all_sites.extend(data.get("results", []))

            if not data.get("next"):
                break
            offset += 50

        return all_sites

    def get_site_by_name(self, name: str) -> Optional[Dict]:
        """Get site by name."""
        sites = self.get_sites(filters={"name__ic": name})
        return sites[0] if sites else None

    def create_site(self, name: str, slug: Optional[str] = None) -> Dict:
        """Create a new site.

        Args:
            name: Site name
            slug: URL-friendly slug (auto-generated from name if not provided)

        Returns:
            Created site dictionary
        """
        if not slug:
            slug = generate_slug(name)
        data = {"name": name, "slug": slug, "status": "active"}
        response = self._request("POST", "dcim/sites/", json_data=data)
        return response.json()

    def get_or_create_site(self, name: str) -> Optional[Dict]:
        """Get site by name, or create it if it doesn't exist.

        Args:
            name: Site name

        Returns:
            Site dictionary, or None on error
        """
        site = self.get_site_by_name(name)
        if site:
            return site

        return self.create_site(name)

    # ==================== Locations ====================

    def get_locations(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Get locations."""
        params = {"limit": 50}
        if filters:
            params.update(filters)

        all_locations = []
        offset = 0

        while True:
            params["offset"] = offset
            response = self._request("GET", "dcim/locations/", params=params)
            data = response.json()

            all_locations.extend(data.get("results", []))

            if not data.get("next"):
                break
            offset += 50

        return all_locations

    def get_location_by_name(self, name: str) -> Optional[Dict]:
        """Get location by name."""
        locations = self.get_locations(filters={"name": name})
        return locations[0] if locations else None

    def get_location_by_name_and_site(self, name: str, site_id: int) -> Optional[Dict]:
        """Get location by name within a specific site."""
        locations = self.get_locations(filters={"name": name, "site_id": site_id})
        return locations[0] if locations else None

    def get_location_by_slug_and_site(self, slug: str, site_id: int) -> Optional[Dict]:
        """Get location by slug within a specific site - NetBox's real
        uniqueness constraint (per site), unlike name."""
        locations = self.get_locations(filters={"slug": slug, "site_id": site_id})
        return locations[0] if locations else None

    def create_location(self, name: str, site_id: int, slug: Optional[str] = None) -> Dict:
        """Create a new location.

        Args:
            name: Location name
            site_id: Site ID the location belongs to
            slug: URL-friendly slug (auto-generated from name if not provided)

        Returns:
            Created location dictionary
        """
        if not slug:
            slug = generate_slug(name)
        data = {"name": name, "site": site_id, "slug": slug, "status": "active"}
        response = self._request("POST", "dcim/locations/", json_data=data)
        return response.json()

    def get_or_create_location(self, name: str, site_id: int) -> Optional[Dict]:
        """Get location by name within a site, or create it if it doesn't exist.

        Args:
            name: Location name
            site_id: Site ID the location belongs to

        Returns:
            Location dictionary, or None on error
        """
        location = self.get_location_by_name_and_site(name, site_id)
        if location:
            return location

        # Confirmed live: "A location with this slug already exists
        # within the specified site" - a name variant that slugifies the
        # same as an existing location (e.g. differing only in case)
        # misses the exact-name lookup above but collides on create.
        # NetBox's real uniqueness constraint is the slug (per site), not
        # the name. Try the slug before creating.
        slug = generate_slug(name)
        location = self.get_location_by_slug_and_site(slug, site_id)
        if location:
            return location

        return self.create_location(name, site_id, slug=slug)

    # ==================== Tenants ====================

    def get_tenants(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Get tenants."""
        params = {"limit": 50}
        if filters:
            params.update(filters)

        all_tenants = []
        offset = 0

        while True:
            params["offset"] = offset
            response = self._request("GET", "tenancy/tenants/", params=params)
            data = response.json()

            all_tenants.extend(data.get("results", []))

            if not data.get("next"):
                break
            offset += 50

        return all_tenants

    def get_tenant_by_name(self, name: str) -> Optional[Dict]:
        """Get tenant by name."""
        tenants = self.get_tenants(filters={"name__ic": name})
        return tenants[0] if tenants else None

    def create_tenant(self, name: str, slug: Optional[str] = None) -> Dict:
        """Create a new tenant.

        Args:
            name: Tenant name
            slug: URL-friendly slug (auto-generated from name if not provided)

        Returns:
            Created tenant dictionary
        """
        if not slug:
            slug = generate_slug(name)
        data = {"name": name, "slug": slug}
        response = self._request("POST", "tenancy/tenants/", json_data=data)
        return response.json()

    def get_or_create_tenant(self, name: str) -> Optional[Dict]:
        """Get tenant by name, or create it if it doesn't exist.

        Args:
            name: Tenant name

        Returns:
            Tenant dictionary, or None on error
        """
        tenant = self.get_tenant_by_name(name)
        if tenant:
            return tenant

        return self.create_tenant(name)

    # ==================== Racks ====================

    def get_racks(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Get racks."""
        params = {"limit": 50}
        if filters:
            params.update(filters)

        all_racks = []
        offset = 0

        while True:
            params["offset"] = offset
            response = self._request("GET", "dcim/racks/", params=params)
            data = response.json()

            all_racks.extend(data.get("results", []))

            if not data.get("next"):
                break
            offset += 50

        return all_racks

    def get_rack_by_name(self, name: str) -> Optional[Dict]:
        """Get rack by name."""
        racks = self.get_racks(filters={"name__ic": name})
        return racks[0] if racks else None

    # ==================== Circuits ====================

    def get_circuits(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Get circuits."""
        params = {"limit": 50}
        if filters:
            params.update(filters)

        all_circuits = []
        offset = 0

        while True:
            params["offset"] = offset
            response = self._request("GET", "circuits/circuits/", params=params)
            data = response.json()

            all_circuits.extend(data.get("results", []))

            if not data.get("next"):
                break
            offset += 50

        return all_circuits

    def get_providers(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Get circuit providers."""
        params = {"limit": 50}
        if filters:
            params.update(filters)

        all_providers = []
        offset = 0

        while True:
            params["offset"] = offset
            response = self._request("GET", "circuits/providers/", params=params)
            data = response.json()

            all_providers.extend(data.get("results", []))

            if not data.get("next"):
                break
            offset += 50

        return all_providers

    # ==================== Interfaces ====================

    def get_interfaces(self, device_id: int, limit: int = 100) -> List[Dict]:
        """Get interfaces for a device."""
        params = {"device_id": device_id, "limit": limit}
        all_interfaces = []
        offset = 0

        while True:
            params["offset"] = offset
            response = self._request("GET", "dcim/interfaces/", params=params)
            data = response.json()

            all_interfaces.extend(data.get("results", []))

            if not data.get("next"):
                break
            offset += limit

        return all_interfaces

    def search_interfaces(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Search interfaces across all devices (unlike get_interfaces, which is
        scoped to one device) - e.g. filters={"mac_address": "..."} to find every
        interface currently carrying a given MAC, for conflict detection."""
        params = {"limit": 50}
        if filters:
            params.update(filters)

        all_interfaces = []
        offset = 0

        while True:
            params["offset"] = offset
            response = self._request("GET", "dcim/interfaces/", params=params)
            data = response.json()

            all_interfaces.extend(data.get("results", []))

            if not data.get("next"):
                break
            offset += 50

        return all_interfaces

    def get_interface_by_name(self, device_id: int, name: str) -> Optional[Dict]:
        """Get interface by name for a device."""
        interfaces = self.get_interfaces(device_id)
        for iface in interfaces:
            if iface.get("name") == name:
                return iface
        return None

    def create_interface(self, interface_data: Dict) -> Dict:
        """Create a new interface.

        Args:
            interface_data: Interface data with required fields:
                - device (int): Device ID
                - name (str): Interface name
                - type (str): Interface type (e.g., 'virtual', '1000base-t', '10gbase-x-sfpp')

        Returns:
            Created interface dictionary
        """
        response = self._request("POST", "dcim/interfaces/", json_data=interface_data)
        return response.json()

    def update_interface(self, interface_id: int, interface_data: Dict) -> Dict:
        """Update an existing interface."""
        response = self._request("PATCH", f"dcim/interfaces/{interface_id}/", json_data=interface_data)
        return response.json()

    def delete_interface(self, interface_id: int) -> bool:
        """Delete an interface."""
        response = self._request("DELETE", f"dcim/interfaces/{interface_id}/")
        return response.status_code == 204

    def get_or_create_interface(
        self, device_id: int, name: str = "mgmt0", interface_type: str = "virtual"
    ) -> Optional[Dict]:
        """Get interface by name, or create it if it doesn't exist.

        Args:
            device_id: Device ID
            name: Interface name (default: "mgmt0")
            interface_type: Interface type (default: "virtual")

        Returns:
            Interface dictionary, or None on error
        """
        interface = self.get_interface_by_name(device_id, name)
        if interface:
            return interface

        interface_data = {
            "device": device_id,
            "name": name,
            "type": interface_type,
        }
        return self.create_interface(interface_data)

    # ==================== IP Addresses ====================

    def get_ip_addresses(self, filters: Optional[Dict] = None, limit: int = 50) -> List[Dict]:
        """Get IP addresses."""
        params = {"limit": limit}
        if filters:
            params.update(filters)

        all_ips = []
        offset = 0

        while True:
            params["offset"] = offset
            response = self._request("GET", "ipam/ip-addresses/", params=params)
            data = response.json()

            all_ips.extend(data.get("results", []))

            if not data.get("next"):
                break
            offset += limit

        return all_ips

    def get_ip_address_by_address(self, address: str, vrf_id: Optional[int] = None) -> Optional[Dict]:
        """Get IP address by address string (e.g., '192.168.1.1/24' or '192.168.1.1').

        NetBox enforces IP uniqueness per VRF, not globally, so the same
        address can legitimately exist in more than one VRF. Always scoped
        by VRF - vrf_id when given, otherwise vrf_id__isnull (i.e. "no
        VRF"), never unscoped - an unscoped lookup could match a record in
        a foreign VRF (hand-created, or written by a different tool) and
        this plugin would then update or conflict-check against the wrong
        record entirely.

        Args:
            address: IP address string, with or without CIDR notation
            vrf_id: NetBox VRF id to scope the lookup to, or None for "no VRF"

        Returns:
            IP address dictionary if found, None otherwise
        """
        ip_only = address.split("/")[0]
        vrf_filter = {"vrf_id": vrf_id} if vrf_id is not None else {"vrf_id__isnull": "true"}

        # Try exact CIDR match first - most reliable, handles IPv6 normalization.
        # Falls back to a contains search to catch prefix-length mismatches (e.g.
        # LVI reports /32 but NetBox stored the address with a different prefix).
        ips = self.get_ip_addresses(filters={"address": address, **vrf_filter})
        if ips:
            return ips[0]

        ips = self.get_ip_addresses(filters={"address__contains": ip_only, **vrf_filter})
        for ip in ips:
            if ip.get("address", "").startswith(ip_only):
                return ip
        return None

    def get_ip_address_on_interface(self, address: str, interface_id: int) -> Optional[Dict]:
        """Find an IP address already assigned to a specific interface, regardless of VRF.

        A fallback for when get_ip_address_by_address()'s VRF-scoped lookup
        misses: an address already attached to this exact interface is
        unambiguously the same logical record even if its current vrf
        doesn't match what was just resolved for it (e.g. VRF Sync turned
        on after the address was already synced with no VRF) - the caller
        should update it, including moving its vrf, rather than creating a
        duplicate second record for the same address on the same interface.
        """
        ips = self.get_ip_addresses(
            filters={"address": address, "assigned_object_id": interface_id, "assigned_object_type": "dcim.interface"}
        )
        return ips[0] if ips else None

    def create_ip_address(self, ip_data: Dict) -> Dict:
        """Create a new IP address.

        Args:
            ip_data: IP address data with required 'address' field in CIDR notation.
                Optional fields: vrf, tenant, status, role, assigned_object_type,
                assigned_object_id, dns_name, description, tags, custom_fields

        Returns:
            Created IP address dictionary
        """
        response = self._request("POST", "ipam/ip-addresses/", json_data=ip_data)
        return response.json()

    def clear_primary_ip_owner(self, ip_id: int) -> List[Dict]:
        """Clear primary_ip4 from every device currently designating *ip_id* as its primary.

        NetBox refuses to move an address to a different interface while it
        is still a parent object's primary IP, rejecting the PATCH outright
        with HTTP 400 ("Cannot reassign IP address while it is designated as
        the primary IP for the parent object"). Any caller that reassigns an
        existing address has to clear the designation first.

        Returns the devices that were cleared (empty when the address was
        not anyone's primary, which is the common case).
        """
        devices = self.get_devices(filters={"primary_ip4_id": ip_id})
        for device in devices:
            self.update_device(device["id"], {"primary_ip4": None})
        return devices

    def update_ip_address(self, ip_id: int, ip_data: Dict) -> Dict:
        """Update an existing IP address.

        When this moves the address to a different interface, call
        clear_primary_ip_owner() first - NetBox rejects the reassignment
        while the address is still its parent's primary.
        """
        response = self._request("PATCH", f"ipam/ip-addresses/{ip_id}/", json_data=ip_data)
        return response.json()

    def delete_ip_address(self, ip_id: int) -> bool:
        """Delete an IP address."""
        response = self._request("DELETE", f"ipam/ip-addresses/{ip_id}/")
        return response.status_code == 204

    # ==================== VRFs ====================

    def get_vrfs(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Get VRFs (Virtual Routing and Forwarding)."""
        params = {"limit": 50}
        if filters:
            params.update(filters)

        all_vrfs = []
        offset = 0

        while True:
            params["offset"] = offset
            response = self._request("GET", "ipam/vrfs/", params=params)
            data = response.json()

            all_vrfs.extend(data.get("results", []))

            if not data.get("next"):
                break
            offset += 50

        return all_vrfs

    def get_vrf_by_name(self, name: str) -> Optional[Dict]:
        """Get VRF by name."""
        vrfs = self.get_vrfs(filters={"name": name})
        return vrfs[0] if vrfs else None

    def create_vrf(self, name: str) -> Dict:
        """Create a VRF (Virtual Routing and Forwarding) in NetBox. Only `name` is required."""
        response = self._request("POST", "ipam/vrfs/", json_data={"name": name})
        return response.json()

    # ==================== Tags ====================

    def get_tags(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Get tags (extras/tags/)."""
        params = {"limit": 50}
        if filters:
            params.update(filters)

        all_tags = []
        offset = 0

        while True:
            params["offset"] = offset
            response = self._request("GET", "extras/tags/", params=params)
            data = response.json()

            all_tags.extend(data.get("results", []))

            if not data.get("next"):
                break
            offset += 50

        return all_tags

    def get_tag_by_name(self, name: str) -> Optional[Dict]:
        """Get tag by name."""
        tags = self.get_tags(filters={"name": name})
        return tags[0] if tags else None

    def get_tag_by_slug(self, slug: str) -> Optional[Dict]:
        """Get tag by slug - NetBox's real uniqueness constraint, unlike name."""
        tags = self.get_tags(filters={"slug": slug})
        return tags[0] if tags else None

    def create_tag(self, name: str, slug: str, color: str = "9e9e9e") -> Dict:
        """Create a new tag."""
        data = {"name": name, "slug": slug, "color": color}
        response = self._request("POST", "extras/tags/", json_data=data)
        return response.json()

    def get_or_create_tag(self, name: str) -> Optional[Dict]:
        """Get tag by name, or create it if it doesn't exist.

        Args:
            name: Tag name (e.g. "lvi-managed")

        Returns:
            Tag dictionary, or None on error
        """
        tag = self.get_tag_by_name(name)
        if tag:
            return tag

        # Same class of bug already fixed for device roles/manufacturers: a
        # name variant that slugifies the same as an existing tag misses the
        # exact-name lookup above but collides on create. Try the slug
        # before creating.
        slug = generate_slug(name)
        tag = self.get_tag_by_slug(slug)
        if tag:
            return tag

        return self.create_tag(name, slug)

    # ==================== VLANs ====================

    def get_vlans(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Get VLANs."""
        params = {"limit": 50}
        if filters:
            params.update(filters)

        all_vlans = []
        offset = 0

        while True:
            params["offset"] = offset
            response = self._request("GET", "ipam/vlans/", params=params)
            data = response.json()

            all_vlans.extend(data.get("results", []))

            if not data.get("next"):
                break
            offset += 50

        return all_vlans

    def get_vlan_by_vid(self, vid: int, site_id: Optional[int] = None) -> Optional[Dict]:
        """Get a VLAN by its numeric ID, optionally scoped to a site.

        The same VID can legitimately exist in more than one site, so a
        site-scoped lookup avoids matching an unrelated VLAN that happens
        to share the number.
        """
        filters: Dict = {"vid": vid}
        if site_id is not None:
            filters["site_id"] = site_id
        vlans = self.get_vlans(filters=filters)
        return vlans[0] if vlans else None

    def create_vlan(self, vid: int, name: str, site_id: Optional[int] = None) -> Dict:
        """Create a VLAN. `name` is required by NetBox."""
        payload: Dict = {"vid": vid, "name": name}
        if site_id is not None:
            payload["site"] = site_id
        response = self._request("POST", "ipam/vlans/", json_data=payload)
        return response.json()

    # ==================== Custom Fields ====================

    def get_custom_fields(self) -> List[Dict]:
        """Get custom fields configuration."""
        params = {"limit": 100}
        all_custom_fields = []
        offset = 0

        while True:
            params["offset"] = offset
            response = self._request("GET", "extras/custom-fields/", params=params)
            data = response.json()

            all_custom_fields.extend(data.get("results", []))

            if not data.get("next"):
                break
            offset += 100

        return all_custom_fields

    def get_custom_field_by_name(self, name: str) -> Optional[Dict]:
        """Get custom field by name."""
        fields = self.get_custom_fields()
        for field in fields:
            if field.get("name") == name:
                return field
        return None

    def create_custom_field(
        self, name: str, field_type: str, object_types: List[str], label: Optional[str] = None
    ) -> Dict:
        """Create a custom field definition in NetBox (extras/custom-fields/)."""
        payload = {
            "name": name,
            "type": field_type,
            "object_types": object_types,
            "label": label or name.replace("_", " ").title(),
        }
        response = self._request("POST", "extras/custom-fields/", json_data=payload)
        return response.json()

    @staticmethod
    def _missing_custom_fields(response: requests.Response) -> List[str]:
        """Parse a 400 response body for custom field names NetBox rejected as unknown.

        NetBox's DRF validation shapes this as
        {"custom_fields": {"<name>": "Custom field '<name>' does not exist
        for this object type."}} - the message is usually a plain string per
        field but DRF sometimes wraps validation messages in a list, so both
        are handled. Returns an empty list for any other 400 shape (a real
        validation error, not a missing-field one) so the caller re-raises
        instead of misinterpreting it.
        """
        try:
            body = response.json()
        except ValueError:
            return []
        errors = body.get("custom_fields")
        if not isinstance(errors, dict):
            return []
        missing = []
        for field_name, message in errors.items():
            messages = message if isinstance(message, list) else [message]
            if any(isinstance(m, str) and _MISSING_CUSTOM_FIELD_RE.match(m) for m in messages):
                missing.append(field_name)
        return missing
