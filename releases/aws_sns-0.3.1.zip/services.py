"""Background services contributed by the AWS SNS plugin.

A subscriber, like the Jira plugin: it registers its handlers with the core
``/webhook/lvi-alert`` dispatch and the core config-change dispatch, and
starts no detection backend of its own.

The core calls :func:`build_services` at startup and again on every settings
save, but never unregisters a plugin's handlers itself. So this function
registers each handler while its switch is on and **unregisters** it when
off - registering only would keep a handler live until a restart after its
switch went off:

- the alert handler: ``features.alerts`` (App Settings);
- the change handler: ``features.change_detection`` (App Settings) and the
  plugin's own ``changes.enabled``.

It returns the held-event flusher as a service, while either handler is
registered, rather than starting a thread itself: the core stops and
restarts returned services on a settings save and stops them on shutdown,
whereas a thread started here would be duplicated on every save and outlive
an uninstall.
"""

from typing import Any, List


def build_services() -> List[Any]:
    """Register or unregister each handler; return the flusher.

    Returns:
        ``[Flusher()]`` while either handler is registered, else ``[]``.
    """
    # src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
    from src.plugin_api import (  # pyright: ignore[reportMissingImports]
        get_app_settings,
        register_alert_handler,
        register_change_handler,
        unregister_alert_handler,
        unregister_change_handler,
    )

    from .flusher import Flusher
    from .handlers import get_alert_handler, get_change_handler
    from .settings import get_settings

    features = get_app_settings().get("features", {}) or {}
    alerts_on = bool(features.get("alerts", True))
    changes_on = bool(features.get("change_detection", True)) and bool(
        (get_settings().get("changes", {}) or {}).get("enabled", False)
    )

    alert_handler = get_alert_handler()
    if alerts_on:
        register_alert_handler(alert_handler)
    else:
        unregister_alert_handler(alert_handler)
    change_handler = get_change_handler()
    if changes_on:
        register_change_handler(change_handler)
    else:
        unregister_change_handler(change_handler)
    return [Flusher()] if alerts_on or changes_on else []
