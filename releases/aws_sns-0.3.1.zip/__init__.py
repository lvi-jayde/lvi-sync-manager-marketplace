"""AWS SNS plugin: publish LogicVein alerts to an Amazon SNS topic."""

from .plugin import AwsSnsPlugin

__all__ = ["AwsSnsPlugin"]
