"""A thin wrapper over boto3's SNS client: publish to one topic, describe it.

Two boto3 clients, built on first use and reused:

- the **publish client** makes exactly one attempt. botocore's retry modes
  retry throttling and 5xx responses, and a 5xx can arrive after SNS has
  accepted a message, so an SDK retry could text every subscriber twice.
  Retrying is the caller's job (a LogicVein redelivery, or the flusher's next
  tick), and the caller checks its alert state first.
- the **query client** (``get_topic_attributes``, safe to repeat) uses
  botocore's ``standard`` retry mode.

Handlers run in the web server's worker threads and the flusher in its own,
so the clients are shared across threads. A built boto3 client is
thread-safe; a ``Session`` is not, and ``boto3.client()`` uses one shared
default session. So each client gets its own ``boto3.session.Session``, and
clients are built under a lock.

Errors come back as :class:`SnsError`, classified once here so callers only
ask ``retryable`` or ``config``: SNS reports throttling as HTTP 400, so the
class comes from the error code, not the status.
"""

import json
import re
import threading
from dataclasses import dataclass
from typing import Any, Dict, Optional

import boto3
from botocore.config import Config
from botocore.exceptions import (
    ClientError,
    ConnectionError,
    CredentialRetrievalError,
    HTTPClientError,
    NoCredentialsError,
    NoRegionError,
    PartialCredentialsError,
)

# arn:<partition>:sns:<region>:<12-digit account>:<topic name>. A topic name is
# 1-256 letters, digits, hyphens and underscores; a FIFO topic ends ".fifo".
_TOPIC_ARN = re.compile(r"^arn:(aws|aws-us-gov|aws-cn):sns:([a-z0-9-]+):(\d{12}):([A-Za-z0-9_-]{1,256}(?:\.fifo)?)$")

# ClientError codes worth retrying. Throttling is HTTP 400 at SNS, and
# KMSThrottling is one the SDK itself never retries.
_RETRYABLE_CODES = frozenset(
    {
        "Throttling",
        "ThrottlingException",
        "KMSThrottling",
        "InternalError",
        "InternalFailure",
        "ServiceUnavailable",
    }
)

# Seconds to wait for a connection: botocore's default is 60, and an alert
# handler holds LogicVein's webhook request (and every later handler) while
# it waits.
CONNECT_TIMEOUT = 5
# Most seconds per read (sns.timeout). An immediate send counts as
# interrupted after outbox.STALE_SENDING_SECONDS (120), so connect plus one
# read must end well inside that.
MAX_TIMEOUT = 60

SMS_TYPE = "Transactional"


class SnsError(Exception):
    """A failed SNS call, classified.

    Attributes:
        code: AWS's error code (e.g. ``"AuthorizationError"``), or the
            botocore exception's class name for a failure that never reached
            AWS.
        message: AWS's error message, or the exception's text.
        retryable: True when the same call may succeed later (throttling, a
            5xx, a network or credential-endpoint blip).
        config: True for a configuration problem only the operator can fix
            (no credentials, half a key pair, a session token without one, a
            malformed topic ARN). Never retryable.
    """

    def __init__(self, code: str, message: str, retryable: bool = False, config: bool = False) -> None:
        """Record the classified failure.

        Args:
            code: AWS's error code or the exception class name.
            message: The human-readable error.
            retryable: Whether retrying may succeed.
            config: Whether it is a configuration error.
        """
        super().__init__(f"{code}: {message}" if message else code)
        self.code = code
        self.message = message
        self.retryable = retryable and not config
        self.config = config

    @classmethod
    def wrap(cls, exc: BaseException) -> "SnsError":
        """Classify any exception as an :class:`SnsError` (see :func:`classify`).

        Args:
            exc: What a call raised.

        Returns:
            The classified error; an ``SnsError`` is returned as is.
        """
        return classify(exc)


@dataclass(frozen=True)
class TopicInfo:
    """What Test connection reports about the topic."""

    name: str
    subscriptions_confirmed: int
    fifo: bool


@dataclass(frozen=True)
class TopicArn:
    """A parsed SNS topic ARN."""

    arn: str
    partition: str
    region: str
    account: str
    name: str


def parse_topic_arn(arn: str) -> TopicArn:
    """Split an SNS topic ARN into its parts.

    Args:
        arn: e.g. ``arn:aws:sns:us-east-1:123456789012:lvi-alerts``.

    Returns:
        The parsed ARN.

    Raises:
        SnsError: A configuration error when the ARN is empty or malformed.
    """
    match = _TOPIC_ARN.match((arn or "").strip())
    if not match:
        raise SnsError(
            "InvalidTopicArn",
            "sns.topic_arn must look like arn:aws:sns:<region>:<12-digit account>:<topic name>",
            config=True,
        )
    partition, region, account, name = match.groups()
    return TopicArn(arn=match.group(0), partition=partition, region=region, account=account, name=name)


def classify(exc: BaseException) -> SnsError:
    """Turn a botocore exception into an :class:`SnsError`.

    Args:
        exc: What a boto3 call raised.

    Returns:
        The classified error (an existing ``SnsError`` is returned as is).
    """
    if isinstance(exc, SnsError):
        return exc
    if isinstance(exc, ClientError):
        error = exc.response.get("Error", {}) or {}
        code = str(error.get("Code") or "ClientError")
        status = int((exc.response.get("ResponseMetadata", {}) or {}).get("HTTPStatusCode") or 0)
        return SnsError(code, str(error.get("Message") or ""), retryable=code in _RETRYABLE_CODES or status >= 500)
    if isinstance(exc, (NoCredentialsError, PartialCredentialsError, NoRegionError)):
        return SnsError(type(exc).__name__, str(exc), config=True)
    # ConnectionError covers endpoint, connect-timeout, SSL and proxy errors;
    # HTTPClientError covers read timeouts and a connection reset mid-request.
    # CredentialRetrievalError is a blip in a role's credential endpoint.
    if isinstance(exc, (ConnectionError, HTTPClientError, CredentialRetrievalError)):
        return SnsError(type(exc).__name__, str(exc), retryable=True)
    # Anything else - a request botocore refused to send (ParamValidationError),
    # or an AWS error not listed above - would fail the same way again.
    return SnsError(type(exc).__name__, str(exc))


class SnsClient:
    """Publishes to one SNS topic with one set of credentials."""

    def __init__(
        self,
        topic_arn: str,
        access_key_id: str = "",
        secret_access_key: str = "",
        timeout: int = 10,
        endpoint_url: Optional[str] = None,
        session_token: str = "",
    ) -> None:
        """Validate the settings; boto3 clients are built on first use.

        Args:
            topic_arn: The topic to publish to; its region is the client's.
            access_key_id: An IAM access key id, or "" for boto3's default
                credential chain.
            secret_access_key: Its secret, or "".
            timeout: Seconds per socket read on a publish (not a total
                deadline), 1 to :data:`MAX_TIMEOUT`.
            endpoint_url: Overrides the SNS endpoint (tests only).
            session_token: The session token that goes with temporary
                credentials (an ``ASIA...`` key id), or "".

        Raises:
            SnsError: A configuration error for a malformed ARN, half a key
                pair, or a session token without a key pair.
        """
        self.topic = parse_topic_arn(topic_arn)
        access_key_id = (access_key_id or "").strip()
        secret_access_key = (secret_access_key or "").strip()
        session_token = (session_token or "").strip()
        if bool(access_key_id) != bool(secret_access_key):
            raise SnsError(
                "PartialCredentials",
                "Enter both the access key id and the secret access key, or neither to use the default credential chain",
                config=True,
            )
        if session_token and not access_key_id:
            raise SnsError(
                "PartialCredentials",
                "A session token needs the access key id and secret access key it was issued with",
                config=True,
            )
        self._access_key_id = access_key_id
        self._secret_access_key = secret_access_key
        self._session_token = session_token
        self.timeout = min(MAX_TIMEOUT, max(1, int(timeout or 10)))
        self._endpoint_url = endpoint_url
        self._lock = threading.Lock()
        self._publish_client: Any = None
        self._query_client: Any = None

    @property
    def uses_default_chain(self) -> bool:
        """Whether credentials come from boto3's default chain (no key pair entered)."""
        return not self._access_key_id

    @property
    def uses_session_token(self) -> bool:
        """Whether entered temporary credentials (with a session token) are used."""
        return bool(self._session_token)

    def _build(self, config: Config) -> Any:
        """Build an SNS client on its own session.

        Args:
            config: The botocore client config.

        Returns:
            A boto3 SNS client for the topic's region.
        """
        session = boto3.session.Session(
            aws_access_key_id=self._access_key_id or None,
            aws_secret_access_key=self._secret_access_key or None,
            aws_session_token=self._session_token or None,
            region_name=self.topic.region,
        )
        return session.client("sns", config=config, endpoint_url=self._endpoint_url)

    def _publisher(self) -> Any:
        with self._lock:
            if self._publish_client is None:
                self._publish_client = self._build(
                    Config(
                        retries={"mode": "standard", "total_max_attempts": 1},
                        connect_timeout=CONNECT_TIMEOUT,
                        read_timeout=self.timeout,
                    )
                )
            return self._publish_client

    def _querier(self) -> Any:
        with self._lock:
            if self._query_client is None:
                self._query_client = self._build(
                    Config(retries={"mode": "standard"}, connect_timeout=CONNECT_TIMEOUT, read_timeout=self.timeout)
                )
            return self._query_client

    def publish(self, default: str, sms: str, email: str = "", subject: str = "") -> str:
        """Publish one message, with a per-protocol rendering, in one call.

        Args:
            default: The text for every protocol without its own entry.
            sms: The short SMS text.
            email: The email text ("" uses ``default``).
            subject: The email subject; "" for none.

        Returns:
            SNS's ``MessageId``.

        Raises:
            SnsError: The classified failure.
        """
        params: Dict[str, Any] = {
            "TopicArn": self.topic.arn,
            "Message": json.dumps({"default": default, "email": email or default, "sms": sms}),
            "MessageStructure": "json",
            "MessageAttributes": {"AWS.SNS.SMS.SMSType": {"DataType": "String", "StringValue": SMS_TYPE}},
        }
        if subject:
            params["Subject"] = subject
        try:
            response = self._publisher().publish(**params)
        except Exception as exc:
            raise SnsError.wrap(exc) from exc
        return str(response.get("MessageId", ""))

    def topic_info(self) -> TopicInfo:
        """Describe the topic (sends nothing).

        Returns:
            The topic's name, confirmed subscription count and whether it is
            FIFO.

        Raises:
            SnsError: The classified failure.
        """
        try:
            attributes = self._querier().get_topic_attributes(TopicArn=self.topic.arn).get("Attributes", {}) or {}
        except Exception as exc:
            raise SnsError.wrap(exc) from exc
        try:
            confirmed = int(attributes.get("SubscriptionsConfirmed", "0") or 0)
        except ValueError:
            confirmed = 0
        fifo = str(attributes.get("FifoTopic", "false")).lower() == "true" or self.topic.name.endswith(".fifo")
        return TopicInfo(name=self.topic.name, subscriptions_confirmed=confirmed, fifo=fifo)
