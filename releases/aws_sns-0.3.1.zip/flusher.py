"""The held-event flusher: sends what flood control held back, when due.

A background service (``start()``/``stop()``), returned from
``build_services()`` so the core starts it, restarts it on a settings save
and stops it on shutdown. Every :data:`TICK_SECONDS` it:

- claims every held row that is due;
- groups them into messages: one per device for rows held by its coalescing
  window, and one summary for rows held by the per-minute cap (a group of
  one is sent as the plain alert or change); a config change held for a
  retry (reason ``retry``) is always sent on its own;
- sends as many as the per-minute cap allows now and puts the rest back,
  due when the minute frees up;
- records each message as an outbox row of its own (so it counts towards
  the cap and opens the device's next coalescing window), and settles the
  rows it carried: ``sent`` with the MessageId; on a retryable failure
  ``held`` again with backoff and the error shown on the tab; on a permanent
  one ``failed``.

Held rows live in SQLite, so after a restart it sends whatever fell due
while the app was down. Each tick first recovers interrupted sends
(:meth:`.Outbox.recover`): only ones older than two minutes count, so it
runs every tick rather than once at start - a quick restart leaves claims
that become stale only later.
"""

import json
import logging
import threading
import time
from types import SimpleNamespace
from typing import Any, Callable, Dict, List, Optional

# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import get_product_name  # pyright: ignore[reportMissingImports]

from . import render
from .client import SnsError
from .handlers import EVENT_FIELDS, get_outbox, log_feed
from .outbox import Outbox
from .settings import get_client, get_settings

logger = logging.getLogger(__name__)

TICK_SECONDS = 15
BACKOFF_MAX_SECONDS = 900
PRUNE_EVERY_SECONDS = 3600


def backoff(attempts: int) -> float:
    """Seconds before retrying a message that failed *attempts* times.

    Args:
        attempts: Failures so far (at least 1).

    Returns:
        15, 30, 60, ... seconds, at most 15 minutes.
    """
    return float(min(BACKOFF_MAX_SECONDS, TICK_SECONDS * 2 ** max(0, attempts - 1)))


class Flusher:
    """Sends held rows when due; one instance per service lifetime."""

    def __init__(
        self,
        outbox: Optional[Callable[[], Outbox]] = None,
        client: Optional[Callable[[], Any]] = None,
        settings: Optional[Callable[[], Dict[str, Any]]] = None,
        clock: Callable[[], float] = time.time,
    ) -> None:
        """Wire the flusher's collaborators (defaults are the live ones).

        Args:
            outbox: Returns the store.
            client: Returns the SNS client.
            settings: Returns the plugin config.
            clock: Returns the current epoch time.
        """
        self._outbox = outbox or get_outbox
        self._client = client or get_client
        self._settings = settings or get_settings
        self._clock = clock
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._last_prune = 0.0
        self.last_error = ""

    def start(self) -> None:
        """Recover interrupted sends and start the tick thread."""
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="aws-sns-flusher", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        """Stop the tick thread (waits for an in-flight tick)."""
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=TICK_SECONDS + 30)
            self._thread = None

    def is_running(self) -> bool:
        """Whether the tick thread is alive.

        Returns:
            True while running.
        """
        return self._thread is not None and self._thread.is_alive()

    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                self.tick()
            except Exception:  # a bad tick must not kill the service
                logger.exception("AWS SNS flusher tick failed")
            self._stop.wait(TICK_SECONDS)

    def _config(self) -> Dict[str, Any]:
        cfg = self._settings() or {}
        return {
            "sms_max": int((cfg.get("sms", {}) or {}).get("max_length") or 160),
            "include_link": bool((cfg.get("sms", {}) or {}).get("include_link", False)),
            "cap": max(0, int((cfg.get("flood", {}) or {}).get("max_per_minute") or 0)),
            "coalesce": max(0, int((cfg.get("flood", {}) or {}).get("coalesce_minutes") or 0)),
            "templates": cfg.get("templates", {}) or {},
        }

    def tick(self) -> int:
        """Send every held message that is due and the cap allows.

        Returns:
            How many messages were published.
        """
        now = self._clock()
        outbox = self._outbox()
        if now - self._last_prune >= PRUNE_EVERY_SECONDS:
            outbox.prune(now)
            self._last_prune = now
        # Every tick, not only at start: a restart within STALE_SENDING_SECONDS
        # of a claim leaves rows `sending` that only become stale later.
        recovered = outbox.recover(now)
        if recovered:
            logger.warning("AWS SNS: %d interrupted send(s) will be retried", recovered)
        cfg = self._config()
        with outbox.transaction() as conn:
            claimed = Outbox.claim_due(conn, now)
            if not claimed:
                return 0
            groups = self._group(claimed)
            budget = len(groups)
            if cfg["cap"]:
                budget = max(0, cfg["cap"] - Outbox.sends_in_last_minute(conn, now))
            later = groups[budget:]
            if later:
                frees = Outbox.cap_frees_at(conn, now)
                Outbox.release(conn, [r["id"] for group in later for r in group["rows"]], max(frees, now + 1))
            groups = groups[:budget]
            for group in groups:
                group["row_id"] = Outbox.record(
                    conn, group["kind"], "sending", now, group["key"], group["node"], group["severity"], ""
                )
        sent = 0
        for group in groups:
            sent += self._send(group, cfg)
        return sent

    @staticmethod
    def _group(rows: List[Any]) -> List[Dict[str, Any]]:
        """Group claimed rows into messages, in due order.

        Args:
            rows: The claimed rows.

        Returns:
            One dict per message: ``kind``, ``node``, ``key``, ``severity``
            and its ``rows``.
        """
        groups: Dict[tuple, Dict[str, Any]] = {}
        for row in rows:
            if row["hold_reason"] == "coalesce":
                ident: tuple = ("coalesce", row["node"])
            elif row["hold_reason"] == "retry":
                ident = ("retry", row["id"])
            else:
                ident = ("cap", "")
            node = row["node"] if ident[0] == "coalesce" else ""
            groups.setdefault(ident, {"reason": ident[0], "node": node, "rows": []})["rows"].append(row)
        out = []
        for group in groups.values():
            members = group["rows"]
            alerts = [m for m in members if m["kind"] != "change"]
            if len(members) == 1:
                group.update(kind=members[0]["kind"], key=members[0]["key"], node=members[0]["node"])
            elif group["reason"] == "coalesce":
                # Only a message with an alert in it opens the device's
                # window for alerts (see Outbox.window_end).
                group.update(kind="coalesced" if alerts else "changes", key="")
            else:
                group.update(kind="capped", key="")
            # A change has no severity: leave it out of the highest.
            group["severity"] = max((m["severity"] for m in alerts), key=render.severity_rank, default="")
            out.append(group)
        return out

    def _render(self, group: Dict[str, Any], cfg: Dict[str, Any]) -> render.Rendered:
        product = get_product_name()
        members = group["rows"]
        if len(members) == 1 and members[0]["kind"] == "change":
            payload = json.loads(members[0]["payload"] or "{}")
            change = SimpleNamespace(**{k: payload.get(k, "") for k in render.CHANGE_FIELDS})
            change.hostname = change.hostname or members[0]["node"]
            return render.render_change(change, product, cfg["sms_max"], cfg["templates"])
        if len(members) == 1:
            payload = json.loads(members[0]["payload"] or "{}")
            event = SimpleNamespace(**{k: payload.get(k, "") for k in EVENT_FIELDS})
            event.node = event.node or members[0]["node"]
            event.severity = event.severity or members[0]["severity"]
            return render.render_alert(
                event, members[0]["kind"] == "resolve", product, cfg["sms_max"], cfg["include_link"], cfg["templates"]
            )
        items = [
            dict(json.loads(m["payload"] or "{}"), node=m["node"], severity=m["severity"], kind=m["kind"])
            for m in members
        ]
        if group["kind"] in ("coalesced", "changes"):
            return render.render_coalesced(
                group["node"], items, cfg["coalesce"], product, cfg["sms_max"], cfg["templates"]
            )
        return render.render_capped(items, product, cfg["sms_max"], cfg["templates"])

    def _send(self, group: Dict[str, Any], cfg: Dict[str, Any]) -> int:
        """Publish one message and settle its rows.

        Args:
            group: The message, from :meth:`_group`, with its ``row_id``.
            cfg: The flusher config.

        Returns:
            1 when published, else 0.
        """
        outbox = self._outbox()
        member_ids = [r["id"] for r in group["rows"]]
        raise_hashes = [r["key"] for r in group["rows"] if r["kind"] == "raise" and r["key"]]
        rendered = self._render(group, cfg)
        try:
            message_id = self._client().publish(rendered.full, rendered.sms, subject=rendered.subject)
        except Exception as exc:
            error = SnsError.wrap(exc)
            now = self._clock()
            with outbox.transaction() as conn:
                conn.execute("UPDATE outbox SET message = ? WHERE id = ?", (rendered.sms, group["row_id"]))
                Outbox.finish(conn, [group["row_id"]], "failed", now, error=str(error))
                if error.retryable:
                    attempts = 1 + max(r["attempts"] for r in group["rows"])
                    Outbox.release(conn, member_ids, now + backoff(attempts), str(error))
                else:
                    Outbox.finish(conn, member_ids, "failed", now, error=str(error))
                    for alert_hash in raise_hashes:
                        Outbox.set_raise_outcome(conn, alert_hash, "failed")
            self.last_error = str(error)
            log_feed(
                group["kind"],
                group["node"],
                group["key"],
                group["severity"],
                "error",
                error=str(error),
                description=rendered.sms,
            )
            logger.warning(
                "AWS SNS held %s for %s not sent (%s): %s",
                group["kind"],
                group["node"] or "all devices",
                "will retry" if error.retryable else "not retried",
                error,
            )
            return 0
        now = self._clock()
        with outbox.transaction() as conn:
            conn.execute("UPDATE outbox SET message = ? WHERE id = ?", (rendered.sms, group["row_id"]))
            Outbox.finish(conn, [group["row_id"]], "sent", now, message_id=message_id)
            Outbox.finish(conn, member_ids, "sent", now, message_id=message_id)
            for alert_hash in raise_hashes:
                Outbox.set_raise_outcome(conn, alert_hash, "sent", message_id)
        self.last_error = ""
        log_feed(
            group["kind"], group["node"], group["key"], group["severity"], "sent", message_id, description=rendered.sms
        )
        return 1
