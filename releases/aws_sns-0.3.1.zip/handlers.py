"""The alert and config-change handlers: LogicVein events in, SNS out.

Registered with the core alert dispatch, so the core ``/webhook/lvi-alert``
route calls it with each :class:`AlertEvent`. It texts on an alert's
transitions, not on each delivery: LogicVein sends ``raise`` for the first
violation, for each further one and again on a retry, all with the same
``hash``, so the plugin keeps each alert ``open`` or ``closed`` (see
:mod:`.outbox`).

**Raise**

- Already open (a retry, or a further violation): recorded as ``repeat``,
  nothing sent. Two exceptions count as closed, so the delivery sends: an
  open alert whose send was interrupted long ago, and one whose raise failed
  permanently (the configuration may have been fixed since).
- A resolve of the same alert still held by the cap is superseded, so it
  cannot go out after this newer raise.
- Closed or unknown: the alert opens.
  - Below ``alerts.min_severity``: ``skipped``. It stays open, so a later
    repeat at a higher severity does not text either; the next raise after a
    resolve is judged afresh.
  - Over ``flood.max_per_minute``: held (reason ``cap``); the flusher sends
    one summary when the minute frees up.
  - Inside the device's coalescing window (a notification went to that
    device within ``flood.coalesce_minutes``): held (reason ``coalesce``)
    until the window closes, then sent as one message for the device.
  - Otherwise sent at once.

**Resolve** always closes the alert, so the next raise texts again.

- Its raise is still held: the held row is dropped and both are recorded
  ``resolved before sent``; nothing is sent.
- Its raise was sent and ``alerts.notify_on_resolve`` is on: sent at once
  (not coalesced; it counts towards the per-minute cap).
- Otherwise ``skipped``.

**Failures of an immediate send**

- Retryable (throttling, 5xx, network): the error is raised, so the route
  answers with an error and LogicVein retries. A failed raise first closes
  the alert again and a failed resolve reopens it, so the retry sends.
- Permanent (a configuration problem: wrong topic, missing permission, no
  credentials): recorded ``failed`` and returned as an error result *without
  raising* - a retry would fail the same way and re-run every other plugin's
  handler each time. It shows on the event feed, the AWS SNS tab and the log.
  The alert's next delivery tries again, so once the configuration is fixed
  it sends.

A held raise returns success: delivering it is the flusher's job from then
on (:mod:`.flusher`).

**Config changes** (:class:`ChangeHandler`, registered with the core
change dispatch while ``changes.enabled`` is on) are simpler: a change has
no open/closed lifecycle, and the core already sends each one once.

- Filtered out by ``changes.networks``, ``changes.hostname_pattern`` or
  ``changes.ignore_authors``: nothing is sent or recorded.
- Already handled (the same ``event_key``, say after a websocket replay):
  ignored.
- Otherwise the same flood control as a raise: held by the cap, or folded
  into the device's coalesced message while its window is open, else sent
  at once. A change opens a window for later changes; an alert's window is
  opened only by alerts, so a change never delays an alert.
- The core never retries a change, so a retryable failure is held (reason
  ``retry``) for the flusher to send with backoff; a permanent one is
  recorded ``failed``.
"""

import logging
import re
import time
from datetime import datetime
from typing import Any, Callable, Dict, Optional

# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import get_product_name  # pyright: ignore[reportMissingImports]
from src.plugin_api import (  # pyright: ignore[reportMissingImports]
    AlertEvent,
    ConfigChangeEvent,
    get_plugin_data_dir,
    normalize_networks,
)
from src.plugin_api import webhook_store as store  # pyright: ignore[reportMissingImports]

from . import render
from .client import SnsError
from .outbox import STALE_SENDING_SECONDS, Outbox
from .settings import PLUGIN_ID, get_client, get_settings

logger = logging.getLogger(__name__)

# The event-feed direction, "sync mgr->aws sns" with an arrow, like every
# plugin's outbound rows.
FEED_DIRECTION = "sync mgr\u2192aws sns"

# A config change whose immediate send failed retryably is held this long
# before the flusher's first retry (then the flusher's backoff applies).
RETRY_DELAY_SECONDS = 15

_outbox: Optional[Outbox] = None


def get_outbox() -> Outbox:
    """The plugin's store, opened on first use.

    Returns:
        The shared :class:`Outbox`.
    """
    global _outbox
    if _outbox is None:
        _outbox = Outbox(get_plugin_data_dir(PLUGIN_ID) / "aws_sns.db")
    return _outbox


# The AlertEvent fields stored with a held row, to render it later.
EVENT_FIELDS = (
    "action",
    "hash",
    "severity",
    "message",
    "node",
    "link",
    "occurrences",
    "violation_status",
    "updated_at",
)


def event_payload(event: Any) -> Dict[str, Any]:
    """The event's fields, stored with a held row to render it later.

    Args:
        event: The ``AlertEvent``.

    Returns:
        A JSON-serialisable dict.
    """
    return {name: str(getattr(event, name, "") or "") for name in EVENT_FIELDS}


def change_payload(change: Any) -> Dict[str, Any]:
    """The change's fields, stored with a held row to render it later.

    Args:
        change: The ``ConfigChangeEvent``.

    Returns:
        A JSON-serialisable dict (``paths`` stays a list).
    """
    payload: Dict[str, Any] = {name: str(getattr(change, name, "") or "") for name in render.CHANGE_FIELDS}
    payload["paths"] = [str(p) for p in (getattr(change, "paths", None) or [])]
    return payload


def log_feed(
    action: str,
    node: str,
    alert_hash: str,
    severity: str,
    result: str,
    message_id: str = "",
    error: str = "",
    description: str = "",
    ts_out: Optional[datetime] = None,
) -> None:
    """Record an outbound row on the app's Webhooks event feed.

    Args:
        action: ``raise``, ``resolve``, ``change``, ``coalesced``,
            ``changes``, ``capped`` or ``test``.
        node: The device.
        alert_hash: The alert hash or change ``event_key`` ("" for a
            summary).
        severity: The alert severity.
        result: The outcome.
        message_id: SNS's MessageId.
        error: The failure, if any.
        description: The SMS text, shown in the Description column.
        ts_out: The timestamp the core asked handlers to use.
    """
    try:
        store.log_event(
            plugin=PLUGIN_ID,
            # The Webhooks tab's "Show outbound only" filter (on by default)
            # keeps only rows whose direction starts with "sync mgr" + arrow.
            direction=FEED_DIRECTION,
            action=action,
            node=node,
            correlation_hash=alert_hash,
            severity=severity,
            result=result,
            dst="Amazon SNS",
            incident=message_id,
            error=error,
            timestamp=ts_out,
            description=description,
            event_type="config_change" if action in ("change", "changes") else "",
        )
    except Exception:  # the feed is a record, never a reason to fail delivery
        logger.exception("Could not record an AWS SNS event on the event feed")


def hold_or_send(conn: Any, cfg: Dict[str, Any], node: str, now: float, coalesce: bool, alerts_only: bool) -> tuple:
    """Decide, inside the transaction, whether flood control holds a send.

    Args:
        conn: The open transaction.
        cfg: The handler config (``cap``, ``coalesce``).
        node: The device.
        now: The current time.
        coalesce: Whether the device's coalescing window applies (raises
            and changes; not resolves).
        alerts_only: Only alerts open the window (see
            :meth:`.Outbox.window_end`).

    Returns:
        ``("cap", due_at)``, ``("coalesce", due_at)`` or ``("", None)``
        for an immediate send.
    """
    if cfg["cap"] and Outbox.sends_in_last_minute(conn, now) >= cfg["cap"]:
        return "cap", Outbox.cap_frees_at(conn, now)
    if coalesce:
        end = Outbox.window_end(conn, node, cfg["coalesce"], now, alerts_only=alerts_only)
        if end is not None:
            return "coalesce", end
    return "", None


class AlertHandler:
    """Turns ``AlertEvent`` deliveries into SNS notifications."""

    def __init__(
        self,
        outbox: Optional[Callable[[], Outbox]] = None,
        client: Optional[Callable[[], Any]] = None,
        settings: Optional[Callable[[], Dict[str, Any]]] = None,
        clock: Callable[[], float] = time.time,
    ) -> None:
        """Wire the handler's collaborators (defaults are the live ones).

        Args:
            outbox: Returns the store.
            client: Returns the SNS client.
            settings: Returns the plugin config.
            clock: Returns the current epoch time.
        """
        self._outbox = outbox or get_outbox
        self._client = client or get_client
        self._settings = settings or get_settings
        self._clock = clock

    def __repr__(self) -> str:
        return "<aws_sns.AlertHandler>"

    def __call__(self, event: AlertEvent, ts_out: Optional[datetime] = None) -> Dict[str, Any]:
        """Handle one delivery.

        A retryable send failure propagates as ``SnsError`` (from
        :meth:`_send_now`), so the route answers with an error and LogicVein
        retries.

        Args:
            event: The alert.
            ts_out: Timestamp for the event-feed row.

        Returns:
            ``{"result": ..., "incident": <MessageId>, "description": ...}``.
        """
        if (event.action or "").lower() == "resolve":
            return self._resolve(event, ts_out)
        return self._raise(event, ts_out)

    def _config(self) -> Dict[str, Any]:
        cfg = self._settings() or {}
        return {
            "min_severity": str((cfg.get("alerts", {}) or {}).get("min_severity") or "high"),
            "notify_on_resolve": bool((cfg.get("alerts", {}) or {}).get("notify_on_resolve", False)),
            "sms_max": int((cfg.get("sms", {}) or {}).get("max_length") or 160),
            "include_link": bool((cfg.get("sms", {}) or {}).get("include_link", False)),
            "cap": max(0, int((cfg.get("flood", {}) or {}).get("max_per_minute") or 0)),
            "coalesce": max(0, int((cfg.get("flood", {}) or {}).get("coalesce_minutes") or 0)),
            "templates": cfg.get("templates", {}) or {},
        }

    def _hold_or_send(self, conn: Any, cfg: Dict[str, Any], node: str, now: float, coalesce: bool) -> tuple:
        """Flood control for an alert (see :func:`hold_or_send`).

        Args:
            conn: The open transaction.
            cfg: The handler config.
            node: The device.
            now: The current time.
            coalesce: Whether the device's coalescing window applies
                (raises only).

        Returns:
            ``(hold reason, due_at)``, or ``("", None)`` to send now.
        """
        return hold_or_send(conn, cfg, node, now, coalesce, alerts_only=True)

    def _raise(self, event: AlertEvent, ts_out: Optional[datetime]) -> Dict[str, Any]:
        cfg = self._config()
        now = self._clock()
        node = event.node or ""
        rendered = render.render_alert(
            event, False, get_product_name(), cfg["sms_max"], cfg["include_link"], cfg["templates"]
        )
        outbox = self._outbox()
        with outbox.transaction() as conn:
            row = Outbox.alert(conn, event.hash)
            interrupted = (
                row is not None
                and row["raise_outcome"] == "sending"
                and (row["opened_at"] or 0) < now - STALE_SENDING_SECONDS
            )
            # A raise that failed permanently is tried again on the next
            # delivery: the operator may have fixed the configuration since.
            failed = row is not None and row["raise_outcome"] == "failed"
            if row is not None and row["state"] == "open" and not interrupted and not failed:
                Outbox.record(conn, "raise", "repeat", now, event.hash, node, event.severity, rendered.sms)
                decision = "repeat"
            elif render.severity_rank(event.severity) < render.severity_rank(cfg["min_severity"]):
                Outbox.supersede_held(conn, event.hash, "resolve", now)
                Outbox.open_alert(conn, event.hash, node, event.severity, "skipped", now)
                Outbox.record(conn, "raise", "skipped", now, event.hash, node, event.severity, rendered.sms)
                decision = "skipped"
            else:
                # A resolve still held by the cap must not go out after this
                # newer raise of the same alert.
                Outbox.supersede_held(conn, event.hash, "resolve", now)
                reason, due = self._hold_or_send(conn, cfg, node, now, coalesce=True)
                if reason:
                    Outbox.open_alert(conn, event.hash, node, event.severity, "held", now)
                    Outbox.record(
                        conn,
                        "raise",
                        "held",
                        now,
                        event.hash,
                        node,
                        event.severity,
                        rendered.sms,
                        hold_reason=reason,
                        due_at=due,
                        payload=event_payload(event),
                    )
                    decision = "held"
                else:
                    Outbox.open_alert(conn, event.hash, node, event.severity, "sending", now)
                    row_id = Outbox.record(
                        conn, "raise", "sending", now, event.hash, node, event.severity, rendered.sms
                    )
                    decision = "send"
        if decision != "send":
            if decision == "held":
                log_feed("raise", node, event.hash, event.severity, "held", description=rendered.sms, ts_out=ts_out)
            return {"result": decision, "description": rendered.sms}
        return self._send_now(event, "raise", rendered, row_id, ts_out)

    def _resolve(self, event: AlertEvent, ts_out: Optional[datetime]) -> Dict[str, Any]:
        cfg = self._config()
        now = self._clock()
        node = event.node or ""
        rendered = render.render_alert(
            event, True, get_product_name(), cfg["sms_max"], cfg["include_link"], cfg["templates"]
        )
        outbox = self._outbox()
        with outbox.transaction() as conn:
            row = Outbox.alert(conn, event.hash)
            node = node or (row["node"] if row is not None else "")
            held = Outbox.held_raise(conn, event.hash)
            Outbox.close_alert(conn, event.hash, now)
            # A raise the flusher has claimed is on its way: count it as sent.
            raise_went_out = (
                row is not None and row["state"] == "open" and row["raise_outcome"] in ("sent", "sending", "held")
            )
            if held:
                Outbox.drop_held(conn, [r["id"] for r in held], now)
                Outbox.record(
                    conn, "resolve", "resolved before sent", now, event.hash, node, event.severity, rendered.sms
                )
                decision = "resolved before sent"
            elif raise_went_out and cfg["notify_on_resolve"]:
                reason, due = self._hold_or_send(conn, cfg, node, now, coalesce=False)
                if reason:
                    Outbox.record(
                        conn,
                        "resolve",
                        "held",
                        now,
                        event.hash,
                        node,
                        event.severity,
                        rendered.sms,
                        hold_reason=reason,
                        due_at=due,
                        payload=event_payload(event),
                    )
                    decision = "held"
                else:
                    row_id = Outbox.record(
                        conn, "resolve", "sending", now, event.hash, node, event.severity, rendered.sms
                    )
                    decision = "send"
            else:
                Outbox.record(conn, "resolve", "skipped", now, event.hash, node, event.severity, rendered.sms)
                decision = "skipped"
        if decision != "send":
            if decision in ("held", "resolved before sent"):
                log_feed("resolve", node, event.hash, event.severity, decision, description=rendered.sms, ts_out=ts_out)
            return {"result": decision, "description": rendered.sms}
        return self._send_now(event, "resolve", rendered, row_id, ts_out)

    def _send_now(
        self, event: AlertEvent, kind: str, rendered: render.Rendered, row_id: int, ts_out: Optional[datetime]
    ) -> Dict[str, Any]:
        """Publish, then settle the row and the alert state.

        Args:
            event: The alert.
            kind: ``raise`` or ``resolve``.
            rendered: The texts.
            row_id: The outbox row marked ``sending``.
            ts_out: Timestamp for the event-feed row.

        Returns:
            The result dict.

        Raises:
            SnsError: A retryable failure (after the alert is closed again).
        """
        outbox = self._outbox()
        try:
            message_id = self._client().publish(rendered.full, rendered.sms, subject=rendered.subject)
        except Exception as exc:
            error = SnsError.wrap(exc)
            now = self._clock()
            with outbox.transaction() as conn:
                Outbox.finish(conn, [row_id], "failed", now, error=str(error))
                if kind == "raise" and error.retryable:
                    Outbox.close_alert(conn, event.hash, now)  # so the retry sends
                elif kind == "raise":
                    Outbox.set_raise_outcome(conn, event.hash, "failed")
                elif error.retryable:
                    Outbox.reopen_alert(conn, event.hash)  # so the retried resolve still sends
            log_feed(
                kind,
                event.node,
                event.hash,
                event.severity,
                "error",
                error=str(error),
                description=rendered.sms,
                ts_out=ts_out,
            )
            if error.retryable:
                logger.warning("AWS SNS %s for %s failed, LogicVein will retry: %s", kind, event.node, error)
                raise SnsError.wrap(error)
            logger.error(
                "AWS SNS %s for %s failed (not retried - check the AWS SNS settings): %s", kind, event.node, error
            )
            return {"result": "failed", "error": str(error), "description": rendered.sms}
        now = self._clock()
        with outbox.transaction() as conn:
            Outbox.finish(conn, [row_id], "sent", now, message_id=message_id)
            if kind == "raise":
                Outbox.set_raise_outcome(conn, event.hash, "sent", message_id)
        log_feed(
            kind, event.node, event.hash, event.severity, "sent", message_id, description=rendered.sms, ts_out=ts_out
        )
        return {"result": "sent", "incident": message_id, "description": rendered.sms}


class ChangeHandler:
    """Turns ``ConfigChangeEvent`` s into SNS notifications."""

    def __init__(
        self,
        outbox: Optional[Callable[[], Outbox]] = None,
        client: Optional[Callable[[], Any]] = None,
        settings: Optional[Callable[[], Dict[str, Any]]] = None,
        clock: Callable[[], float] = time.time,
    ) -> None:
        """Wire the handler's collaborators (defaults are the live ones).

        Args:
            outbox: Returns the store.
            client: Returns the SNS client.
            settings: Returns the plugin config.
            clock: Returns the current epoch time.
        """
        self._outbox = outbox or get_outbox
        self._client = client or get_client
        self._settings = settings or get_settings
        self._clock = clock
        self._bad_pattern = ""

    def __repr__(self) -> str:
        return "<aws_sns.ChangeHandler>"

    def _config(self) -> Dict[str, Any]:
        cfg = self._settings() or {}
        changes = cfg.get("changes", {}) or {}
        authors = changes.get("ignore_authors") or []
        if isinstance(authors, str):
            authors = authors.split(",")
        return {
            "networks": {n.casefold() for n in normalize_networks(changes.get("networks"))},
            "hostname_pattern": str(changes.get("hostname_pattern") or "").strip(),
            "ignore_authors": {str(a).strip().casefold() for a in authors if str(a).strip()},
            "sms_max": int((cfg.get("sms", {}) or {}).get("max_length") or 160),
            "cap": max(0, int((cfg.get("flood", {}) or {}).get("max_per_minute") or 0)),
            "coalesce": max(0, int((cfg.get("flood", {}) or {}).get("coalesce_minutes") or 0)),
            "templates": cfg.get("templates", {}) or {},
        }

    def _filtered_out(self, event: ConfigChangeEvent, cfg: Dict[str, Any]) -> str:
        """Why the change filters exclude *event*, or "" when they do not.

        Args:
            event: The change.
            cfg: The handler config.

        Returns:
            ``network``, ``hostname`` or ``author``, or "".
        """
        if cfg["networks"] and (event.managed_network or "").casefold() not in cfg["networks"]:
            return "network"
        pattern = cfg["hostname_pattern"]
        if pattern:
            try:
                if not re.search(pattern, event.hostname or "", re.IGNORECASE):
                    return "hostname"
            except re.error as exc:
                # A typo must not silence every change: notify, and say why once.
                if pattern != self._bad_pattern:
                    logger.error(
                        "AWS SNS: changes.hostname_pattern %r is not a valid regex (%s); ignoring it", pattern, exc
                    )
                    self._bad_pattern = pattern
        if (event.author or "").strip().casefold() in cfg["ignore_authors"]:
            return "author"
        return ""

    def __call__(self, event: ConfigChangeEvent, lvi_client: Any = None) -> bool:
        """Handle one change. Never raises: the core would only log it.

        Args:
            event: The change.
            lvi_client: The core's LogicVein client (unused: the event
                carries everything the notification needs).

        Returns:
            True when a notification was sent or will be (held), so the
            Config Change tab counts it.
        """
        try:
            return self._handle(event)
        except Exception:
            logger.exception("AWS SNS: config change %s not handled", event.event_key)
            return False

    def _handle(self, event: ConfigChangeEvent) -> bool:
        cfg = self._config()
        reason = self._filtered_out(event, cfg)
        if reason:
            logger.debug("AWS SNS: change %s filtered out by changes.%s", event.event_key, reason)
            return False
        now = self._clock()
        node = event.hostname or event.ip_address or ""
        rendered = render.render_change(event, get_product_name(), cfg["sms_max"], cfg["templates"])
        outbox = self._outbox()
        with outbox.transaction() as conn:
            if Outbox.has_change(conn, event.event_key):
                logger.debug("AWS SNS: change %s already handled", event.event_key)
                return False
            hold, due = hold_or_send(conn, cfg, node, now, coalesce=True, alerts_only=False)
            row_id = Outbox.record(
                conn,
                "change",
                "held" if hold else "sending",
                now,
                event.event_key,
                node,
                "",
                rendered.sms,
                hold_reason=hold,
                due_at=due,
                payload=change_payload(event),
            )
        if hold:
            log_feed("change", node, event.event_key, "", "held", description=rendered.sms)
            return True
        try:
            message_id = self._client().publish(rendered.full, rendered.sms, subject=rendered.subject)
        except Exception as exc:
            error = SnsError.wrap(exc)
            now = self._clock()
            with outbox.transaction() as conn:
                if error.retryable:
                    Outbox.hold_for_retry(conn, row_id, now + RETRY_DELAY_SECONDS, str(error))
                else:
                    Outbox.finish(conn, [row_id], "failed", now, error=str(error))
            log_feed("change", node, event.event_key, "", "error", error=str(error), description=rendered.sms)
            if error.retryable:
                logger.warning("AWS SNS change for %s failed, will retry: %s", node, error)
                return True
            logger.error("AWS SNS change for %s failed (not retried - check the AWS SNS settings): %s", node, error)
            return False
        with outbox.transaction() as conn:
            Outbox.finish(conn, [row_id], "sent", self._clock(), message_id=message_id)
        log_feed("change", node, event.event_key, "", "sent", message_id, description=rendered.sms)
        return True


def send_test(
    outbox: Optional[Outbox] = None,
    client: Any = None,
    settings: Optional[Dict[str, Any]] = None,
    clock: Callable[[], float] = time.time,
) -> Dict[str, Any]:
    """Publish the fixed test notification (the tab's "Send test notification").

    It goes through the same rendering and client as an alert, so it texts
    every subscriber. Not subject to flood control, and not counted by it.

    Args:
        outbox: The store (the live one when omitted).
        client: The SNS client (the live one when omitted).
        settings: The plugin config (read when omitted).
        clock: Returns the current epoch time.

    Returns:
        ``{"ok": True, "message_id": ...}`` or ``{"ok": False, "error": ...}``.
    """
    outbox = outbox or get_outbox()
    cfg = settings if settings is not None else get_settings()
    sms_max = int((cfg.get("sms", {}) or {}).get("max_length") or 160)
    rendered = render.render_test(get_product_name(), sms_max, cfg.get("templates", {}) or {})
    try:
        message_id = (client or get_client()).publish(rendered.full, rendered.sms, subject=rendered.subject)
    except Exception as exc:
        error = str(SnsError.wrap(exc))
        with outbox.transaction() as conn:
            Outbox.record(conn, "test", "failed", clock(), message=rendered.sms, error=error)
        log_feed("test", "", "", "", "error", error=error, description=rendered.sms)
        return {"ok": False, "error": error}
    with outbox.transaction() as conn:
        Outbox.record(conn, "test", "sent", clock(), message=rendered.sms, message_id=message_id)
    log_feed("test", "", "", "", "sent", message_id, description=rendered.sms)
    return {"ok": True, "message_id": message_id}


_handler: Optional[AlertHandler] = None
_change_handler: Optional[ChangeHandler] = None


def get_alert_handler() -> AlertHandler:
    """The module-level handler, so registering it again is a no-op.

    Returns:
        The shared handler.
    """
    global _handler
    if _handler is None:
        _handler = AlertHandler()
    return _handler


def get_change_handler() -> ChangeHandler:
    """The module-level change handler, so registering it again is a no-op.

    Returns:
        The shared handler.
    """
    global _change_handler
    if _change_handler is None:
        _change_handler = ChangeHandler()
    return _change_handler
