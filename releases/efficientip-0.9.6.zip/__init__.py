"""EfficientIP SOLIDserver IPAM sync plugin."""

from .plugin import EfficientIPPlugin

__all__ = ["EfficientIPPlugin"]
