"""Plugin-local access to the EfficientIP sync configuration."""

from pathlib import Path
from typing import Any, Dict

from src.plugin_api import get_config

_CONFIG_FILE = Path("conf/efficientip_sync_config.yaml")
_DEFAULTS_FILE = Path(__file__).parent / "conf" / "defaults.yaml"


def get_efficientip_settings() -> Dict[str, Any]:
    """Return the full EfficientIP sync config (created from defaults on first use)."""
    return get_config(_CONFIG_FILE, _DEFAULTS_FILE)
