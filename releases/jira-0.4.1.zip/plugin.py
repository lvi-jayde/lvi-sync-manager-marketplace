"""Jira plugin: raise/resolve Jira issues from LogicVein alerts, and sync
LogicVein device inventory into Jira Assets.

Declares both ``alerts`` (a handler for the core ``/webhook/lvi-alert``
route) and ``inventory_sync`` (per-device Jira Assets objects, see
``assets_sync.py``) in its manifest.
"""

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from src.plugin_api import SyncPlugin, load_plugin_config, normalize_networks

from .client import JiraClient

logger = logging.getLogger(__name__)


class JiraPlugin(SyncPlugin):
    """Plugin that turns LVI alerts into Jira issues (Jira Cloud)."""

    def __init__(self) -> None:
        """Initialise the Jira plugin from its manifest.json."""
        self.config = load_plugin_config(Path(__file__).parent)

    def create_client(self, credentials: Dict[str, Any]) -> JiraClient:
        """Create an authenticated Jira client from credentials or env vars."""
        kwargs: Dict[str, Any] = {}
        if credentials.get("ignore_env_vars"):
            kwargs["ignore_env_vars"] = True
        if credentials.get("instance"):
            kwargs["instance"] = credentials["instance"]
        if credentials.get("email"):
            kwargs["email"] = credentials["email"]
        token = credentials.get("api_token") or credentials.get("token")
        if token:
            kwargs["api_token"] = token
        return JiraClient(**kwargs)

    def test_connection(self, credentials: Dict[str, Any]) -> Tuple[bool, str]:
        """Verify the Jira credentials authenticate against the site."""
        try:
            if self.create_client(credentials).test_connection():
                return True, "Connected to Jira successfully"
            return False, "Connection test failed - check base URL, email, and API token"
        except Exception as e:
            return False, f"Connection failed: {e}"

    def create_sync_engine(self, lvi_client: Any, target_client: Any, sync_config: Dict[str, Any]) -> Any:
        """Create the Jira Assets inventory sync engine.

        Args:
            lvi_client: LogicVein API client.
            target_client: A ``JiraClient`` (its session carries the shared auth;
                the Assets client is built from it).
            sync_config: Config dict from ``build_sync_config``.
        """
        from .assets_client import JiraAssetsClient
        from .assets_sync import LogicVeinJiraAssetsSync

        workspace_id = (sync_config.get("assets", {}) or {}).get("workspace_id", "")
        assets_client = JiraAssetsClient(target_client, workspace_id=workspace_id)
        return LogicVeinJiraAssetsSync(lvi_client=lvi_client, assets_client=assets_client, config=sync_config)

    def build_sync_config(self, yaml_config: Dict[str, Any], timestamp: Optional[str] = None) -> Dict[str, Any]:
        """Build the inventory sync config (LVI devices -> Jira Assets objects)."""
        sync_cfg = yaml_config.get("sync", {})
        lvi_cfg = yaml_config.get("logicvein", {})
        assets_cfg = yaml_config.get("assets", {})
        return {
            "dry_run": sync_cfg.get("dry_run", False),
            "continue_on_error": sync_cfg.get("continue_on_error", True),
            "network": lvi_cfg.get("networks", "Default"),
            "assets": {
                "object_schema": assets_cfg.get("object_schema", ""),
                "object_type": assets_cfg.get("object_type", "Device"),
                "correlation_attribute": assets_cfg.get("correlation_attribute", "Name"),
                "workspace_id": assets_cfg.get("workspace_id", ""),
                "create_missing": assets_cfg.get("create_missing", True),
                "update_existing": assets_cfg.get("update_existing", True),
                "field_mapping": assets_cfg.get("field_mapping", {}),
                "strip_domain_from_names": assets_cfg.get("strip_domain_from_names", True),
            },
        }

    def get_background_services(self) -> List[Any]:
        """Register the alert handler (no long-lived services)."""
        from . import services

        return services.build_services()

    def get_status_detail(self, config: Dict[str, Any]) -> str:
        """Return a one-line status string for the Run Sync header (inventory)."""
        assets = config.get("assets", {})
        schema = assets.get("object_schema", "")
        otype = assets.get("object_type", "Device")
        networks = normalize_networks(config.get("logicvein", {}).get("networks", "Default"))
        net = ", ".join(networks) if networks else "all"
        if schema:
            return f"Assets: {schema} / {otype} | Network: {net}"
        return ""

    def get_quick_settings(self) -> List[Dict[str, Any]]:
        """Toggle group for the Assets inventory sync (rendered in Configuration)."""
        return [
            {
                "name": "Inventory Sync (Assets)",
                "toggles": [
                    ("sync.dry_run", "Dry Run", "Log what would change without writing to Assets"),
                    ("sync.continue_on_error", "Continue on Error", "Continue if individual devices fail"),
                    ("assets.create_missing", "Create Missing", "Create objects for devices not yet in Assets"),
                    ("assets.update_existing", "Update Existing", "Update objects that already exist"),
                    (
                        "assets.strip_domain_from_names",
                        "Strip Domain From Names",
                        "Truncate an FQDN-looking LogicVein hostname to its short name before writing "
                        "it into any attribute mapped from 'hostname' (e.g. 'asa5505.home.arpa' -> "
                        "'asa5505'). Only affects lookup/duplicate risk if correlation_attribute is "
                        "itself mapped from hostname - toggling then renames the existing object "
                        "instead of creating a duplicate.",
                    ),
                ],
                "number_fields": [
                    (
                        "sync.watchdog_timeout_minutes",
                        "Watchdog Timeout (minutes)",
                        "Force-cancel a hung run after this many minutes (same as clicking Cancel Sync). "
                        "0 disables the watchdog.",
                        0,
                        None,
                    ),
                ],
            },
        ]
