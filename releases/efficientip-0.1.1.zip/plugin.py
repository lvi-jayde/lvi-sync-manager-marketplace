"""EfficientIP SOLIDserver sync plugin - the SyncPlugin entry point."""

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from src.plugin_api import SyncPlugin, load_plugin_config, normalize_networks

from .client import EfficientIPClient
from .sync import LogicVeinEfficientIPSync

logger = logging.getLogger(__name__)


class EfficientIPPlugin(SyncPlugin):
    """Plugin for synchronizing LogicVein device inventory to EfficientIP SOLIDserver IPAM."""

    def __init__(self) -> None:
        """Initialise the EfficientIP plugin from its manifest.json."""
        self.config = load_plugin_config(Path(__file__).parent)

    # --- Required (abstract) -------------------------------------------------

    def create_client(self, credentials: Dict[str, Any]) -> Any:
        """Create an authenticated EfficientIP SOLIDserver client.

        Args:
            credentials: Dict with keys: host, username, password, and
                         optionally ignore_env_vars.

        Returns:
            EfficientIPClient instance.
        """
        from .settings import get_efficientip_settings

        eip_cfg = get_efficientip_settings().get("efficientip", {})
        kwargs: Dict[str, Any] = {
            "verify_ssl": bool(eip_cfg.get("verify_ssl", False)),
            "timeout": int(eip_cfg.get("timeout", 120)),
        }
        if credentials.get("ignore_env_vars"):
            kwargs["ignore_env_vars"] = True
        if credentials.get("host"):
            kwargs["host"] = credentials["host"]
        if credentials.get("username"):
            kwargs["username"] = credentials["username"]
        if credentials.get("password"):
            kwargs["password"] = credentials["password"]
        return EfficientIPClient(**kwargs)

    def create_sync_engine(
        self,
        lvi_client: Any,
        target_client: Any,
        sync_config: Dict[str, Any],
    ) -> LogicVeinEfficientIPSync:
        """Create the EfficientIP sync engine.

        Args:
            lvi_client: LogicVein API client.
            target_client: EfficientIPClient instance.
            sync_config: Config dict produced by build_sync_config().

        Returns:
            LogicVeinEfficientIPSync instance.
        """
        return LogicVeinEfficientIPSync(lvi_client=lvi_client, efficientip_client=target_client, config=sync_config)

    def build_sync_config(
        self,
        yaml_config: Dict[str, Any],
        timestamp: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Build sync configuration from YAML config.

        Args:
            yaml_config: Parsed YAML configuration dictionary.
            timestamp: Optional timestamp for archive file naming.

        Returns:
            Configuration dictionary ready for LogicVeinEfficientIPSync.
        """
        sync = yaml_config.get("sync", {})
        lvi = yaml_config.get("logicvein", {})
        eip = yaml_config.get("efficientip", {})
        return {
            "dry_run": sync.get("dry_run", False),
            "continue_on_error": sync.get("continue_on_error", True),
            "network": lvi.get("networks", "Default"),
            "space_name": eip.get("space_name", "Local"),
            "create_missing_subnets": eip.get("create_missing_subnets", False),
            "class_parameter_mapping": eip.get("class_parameter_mapping", {}),
        }

    def test_connection(self, credentials: Dict[str, Any]) -> Tuple[bool, str]:
        """Test connection to EfficientIP SOLIDserver.

        Args:
            credentials: Dict with 'host', 'username', 'password' keys.

        Returns:
            Tuple of (success, message).
        """
        try:
            client = self.create_client(credentials)
            if client.test_connection():
                return True, "Connected to EfficientIP SOLIDserver successfully"
            return False, "Connection test failed - check credentials"
        except Exception as e:
            return False, f"Connection failed: {e}"

    # --- Optional hooks --------------------------------------------------------

    def supports_preview(self) -> bool:
        return True

    def get_preview(self, lvi_client: Any, target_client: Any, config: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Return a dry-run summary for the Preview button (no writes)."""
        networks = normalize_networks(config.get("network", "Default"))
        devices = lvi_client.search_devices_in_network(network=networks)
        return {"total_lvi_devices": len(devices)}

    def get_status_detail(self, config: Dict[str, Any]) -> str:
        """One-line summary shown in the sync tab header."""
        networks = normalize_networks(config.get("logicvein", {}).get("networks", "Default"))
        space_name = config.get("efficientip", {}).get("space_name", "Local")
        return f"Network: {', '.join(networks) if networks else 'all'} -> Space: {space_name}"

    def get_quick_settings(self) -> List[Dict[str, Any]]:
        """Quick-settings groups rendered above the raw-YAML editor."""
        return [
            {
                "name": "General",
                "toggles": [
                    ("sync.dry_run", "Dry Run", "Preview changes without writing to SOLIDserver"),
                    (
                        "efficientip.create_missing_subnets",
                        "Create missing subnets",
                        "Automatically create the containing subnet when missing (requires a pre-existing IP block)",
                    ),
                ],
                "text_fields": [
                    (
                        "logicvein.networks",
                        "LogicVein Network(s)",
                        "Network name(s) in LogicVein. Use 'all' for every network, or comma-separate names.",
                    ),
                    ("efficientip.space_name", "IP space name", "SOLIDserver IP space (site) to sync devices into"),
                ],
            },
        ]

    def supports_cancellation(self) -> bool:
        return True
