"""Client for the EfficientIP SOLIDserver REST API.

Credentials are accepted as explicit constructor parameters; if omitted they
fall back to the EFFICIENTIP_* environment variables unless ignore_env_vars
is True. TLS verification and request timeout are read from
conf/efficientip_sync_config.yaml (not env vars) unless passed explicitly.

Confirmed SOLIDserver-specific conventions this client wraps (verified
against a live instance):

- **All parameters go in the URL query string, never the request body -
  even for POST/PUT/DELETE.** A form-encoded POST body is silently rejected
  (HTTP 400, empty body); the same call succeeds when the identical
  parameters are query-string args.
- IP addresses are represented internally in hex (e.g. "c0a80100" for
  192.168.1.0) alongside a dotted-decimal field. Exact-match WHERE queries
  need the hex form - see _ip_to_hex().
- Per-object custom metadata ("class parameters") is not a separate object
  type: it's a single <object>_class_parameters field holding a raw
  URL-query-encoded blob (e.g. "key1=val1&key2=val2"), decoded/encoded with
  urllib.parse.parse_qs/urlencode - see _decode_class_parameters()/
  _encode_class_parameters().
- Error convention: a failed call returns a JSON array wrapping one error
  object, e.g. [{"errno": "3", "errmsg": "unknown service", ...}], even for
  a single error - not a bare object. A successful empty list result is
  HTTP 204 with an empty body, not "[]".
- Creating a subnet requires it to fall within an existing IP block
  (errno 5001, "Subnet is not in a block") unless SOLIDserver already has
  address space provisioned there. This client does not create blocks -
  see create_subnet()'s docstring.
"""

import ipaddress
import logging
import os
from typing import Any, Dict, List, Optional
from urllib.parse import parse_qs, urlencode

import requests
import urllib3
from src.plugin_api import build_retry_adapter

logger = logging.getLogger(__name__)


class EfficientIPError(Exception):
    """Raised when the SOLIDserver REST API returns an error response."""


class EfficientIPClient:
    """Native Python client for the EfficientIP SOLIDserver REST API."""

    def __init__(
        self,
        host: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        verify_ssl: Optional[bool] = None,
        timeout: Optional[int] = None,
        ignore_env_vars: bool = False,
    ) -> None:
        """Initialise the EfficientIP SOLIDserver client.

        Args:
            host: SOLIDserver hostname or URL. Defaults to EFFICIENTIP_HOST env var.
            username: API username. Defaults to EFFICIENTIP_USERNAME env var.
            password: API password. Defaults to EFFICIENTIP_PASSWORD env var.
            verify_ssl: Verify TLS certificates. Defaults to
                        conf/efficientip_sync_config.yaml efficientip.verify_ssl, or False.
            timeout: Request timeout in seconds. Defaults to
                     conf/efficientip_sync_config.yaml efficientip.timeout, or 120.
            ignore_env_vars: If True, do not fall back to environment variables.
        """
        if ignore_env_vars:
            self.host = host
            self.username = username
            self.password = password
            self.verify_ssl = verify_ssl if verify_ssl is not None else False
            self.timeout = timeout or 120
        else:
            self.host = host or os.getenv("EFFICIENTIP_HOST")
            self.username = username or os.getenv("EFFICIENTIP_USERNAME")
            self.password = password or os.getenv("EFFICIENTIP_PASSWORD")
            if verify_ssl is not None and timeout is not None:
                self.verify_ssl = verify_ssl
                self.timeout = timeout
            else:
                from .settings import get_efficientip_settings

                eip_cfg = get_efficientip_settings().get("efficientip", {})
                self.verify_ssl = verify_ssl if verify_ssl is not None else bool(eip_cfg.get("verify_ssl", False))
                self.timeout = timeout if timeout is not None else int(eip_cfg.get("timeout", 120))

        # Normalize host - remove protocol if present
        if self.host and self.host.startswith(("http://", "https://")):
            self.host = self.host.split("://", 1)[1]

        self.base_url = f"https://{self.host}/rest"

        self.session = requests.Session()
        if self.username and self.password:
            self.session.auth = (self.username, self.password)
        self.session.headers.update({"Accept": "application/json"})
        self.session.verify = self.verify_ssl
        if not self.verify_ssl:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        _adapter = build_retry_adapter()
        self.session.mount("https://", _adapter)
        self.session.mount("http://", _adapter)

    # ------------------------------------------------------------------ #
    # Low-level request handling                                          #
    # ------------------------------------------------------------------ #

    def _request(
        self,
        method: str,
        service: str,
        params: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """Call a SOLIDserver REST service and return its parsed result list.

        All parameters are sent as URL query-string args regardless of
        method - SOLIDserver silently rejects a form-encoded request body
        (confirmed empirically; see module docstring).

        Args:
            method: HTTP method (GET, POST, PUT, DELETE).
            service: Service name (e.g. "ip_site_list", "ip_add").
            params: Query parameters.

        Returns:
            Parsed JSON array of result objects. Empty list on HTTP 204
            (SOLIDserver's convention for an empty result set).

        Raises:
            EfficientIPError: If the service returns an error object.
        """
        url = f"{self.base_url}/{service}"
        logger.debug("Request: %s %s params=%s", method, url, params)

        response = self.session.request(method=method, url=url, params=params, timeout=self.timeout)

        if response.status_code == 204:
            return []

        try:
            data = response.json()
        except ValueError:
            response.raise_for_status()
            return []

        if response.status_code >= 400:
            errmsg = data[0].get("errmsg", "unknown error") if isinstance(data, list) and data else str(data)
            raise EfficientIPError(f"{service} failed: {errmsg}")

        return data if isinstance(data, list) else [data]

    # ------------------------------------------------------------------ #
    # SOLIDserver-specific encoding helpers                                #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _ip_to_hex(ip_address: str) -> str:
        """Convert a dotted-decimal IPv4 address to SOLIDserver's internal hex form."""
        return format(int(ipaddress.IPv4Address(ip_address)), "08x")

    @staticmethod
    def _decode_class_parameters(raw: str) -> Dict[str, str]:
        """Decode a SOLIDserver `<object>_class_parameters` blob into a flat dict."""
        if not raw:
            return {}
        parsed = parse_qs(raw, keep_blank_values=True)
        return {k: v[0] if v else "" for k, v in parsed.items()}

    @staticmethod
    def _encode_class_parameters(params: Dict[str, str]) -> str:
        """Encode a flat dict into a SOLIDserver `<object>_class_parameters` blob."""
        return urlencode(params)

    # ------------------------------------------------------------------ #
    # Connection                                                           #
    # ------------------------------------------------------------------ #

    def test_connection(self) -> bool:
        """Test connectivity to the SOLIDserver instance."""
        try:
            self._request("GET", "ip_site_list", params={"limit": 1})
            return True
        except Exception as e:
            logger.error("EfficientIP connection test failed: %s", e)
            return False

    # ------------------------------------------------------------------ #
    # IP spaces (sites)                                                    #
    # ------------------------------------------------------------------ #

    def get_spaces(self) -> List[Dict[str, Any]]:
        """Return all IP spaces (SOLIDserver "sites")."""
        return self._request("GET", "ip_site_list")

    def get_space_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        """Return one IP space by name, or None if not found."""
        results = self._request("GET", "ip_site_list", params={"WHERE": f"site_name='{name}'"})
        return results[0] if results else None

    # ------------------------------------------------------------------ #
    # Subnets                                                              #
    # ------------------------------------------------------------------ #

    def get_subnets(self, site_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Return all subnets (excludes blocks), optionally filtered to one IP space."""
        where = "type='subnet'"
        if site_id:
            where += f" AND site_id='{site_id}'"
        return self._request("GET", "ip_block_subnet_list", params={"WHERE": where})

    def find_subnet_for_ip(self, ip_address: str, site_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Return the most specific subnet containing *ip_address*, or None."""
        ip = ipaddress.IPv4Address(ip_address)
        candidates = self.get_subnets(site_id=site_id)
        matches = []
        for subnet in candidates:
            try:
                network = ipaddress.IPv4Network(f"{subnet['start_hostaddr']}/{subnet['subnet_prefix']}", strict=False)
            except (KeyError, ValueError):
                continue
            if ip in network:
                matches.append((network.prefixlen, subnet))
        if not matches:
            return None
        # Most specific (largest prefix length) wins.
        return max(matches, key=lambda m: m[0])[1]

    def create_subnet(self, cidr: str, site_id: str, name: str = "") -> bool:
        """Create a subnet in the given IP space. Returns True on success.

        SOLIDserver requires the subnet to fall within an existing IP block
        (address space must be pre-provisioned) - this client does not
        create blocks, so this fails with a clear error (errno 5001,
        "Subnet is not in a block") when no covering block exists. Callers
        should treat that as an expected, loggable failure rather than a bug.
        """
        network = ipaddress.IPv4Network(cidr, strict=False)
        params = {
            "site_id": site_id,
            "subnet_addr": str(network.network_address),
            "subnet_prefix": str(network.prefixlen),
            "subnet_name": name or str(network),
        }
        try:
            self._request("POST", "ip_subnet_add", params=params)
            return True
        except EfficientIPError as e:
            logger.warning("Failed to create subnet %s: %s", cidr, e)
            return False

    # ------------------------------------------------------------------ #
    # Addresses                                                            #
    # ------------------------------------------------------------------ #

    def find_address(self, ip_address: str, site_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Return an existing IP address record, or None if not registered."""
        where = f"ip_addr='{self._ip_to_hex(ip_address)}'"
        if site_id:
            where += f" AND site_id='{site_id}'"
        results = self._request("GET", "ip_address_list", params={"WHERE": where})
        return results[0] if results else None

    def create_or_update_address(
        self,
        ip_address: str,
        site_id: str,
        hostname: str = "",
        mac_address: str = "",
        class_parameters: Optional[Dict[str, str]] = None,
    ) -> bool:
        """Create or update an IP address record (ip_add is an upsert). Returns True on success."""
        params: Dict[str, Any] = {
            "site_id": site_id,
            "hostaddr": ip_address,
        }
        if hostname:
            params["name"] = hostname
        if mac_address:
            params["mac_addr"] = mac_address
        if class_parameters:
            params["ip_class_parameters"] = self._encode_class_parameters(class_parameters)
        try:
            self._request("POST", "ip_add", params=params)
            return True
        except EfficientIPError as e:
            logger.warning("Failed to create/update address %s: %s", ip_address, e)
            return False
