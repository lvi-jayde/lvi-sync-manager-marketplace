"""NetBox API client for DCIM and device management."""

import logging
import os
import re
from typing import Dict, List, Optional

import requests
import urllib3
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

logger = logging.getLogger(__name__)

_RETRY_TOTAL = 3
_RETRY_BACKOFF = 0.5
_RETRY_ON_STATUS = (429, 500, 502, 503, 504)


def _build_retry_adapter() -> HTTPAdapter:
    """Return an HTTPAdapter with exponential-backoff retry on transient errors."""
    retry = Retry(
        total=_RETRY_TOTAL,
        backoff_factor=_RETRY_BACKOFF,
        status_forcelist=_RETRY_ON_STATUS,
        allowed_methods={"DELETE", "GET", "HEAD", "OPTIONS", "POST", "PUT", "PATCH"},
        raise_on_status=False,
    )
    return HTTPAdapter(max_retries=retry)


def generate_slug(name: str) -> str:
    """Generate a valid NetBox slug from a name.

    Slugs must contain only lowercase letters, numbers, underscores, or hyphens.

    Args:
        name: The name to convert to a slug

    Returns:
        A valid slug string
    """
    # Convert to lowercase
    slug = name.lower()
    # Replace spaces and underscores with hyphens
    slug = slug.replace(" ", "-").replace("_", "-")
    # Remove any characters that are not alphanumeric or hyphens
    slug = re.sub(r"[^a-z0-9-]", "", slug)
    # Remove consecutive hyphens
    slug = re.sub(r"-+", "-", slug)
    # Remove leading/trailing hyphens
    slug = slug.strip("-")
    # Ensure slug is not empty
    return slug if slug else "unknown"


class NetBoxClient:
    """
    Native Python client for NetBox REST API.

    Supports DCIM operations: devices, manufacturers, platforms, device roles,
    sites, locations, racks, and more.
    """

    def __init__(
        self,
        host: Optional[str] = None,
        api_token: Optional[str] = None,
        ignore_env_vars: bool = False,
    ) -> None:
        """Initialize NetBox client.

        Args:
            host: NetBox host URL or hostname (e.g., https://netbox.example.com or netbox.example.com or 192.168.1.54).
                  If not provided, uses NETBOX_HOST env var.
            api_token: NetBox API token. If not provided, uses NETBOX_API_TOKEN env var.
            ignore_env_vars: If True, do not fall back to environment variables.
        """
        if ignore_env_vars:
            self.host = host
            self.api_token = api_token
            self.verify_ssl = False
            self.timeout = 120
        else:
            self.host = host or os.getenv("NETBOX_HOST")
            self.api_token = api_token or os.getenv("NETBOX_API_TOKEN")
            self.verify_ssl = os.getenv("NETBOX_VERIFY_SSL", "False").lower() == "true"
            self.timeout = int(os.getenv("NETBOX_TIMEOUT", "120"))

        # Normalize host - remove protocol if present
        if self.host and self.host.startswith(("http://", "https://")):
            self.host = self.host.split("://", 1)[1]

        self.base_url = f"https://{self.host}/api"

        # Session for connection pooling
        self.session = requests.Session()
        self.session.headers.update(
            {
                "Authorization": f"Token {self.api_token}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            }
        )
        self.session.verify = self.verify_ssl
        if not self.verify_ssl:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        _adapter = _build_retry_adapter()
        self.session.mount("https://", _adapter)
        self.session.mount("http://", _adapter)

    def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict] = None,
        json_data: Optional[Dict] = None,
        suppress_errors: bool = False,
    ) -> requests.Response:
        """Make HTTP request to NetBox API."""
        url = f"{self.base_url}/{endpoint}"

        logger.debug(f"Request: {method} {url}")
        if params:
            logger.debug(f"Params: {params}")
        if json_data:
            logger.debug(f"JSON: {json_data}")

        try:
            response = self.session.request(method=method, url=url, params=params, json=json_data, timeout=self.timeout)

            logger.debug(f"Response: {response.status_code}")
            if response.text:
                logger.debug(f"Response body (first 500 chars): {response.text[:500]}")

            response.raise_for_status()
            return response

        except requests.exceptions.RequestException as e:
            if suppress_errors:
                return e.response  # type: ignore
            if hasattr(e, "response") and e.response is not None:
                logger.error(f"HTTP error: {e.response.status_code} - {e.response.text}")
            else:
                logger.error(f"Request error: {str(e)}")
            raise

    def test_connection(self) -> bool:
        """Test connectivity to NetBox API."""
        try:
            response = self._request("GET", "dcim/devices/?limit=1")
            return response.status_code == 200
        except Exception as e:
            logger.error(f"NetBox connection test failed: {e}")
            return False

    # ==================== Devices ====================

    def get_devices(self, filters: Optional[Dict] = None, limit: int = 50) -> List[Dict]:
        """
        Get devices from NetBox.

        Args:
            filters: Query filters (e.g., {'name': 'router1', 'site': 'site1'})
            limit: Results per page (NetBox default: 50)

        Returns:
            List of device dictionaries
        """
        params = {"limit": limit}
        if filters:
            params.update(filters)

        all_devices = []
        offset = 0

        while True:
            params["offset"] = offset
            response = self._request("GET", "dcim/devices/", params=params)
            data = response.json()

            all_devices.extend(data.get("results", []))

            # Check if there are more results
            if not data.get("next"):
                break
            offset += limit

        return all_devices

    def get_device_by_name(self, name: str) -> Optional[Dict]:
        """Get device by name."""
        devices = self.get_devices(filters={"name": name})
        return devices[0] if devices else None

    def create_device(self, device_data: Dict) -> Dict:
        """Create a new device in NetBox."""
        response = self._request("POST", "dcim/devices/", json_data=device_data)
        return response.json()

    def update_device(self, device_id: int, device_data: Dict) -> Dict:
        """Update an existing device."""
        response = self._request("PATCH", f"dcim/devices/{device_id}/", json_data=device_data)
        return response.json()

    def delete_device(self, device_id: int) -> bool:
        """Delete a device."""
        response = self._request("DELETE", f"dcim/devices/{device_id}/")
        return response.status_code == 204

    # ==================== Device Types ====================

    def get_device_types(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Get device types."""
        params = {"limit": 50}
        if filters:
            params.update(filters)

        response = self._request("GET", "dcim/device-types/", params=params)
        return response.json().get("results", [])

    def get_device_type_by_model(self, model: str) -> Optional[Dict]:
        """Get device type by model name."""
        types = self.get_device_types(filters={"model__ic": model})
        return types[0] if types else None

    def create_device_type(self, model: str, manufacturer_id: int, slug: Optional[str] = None) -> Dict:
        """Create a new device type.

        Args:
            model: Device model name (e.g., "ISR4321", "2500")
            manufacturer_id: ID of the manufacturer
            slug: URL-friendly slug (auto-generated from model if not provided)

        Returns:
            Created device type dictionary
        """
        if not slug:
            slug = generate_slug(model)
        data = {"model": model, "manufacturer": manufacturer_id, "slug": slug}
        response = self._request("POST", "dcim/device-types/", json_data=data)
        return response.json()

    def get_or_create_device_type(self, model: str, manufacturer_name: str) -> Optional[Dict]:
        """Get device type by model, or create it if it doesn't exist.

        Args:
            model: Device model name
            manufacturer_name: Manufacturer name (will be created if missing)

        Returns:
            Device type dictionary, or None on error
        """
        # Try to find existing device type
        device_type = self.get_device_type_by_model(model)
        if device_type:
            return device_type

        # Get or create manufacturer
        manufacturer = self.get_manufacturer_by_name(manufacturer_name)
        if not manufacturer:
            slug = generate_slug(manufacturer_name)
            manufacturer = self.create_manufacturer(manufacturer_name, slug)

        manufacturer_id = manufacturer.get("id")
        if not manufacturer_id:
            return None

        # Create device type
        return self.create_device_type(model, manufacturer_id)

    # ==================== Manufacturers ====================

    def get_manufacturers(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Get manufacturers."""
        params = {"limit": 50}
        if filters:
            params.update(filters)

        response = self._request("GET", "dcim/manufacturers/", params=params)
        return response.json().get("results", [])

    def get_manufacturer_by_name(self, name: str) -> Optional[Dict]:
        """Get manufacturer by name."""
        manufacturers = self.get_manufacturers(filters={"name": name})
        return manufacturers[0] if manufacturers else None

    def create_manufacturer(self, name: str, slug: str) -> Dict:
        """Create a new manufacturer."""
        data = {"name": name, "slug": slug}
        response = self._request("POST", "dcim/manufacturers/", json_data=data)
        return response.json()

    # ==================== Device Roles ====================

    def get_device_roles(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Get device roles."""
        params = {"limit": 50}
        if filters:
            params.update(filters)

        response = self._request("GET", "dcim/device-roles/", params=params)
        return response.json().get("results", [])

    def get_device_role_by_name(self, name: str) -> Optional[Dict]:
        """Get device role by name."""
        roles = self.get_device_roles(filters={"name": name})
        return roles[0] if roles else None

    def create_device_role(self, name: str, slug: str, color: str = "3f51b5") -> Dict:
        """Create a new device role."""
        data = {"name": name, "slug": slug, "color": color}
        response = self._request("POST", "dcim/device-roles/", json_data=data)
        return response.json()

    def get_or_create_device_role(self, name: str) -> Optional[Dict]:
        """Get device role by name, or create it if it doesn't exist.

        Args:
            name: Device role name (e.g., "Router", "Switch")

        Returns:
            Device role dictionary, or None on error
        """
        role = self.get_device_role_by_name(name)
        if role:
            return role

        slug = generate_slug(name)
        return self.create_device_role(name, slug)

    # ==================== Platforms ====================

    def get_platforms(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Get platforms."""
        params = {"limit": 50}
        if filters:
            params.update(filters)

        response = self._request("GET", "dcim/platforms/", params=params)
        return response.json().get("results", [])

    def get_platform_by_name(self, name: str) -> Optional[Dict]:
        """Get platform by name."""
        platforms = self.get_platforms(filters={"name": name})
        return platforms[0] if platforms else None

    def create_platform(self, name: str, slug: str, napalm_driver: Optional[str] = None) -> Dict:
        """Create a new platform."""
        data = {"name": name, "slug": slug}
        if napalm_driver:
            data["napalm_driver"] = napalm_driver
        response = self._request("POST", "dcim/platforms/", json_data=data)
        return response.json()

    def get_or_create_platform(self, name: str) -> Optional[Dict]:
        """Get platform by name, or create it if it doesn't exist.

        Args:
            name: Platform name (e.g., "IOS", "JunOS", "Linux")

        Returns:
            Platform dictionary, or None on error
        """
        platform = self.get_platform_by_name(name)
        if platform:
            return platform

        slug = generate_slug(name)
        return self.create_platform(name, slug)

    # ==================== Sites ====================

    def get_sites(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Get sites."""
        params = {"limit": 50}
        if filters:
            params.update(filters)

        response = self._request("GET", "dcim/sites/", params=params)
        return response.json().get("results", [])

    def get_site_by_name(self, name: str) -> Optional[Dict]:
        """Get site by name."""
        sites = self.get_sites(filters={"name__ic": name})
        return sites[0] if sites else None

    def create_site(self, name: str, slug: Optional[str] = None) -> Dict:
        """Create a new site.

        Args:
            name: Site name
            slug: URL-friendly slug (auto-generated from name if not provided)

        Returns:
            Created site dictionary
        """
        if not slug:
            slug = generate_slug(name)
        data = {"name": name, "slug": slug, "status": "active"}
        response = self._request("POST", "dcim/sites/", json_data=data)
        return response.json()

    def get_or_create_site(self, name: str) -> Optional[Dict]:
        """Get site by name, or create it if it doesn't exist.

        Args:
            name: Site name

        Returns:
            Site dictionary, or None on error
        """
        site = self.get_site_by_name(name)
        if site:
            return site

        return self.create_site(name)

    # ==================== Locations ====================

    def get_locations(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Get locations."""
        params = {"limit": 50}
        if filters:
            params.update(filters)

        response = self._request("GET", "dcim/locations/", params=params)
        return response.json().get("results", [])

    def get_location_by_name(self, name: str) -> Optional[Dict]:
        """Get location by name."""
        locations = self.get_locations(filters={"name": name})
        return locations[0] if locations else None

    def get_location_by_name_and_site(self, name: str, site_id: int) -> Optional[Dict]:
        """Get location by name within a specific site."""
        locations = self.get_locations(filters={"name": name, "site_id": site_id})
        return locations[0] if locations else None

    def create_location(self, name: str, site_id: int, slug: Optional[str] = None) -> Dict:
        """Create a new location.

        Args:
            name: Location name
            site_id: Site ID the location belongs to
            slug: URL-friendly slug (auto-generated from name if not provided)

        Returns:
            Created location dictionary
        """
        if not slug:
            slug = generate_slug(name)
        data = {"name": name, "site": site_id, "slug": slug, "status": "active"}
        response = self._request("POST", "dcim/locations/", json_data=data)
        return response.json()

    def get_or_create_location(self, name: str, site_id: int) -> Optional[Dict]:
        """Get location by name within a site, or create it if it doesn't exist.

        Args:
            name: Location name
            site_id: Site ID the location belongs to

        Returns:
            Location dictionary, or None on error
        """
        location = self.get_location_by_name_and_site(name, site_id)
        if location:
            return location

        return self.create_location(name, site_id)

    # ==================== Tenants ====================

    def get_tenants(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Get tenants."""
        params = {"limit": 50}
        if filters:
            params.update(filters)

        response = self._request("GET", "tenancy/tenants/", params=params)
        return response.json().get("results", [])

    def get_tenant_by_name(self, name: str) -> Optional[Dict]:
        """Get tenant by name."""
        tenants = self.get_tenants(filters={"name__ic": name})
        return tenants[0] if tenants else None

    def create_tenant(self, name: str, slug: Optional[str] = None) -> Dict:
        """Create a new tenant.

        Args:
            name: Tenant name
            slug: URL-friendly slug (auto-generated from name if not provided)

        Returns:
            Created tenant dictionary
        """
        if not slug:
            slug = generate_slug(name)
        data = {"name": name, "slug": slug}
        response = self._request("POST", "tenancy/tenants/", json_data=data)
        return response.json()

    def get_or_create_tenant(self, name: str) -> Optional[Dict]:
        """Get tenant by name, or create it if it doesn't exist.

        Args:
            name: Tenant name

        Returns:
            Tenant dictionary, or None on error
        """
        tenant = self.get_tenant_by_name(name)
        if tenant:
            return tenant

        return self.create_tenant(name)

    # ==================== Racks ====================

    def get_racks(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Get racks."""
        params = {"limit": 50}
        if filters:
            params.update(filters)

        response = self._request("GET", "dcim/racks/", params=params)
        return response.json().get("results", [])

    def get_rack_by_name(self, name: str) -> Optional[Dict]:
        """Get rack by name."""
        racks = self.get_racks(filters={"name__ic": name})
        return racks[0] if racks else None

    # ==================== Circuits ====================

    def get_circuits(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Get circuits."""
        params = {"limit": 50}
        if filters:
            params.update(filters)

        response = self._request("GET", "circuits/circuits/", params=params)
        return response.json().get("results", [])

    def get_providers(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Get circuit providers."""
        params = {"limit": 50}
        if filters:
            params.update(filters)

        response = self._request("GET", "circuits/providers/", params=params)
        return response.json().get("results", [])

    # ==================== Interfaces ====================

    def get_interfaces(self, device_id: int) -> List[Dict]:
        """Get interfaces for a device."""
        response = self._request("GET", f"dcim/interfaces/?device_id={device_id}&limit=100")
        return response.json().get("results", [])

    def get_interface_by_name(self, device_id: int, name: str) -> Optional[Dict]:
        """Get interface by name for a device."""
        interfaces = self.get_interfaces(device_id)
        for iface in interfaces:
            if iface.get("name") == name:
                return iface
        return None

    def create_interface(self, interface_data: Dict) -> Dict:
        """Create a new interface.

        Args:
            interface_data: Interface data with required fields:
                - device (int): Device ID
                - name (str): Interface name
                - type (str): Interface type (e.g., 'virtual', '1000base-t', '10gbase-x-sfpp')

        Returns:
            Created interface dictionary
        """
        response = self._request("POST", "dcim/interfaces/", json_data=interface_data)
        return response.json()

    def update_interface(self, interface_id: int, interface_data: Dict) -> Dict:
        """Update an existing interface."""
        response = self._request("PATCH", f"dcim/interfaces/{interface_id}/", json_data=interface_data)
        return response.json()

    def delete_interface(self, interface_id: int) -> bool:
        """Delete an interface."""
        response = self._request("DELETE", f"dcim/interfaces/{interface_id}/")
        return response.status_code == 204

    def get_or_create_interface(
        self, device_id: int, name: str = "mgmt0", interface_type: str = "virtual"
    ) -> Optional[Dict]:
        """Get interface by name, or create it if it doesn't exist.

        Args:
            device_id: Device ID
            name: Interface name (default: "mgmt0")
            interface_type: Interface type (default: "virtual")

        Returns:
            Interface dictionary, or None on error
        """
        interface = self.get_interface_by_name(device_id, name)
        if interface:
            return interface

        interface_data = {
            "device": device_id,
            "name": name,
            "type": interface_type,
        }
        return self.create_interface(interface_data)

    # ==================== IP Addresses ====================

    def get_ip_addresses(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Get IP addresses."""
        params = {"limit": 50}
        if filters:
            params.update(filters)

        response = self._request("GET", "ipam/ip-addresses/", params=params)
        return response.json().get("results", [])

    def get_ip_address_by_address(self, address: str) -> Optional[Dict]:
        """Get IP address by address string (e.g., '192.168.1.1/24' or '192.168.1.1').

        Args:
            address: IP address string, with or without CIDR notation

        Returns:
            IP address dictionary if found, None otherwise
        """
        ip_only = address.split("/")[0]

        # Try exact CIDR match first - most reliable, handles IPv6 normalization.
        # Falls back to a contains search to catch prefix-length mismatches (e.g.
        # LVI reports /32 but NetBox stored the address with a different prefix).
        ips = self.get_ip_addresses(filters={"address": address})
        if ips:
            return ips[0]

        ips = self.get_ip_addresses(filters={"address__contains": ip_only})
        for ip in ips:
            if ip.get("address", "").startswith(ip_only):
                return ip
        return None

    def create_ip_address(self, ip_data: Dict) -> Dict:
        """Create a new IP address.

        Args:
            ip_data: IP address data with required 'address' field in CIDR notation.
                Optional fields: vrf, tenant, status, role, assigned_object_type,
                assigned_object_id, dns_name, description, tags, custom_fields

        Returns:
            Created IP address dictionary
        """
        response = self._request("POST", "ipam/ip-addresses/", json_data=ip_data)
        return response.json()

    def update_ip_address(self, ip_id: int, ip_data: Dict) -> Dict:
        """Update an existing IP address."""
        response = self._request("PATCH", f"ipam/ip-addresses/{ip_id}/", json_data=ip_data)
        return response.json()

    def delete_ip_address(self, ip_id: int) -> bool:
        """Delete an IP address."""
        response = self._request("DELETE", f"ipam/ip-addresses/{ip_id}/")
        return response.status_code == 204

    # ==================== VRFs ====================

    def get_vrfs(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Get VRFs (Virtual Routing and Forwarding)."""
        params = {"limit": 50}
        if filters:
            params.update(filters)

        response = self._request("GET", "ipam/vrfs/", params=params)
        return response.json().get("results", [])

    def get_vrf_by_name(self, name: str) -> Optional[Dict]:
        """Get VRF by name."""
        vrfs = self.get_vrfs(filters={"name": name})
        return vrfs[0] if vrfs else None

    # ==================== Custom Fields ====================

    def get_custom_fields(self) -> List[Dict]:
        """Get custom fields configuration."""
        response = self._request("GET", "extras/custom-fields/?limit=100")
        return response.json().get("results", [])

    def get_custom_field_by_name(self, name: str) -> Optional[Dict]:
        """Get custom field by name."""
        fields = self.get_custom_fields()
        for field in fields:
            if field.get("name") == name:
                return field
        return None
