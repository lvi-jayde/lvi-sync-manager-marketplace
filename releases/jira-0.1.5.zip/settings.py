"""Plugin-local access to the Jira sync configuration and client."""

from pathlib import Path
from typing import Any, Dict

from src.plugin_api import get_config

_CONFIG_FILE = Path("conf/jira_sync_config.yaml")
_DEFAULTS_FILE = Path(__file__).parent / "conf" / "defaults.yaml"


def get_jira_settings() -> Dict[str, Any]:
    """Return the full Jira sync config (created from defaults on first use)."""
    return get_config(_CONFIG_FILE, _DEFAULTS_FILE)


def get_jira_client() -> Any:
    """Return a JiraClient built from environment variables."""
    from .client import JiraClient

    return JiraClient()
