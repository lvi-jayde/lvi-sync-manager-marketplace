"""Background services contributed by the Jira plugin.

Jira is incident-only (alerts): it registers a handler for the core
``/webhook/lvi-alert`` route and runs no long-lived background service of its
own. ``build_services`` therefore returns an empty list but performs the handler
registration, idempotently, the way the host expects.
"""

from typing import Any, List


def build_services() -> List[Any]:
    """Register the Jira alert handler (when features.alerts is on); no services."""
    from src.plugin_api import get_app_settings

    if get_app_settings().get("features", {}).get("alerts", True):
        from src.plugin_api import register_alert_handler

        from .webhook.alert_handler import get_alert_handler

        register_alert_handler(get_alert_handler())

    return []
