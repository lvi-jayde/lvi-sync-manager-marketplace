"""Jira Cloud REST API v3 client (issues, search, transitions, comments).

Authenticates with HTTP Basic ``email:api_token`` (the Jira Cloud scheme; the
API token is created at id.atlassian.com/manage/api-tokens). Credentials are
explicit constructor args, falling back to the JIRA_* environment variables
unless ``ignore_env_vars`` is set.
"""

import logging
import os
from typing import Any, Dict, List, Optional

import requests
from src.plugin_api import build_retry_adapter

logger = logging.getLogger(__name__)

_API = "rest/api/3"
_SDAPI = "rest/servicedeskapi"


def _base_url_from_instance(instance: str) -> str:
    """Build the site base URL from an instance hostname.

    Accepts a bare host (``your-site.atlassian.net``) and adds the https://
    scheme automatically; tolerates a value that already includes a scheme or
    a trailing slash.
    """
    host = (instance or "").strip().rstrip("/")
    host = host.removeprefix("https://").removeprefix("http://")
    return f"https://{host}" if host else ""


class JiraClient:
    """Native client for the Jira Cloud REST API v3."""

    def __init__(
        self,
        instance: Optional[str] = None,
        email: Optional[str] = None,
        api_token: Optional[str] = None,
        verify_ssl: Optional[bool] = None,
        timeout: Optional[int] = None,
        ignore_env_vars: bool = False,
    ) -> None:
        """Initialise the Jira client.

        Args:
            instance: Site hostname, e.g. ``your-site.atlassian.net``. The
                      https:// scheme is added automatically. Defaults to
                      JIRA_INSTANCE.
            email: Atlassian account email. Defaults to JIRA_EMAIL.
            api_token: API token. Defaults to JIRA_API_TOKEN.
            verify_ssl: Verify TLS (Jira Cloud is publicly trusted; default True).
            timeout: Request timeout in seconds (default JIRA_TIMEOUT or 60).
            ignore_env_vars: If True, do not fall back to environment variables.
        """
        if ignore_env_vars:
            self.base_url = _base_url_from_instance(instance or "")
            self.email = email
            self.api_token = api_token
            self.verify_ssl = verify_ssl if verify_ssl is not None else True
            self.timeout = timeout or 60
        else:
            self.base_url = _base_url_from_instance(instance or os.getenv("JIRA_INSTANCE") or "")
            self.email = email or os.getenv("JIRA_EMAIL")
            self.api_token = api_token or os.getenv("JIRA_API_TOKEN")
            verify_env = os.getenv("JIRA_VERIFY_SSL", "true").lower() == "true"
            self.verify_ssl = verify_ssl if verify_ssl is not None else verify_env
            self.timeout = timeout or int(os.getenv("JIRA_TIMEOUT", "60"))

        _src = "explicit" if ignore_env_vars else "env-var fallback"
        if self.base_url and self.email and self.api_token:
            logger.info(
                "Jira client: base_url=%s, email=%s, auth=api_token (len=%d), cred_src=%s",
                self.base_url,
                self.email,
                len(self.api_token),
                _src,
            )
        else:
            logger.warning(
                "Jira client: incomplete credentials (instance/email/api_token); "
                "set JIRA_INSTANCE, JIRA_EMAIL and JIRA_API_TOKEN"
            )

        self.session = requests.Session()
        self.session.headers.update({"Content-Type": "application/json", "Accept": "application/json"})
        if self.email and self.api_token:
            self.session.auth = (self.email, self.api_token)
        self.session.verify = self.verify_ssl
        adapter = build_retry_adapter()
        self.session.mount("https://", adapter)
        self.session.mount("http://", adapter)

    def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict] = None,
        json_data: Optional[Dict] = None,
    ) -> requests.Response:
        """Issue an HTTP request to the Jira API and raise on error."""
        url = f"{self.base_url}/{endpoint}"
        logger.debug("Jira request: %s %s", method, url)
        try:
            response = self.session.request(
                method=method,
                url=url,
                params=params,
                json=json_data,
                timeout=self.timeout,
            )
            response.raise_for_status()
            return response
        except requests.exceptions.RequestException as e:
            resp = getattr(e, "response", None)
            if resp is not None:
                logger.error("Jira HTTP error: %s - %s", resp.status_code, resp.text[:500])
            else:
                logger.error("Jira request error: %s", e)
            raise

    # ------------------------------------------------------------------ #
    # Connection                                                           #
    # ------------------------------------------------------------------ #

    def test_connection(self) -> bool:
        """Return True if the credentials authenticate against the site."""
        try:
            return self._request("GET", f"{_API}/myself").status_code == 200
        except Exception as e:
            logger.error("Jira connection test failed: %s", e)
            return False

    # ------------------------------------------------------------------ #
    # Issues                                                               #
    # ------------------------------------------------------------------ #

    def create_issue(self, fields: Dict[str, Any]) -> Dict[str, Any]:
        """Create an issue. ``fields`` is the Jira ``fields`` object; returns
        the created ``{id, key, self}``."""
        return self._request("POST", f"{_API}/issue", json_data={"fields": fields}).json()

    def add_comment(self, issue_key: str, body_adf: Dict[str, Any]) -> Dict[str, Any]:
        """Add an ADF comment to an issue."""
        return self._request("POST", f"{_API}/issue/{issue_key}/comment", json_data={"body": body_adf}).json()

    def add_labels(self, issue_key: str, labels: List[str]) -> None:
        """Add labels to an existing issue (used to tag JSM requests for correlation)."""
        body = {"update": {"labels": [{"add": label} for label in labels]}}
        self._request("PUT", f"{_API}/issue/{issue_key}", json_data=body)

    # ------------------------------------------------------------------ #
    # Jira Service Management (customer requests)                          #
    # ------------------------------------------------------------------ #

    def create_request(
        self,
        service_desk_id: str,
        request_type_id: str,
        summary: str,
        description: str,
        labels: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Raise a JSM customer request so the issue appears in service-desk queues.

        Plain ``POST /issue`` never sets a Request Type, so issues stay invisible
        to JSM queues/filters that key on it (e.g. "Open Incidents"). The Service
        Desk API sets the request type and inherits its hidden-field defaults. The
        result is an ordinary Jira issue, so the ``lvi-<hash>`` label and JQL
        correlation still work - the label is applied with a follow-up issue update
        because a request type's create form may not expose the labels field.
        Descriptions here are plain text; the Service Desk API does not accept ADF.

        Args:
            service_desk_id: The JSM service desk id (must own request_type_id).
            request_type_id: The request type id within that service desk.
            summary: Issue summary.
            description: Plain-text issue description.
            labels: Labels to attach after creation (the correlation label).

        Returns:
            Dict with at least ``{"key": issueKey}`` plus the raw response.
        """
        body = {
            "serviceDeskId": str(service_desk_id),
            "requestTypeId": str(request_type_id),
            "requestFieldValues": {"summary": summary, "description": description},
        }
        created = self._request("POST", f"{_SDAPI}/request", json_data=body).json()
        issue_key = created.get("issueKey") or created.get("issueId") or ""
        if labels and issue_key:
            self.add_labels(issue_key, labels)
        return {"key": issue_key, **created}

    def get_transitions(self, issue_key: str) -> List[Dict[str, Any]]:
        """Return the workflow transitions currently available on an issue."""
        return self._request("GET", f"{_API}/issue/{issue_key}/transitions").json().get("transitions", [])

    def transition_issue(
        self,
        issue_key: str,
        transition_id: str,
        fields: Optional[Dict[str, Any]] = None,
        comment_adf: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Execute a workflow transition, optionally setting fields and adding a comment."""
        body: Dict[str, Any] = {"transition": {"id": str(transition_id)}}
        if fields:
            body["fields"] = fields
        if comment_adf is not None:
            body["update"] = {"comment": [{"add": {"body": comment_adf}}]}
        self._request("POST", f"{_API}/issue/{issue_key}/transitions", json_data=body)

    # ------------------------------------------------------------------ #
    # Search (JQL) - POST /search/jql (the legacy /search was removed 2025-05)
    # ------------------------------------------------------------------ #

    def search_jql(self, jql: str, fields: Optional[List[str]] = None, max_results: int = 1) -> List[Dict[str, Any]]:
        """Run a JQL query and return the matching issues (a single page)."""
        body: Dict[str, Any] = {"jql": jql, "maxResults": max_results}
        if fields:
            body["fields"] = fields
        return self._request("POST", f"{_API}/search/jql", json_data=body).json().get("issues", [])

    def find_open_issue_by_label(self, label: str) -> Optional[Dict[str, Any]]:
        """Return the most recent not-Done issue carrying *label*, or None."""
        jql = f'labels = "{label}" AND statusCategory != Done ORDER BY created DESC'
        issues = self.search_jql(jql, fields=["status", "summary"], max_results=1)
        return issues[0] if issues else None

    def find_any_issue_by_label(self, label: str) -> Optional[Dict[str, Any]]:
        """Return the most recent issue carrying *label* in any state, or None."""
        jql = f'labels = "{label}" ORDER BY created DESC'
        issues = self.search_jql(jql, fields=["status", "summary"], max_results=1)
        return issues[0] if issues else None

    def find_resolve_transition(self, issue_key: str, status_name: str = "") -> Optional[Dict[str, Any]]:
        """Pick the transition that resolves an issue.

        Prefers a transition to *status_name* (case-insensitive) when given;
        otherwise the first transition whose target status is in Jira's "Done"
        category. Returns the transition dict (with ``id``/``name``), or None.
        """
        transitions = self.get_transitions(issue_key)
        wanted = status_name.strip().lower()
        if wanted:
            for tr in transitions:
                if (tr.get("to", {}).get("name", "") or "").lower() == wanted:
                    return tr
        for tr in transitions:
            if (tr.get("to", {}).get("statusCategory", {}).get("key", "") or "") == "done":
                return tr
        return None
