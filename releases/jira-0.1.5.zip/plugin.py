"""Jira plugin: raise/resolve Jira issues from LogicVein alerts.

Incident-only (capability ``alerts``): it contributes an alert handler for the
core ``/webhook/lvi-alert`` route and does no inventory sync. The inventory
``SyncPlugin`` hooks (``create_sync_engine`` / ``build_sync_config``) are not
applicable and raise ``NotImplementedError``; the host never calls them because
``inventory_sync`` is not declared in the manifest.
"""

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from src.plugin_api import SyncPlugin, load_plugin_config

from .client import JiraClient

logger = logging.getLogger(__name__)


class JiraPlugin(SyncPlugin):
    """Plugin that turns LVI alerts into Jira issues (Jira Cloud)."""

    def __init__(self) -> None:
        """Initialise the Jira plugin from its manifest.json."""
        self.config = load_plugin_config(Path(__file__).parent)

    def create_client(self, credentials: Dict[str, Any]) -> JiraClient:
        """Create an authenticated Jira client from credentials or env vars."""
        kwargs: Dict[str, Any] = {}
        if credentials.get("ignore_env_vars"):
            kwargs["ignore_env_vars"] = True
        if credentials.get("instance"):
            kwargs["instance"] = credentials["instance"]
        if credentials.get("email"):
            kwargs["email"] = credentials["email"]
        token = credentials.get("api_token") or credentials.get("token")
        if token:
            kwargs["api_token"] = token
        return JiraClient(**kwargs)

    def test_connection(self, credentials: Dict[str, Any]) -> Tuple[bool, str]:
        """Verify the Jira credentials authenticate against the site."""
        try:
            if self.create_client(credentials).test_connection():
                return True, "Connected to Jira successfully"
            return False, "Connection test failed - check base URL, email, and API token"
        except Exception as e:
            return False, f"Connection failed: {e}"

    def create_sync_engine(self, lvi_client: Any, target_client: Any, sync_config: Dict[str, Any]) -> Any:
        """Not applicable: Jira is incident-only, with no inventory sync engine."""
        raise NotImplementedError("The Jira plugin does not provide inventory sync")

    def build_sync_config(self, yaml_config: Dict[str, Any], timestamp: Optional[str] = None) -> Dict[str, Any]:
        """Not applicable: Jira is incident-only, with no inventory sync config."""
        raise NotImplementedError("The Jira plugin does not provide inventory sync")

    def get_background_services(self) -> List[Any]:
        """Register the alert handler (no long-lived services)."""
        from . import services

        return services.build_services()

    def get_status_detail(self, config: Dict[str, Any]) -> str:
        """Return a one-line status string for the UI header."""
        project = config.get("jira", {}).get("project_key", "")
        return f"Project: {project}" if project else ""
