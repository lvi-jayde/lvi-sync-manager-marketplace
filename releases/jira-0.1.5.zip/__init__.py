"""Jira incident-sync plugin (raise/resolve Jira issues from LVI alerts)."""
