"""Background services contributed by the ServiceNow plugin.

The config-change detection component runs in one of two mutually exclusive modes
(change_detection.mode): a WebSocket event-bus watcher or a REST poller.
``build_services`` constructs the backend the current settings ask for and
registers the ServiceNow event/alert/change handlers. From there the host's
registry-owned service container owns the running instance's lifecycle, so this
plugin keeps no service references of its own: the tabs and the change handler
read live status back through the thin accessors below, which delegate to that
container via ``src.plugin_api``.
"""

from typing import Any, List, Optional


def build_services() -> List[Any]:
    """Build the background services enabled by configuration and register handlers.

    Reentrant: the host calls it again when detection settings change (a
    websocket<->poll switch, or ``features.alerts`` toggled). It drops the
    websocket-only event handlers and re-registers the alert/change handlers
    idempotently, then constructs the backend the current settings select. The
    returned instances are owned by the host's service container from here.

    Also registers the ServiceNow handlers for core-owned event sources: the LVI
    alert handler (for the core /webhook/lvi-alert route) and, when change
    detection is enabled, the config-change incident creator.
    """
    from src.plugin_api import get_app_settings

    from .settings import get_change_detection_settings

    # Drop the websocket-only event handlers so a poll<->websocket switch does not
    # leave stale handlers registered; the alert/change handlers below re-register
    # idempotently.
    _unregister_event_handlers()

    # Register the LVI alert handler when features.alerts is on (capability
    # "alerts"). The core /webhook/lvi-alert route fans events out to it; this is
    # independent of config-change detection below.
    if get_app_settings().get("features", {}).get("alerts", True):
        from src.plugin_api import register_alert_handler

        from .webhook.alert_incident import get_alert_handler

        register_alert_handler(get_alert_handler())

    cfg = get_change_detection_settings()
    if not cfg.get("enabled", False):
        return []

    # Core detects config changes and emits ConfigChangeEvents; our incident
    # creator consumes them in either detection mode.
    from src.plugin_api import register_change_handler

    from .change_detection.incident import get_incident_creator

    register_change_handler(get_incident_creator())

    if cfg.get("mode", "websocket") == "websocket":
        from src.plugin_api import (
            EventBusWatcher,
            event_bus_client,
            get_websocket_detector,
            register_event_handler,
        )

        from .event_bus.handler import get_handler as get_job_completion_handler

        # App-level (admin-only) toggle: subscribe to every LogicVein event topic
        # for the Event Bus tab, not just the config-change topics we act on.
        subscribe_all = bool(get_app_settings().get("event_bus", {}).get("subscribe_all_events", False))
        topics = event_bus_client.ALL_TOPICS if subscribe_all else event_bus_client.CHANGE_TOPICS

        # The core watcher produces raw events; the core detector turns backup
        # events into ConfigChangeEvents, and our handler bridges job completion.
        register_event_handler(get_websocket_detector())
        register_event_handler(get_job_completion_handler())
        return [EventBusWatcher(topics=topics)]

    from src.plugin_api import ConfigChangePoller

    return [ConfigChangePoller()]


def services_match_config() -> bool:
    """Whether the running detection backend matches the saved configuration.

    Delegates to the host: ``False`` means a setting that selects which service
    runs was changed since the services were built, so the Config Change tab
    shows a "restart to apply" banner.
    """
    from src.plugin_api import service_config_matches

    return service_config_matches()


def active_watcher() -> Optional[Any]:
    """Return the running event-bus watcher, if websocket mode is active."""
    from src.plugin_api import running_plugin_service

    return running_plugin_service("snow", "EventBusWatcher")


def active_poller() -> Optional[Any]:
    """Return the running config-change poller, if poll mode is active."""
    from src.plugin_api import running_plugin_service

    return running_plugin_service("snow", "ConfigChangePoller")


def _unregister_event_handlers() -> None:
    """Drop the websocket-only event handlers (idempotent; safe in any mode)."""
    try:
        from src.plugin_api import get_websocket_detector, unregister_event_handler

        from .event_bus.handler import get_handler as get_job_completion_handler

        unregister_event_handler(get_websocket_detector())
        unregister_event_handler(get_job_completion_handler())
    except Exception:
        pass  # best-effort cleanup; never block a rebuild
