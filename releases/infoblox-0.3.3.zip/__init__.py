"""Infoblox IPAM sync plugin."""

from .plugin import InfobloxPlugin

__all__ = ["InfobloxPlugin"]
