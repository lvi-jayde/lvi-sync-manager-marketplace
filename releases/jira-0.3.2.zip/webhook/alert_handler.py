"""Jira alert handler: raise/resolve Jira issues from LVI AlertEvents.

Registered with the core alert dispatch (``register_alert_handler``), this
handler is called by the core ``/webhook/lvi-alert`` route with each
:class:`AlertEvent`. On the first violation it creates a Jira issue tagged with a
``lvi-<hash>`` label; repeat violations add a (flood-suppressed) comment; on
clear it transitions the issue to a Done status and comments. Correlation is the
label (Jira has no native correlation field), found via JQL - so it survives
restarts without local state.

Exceptions propagate to the core route, which maps them to 502/500 so LogicVein
retries delivery.
"""

import logging
from datetime import datetime
from typing import Any, Dict, Optional

from src.plugin_api import AlertEvent
from src.plugin_api import webhook_store as store

from .. import adf
from ..settings import get_jira_client, get_jira_settings

logger = logging.getLogger(__name__)

_SUMMARY_MAX = 255  # Jira summary length limit
_PLUGIN_ID = "jira"  # tags webhook events so the UI can filter the log per plugin


def _log_event(**kwargs: Any) -> None:
    """Record a webhook event tagged with this plugin's id."""
    store.log_event(plugin=_PLUGIN_ID, **kwargs)


def _label(alert_hash: str) -> str:
    """The correlation label for an LVI alert hash (Jira labels disallow spaces)."""
    return f"lvi-{alert_hash}"


def _build_summary(payload: AlertEvent) -> str:
    sev = (payload.severity or "alert").upper()
    node = payload.node or "unknown node"
    msg = payload.message or "violation"
    return f"[LVI] {sev} - {msg} on {node}"[:_SUMMARY_MAX]


def _build_description(payload: AlertEvent) -> Dict[str, Any]:
    rows = [
        ("Severity", adf.text(payload.severity)),
        ("Message", adf.text(payload.message)),
        ("Node", adf.text(payload.node)),
        ("Occurrences", adf.text(payload.occurrences)),
        ("Violation Status", adf.text(payload.violation_status)),
        ("Updated At", adf.text(payload.updated_at)),
        ("Correlation", adf.text(payload.hash)),
    ]
    content = [adf.detail_table(rows)]
    if payload.link:
        content.append(adf.paragraph(adf.link("Open in LogicVein", payload.link)))
    return adf.doc(*content)


def _build_description_text(payload: AlertEvent) -> str:
    """Plain-text description for the JSM Service Desk API (it does not accept ADF)."""
    lines = [
        f"Severity: {payload.severity}",
        f"Message: {payload.message}",
        f"Node: {payload.node}",
        f"Occurrences: {payload.occurrences}",
        f"Violation Status: {payload.violation_status}",
        f"Updated At: {payload.updated_at}",
        f"Correlation: {payload.hash}",
    ]
    if payload.link:
        lines.append(f"Open in LogicVein: {payload.link}")
    return "\n".join(lines)


class JiraAlertHandler:
    """Alert handler that raises/resolves Jira issues from LVI AlertEvents."""

    def __call__(self, event: AlertEvent, ts_out: Optional[datetime] = None) -> Dict[str, Any]:
        """Process one AlertEvent and return a result dict."""
        jira = get_jira_client()
        dst = jira.base_url
        if event.action == "raise":
            result = _handle_raise(jira, event, dst=dst, ts_out=ts_out)
        else:
            result = _handle_resolve(jira, event, dst=dst, ts_out=ts_out)
        # The core route stamps the shared inbound row with this id so it shows
        # in the Jira event log alongside the OUT rows logged above.
        result["plugin"] = _PLUGIN_ID
        return result


_handler: Optional[JiraAlertHandler] = None


def get_alert_handler() -> JiraAlertHandler:
    """Return the module-level singleton alert handler (created on first use)."""
    global _handler
    if _handler is None:
        _handler = JiraAlertHandler()
    return _handler


def _min_update_minutes() -> int:
    try:
        return int(get_jira_settings().get("lvi_alerts", {}).get("min_update_minutes", 5))
    except Exception:
        # Broad on purpose: get_jira_settings() reads YAML config, which can fail
        # in varied ways; any read/parse problem defaults the interval to 5.
        return 5


def _jsm_ids() -> tuple:
    """Return the configured (service_desk_id, request_type_id) JSM pair, stripped."""
    cfg = get_jira_settings().get("jira", {})
    return str(cfg.get("service_desk_id", "") or "").strip(), str(cfg.get("request_type_id", "") or "").strip()


def _handle_raise(jira: Any, payload: AlertEvent, dst: str = "", ts_out: Optional[datetime] = None) -> Dict[str, Any]:
    """Create a Jira issue, or comment on an existing open one for the same alert."""
    label = _label(payload.hash)
    existing = jira.find_open_issue_by_label(label)
    sd_id, rt_id = _jsm_ids()

    if existing:
        key = existing["key"]
        title = existing.get("fields", {}).get("summary", "") or _build_summary(payload)
        if store.should_update(payload.hash, _min_update_minutes()):
            jira.add_comment(
                key,
                adf.comment(
                    f"Ongoing violation detected by LogicVein. "
                    f"Occurrences: {payload.occurrences or '?'}; "
                    f"Violation Status: {payload.violation_status or '?'}; "
                    f"Updated At: {payload.updated_at or '?'}."
                ),
            )
            # Retrofit the request type on an issue raised before JSM mode was
            # configured (created via plain /issue, so invisible to JSM queues).
            if sd_id and rt_id:
                try:
                    jira.set_request_type(key, rt_id)
                except Exception as exc:
                    logger.warning("Could not set request type on existing Jira issue %s: %s", key, exc)
            _log_event(
                direction="sync mgr→jira",
                action="update",
                node=payload.node,
                correlation_hash=payload.hash,
                severity=payload.severity,
                result="updated",
                src="Sync Manager",
                dst=dst,
                incident=key,
                status_code=200,
                timestamp=ts_out,
                description=title,
            )
            logger.info("Commented on existing Jira issue %s for hash=%s", key, payload.hash)
            return {"result": "updated", "issue": key, "description": title}
        logger.debug("Suppressed comment for issue %s (within interval) hash=%s", key, payload.hash)
        return {"result": "suppressed", "issue": key, "description": title}

    cfg = get_jira_settings().get("jira", {})
    if sd_id and rt_id:
        # JSM mode: raise a customer request so the issue lands in the service
        # desk's queues (a plain /issue create sets no request type and stays
        # invisible to queues that filter on it). Plain-text description; the
        # correlation label is applied by create_request after creation.
        created = jira.create_request(
            service_desk_id=sd_id,
            request_type_id=rt_id,
            summary=_build_summary(payload),
            description=_build_description_text(payload),
            labels=[label],
        )
    else:
        fields: Dict[str, Any] = {
            "project": {"key": cfg.get("project_key", "")},
            "issuetype": {"name": cfg.get("issue_type", "Incident")},
            "summary": _build_summary(payload),
            "description": _build_description(payload),
            "labels": [label],
        }
        created = jira.create_issue(fields)
    key = created.get("key", created.get("id", "unknown"))
    title = _build_summary(payload)
    _log_event(
        direction="sync mgr→jira",
        action="create",
        node=payload.node,
        correlation_hash=payload.hash,
        severity=payload.severity,
        result="created",
        src="Sync Manager",
        dst=dst,
        incident=key,
        status_code=201,
        timestamp=ts_out,
        description=title,
    )
    logger.info("Created Jira issue %s for hash=%s", key, payload.hash)
    return {"result": "created", "issue": key, "description": title}


def _resolve_statuses(cfg: Dict[str, Any]) -> list:
    """Normalise resolve_status from the Jira config to an ordered list of status names.

    Accepts a string ("Completed, Closed"), a list (["Completed", "Closed"]), or
    empty/blank. An empty result means "use the first Done-category transition"
    (legacy single-step behaviour).
    """
    raw = cfg.get("resolve_status", "")
    if isinstance(raw, list):
        statuses = [str(s).strip() for s in raw if str(s).strip()]
    elif isinstance(raw, str) and raw.strip():
        statuses = [s.strip() for s in raw.split(",") if s.strip()]
    else:
        statuses = []
    return statuses or [""]  # empty string = Done-category fallback


def _handle_resolve(jira: Any, payload: AlertEvent, dst: str = "", ts_out: Optional[datetime] = None) -> Dict[str, Any]:
    """Transition the open Jira issue for this alert through the configured status chain."""
    label = _label(payload.hash)
    existing = jira.find_open_issue_by_label(label)

    if not existing:
        any_issue = jira.find_any_issue_by_label(label)
        result = "already_resolved" if any_issue else "not_found"
        key = any_issue.get("key", "") if any_issue else ""
        title = (any_issue.get("fields", {}).get("summary", "") if any_issue else "") or _build_summary(payload)
        logger.info("Resolve for hash=%s: %s%s", payload.hash, result, f" ({key})" if key else "")
        _log_event(
            direction="sync mgr→jira",
            action="resolve",
            node=payload.node,
            correlation_hash=payload.hash,
            severity=payload.severity,
            result=result,
            src="Sync Manager",
            dst=dst,
            incident=key,
            status_code=200 if any_issue else 404,
            timestamp=ts_out,
            description=title,
        )
        return {"result": result, "issue": key, "description": title}

    key = existing["key"]
    title = existing.get("fields", {}).get("summary", "") or _build_summary(payload)
    cfg = get_jira_settings().get("jira", {})
    statuses = _resolve_statuses(cfg)
    resolution = (cfg.get("resolution") or "").strip()
    n = len(statuses)

    for i, status_name in enumerate(statuses):
        is_last = i == n - 1
        transition = jira.find_resolve_transition(key, status_name)
        if not transition:
            label_str = f"'{status_name}'" if status_name else "Done-category"
            logger.error("No transition to %s available on Jira issue %s (hash=%s)", label_str, key, payload.hash)
            _log_event(
                direction="sync mgr→jira",
                action="resolve",
                node=payload.node,
                correlation_hash=payload.hash,
                severity=payload.severity,
                result="no_transition",
                src="Sync Manager",
                dst=dst,
                incident=key,
                error=f"no transition to {label_str} is available",
                status_code=409,
                timestamp=ts_out,
                description=title,
            )
            return {"result": "no_transition", "issue": key, "description": title}

        fields = None
        if is_last and resolution:
            fields = {"resolution": {"name": resolution}}
        comment_adf = None
        if is_last:
            comment_adf = adf.comment(
                f"LogicVein cleared this alert. Violation Status: {payload.violation_status or '?'}; "
                f"Updated At: {payload.updated_at or '?'}."
            )
        jira.transition_issue(key, transition["id"], fields=fields, comment_adf=comment_adf)
        if not is_last:
            dest = (transition.get("to") or {}).get("name", status_name)
            logger.info("Transitioned Jira issue %s to '%s' (step %d/%d, hash=%s)", key, dest, i + 1, n, payload.hash)

    store.clear_update_tracking(payload.hash)
    _log_event(
        direction="sync mgr→jira",
        action="resolve",
        node=payload.node,
        correlation_hash=payload.hash,
        severity=payload.severity,
        result="resolved",
        src="Sync Manager",
        dst=dst,
        incident=key,
        status_code=200,
        timestamp=ts_out,
        description=title,
    )
    logger.info("Resolved Jira issue %s (final status '%s') for hash=%s", key, statuses[-1] or "Done", payload.hash)
    return {"result": "resolved", "issue": key, "description": title}
