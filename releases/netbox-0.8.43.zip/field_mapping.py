"""Pure LogicVein -> NetBox field/value transforms.

Extracted from ``sync.py`` so the value-mapping logic (interface-type mapping,
custom/lifecycle/LVI custom-field building, timestamp formatting) is a small,
side-effect-free unit that can be tested directly without constructing the full
sync engine. Each function takes the LVI input (and the relevant config mapping
where needed) and returns plain data - no NetBox/LVI API calls, no ``self``.
``LogicVeinNetBoxSync`` keeps thin methods that delegate here.
"""

import logging
from datetime import datetime
from typing import Any, Dict, Iterable, Optional

# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import format_epoch_ms  # pyright: ignore[reportMissingImports]

logger = logging.getLogger(__name__)


def map_interface_type(lvi_interface: Dict[str, Any]) -> str:
    """Map an LVI interface's speed/type/name to a NetBox interface type string."""
    speed = lvi_interface.get("speed", 0)
    iface_type = lvi_interface.get("type", "").lower()
    name = lvi_interface.get("name", "").lower()

    # Check for virtual interfaces first
    if "loopback" in name or "lo" in iface_type:
        return "virtual"
    if "tunnel" in name or "tun" in iface_type:
        return "virtual"
    if "vlan" in name or "vlan" in iface_type:
        return "virtual"
    if "management" in name or "mgmt" in name:
        return "virtual"

    # Map by speed (in bps)
    if speed:
        try:
            speed_int = int(speed)
            if speed_int >= 100_000_000_000:  # 100 Gbps
                return "100gbase-x-qsfp28"
            elif speed_int >= 40_000_000_000:  # 40 Gbps
                return "40gbase-x-qsfpp"
            elif speed_int >= 25_000_000_000:  # 25 Gbps
                return "25gbase-x-sfp28"
            elif speed_int >= 10_000_000_000:  # 10 Gbps
                return "10gbase-x-sfpp"
            elif speed_int >= 1_000_000_000:  # 1 Gbps
                return "1000base-t"
            elif speed_int >= 100_000_000:  # 100 Mbps
                return "100base-tx"
            else:  # 10 Mbps or slower
                return "other"
        except (ValueError, TypeError):
            pass

    # Default based on interface name patterns
    if "gigabit" in name or "gi" in name[:3]:
        return "1000base-t"
    if "tengig" in name or "te" in name[:3]:
        return "10gbase-x-sfpp"
    if "fastethernet" in name or "fa" in name[:3]:
        return "100base-tx"
    if "ethernet" in name or "eth" in name[:4]:
        return "1000base-t"

    # Default to 1000base-t for physical interfaces
    return "1000base-t"


def build_custom_fields(lvi_device: Dict[str, Any], custom_field_mapping: Dict[str, str]) -> Dict[str, Any]:
    """Map configured LVI fields onto NetBox custom-field names (skipping empties)."""
    custom_fields: Dict[str, Any] = {}

    if not custom_field_mapping:
        return custom_fields

    for lvi_field, netbox_field in custom_field_mapping.items():
        value = lvi_device.get(lvi_field)
        if value:
            custom_fields[netbox_field] = value
            logger.debug("Mapped custom field: %s=%s -> %s", lvi_field, value, netbox_field)

    return custom_fields


def build_lifecycle_fields(lvi_device: Dict[str, Any], lifecycle_field_mapping: Dict[str, str]) -> Dict[str, Any]:
    """Build NetBox lifecycle custom fields, converting epoch timestamps to ISO dates."""
    custom_fields: Dict[str, Any] = {}

    if not lifecycle_field_mapping:
        return custom_fields

    # Map LVI lifecycle fields to NetBox custom field names
    lifecycle_mapping = {
        "endOfSale": lifecycle_field_mapping.get("end_of_sale", ""),
        "endOfLife": lifecycle_field_mapping.get("end_of_life", ""),
        "softwareEndOfSale": lifecycle_field_mapping.get("sw_end_of_sale", ""),
        "softwareEndOfLife": lifecycle_field_mapping.get("sw_end_of_life", ""),
    }

    for lvi_field, netbox_field in lifecycle_mapping.items():
        if not netbox_field:
            continue

        date_str = format_epoch_ms(lvi_device.get(lvi_field), date_only=True)
        if date_str:
            custom_fields[netbox_field] = date_str
            logger.debug("Mapped lifecycle field: %s -> %s=%s", lvi_field, netbox_field, date_str)

    return custom_fields


def normalize_vrf_name(raw: Optional[str], aliases: Iterable[str]) -> Optional[str]:
    """Fold a blank or vendor-spelled "global routing table" VRF name onto None.

    Unlike EfficientIP's space_partition.normalize_vrf() (which always
    returns a string, falling back to a configured default_vrf_name since
    SOLIDserver's VRF Manager needs some container value), NetBox's VRF
    field on an IP address is genuinely nullable - "no VRF" is None here,
    not a fallback object to create. Matching is case-insensitive and
    whitespace-trimmed, same as EfficientIP's version.

    Args:
        raw: The raw VRF name as reported by LogicVein.
        aliases: Vendor spellings of the global routing table to fold to None.

    Returns:
        The normalized VRF name, or None for the global table.
    """
    cleaned = (raw or "").strip()
    if not cleaned:
        return None
    if cleaned.casefold() in {a.strip().casefold() for a in aliases if a and a.strip()}:
        return None
    return cleaned


def format_timestamp(epoch_ms: Optional[int]) -> str:
    """Format epoch milliseconds as an ISO timestamp string ("" when falsy/invalid)."""
    if not epoch_ms:
        return ""
    try:
        dt = datetime.fromtimestamp(epoch_ms / 1000)
        return dt.isoformat()
    except (ValueError, TypeError, OSError):
        return ""
