"""ServiceNow incident creator: a ConfigChangeEvent handler.

Registered with the core change-detection dispatch (``register_change_handler``),
this handler receives each detected :class:`ConfigChangeEvent` together with an
initialised LVI client. It fetches per-path word diffs, applies the
``minimum_changed_lines`` suppression, computes a deterministic correlation_id,
deduplicates against ServiceNow, looks up the caller and CMDB CI, and creates the
incident. It returns True when an incident was created (so the detection cycle
can count it).

This is the ServiceNow-specific half of config-change detection; all the
target-agnostic work (LVI history fetch, coalescing, dedup, cycle recording)
lives in core.
"""

import difflib
import hashlib
import logging
import os
from typing import Any, Dict, List, Optional

from src.plugin_api import ConfigChangeEvent, webhook_store

from ..settings import get_change_detection_settings, get_snow_client
from ..webhook.alert_incident import _resolve_caller_sys_id

logger = logging.getLogger(__name__)


def _log_event(**kwargs):
    """Record a webhook event tagged with this plugin's id (UI per-plugin filter)."""
    webhook_store.log_event(plugin="snow", **kwargs)


_STATE_NEW = 1

# Cap the diff text embedded in the incident. A large device (e.g. an F5 BIG-IP)
# can produce a multi-megabyte config diff; ServiceNow rejects REST payloads over
# ~10 MB ("Rejected large REST payload"), and an incident description that large
# is unusable anyway. Truncate per-path and overall, well under the SNOW limit.
_MAX_DIFF_CHARS = 20000
_MAX_DESCRIPTION_CHARS = 40000
_TRUNCATION_NOTE = "  ... [diff truncated - see LogicVein for the full change]"


def _count_changed_lines(segments: List[Dict[str, Any]]) -> int:
    """Return the number of config lines that differ between old and new revisions.

    Reconstructs the full old and new texts from the word-diff segments, then
    counts positional line differences.  A single modified line counts as 1.
    Pure additions and pure deletions each count as 1 per line.
    """
    old_text, new_text = "", ""
    for s in segments:
        op = s.get("op", "EQUAL")
        text = s.get("text", "")
        if op == "EQUAL":
            old_text += text
            new_text += text
        elif op == "DELETE":
            old_text += text
        elif op == "ADD":
            new_text += text
        elif op == "CHANGE":
            old_text += text
            new_text += s.get("newText", "")

    old_lines = old_text.splitlines()
    new_lines = new_text.splitlines()
    changed = sum(1 for a, b in zip(old_lines, new_lines) if a != b)
    changed += abs(len(old_lines) - len(new_lines))
    return changed


def _format_diff_for_description(segments: List[Dict[str, Any]], max_chars: int = _MAX_DIFF_CHARS) -> str:
    """Render a config word-diff as a line-level +/- change summary.

    The LVI word-diff returns word/region-level segments; rendering each segment
    as its own +/- line splits a single changed config line across several lines
    (e.g. one banner edit shown as four lines). Instead, reconstruct the full old
    and new text from the segments and diff them per line, so one changed line
    shows as exactly one '-' and one '+'. Unchanged lines are omitted. Output is
    capped at *max_chars* so a huge config diff cannot bloat the incident payload
    past ServiceNow's REST limit.
    """
    old_text, new_text = "", ""
    for s in segments:
        op = s.get("op", "EQUAL")
        text = s.get("text", "")
        if op == "EQUAL":
            old_text += text
            new_text += text
        elif op == "DELETE":
            old_text += text
        elif op == "ADD":
            new_text += text
        elif op == "CHANGE":
            old_text += text
            new_text += s.get("newText", "")

    old_lines = old_text.splitlines()
    new_lines = new_text.splitlines()

    out: List[str] = []
    total = 0
    truncated = False

    def _add(line: str) -> None:
        nonlocal total, truncated
        remaining = max_chars - total
        if len(line) >= remaining:  # a single huge line (e.g. a config with no breaks)
            out.append(line[: max(0, remaining)])
            total = max_chars
            truncated = True
        else:
            out.append(line)
            total += len(line) + 1

    matcher = difflib.SequenceMatcher(None, old_lines, new_lines, autojunk=False)
    for op, i1, i2, j1, j2 in matcher.get_opcodes():
        if op == "equal":
            continue
        if op in ("replace", "delete"):
            for line in old_lines[i1:i2]:
                if line.strip():
                    _add(f"  - {line.rstrip()}")
                if truncated:
                    break
        if not truncated and op in ("replace", "insert"):
            for line in new_lines[j1:j2]:
                if line.strip():
                    _add(f"  + {line.rstrip()}")
                if truncated:
                    break
        if truncated:
            break

    if truncated:
        out.append(_TRUNCATION_NOTE)
    return "\n".join(out)


def _lookup_snow_ci(snow: Any, hostname: str, ip: str, cache: Dict[str, str]) -> str:
    """Return the sys_id of the CMDB CI matching *hostname* or *ip*, or '' on miss.

    Queries the ``cmdb_ci`` base table: hostname first (``name`` field), then IP
    (``ip_address`` field).  Results are cached in *cache*.
    """
    for field, value in (("name", hostname), ("ip_address", ip)):
        if not value or value == "unknown":
            continue
        key = f"ci:{value}"
        if key in cache:
            return cache[key]
        try:
            rows = snow.query_table("cmdb_ci", f"{field}={value}", fields=["sys_id"], limit=1)
            if rows:
                sys_id = rows[0].get("sys_id", "")
                cache[key] = sys_id
                return sys_id
        except Exception as exc:
            logger.debug("SNOW CI lookup failed for %s=%s: %s", field, value, exc)
    return ""


class SnowIncidentCreator:
    """Config-change handler that creates a ServiceNow incident per change."""

    def __init__(self) -> None:
        # CI/caller lookups are cached across events for the life of the process.
        self._lookup_cache: Dict[str, str] = {}

    def __call__(self, event: ConfigChangeEvent, lvi: Any) -> bool:
        """Create a SNOW incident for *event*. Return True if one was created."""
        try:
            snow = get_snow_client()
        except Exception as exc:
            logger.error("SnowIncidentCreator: failed to create SNOW client: %s", exc)
            snow_dst = os.getenv("SNOW_INSTANCE", "")
            _log_event(
                direction="sync mgr→snow",
                action="config_change",
                node=event.hostname or event.ip_address or "?",
                correlation_hash=event.event_key,
                severity="",
                result="snow_error",
                src="Sync Manager",
                dst=snow_dst,
                error=f"SNOW client init failed: {exc}",
                status_code=503,
                event_type="config_change",
            )
            return False

        snow_cfg = get_change_detection_settings().get("snow_incident", {})
        snow_dst = os.getenv("SNOW_INSTANCE", "")
        try:
            number = self._create_incident(snow, lvi, event, snow_cfg, snow_dst)
        except Exception as exc:
            node = event.hostname or event.ip_address or "?"
            logger.error("SnowIncidentCreator: failed to create SNOW incident for %s: %s", node, exc)
            _log_event(
                direction="sync mgr→snow",
                action="config_change",
                node=node,
                correlation_hash=event.event_key,
                severity="",
                result="error",
                src="Sync Manager",
                dst=snow_dst,
                error=str(exc),
                status_code=500,
                event_type="config_change",
            )
            return False
        return number is not None

    def _create_incident(
        self,
        snow: Any,
        lvi: Any,
        event: ConfigChangeEvent,
        snow_cfg: Dict[str, Any],
        snow_dst: str,
    ) -> Optional[str]:
        """Create a SNOW incident for a config change event.

        Returns:
            The created incident number (e.g. ``INC0001234``), or ``None`` if the
            incident already exists in SNOW or creation was suppressed.
        """
        hostname = event.hostname or event.ip_address or "unknown"
        ip = event.ip_address or ""
        network = event.managed_network or ""
        author = event.author or "unknown"
        changed_at = event.last_changed or ""
        paths = event.paths or []
        paths_str = ", ".join(paths) if paths else "unknown"

        short_description = f"[LVI] Config change on {hostname}"

        # Build the stable header first so we can compute the correlation_id before
        # fetching diffs (diffs are optional and may not always be available).
        description_header = [
            "LogicVein Configuration Change Detected",
            "=" * 40,
            f"Device:       {hostname}",
            f"IP Address:   {ip}",
            f"Network:      {network}",
            f"Changed At:   {changed_at}",
            f"Author:       {author}",
            f"Config Paths: {paths_str}",
        ]

        # Correlation ID: SHA-256 of the stable header (device + timestamp + paths).
        # Deterministic across restarts so SNOW can deduplicate even if the local
        # seen_events DB is wiped (e.g. fresh Docker volume).
        correlation_id = hashlib.sha256("\n".join(description_header).encode()).hexdigest()[:40]

        # Check SNOW for an existing incident before doing any expensive work.
        try:
            existing = snow.query_table(
                "incident", f"correlation_id={correlation_id}", fields=["number", "state"], limit=1
            )
            if existing:
                number = existing[0].get("number", "?")
                logger.info("SnowIncidentCreator: %s already in SNOW as %s - skipping", hostname, number)
                return None
        except Exception as exc:
            logger.warning(
                "SnowIncidentCreator: SNOW dedup check failed for %s (%s) - proceeding: %s",
                hostname,
                correlation_id,
                exc,
            )

        description_lines = list(description_header)

        _NO_DIFF_EXTS = (".gz", ".tgz", ".tar", ".zip", ".bak", ".dat")
        min_lines = int(snow_cfg.get("minimum_changed_lines", 1))
        total_changed_lines = 0
        diffs_fetched = False

        # Append per-path diffs - skip gracefully if the API call fails.
        for pd in event.path_details:
            path = pd.get("path", "")
            prev_change = pd.get("prev_change", "")
            if not path or not prev_change or not changed_at:
                continue
            if path.lower().endswith(_NO_DIFF_EXTS):
                continue
            try:
                segments = lvi.get_config_revision_word_diff(
                    ip_address=ip,
                    timestamp1=prev_change,
                    timestamp2=changed_at,
                    network=network,
                    config_path=path,
                )
                diffs_fetched = True
                total_changed_lines += _count_changed_lines(segments)
                diff_text = _format_diff_for_description(segments)
                if diff_text:
                    description_lines.append("")
                    description_lines.append(f"--- {path} ---")
                    description_lines.append(diff_text)
            except Exception as exc:
                logger.debug("Could not fetch diff for %s %s: %s", hostname, path, exc)

        # Suppress incident creation when we have diff data but the change is
        # below the configured minimum.  If no diffs could be fetched (first
        # revision, binary paths, etc.) we always proceed.
        if diffs_fetched and total_changed_lines < min_lines:
            logger.info(
                "SnowIncidentCreator: skipping %s - %d changed line(s) < minimum_changed_lines=%d",
                hostname,
                total_changed_lines,
                min_lines,
            )
            return None

        description = "\n".join(description_lines)
        # Final guard: keep the whole description (many paths combined) well under
        # ServiceNow's REST payload limit even if individual diffs were each small.
        if len(description) > _MAX_DESCRIPTION_CHARS:
            description = description[:_MAX_DESCRIPTION_CHARS].rstrip() + "\n" + _TRUNCATION_NOTE

        # Look up caller and CI in SNOW - fail gracefully if not found.
        caller_sys_id = _resolve_caller_sys_id(snow)
        ci_sys_id = _lookup_snow_ci(snow, hostname, ip, self._lookup_cache)

        incident_data: Dict[str, Any] = {
            "short_description": short_description,
            "description": description,
            "correlation_id": correlation_id,
            "correlation_display": "LogicVein Config Change",
            "category": snow_cfg.get("category", "Network"),
            "subcategory": snow_cfg.get("subcategory", "Network Monitoring"),
            "urgency": str(snow_cfg.get("urgency", 2)),
            "impact": str(snow_cfg.get("impact", 2)),
            "state": str(_STATE_NEW),
        }
        if caller_sys_id:
            incident_data["caller_id"] = caller_sys_id
        if ci_sys_id:
            incident_data["cmdb_ci"] = ci_sys_id

        created = snow.create_record("incident", incident_data)
        number = created.get("number", created.get("sys_id", "unknown"))
        node_label = f"{hostname} ({ip})" if ip and ip != hostname else hostname

        _urgency_map = {1: "High", 2: "Medium", 3: "Low"}
        _severity = _urgency_map.get(int(snow_cfg.get("urgency", 2)), "Medium")

        _log_event(
            direction="sync mgr→snow",
            action="config_change",
            node=node_label,
            correlation_hash=correlation_id,
            severity=_severity,
            result="created",
            src="LogicVein",
            dst=snow_dst,
            incident=number,
            status_code=201,
            event_type="config_change",
        )
        logger.info(
            "SnowIncidentCreator: created SNOW incident %s for config change on %s (author=%s paths=%s)",
            number,
            hostname,
            author,
            paths_str,
        )
        return number


_creator: Optional[SnowIncidentCreator] = None


def get_incident_creator() -> SnowIncidentCreator:
    """Return the module-level singleton incident creator (created on first use)."""
    global _creator
    if _creator is None:
        _creator = SnowIncidentCreator()
    return _creator
