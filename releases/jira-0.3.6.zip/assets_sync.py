"""LogicVein -> Jira Assets inventory sync.

Syncs LVI devices into a pre-existing Jira Assets object type (one object per
device), mirroring the ServiceNow CMDB and NetBox/Infoblox inventory syncs. For
each device it builds the object attributes from a configured field mapping
(attribute name -> LVI device field), finds an existing object by the correlation
attribute via AQL, and updates it or creates a new one.

The target object schema + object type + attributes must already exist (a Jira
admin sets them up; see docs/dev_notes/JIRA_ASSETS_INVESTIGATION.md). The sync
resolves attribute names to ids at runtime and never creates schema structure.
"""

import logging
from typing import Any, Dict, Optional

from src.plugin_api import SyncCancelled, normalize_networks

logger = logging.getLogger(__name__)


class LogicVeinJiraAssetsSync:
    """Sync LogicVein devices into Jira Assets objects."""

    def __init__(self, lvi_client: Any, assets_client: Any, config: Optional[Dict[str, Any]] = None) -> None:
        """Initialise the sync.

        Args:
            lvi_client: LogicVein API client.
            assets_client: A ``JiraAssetsClient``.
            config: Sync config dict from ``build_sync_config`` (sync options +
                an ``assets`` sub-dict).
        """
        self.lvi_client = lvi_client
        self.assets_client = assets_client
        self.config = config or {}

        self.dry_run = self.config.get("dry_run", False)
        self.continue_on_error = self.config.get("continue_on_error", True)
        self.networks = normalize_networks(self.config.get("network", "Default"))

        a = self.config.get("assets", {}) or {}
        self.object_schema = a.get("object_schema", "")
        self.object_type = a.get("object_type", "Device")
        self.correlation_attribute = a.get("correlation_attribute", "Name")
        self.create_missing = a.get("create_missing", True)
        self.update_existing = a.get("update_existing", True)
        # {Assets attribute name -> LVI device field}
        self.field_mapping = a.get("field_mapping", {}) or {}

        self._cancel_token: Optional[Any] = None
        self._type_id: Optional[str] = None
        self._name_to_id: Dict[str, str] = {}

    def set_cancel_token(self, token: Any) -> None:
        """Set the cancellation token for this run."""
        self._cancel_token = token

    def _check_cancelled(self) -> None:
        if self._cancel_token and self._cancel_token.is_cancelled():
            raise SyncCancelled("Sync cancelled by user")

    # ------------------------------------------------------------------ #
    # Run                                                                  #
    # ------------------------------------------------------------------ #

    def sync(self) -> bool:
        """Execute the inventory sync. Returns True on success."""
        logger.info("=" * 70)
        logger.info("LogicVein -> Jira Assets inventory sync")
        logger.info("=" * 70)
        if self.dry_run:
            logger.info("DRY RUN - no objects will be written to Jira Assets")

        if not self.object_schema:
            logger.error("No assets.object_schema configured")
            return False

        try:
            self._check_cancelled()
            if not self.assets_client.test_connection():
                logger.error("Jira Assets connection test failed")
                return False

            schema_id = self.assets_client.find_schema_id(self.object_schema)
            if not schema_id:
                logger.error("Object schema '%s' not found in Jira Assets", self.object_schema)
                return False
            self._type_id = self.assets_client.find_object_type_id(schema_id, self.object_type)
            if not self._type_id:
                logger.error("Object type '%s' not found in schema '%s'", self.object_type, self.object_schema)
                return False
            self._name_to_id = self.assets_client.get_type_attributes(self._type_id)

            if self.correlation_attribute not in self._name_to_id:
                logger.error(
                    "Correlation attribute '%s' is not on object type '%s'",
                    self.correlation_attribute,
                    self.object_type,
                )
                return False
            if self.correlation_attribute not in self.field_mapping:
                logger.error("Correlation attribute '%s' is not in the field mapping", self.correlation_attribute)
                return False

            return self._sync_devices()
        except SyncCancelled:
            logger.warning("Sync cancelled")
            return False

    def _sync_devices(self) -> bool:
        net_label = ", ".join(self.networks) if self.networks else "all"
        logger.info("Fetching devices from LogicVein network(s): %s", net_label)
        try:
            devices = self.lvi_client.search_devices_in_network(network=self.networks)
        except Exception as exc:
            logger.error("Could not fetch devices from LogicVein: %s", exc)
            return False
        if not devices:
            logger.warning("No devices found in network(s): %s", net_label)
            return True
        logger.info("Found %d devices", len(devices))

        synced = 0
        errors = 0
        for device in devices:
            self._check_cancelled()
            try:
                if self._sync_device(device):
                    synced += 1
            except SyncCancelled:
                raise
            except Exception as exc:
                errors += 1
                logger.error("Error syncing device %s: %s", device.get("hostname") or device.get("ipAddress"), exc)
                if not self.continue_on_error:
                    return False
        logger.info("Assets sync complete: %d synced, %d errors", synced, errors)
        return errors == 0 or self.continue_on_error

    def _sync_device(self, device: Dict[str, Any]) -> bool:
        """Create or update one Assets object from an LVI device."""
        values: Dict[str, str] = {}
        for attr_name, lvi_field in self.field_mapping.items():
            v = device.get(lvi_field, "")
            values[attr_name] = str(v) if v is not None else ""

        corr_value = (values.get(self.correlation_attribute) or "").strip()
        if not corr_value:
            logger.warning(
                "Skipping device with empty '%s' (ip=%s)", self.correlation_attribute, device.get("ipAddress")
            )
            return False

        attributes = self.assets_client.build_attributes(self._name_to_id, values)
        existing_id = self.assets_client.find_object_id(self.object_type, self.correlation_attribute, corr_value)

        if self.dry_run:
            logger.info("[DRY RUN] Would %s Assets object for '%s'", "update" if existing_id else "create", corr_value)
            return True

        if existing_id:
            if not self.update_existing:
                logger.debug("Object for '%s' exists and update_existing is off; skipping", corr_value)
                return True
            self.assets_client.update_object(existing_id, self._type_id, attributes)
            logger.info("Updated Assets object %s for '%s'", existing_id, corr_value)
        else:
            if not self.create_missing:
                logger.debug("Object for '%s' missing and create_missing is off; skipping", corr_value)
                return True
            created = self.assets_client.create_object(self._type_id, attributes)
            logger.info("Created Assets object %s for '%s'", created.get("objectKey", created.get("id")), corr_value)
        return True
