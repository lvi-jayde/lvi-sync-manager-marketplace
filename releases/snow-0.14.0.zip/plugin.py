"""ServiceNow sync plugin implementation."""

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from src.plugin_api import SyncPlugin, load_plugin_config, normalize_networks

from .client import ServiceNowClient
from .sync import LogicVeinSnowSync

logger = logging.getLogger(__name__)


class ServiceNowPlugin(SyncPlugin):
    """Plugin for synchronising LogicVein device inventory to ServiceNow CMDB."""

    def __init__(self) -> None:
        """Initialise the ServiceNow plugin from its manifest.json."""
        self.config = load_plugin_config(Path(__file__).parent)

    # ------------------------------------------------------------------ #
    # SyncPlugin abstract method implementations                           #
    # ------------------------------------------------------------------ #

    def create_client(self, credentials: Dict[str, Any]) -> ServiceNowClient:
        """Create an authenticated ServiceNow client.

        Args:
            credentials: Dict with keys: instance, api_token, token, and
                         optionally ignore_env_vars.

        Returns:
            ServiceNowClient instance.
        """
        kwargs: Dict[str, Any] = {}
        if credentials.get("ignore_env_vars"):
            kwargs["ignore_env_vars"] = True
        if credentials.get("instance"):
            kwargs["instance"] = credentials["instance"]
        token = credentials.get("api_token") or credentials.get("token")
        if token:
            kwargs["api_token"] = token
        return ServiceNowClient(**kwargs)

    def create_sync_engine(
        self,
        lvi_client: Any,
        target_client: Any,
        sync_config: Dict[str, Any],
    ) -> LogicVeinSnowSync:
        """Create the CMDB sync engine.

        Args:
            lvi_client: LogicVein API client.
            target_client: ServiceNow client.
            sync_config: Config dict produced by build_sync_config().

        Returns:
            LogicVeinSnowSync instance.
        """
        return LogicVeinSnowSync(
            lvi_client=lvi_client,
            snow_client=target_client,
            config=sync_config,
        )

    def build_sync_config(
        self,
        yaml_config: Dict[str, Any],
        timestamp: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Build the runtime sync config from parsed YAML.

        Args:
            yaml_config: Full parsed YAML config dict.
            timestamp: Unused for ServiceNow (no CSV output).

        Returns:
            Config dict ready for LogicVeinSnowSync.
        """
        sync_cfg = yaml_config.get("sync", {})
        lvi_cfg = yaml_config.get("logicvein", {})
        snow_cfg = yaml_config.get("servicenow", {})
        cmdb_cfg = snow_cfg.get("cmdb", {})
        iface_cfg = snow_cfg.get("interfaces", {})

        return {
            "dry_run": sync_cfg.get("dry_run", False),
            "network": lvi_cfg.get("networks", "Default"),
            "continue_on_error": sync_cfg.get("continue_on_error", True),
            "cmdb": {
                "default_ci_table": cmdb_cfg.get("default_ci_table", "cmdb_ci_ip_router"),
                "ci_table_map": cmdb_cfg.get(
                    "ci_table_map",
                    {
                        "Router": "cmdb_ci_ip_router",
                        "Switch": "cmdb_ci_ip_switch",
                        "Firewall": "cmdb_ci_ip_firewall",
                    },
                ),
                "create_missing_cis": cmdb_cfg.get("create_missing_cis", True),
                "update_existing_cis": cmdb_cfg.get("update_existing_cis", True),
                "field_mapping": cmdb_cfg.get("field_mapping", {}),
                "custom_field_mapping": cmdb_cfg.get("custom_field_mapping", {}),
                "sync_mac_address": cmdb_cfg.get("sync_mac_address", True),
                "strip_domain_from_names": cmdb_cfg.get("strip_domain_from_names", True),
                "create_missing_reference_records": cmdb_cfg.get("create_missing_reference_records", True),
                "ip_conflict_policy": cmdb_cfg.get("ip_conflict_policy", "overwrite"),
                "mac_conflict_policy": cmdb_cfg.get("mac_conflict_policy", "overwrite"),
            },
            "interfaces": {
                "sync_interfaces": iface_cfg.get("sync_interfaces", False),
                "delete_stale_interfaces": iface_cfg.get("delete_stale_interfaces", False),
                "field_mapping": iface_cfg.get("field_mapping", {}),
            },
        }

    def test_connection(self, credentials: Dict[str, Any]) -> Tuple[bool, str]:
        """Test connectivity to the ServiceNow instance.

        Args:
            credentials: Dict with instance, username, password keys.

        Returns:
            Tuple of (success, message).
        """
        try:
            client = self.create_client(credentials)
            if client.test_connection():
                return True, "Connected to ServiceNow successfully"
            return False, "Connection test failed - check credentials"
        except Exception as e:
            return False, f"Connection failed: {e}"

    # ------------------------------------------------------------------ #
    # Optional overrides                                                   #
    # ------------------------------------------------------------------ #

    def get_status_detail(self, config: Dict[str, Any]) -> str:
        """Return a one-line status string for the ServiceNow sync tab header.

        Args:
            config: Parsed YAML configuration dictionary.

        Returns:
            Human-readable summary of the active LogicVein network(s).
        """
        networks = normalize_networks(config.get("logicvein", {}).get("networks", "Default"))
        network_str = ", ".join(networks) if networks else "all"
        return f"Network: {network_str}"

    def get_preview_info(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Return a dict of preview metadata shown before a sync run.

        Args:
            config: Parsed YAML configuration dictionary.

        Returns:
            Dict with "target" and "sync_options" sub-dicts for display.
        """
        cmdb = config.get("servicenow", {}).get("cmdb", {})
        return {
            "target": {
                "default_ci_table": cmdb.get("default_ci_table", "cmdb_ci_ip_router"),
            },
            "sync_options": {
                "create_missing_cis": cmdb.get("create_missing_cis", True),
                "update_existing_cis": cmdb.get("update_existing_cis", True),
            },
        }

    def get_routers(self) -> List[Any]:
        """Mount the SNOW-specific webhook routes that are safe to expose.

        The LVI alert intake route (/webhook/lvi-alert) is now owned and mounted
        by the core (the plugin registers an alert handler instead). The SNOW
        change-runner route remains here. An endpoint without its shared secret is
        NOT mounted unless its config section sets allow_unauthenticated: true.
        """
        from src.plugin_api import load_credentials

        from .settings import get_snow_settings

        settings = get_snow_settings()
        routers: List[Any] = []

        def _gate(name: str, secret_desc: str, has_secret: bool, cfg_key: str, make_router) -> None:
            if has_secret:
                routers.append(make_router())
                return
            if bool(settings.get(cfg_key, {}).get("allow_unauthenticated", False)):
                logger.warning(
                    "SECURITY WARNING: %s webhook mounted WITHOUT authentication "
                    "(%s.allow_unauthenticated is true and %s is not set).",
                    name,
                    cfg_key,
                    secret_desc,
                )
                routers.append(make_router())
                return
            logger.error(
                "%s webhook NOT mounted: set %s, or set %s.allow_unauthenticated: "
                "true in conf/snow_sync_config.yaml to accept unauthenticated requests.",
                name,
                secret_desc,
                cfg_key,
            )

        def _change_router():
            from .webhook.snow_change_handler import router

            return router

        webhook_secret = load_credentials("snow").get("webhook_secret", "")
        _gate(
            "SNOW change",
            "the Change Runner Webhook Secret (Credentials tab)",
            bool(webhook_secret),
            "lvi_change_runner",
            _change_router,
        )
        return routers

    def get_background_services(self) -> List[Any]:
        """Start config-change detection in the configured mode."""
        from . import services

        return services.build_services()

    # The Webhooks, Config Change, and Event Bus tabs are all core now (shown for
    # any plugin that declares the matching capability and filtered to the selected
    # plugin), so this plugin contributes no extra tabs - it inherits the shared
    # core ones. Per-event colour tweaks go through get_webhook_overrides() rather
    # than a forked tab.

    def resolve_conflict(self, conflict_type: str, desired_payload: Dict[str, Any]) -> bool:
        """Apply an "Overwrite" decision for one pending conflict.

        Uses create_client({}) - the same "no override, resolve from stored
        credentials/settings" call real sync runs make. "ip_exists" performs
        the deferred CI create/update (create when desired_payload["sys_id"]
        is None, update otherwise) with its full original payload;
        "mac_differs"/"mac_duplicate" both PATCH just the MAC field, leaving
        every other CI field untouched.
        """
        client = self.create_client({})
        table = desired_payload["table"]
        if conflict_type == "ip_exists":
            sys_id = desired_payload.get("sys_id")
            ci_data = desired_payload.get("ci_data", {})
            if sys_id:
                result = client.update_ci(table, sys_id, ci_data)
            else:
                result = client.create_ci(table, ci_data)
            return bool(result.get("sys_id"))
        result = client.update_ci(
            table, desired_payload["sys_id"], {desired_payload["mac_field"]: desired_payload.get("mac_address", "")}
        )
        return bool(result.get("sys_id"))

    def get_quick_settings(self) -> List[Dict[str, Any]]:
        """Return the quick-settings definition for the ServiceNow config editor.

        Returns:
            List of group dicts, each with "name", "toggles", and optional "text_fields" keys.
        """
        return [
            {
                "name": "General",
                "toggles": [
                    ("sync.dry_run", "Dry Run", "Preview changes without modifying ServiceNow"),
                    ("sync.continue_on_error", "Continue on Error", "Continue if individual devices fail"),
                ],
                "text_fields": [
                    (
                        "logicvein.networks",
                        "LogicVein Network(s)",
                        "Network name(s) in LogicVein. Use 'all' to sync every network, or enter multiple names separated by commas.",
                    ),
                    (
                        "servicenow.cmdb.default_ci_table",
                        "Default CI Table",
                        "CMDB table used when device type has no specific mapping",
                    ),
                ],
            },
            {
                "name": "CI Management",
                "toggles": [
                    (
                        "servicenow.cmdb.create_missing_cis",
                        "Create Missing CIs",
                        "Create new CIs for devices not in ServiceNow",
                    ),
                    (
                        "servicenow.cmdb.update_existing_cis",
                        "Update Existing CIs",
                        "Update CI fields for devices already in ServiceNow",
                    ),
                    (
                        "servicenow.cmdb.sync_mac_address",
                        "Sync MAC Address",
                        "Set the device's MAC address on its CI. Turn off to never read, compare, or "
                        "write it - the existing value is left exactly as-is.",
                    ),
                    (
                        "servicenow.cmdb.strip_domain_from_names",
                        "Strip Domain From Names",
                        "Truncate an FQDN-looking LogicVein hostname to its short name before writing "
                        "it as the CI's name (e.g. 'asa5505.home.arpa' -> 'asa5505'). The CI's primary "
                        "lookup key is a stable id, not the name, so toggling this is safe.",
                    ),
                    (
                        "servicenow.cmdb.create_missing_reference_records",
                        "Create Missing Reference Records",
                        "Auto-create the location (cmn_location), company/manufacturer "
                        "(core_company), and model (cmdb_model) records a CI's fields reference, "
                        "when no matching record exists. Off leaves that field unresolved rather "
                        "than failing the whole CI write.",
                    ),
                ],
                "selects": [
                    (
                        "servicenow.cmdb.ip_conflict_policy",
                        "When an IP already exists",
                        "What to do when a device's IP is already assigned to a different CI.",
                        ["overwrite", "ignore", "ask"],
                    ),
                    (
                        "servicenow.cmdb.mac_conflict_policy",
                        "When the MAC differs",
                        "What to do when this device's own CI has a different MAC than LogicVein "
                        "reports, or the incoming MAC is already set on a different CI (other CI "
                        "fields still sync either way). Only consulted when 'Sync MAC Address' is on "
                        "and this device's own CI already exists.",
                        ["overwrite", "leave_untouched", "ask"],
                    ),
                ],
            },
            {
                "name": "Interfaces",
                "toggles": [
                    (
                        "servicenow.interfaces.sync_interfaces",
                        "Sync Interfaces",
                        "Sync device interfaces as cmdb_ci_network_adapter CIs",
                    ),
                    (
                        "servicenow.interfaces.delete_stale_interfaces",
                        "Delete Stale Interfaces",
                        "Remove interface CIs in ServiceNow that no longer exist in LogicVein",
                    ),
                ],
            },
            {
                "name": "Integrations",
                "toggles": [
                    # Alert Incidents and Change Runner are enabled in App Settings
                    # (features.alerts / features.change_runner), not here.
                    (
                        "lvi_change_runner.dry_run",
                        "Change Runner Dry Run",
                        "Post 'would run' work notes without submitting the LVI job",
                    ),
                ],
            },
        ]
