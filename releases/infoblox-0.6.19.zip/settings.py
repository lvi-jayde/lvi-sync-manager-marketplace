"""Plugin-local access to the Infoblox sync configuration."""

from pathlib import Path
from typing import Any, Dict

# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import get_config  # pyright: ignore[reportMissingImports]

_CONFIG_FILE = Path("conf/infoblox_sync_config.yaml")
_DEFAULTS_FILE = Path(__file__).parent / "conf" / "defaults.yaml"


def get_infoblox_settings() -> Dict[str, Any]:
    """Return the full Infoblox sync config (created from defaults on first use)."""
    return get_config(_CONFIG_FILE, _DEFAULTS_FILE)
