"""ServiceNow REST API client for the Table API and Attachment API."""

import logging
import os
from typing import Any, Dict, List, Optional

import requests
import urllib3
from src.plugin_api import build_retry_adapter

logger = logging.getLogger(__name__)


class ServiceNowClient:
    """
    Native Python client for the ServiceNow REST API (Table API + Attachment API).

    Credentials are accepted as explicit constructor parameters; if omitted they
    fall back to the SNOW_* environment variables unless ignore_env_vars is True.
    """

    def __init__(
        self,
        instance: Optional[str] = None,
        api_token: Optional[str] = None,
        verify_ssl: Optional[bool] = None,
        timeout: Optional[int] = None,
        ignore_env_vars: bool = False,
    ) -> None:
        """Initialise the ServiceNow client.

        Authentication is API-token only: the token is sent as the
        ``x-sn-apikey`` header. Basic (username/password) auth is not supported.

        Args:
            instance: ServiceNow instance hostname (e.g. dev12345.service-now.com).
                      Defaults to SNOW_INSTANCE env var.
            api_token: API key for token-based auth (sent as x-sn-apikey header).
                       Defaults to SNOW_API_TOKEN env var.
            verify_ssl: Verify TLS certificates.  Defaults to SNOW_VERIFY_SSL env var
                        (true) or False if the env var is absent.
            timeout: Request timeout in seconds.  Defaults to SNOW_TIMEOUT env var or 120.
            ignore_env_vars: If True, do not fall back to environment variables.
        """
        if ignore_env_vars:
            self.instance = instance
            self.api_token = api_token
            self.verify_ssl = verify_ssl if verify_ssl is not None else False
            self.timeout = timeout or 120
        else:
            self.instance = instance or os.getenv("SNOW_INSTANCE")
            self.api_token = api_token or os.getenv("SNOW_API_TOKEN")
            verify_env = os.getenv("SNOW_VERIFY_SSL", "true").lower() == "true"
            self.verify_ssl = verify_ssl if verify_ssl is not None else verify_env
            self.timeout = timeout or int(os.getenv("SNOW_TIMEOUT", "120"))

        self.base_url = f"https://{self.instance}/api"

        # Credential diagnostics (masked)
        _src = "explicit" if ignore_env_vars else "env-var fallback"
        if self.api_token:
            logger.info(
                f"SNOW client: instance={self.instance}, auth=api_token "
                f"(len={len(self.api_token)}), cred_src={_src}"
            )
        else:
            logger.warning(
                "SNOW client: instance=%s has no API token; set SNOW_API_TOKEN " "(requests will fail to authenticate)",
                self.instance,
            )

        if not self.verify_ssl:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        self.session = requests.Session()
        session_headers: Dict[str, str] = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if self.api_token:
            session_headers["x-sn-apikey"] = self.api_token
        self.session.headers.update(session_headers)
        self.session.verify = self.verify_ssl
        _adapter = build_retry_adapter()
        self.session.mount("https://", _adapter)
        self.session.mount("http://", _adapter)

    def _parse_json_response(self, response: requests.Response, default: Any = None) -> Any:
        """Parse a JSON response body, returning *default* for empty bodies.

        Raises ``ValueError`` with a readable message when SNOW returns HTML
        instead of JSON (e.g. when the ADC serves a maintenance or login page
        after an outage with HTTP 200, bypassing raise_for_status).
        """
        if not response.text:
            return default
        ct = response.headers.get("Content-Type", "")
        if "json" not in ct and response.text.lstrip().startswith("<"):
            raise ValueError(
                f"ServiceNow returned a non-JSON response "
                f"(HTTP {response.status_code}, Content-Type: {ct!r}) - "
                f"check SNOW instance availability: {response.text[:300]}"
            )
        return response.json()

    def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict] = None,
        json_data: Optional[Dict] = None,
        data: Optional[bytes] = None,
        headers: Optional[Dict] = None,
        suppress_errors: bool = False,
    ) -> requests.Response:
        """Make an HTTP request to the ServiceNow API.

        Args:
            method: HTTP method (GET, POST, PATCH, DELETE).
            endpoint: API endpoint path (e.g. "now/table/incident").
            params: URL query parameters.
            json_data: JSON request body.
            data: Raw binary body (for file attachments).
            headers: Additional headers to merge into the session headers.
            suppress_errors: If True, return error responses instead of raising.

        Returns:
            Response object.
        """
        url = f"{self.base_url}/{endpoint}"
        logger.debug(f"Request: {method} {url}")
        if params:
            logger.debug(f"Params: {params}")
        if json_data:
            logger.debug(f"JSON: {json_data}")

        try:
            req_headers = {**self.session.headers, **headers} if headers else None

            response = self.session.request(
                method=method,
                url=url,
                params=params,
                json=json_data,
                data=data,
                headers=req_headers,
                timeout=self.timeout,
            )

            logger.debug(f"Response: {response.status_code}")
            if response.text:
                logger.debug(f"Response body (first 500 chars): {response.text[:500]}")

            response.raise_for_status()
            return response

        except requests.exceptions.RequestException as e:
            if suppress_errors:
                return e.response  # type: ignore
            if hasattr(e, "response") and e.response is not None:
                logger.error(f"HTTP error: {e.response.status_code} - {e.response.text[:500]}")
            else:
                logger.error(f"Request error: {e}")
            raise

    # ------------------------------------------------------------------ #
    # Connection                                                           #
    # ------------------------------------------------------------------ #

    def test_connection(self) -> bool:
        """Test connectivity to the ServiceNow instance.

        Returns:
            True if the connection is successful.
        """
        try:
            response = self._request("GET", "now/table/sys_user", params={"sysparm_limit": "1"})
            return response.status_code == 200
        except Exception as e:
            logger.error(f"ServiceNow connection test failed: {e}")
            return False

    # ------------------------------------------------------------------ #
    # Generic Table API                                                    #
    # ------------------------------------------------------------------ #

    def query_table(
        self,
        table: str,
        query: str = "",
        fields: Optional[List[str]] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """Query a ServiceNow table.

        Args:
            table: Table name (e.g. "incident", "cmdb_ci_ip_router").
            query: Encoded query string (e.g. "state=1^priority=1").
            fields: Fields to return (None = all).
            limit: Maximum records per page.
            offset: Starting record offset.

        Returns:
            List of record dicts.
        """
        params: Dict[str, Any] = {
            "sysparm_limit": str(limit),
            "sysparm_offset": str(offset),
        }
        if query:
            params["sysparm_query"] = query
        if fields:
            params["sysparm_fields"] = ",".join(fields)

        response = self._request("GET", f"now/table/{table}", params=params)
        return self._parse_json_response(response, {}).get("result", [])

    def query_table_all(
        self,
        table: str,
        query: str = "",
        fields: Optional[List[str]] = None,
        page_size: int = 100,
        max_records: int = 50_000,
    ) -> List[Dict[str, Any]]:
        """Query all records from a table with automatic pagination.

        Args:
            table: Table name.
            query: Encoded query string.
            fields: Fields to return.
            page_size: Records per page.
            max_records: Hard cap on total records returned (0 = unlimited).

        Returns:
            All matching records.
        """
        all_results: List[Dict[str, Any]] = []
        offset = 0
        while True:
            batch = self.query_table(table, query=query, fields=fields, limit=page_size, offset=offset)
            all_results.extend(batch)
            if len(batch) < page_size:
                break
            offset += page_size
            if max_records and len(all_results) >= max_records:
                logger.warning(
                    "query_table_all: reached max_records limit (%d) for table '%s' - results may be incomplete",
                    max_records,
                    table,
                )
                break
        return all_results

    def get_record(self, table: str, sys_id: str) -> Optional[Dict[str, Any]]:
        """Get a single record by sys_id.

        Args:
            table: Table name.
            sys_id: Record sys_id.

        Returns:
            Record dict, or None if not found.
        """
        try:
            response = self._request("GET", f"now/table/{table}/{sys_id}")
            return self._parse_json_response(response, {}).get("result")
        except requests.exceptions.HTTPError as e:
            if hasattr(e, "response") and e.response is not None and e.response.status_code == 404:
                return None
            raise

    def create_record(self, table: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a record.

        Args:
            table: Table name.
            data: Field values.

        Returns:
            Created record dict (includes sys_id).
        """
        response = self._request("POST", f"now/table/{table}", json_data=data)
        return self._parse_json_response(response, {}).get("result", {})

    def update_record(self, table: str, sys_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Update a record by sys_id.

        Args:
            table: Table name.
            sys_id: Record sys_id.
            data: Fields to update.

        Returns:
            Updated record dict.
        """
        response = self._request("PATCH", f"now/table/{table}/{sys_id}", json_data=data)
        return self._parse_json_response(response, {}).get("result", {})

    def delete_record(self, table: str, sys_id: str) -> bool:
        """Delete a record by sys_id.

        Args:
            table: Table name.
            sys_id: Record sys_id.

        Returns:
            True if deleted.
        """
        response = self._request("DELETE", f"now/table/{table}/{sys_id}")
        return response.status_code == 204

    # ------------------------------------------------------------------ #
    # CMDB                                                                 #
    # ------------------------------------------------------------------ #

    def get_ci_by_name(self, name: str, table: str = "cmdb_ci_ip_router") -> Optional[Dict[str, Any]]:
        """Get a CI by name (hostname).

        Args:
            name: CI name.
            table: CMDB table to search.

        Returns:
            CI record, or None if not found.
        """
        results = self.query_table(table, query=f"name={name}", limit=1)
        return results[0] if results else None

    def get_ci_by_correlation_id(
        self,
        correlation_id: str,
        table: str = "cmdb_ci_ip_router",
    ) -> Optional[Dict[str, Any]]:
        """Get a CI by correlation_id.

        Args:
            correlation_id: Correlation ID value.
            table: CMDB table to search.

        Returns:
            CI record, or None if not found.
        """
        results = self.query_table(table, query=f"correlation_id={correlation_id}", limit=1)
        return results[0] if results else None

    def create_ci(self, table: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a CI record.

        Args:
            table: CI table name.
            data: Field values.

        Returns:
            Created CI record.
        """
        return self.create_record(table, data)

    def update_ci(self, table: str, sys_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Update a CI record.

        Args:
            table: CI table name.
            sys_id: CI sys_id.
            data: Fields to update.

        Returns:
            Updated CI record.
        """
        return self.update_record(table, sys_id, data)

    # ------------------------------------------------------------------ #
    # Reference resolution helpers                                         #
    # ------------------------------------------------------------------ #

    def get_location_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        """Get a location record by name.

        Args:
            name: Location name.

        Returns:
            Location record, or None if not found.
        """
        results = self.query_table("cmn_location", query=f"name={name}", limit=1)
        if not results:
            results = self.query_table("cmn_location", query=f"nameCONTAINS{name}", limit=1)
        return results[0] if results else None

    def get_company_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        """Get a company (manufacturer) record by name.

        Tries an exact match first, then falls back to a case-insensitive
        CONTAINS search so that values like "HP" can match "HP Inc." etc.

        Args:
            name: Company name.

        Returns:
            Company record, or None if not found.
        """
        results = self.query_table("core_company", query=f"name={name}", limit=1)
        if not results:
            results = self.query_table("core_company", query=f"nameCONTAINS{name}", limit=1)
        return results[0] if results else None

    def get_network_adapter(self, ci_sys_id: str, name: str) -> Optional[Dict[str, Any]]:
        """Get a network adapter CI linked to a parent CI by interface name.

        Args:
            ci_sys_id: sys_id of the parent configuration item.
            name: Interface name (e.g. "GigabitEthernet0/1").

        Returns:
            cmdb_ci_network_adapter record, or None if not found.
        """
        results = self.query_table(
            "cmdb_ci_network_adapter",
            query=f"cmdb_ci={ci_sys_id}^name={name}",
            limit=1,
        )
        return results[0] if results else None

    def get_network_adapters_for_ci(self, ci_sys_id: str) -> List[Dict[str, Any]]:
        """Get all network adapter CIs linked to a parent CI.

        Args:
            ci_sys_id: sys_id of the parent configuration item.

        Returns:
            List of cmdb_ci_network_adapter records.
        """
        return self.query_table(
            "cmdb_ci_network_adapter",
            query=f"cmdb_ci={ci_sys_id}",
        )

    def get_model_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        """Get a CMDB model record by name.

        Tries an exact match first, then a CONTAINS fallback.

        Args:
            name: Model name (e.g. "ProCurve 2626 PWR").

        Returns:
            cmdb_model record, or None if not found.
        """
        results = self.query_table("cmdb_model", query=f"name={name}", limit=1)
        if not results:
            results = self.query_table("cmdb_model", query=f"nameCONTAINS{name}", limit=1)
        return results[0] if results else None

    # ------------------------------------------------------------------ #
    # Change Request                                                       #
    # ------------------------------------------------------------------ #

    def get_change_request(self, change_number: str) -> Optional[Dict[str, Any]]:
        """Get a Change Request record by change number.

        Args:
            change_number: Change number (e.g. "CHG0012345").

        Returns:
            Change Request record dict, or None if not found.
        """
        results = self.query_table(
            "change_request",
            query=f"number={change_number}",
            fields=["sys_id", "number", "state", "cmdb_ci", "u_lvi_commands", "requested_by"],
            limit=1,
        )
        return results[0] if results else None

    def add_work_note_to_change(self, sys_id: str, note: str) -> Dict[str, Any]:
        """Add a work note to a Change Request.

        Args:
            sys_id: Change Request sys_id.
            note: Work note text.

        Returns:
            Updated Change Request record dict.
        """
        return self.update_record("change_request", sys_id, {"work_notes": note})

    # ------------------------------------------------------------------ #
    # Attachment API                                                        #
    # ------------------------------------------------------------------ #

    def add_attachment(
        self,
        table: str,
        sys_id: str,
        filename: str,
        content: str,
        content_type: str = "text/plain",
    ) -> Dict[str, Any]:
        """Attach a file to a record.

        Args:
            table: Table the record belongs to.
            sys_id: Record sys_id.
            filename: Attachment filename.
            content: File content as a string.
            content_type: MIME type.

        Returns:
            Attachment record.
        """
        params = {
            "table_name": table,
            "table_sys_id": sys_id,
            "file_name": filename,
        }
        response = self._request(
            "POST",
            "now/attachment/file",
            params=params,
            data=content.encode("utf-8"),
            headers={
                "Content-Type": content_type,
                "Accept": "application/json",
            },
        )
        return self._parse_json_response(response, {}).get("result", {})
