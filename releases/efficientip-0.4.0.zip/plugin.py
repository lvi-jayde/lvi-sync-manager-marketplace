"""EfficientIP SOLIDserver sync plugin - the SyncPlugin entry point."""

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from src.plugin_api import SyncPlugin, load_plugin_config, normalize_networks

from .client import EfficientIPClient
from .sync import LogicVeinEfficientIPSync

logger = logging.getLogger(__name__)


class EfficientIPPlugin(SyncPlugin):
    """Plugin for synchronizing LogicVein device inventory to EfficientIP SOLIDserver IPAM."""

    def __init__(self) -> None:
        """Initialise the EfficientIP plugin from its manifest.json."""
        self.config = load_plugin_config(Path(__file__).parent)

    # --- Required (abstract) -------------------------------------------------

    def create_client(self, credentials: Dict[str, Any]) -> Any:
        """Create an authenticated EfficientIP SOLIDserver client.

        Args:
            credentials: Dict with keys: host, username, password, token_id,
                         token_secret, use_token, and optionally ignore_env_vars.
                         "use_token" (set by the credentials UI's auth-method
                         toggle) picks username/password vs token_id/
                         token_secret explicitly; when absent (e.g. the empty
                         dict scheduled syncs and resolve_conflict() pass),
                         both pairs are forwarded and EfficientIPClient's own
                         precedence (token wins if both resolve) decides.

        Returns:
            EfficientIPClient instance.
        """
        from .settings import get_efficientip_settings

        eip_cfg = get_efficientip_settings().get("efficientip", {})
        kwargs: Dict[str, Any] = {
            "verify_ssl": bool(eip_cfg.get("verify_ssl", False)),
            "timeout": int(eip_cfg.get("timeout", 120)),
        }
        if credentials.get("ignore_env_vars"):
            kwargs["ignore_env_vars"] = True
        if credentials.get("host"):
            kwargs["host"] = credentials["host"]

        use_token = credentials.get("use_token")
        if use_token is not True:
            if credentials.get("username"):
                kwargs["username"] = credentials["username"]
            if credentials.get("password"):
                kwargs["password"] = credentials["password"]
        if use_token is not False:
            if credentials.get("token_id"):
                kwargs["token_id"] = credentials["token_id"]
            if credentials.get("token_secret"):
                kwargs["token_secret"] = credentials["token_secret"]
        return EfficientIPClient(**kwargs)

    def create_sync_engine(
        self,
        lvi_client: Any,
        target_client: Any,
        sync_config: Dict[str, Any],
    ) -> LogicVeinEfficientIPSync:
        """Create the EfficientIP sync engine.

        Args:
            lvi_client: LogicVein API client.
            target_client: EfficientIPClient instance.
            sync_config: Config dict produced by build_sync_config().

        Returns:
            LogicVeinEfficientIPSync instance.
        """
        return LogicVeinEfficientIPSync(lvi_client=lvi_client, efficientip_client=target_client, config=sync_config)

    def build_sync_config(
        self,
        yaml_config: Dict[str, Any],
        timestamp: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Build sync configuration from YAML config.

        Args:
            yaml_config: Parsed YAML configuration dictionary.
            timestamp: Optional timestamp for archive file naming.

        Returns:
            Configuration dictionary ready for LogicVeinEfficientIPSync.
        """
        sync = yaml_config.get("sync", {})
        lvi = yaml_config.get("logicvein", {})
        eip = yaml_config.get("efficientip", {})
        return {
            "dry_run": sync.get("dry_run", False),
            "continue_on_error": sync.get("continue_on_error", True),
            "network": lvi.get("networks", "Default"),
            "space_name": eip.get("space_name", "Local"),
            "sync_to_ipam": eip.get("sync_to_ipam", True),
            "sync_to_nom": eip.get("sync_to_nom", False),
            "nom_folder_name": eip.get("nom_folder_name", "LogicVein Devices"),
            "create_missing_subnets": eip.get("create_missing_subnets", False),
            "create_missing_blocks": eip.get("create_missing_blocks", False),
            "class_parameter_mapping": eip.get("class_parameter_mapping", {}),
            "lifecycle_class_parameter_mapping": eip.get("lifecycle_class_parameter_mapping", {}),
            "sync_mac_address": eip.get("sync_mac_address", True),
            "ip_conflict_policy": eip.get("ip_conflict_policy", "overwrite"),
            "mac_conflict_policy": eip.get("mac_conflict_policy", "overwrite"),
        }

    def test_connection(self, credentials: Dict[str, Any]) -> Tuple[bool, str]:
        """Test connection to EfficientIP SOLIDserver.

        Args:
            credentials: Dict with 'host', 'username', 'password' keys.

        Returns:
            Tuple of (success, message).
        """
        try:
            client = self.create_client(credentials)
            if client.test_connection():
                return True, "Connected to EfficientIP SOLIDserver successfully"
            return False, "Connection test failed - check credentials"
        except Exception as e:
            return False, f"Connection failed: {e}"

    # --- Optional hooks --------------------------------------------------------

    def supports_preview(self) -> bool:
        return True

    def get_preview(self, lvi_client: Any, target_client: Any, config: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Return a dry-run summary for the Preview button (no writes)."""
        networks = normalize_networks(config.get("network", "Default"))
        devices = lvi_client.search_devices_in_network(network=networks)
        return {"total_lvi_devices": len(devices)}

    def get_status_detail(self, config: Dict[str, Any]) -> str:
        """One-line summary shown in the sync tab header."""
        networks = normalize_networks(config.get("logicvein", {}).get("networks", "Default"))
        space_name = config.get("efficientip", {}).get("space_name", "Local")
        return f"Network: {', '.join(networks) if networks else 'all'} -> Space: {space_name}"

    def get_quick_settings(self) -> List[Dict[str, Any]]:
        """Quick-settings groups rendered above the raw-YAML editor."""
        return [
            {
                "name": "General",
                "toggles": [
                    ("sync.dry_run", "Dry Run", "Preview changes without writing to SOLIDserver"),
                    (
                        "efficientip.create_missing_blocks",
                        "Create missing IP blocks",
                        "Automatically create a covering /16 IP block when none exists. "
                        "Required before 'Create missing subnets' can succeed for a new range.",
                    ),
                    (
                        "efficientip.create_missing_subnets",
                        "Create missing subnets",
                        "Automatically create the containing /24 subnet when missing. "
                        "Requires a pre-existing IP block, or 'Create missing IP blocks' also enabled.",
                    ),
                ],
                "text_fields": [
                    (
                        "logicvein.networks",
                        "LogicVein Network(s)",
                        "Network name(s) in LogicVein. Use 'all' for every network, or comma-separate names.",
                    ),
                    ("efficientip.space_name", "IP space name", "SOLIDserver IP space (site) to sync devices into"),
                ],
            },
            {
                "name": "Sync Targets",
                "toggles": [
                    (
                        "efficientip.sync_to_ipam",
                        "Sync to IPAM",
                        "Sync devices into IPAM (IP address records). This was the plugin's only "
                        "behavior before NOM sync was added.",
                    ),
                    (
                        "efficientip.sync_to_nom",
                        "Sync to Network Object Manager",
                        "Also sync devices (and every interface/port LogicVein knows about for each) "
                        "into NOM, a separate device inventory module from IPAM. Independent of "
                        "'Sync to IPAM' - either can run alone or both together.",
                    ),
                ],
                "text_fields": [
                    (
                        "efficientip.nom_folder_name",
                        "NOM folder name",
                        "Folder synced devices are organized under in Network Object Manager. "
                        "Created automatically if it doesn't already exist.",
                    ),
                ],
            },
            {
                "name": "Conflict Handling",
                "toggles": [
                    (
                        "efficientip.sync_mac_address",
                        "Sync MAC addresses",
                        "Sync device MAC addresses into EfficientIP. Turn off to never read, compare, or write MAC.",
                    ),
                ],
                "selects": [
                    (
                        "efficientip.ip_conflict_policy",
                        "When an IP already exists",
                        "What to do when a device's IP already has a record in EfficientIP.",
                        ["overwrite", "ignore", "ask"],
                    ),
                    (
                        "efficientip.mac_conflict_policy",
                        "When the MAC differs",
                        "What to do when an existing record's MAC differs from LogicVein's "
                        "(other device attributes still sync either way).",
                        ["overwrite", "leave_untouched", "ask"],
                    ),
                ],
            },
        ]

    def supports_cancellation(self) -> bool:
        return True

    def resolve_conflict(self, conflict_type: str, desired_payload: Dict[str, Any]) -> bool:
        """Apply an "Overwrite" decision for one pending conflict.

        Uses create_client({}) - the same "no override, resolve from stored
        credentials/settings" call real sync runs make (see
        src.common.sync_runner.run_sync's plugin.create_client(target_credentials or {})).

        "mac_differs" only carries mac_address forward (site_id/hostaddr are
        required by ip_add but omitting subnet_id/hostname/class_parameters
        leaves those fields untouched - create_or_update_address only sets a
        field when the argument is truthy).
        """
        client = self.create_client({})
        if conflict_type == "mac_differs":
            return client.create_or_update_address(
                ip_address=desired_payload["ip_address"],
                site_id=desired_payload["site_id"],
                mac_address=desired_payload.get("mac_address", ""),
            )
        return client.create_or_update_address(
            ip_address=desired_payload["ip_address"],
            site_id=desired_payload["site_id"],
            subnet_id=desired_payload.get("subnet_id"),
            hostname=desired_payload.get("hostname", ""),
            mac_address=desired_payload.get("mac_address", ""),
            class_parameters=desired_payload.get("class_parameters") or {},
        )
