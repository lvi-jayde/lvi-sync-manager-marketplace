"""NetBox IPAM sync plugin."""

from .plugin import NetBoxPlugin

__all__ = ["NetBoxPlugin"]
