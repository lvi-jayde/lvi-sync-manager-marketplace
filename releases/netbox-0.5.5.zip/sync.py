"""LogicVein to NetBox IPAM Sync Module."""

import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from logicvein import LogicVeinAPIClient
from src.plugin_api import (
    CancellationToken,
    DeviceSyncOutcome,
    SyncCancelled,
    SyncReport,
    normalize_networks,
    record_pending_conflicts,
    resolve_display_name,
)

from . import field_mapping
from .client import NetBoxClient

logger = logging.getLogger(__name__)

PLUGIN_NAME = "netbox"


def _append_detail(existing: str, note: str) -> str:
    """Append *note* to a DeviceSyncOutcome's detail, semicolon-separated -
    a device can accumulate more than one conflict note (e.g. a primary IP
    conflict and a MAC conflict) without clobbering an earlier one."""
    return f"{existing}; {note}" if existing else note


class LogicVeinNetBoxSync:
    """Sync LogicVein devices to NetBox IPAM."""

    def __init__(
        self,
        lvi_client: LogicVeinAPIClient,
        netbox_client: NetBoxClient,
        config: Optional[Dict[str, Any]] = None,
    ):
        """
        Initialize LogicVein to NetBox sync.

        Args:
            lvi_client: LogicVeinAPIClient instance
            netbox_client: NetBoxClient instance
            config: Configuration dictionary with sync and mapping settings
        """
        self.lvi_client = lvi_client
        self.netbox_client = netbox_client
        self.config = config or {}

        # Extract config values
        self.dry_run = self.config.get("dry_run", False)
        self.networks = normalize_networks(self.config.get("network", "Default"))
        # Sync devices into DCIM (create/update the Device object and its
        # role/type/platform/comments/lifecycle/custom fields). Default on
        # - this was the plugin's only behavior before this toggle was
        # added. Off is for sites that manage Devices themselves (e.g. via
        # NetBox's own discovery/onboarding) and only want LogicVein to
        # keep IPAM/interfaces in sync - see _sync_single_device()'s
        # sync_to_dcim branch: it looks the device up by name but never
        # creates or edits it, skipping the device (and its IP/interfaces)
        # entirely when no existing match is found, matching
        # EfficientIP's independent sync_to_ipam/sync_to_nom split.
        self.sync_to_dcim = bool(self.config.get("sync_to_dcim", True))
        self.site_name = self.config.get("site_name", "")  # If empty, uses LVI network name
        self.tenant_name = self.config.get("tenant_name", "")
        self.device_role_name = self.config.get("device_role_name", "")  # Fallback if LVI deviceType empty
        self.default_device_type = self.config.get("default_device_type", "")  # Fallback if LVI model empty
        self.default_manufacturer = self.config.get("default_manufacturer", "Unknown")  # Fallback manufacturer
        self.create_missing_resources = self.config.get(
            "create_missing_resources", True
        )  # Auto-create sites/roles/types
        self.populate_custom_fields = self.config.get("populate_custom_fields", False)
        self.custom_field_mapping = self.config.get("custom_field_mapping", {})
        self.continue_on_error = self.config.get("continue_on_error", True)
        # Truncate an FQDN-looking LVI hostname to its short name before
        # writing it as the NetBox device name (e.g. "asa5505.home.arpa" ->
        # "asa5505"). Toggling this renames the existing device rather
        # than creating a duplicate - see _resolve_display_name() and
        # _sync_single_device()'s device lookup, which tries both names.
        self.strip_domain_from_names = bool(self.config.get("strip_domain_from_names", True))

        # IPAM settings
        self.create_ip_addresses = self.config.get("create_ip_addresses", True)
        self.set_primary_ip = self.config.get("set_primary_ip", True)
        self.default_ip_status = self.config.get("default_ip_status", "active")
        self.default_subnet_mask = self.config.get("default_subnet_mask", 32)

        # Additional field sync settings
        self.sync_platform = self.config.get("sync_platform", False)
        self.sync_comments = self.config.get("sync_comments", False)
        self.sync_description = self.config.get("sync_description", False)
        self.sync_mac_address = self.config.get("sync_mac_address", False)
        # What to do when an IP address already has a record in NetBox
        # assigned to a different interface/device: "overwrite" (default,
        # steal it - today's only behavior), "ignore" (leave the existing
        # assignment untouched), "ask" (defer for review in the Resolve
        # Conflicts screen). See _sync_ip_address()/_sync_interface_ips().
        self.ip_conflict_policy = self.config.get("ip_conflict_policy", "overwrite")
        # What to do when an interface's existing MAC differs from
        # LogicVein's, or the incoming MAC is already used by a *different*
        # interface: "overwrite" (default), "leave_untouched" (skip the MAC
        # write, other fields still sync), "ask" (defer for review). Only
        # consulted when sync_mac_address is on.
        self.mac_conflict_policy = self.config.get("mac_conflict_policy", "overwrite")

        # Lifecycle custom fields
        self.sync_lifecycle = self.config.get("sync_lifecycle", False)
        self.lifecycle_field_mapping = self.config.get("lifecycle_field_mapping", {})

        # LVI custom fields (custom1-5)
        self.lvi_custom_field_mapping = self.config.get("lvi_custom_field_mapping", {})

        # Location sync settings
        self.sync_location = self.config.get("sync_location", False)
        self.create_missing_locations = self.config.get("create_missing_locations", False)

        # Interface sync settings
        self.sync_interfaces = self.config.get("sync_interfaces", False)
        self.delete_stale_interfaces = self.config.get("delete_stale_interfaces", False)

        # Stale device/IP deletion settings
        self.delete_stale_devices = self.config.get("delete_stale_devices", False)
        self.delete_stale_ips = self.config.get("delete_stale_ips", False)

        self.task_name = ""
        self.site_id: Optional[int] = None
        self.tenant_id: Optional[int] = None
        self.device_role_id: Optional[int] = None

        # Cache for dynamically resolved IDs
        self._site_cache: Dict[str, int] = {}
        self._role_cache: Dict[str, int] = {}
        self._device_type_cache: Dict[str, int] = {}
        self._platform_cache: Dict[str, int] = {}
        self._location_cache: Dict[str, int] = {}

        # Track synced items for stale deletion
        self._synced_device_ids: set = set()
        self._synced_ip_ids: set = set()

        # Per-device outcomes for this run's SyncReport (see sync())
        self._outcomes: List[DeviceSyncOutcome] = []

        # Conflicts deferred this run under an "ask" policy - recorded once
        # at the end of sync() via record_pending_conflicts().
        self._pending_items: List[Dict[str, Any]] = []

        # Management-IP -> MAC map, populated by _prefetch_mac_lookup() once
        # per sync (see that method for why this is needed at all).
        self._mac_lookup: Dict[str, str] = {}

        # Cancellation support
        self._cancel_token: Optional["CancellationToken"] = None

    def set_cancel_token(self, token: "CancellationToken") -> None:
        """Set cancellation token for this sync operation.

        Args:
            token: CancellationToken instance to check for cancellation.
        """
        self._cancel_token = token

    def _check_cancelled(self) -> None:
        """Check if cancellation was requested and raise if so.

        Raises:
            SyncCancelled: If cancellation was requested.
        """
        if self._cancel_token and self._cancel_token.is_cancelled():
            raise SyncCancelled("Sync cancelled by user")

    def _resolve_display_name(self, raw_name: str) -> Tuple[str, str]:
        """Return (display_name, alt_name) for one LVI-reported hostname,
        per strip_domain_from_names - see plugin_api.resolve_display_name()'s
        docstring for the full FQDN-truncation/alt_name contract.

        NetBox looks devices up by name (get_device_by_name()), so
        *alt_name* matters here: flipping strip_domain_from_names between
        runs would otherwise miss the existing device (still under its
        old-style name) and create a duplicate - _sync_single_device()
        tries alt_name as a fallback lookup and renames in place instead
        (update_device() already sends "name": hostname on every update).
        """
        return resolve_display_name(raw_name, self.strip_domain_from_names)

    def _generate_task_name(self) -> str:
        """Generate unique task name for this sync.

        Returns:
            Task name in format: {lvi_host}_{network}_{timestamp}
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return f"{self.lvi_client.host}_{', '.join(self.networks) or 'all'}_{timestamp}"

    def _prefetch_mac_lookup(self, networks: List[str]) -> Dict[str, str]:
        """Bulk-fetch device interfaces per network and build a management-IP -> MAC map.

        LVI's device search (Inventory.search) does not return a MAC
        address at all - confirmed against a live instance, it's only
        available per-interface via a separate bulk call
        (Inventory.searchDeviceInterfaces). One call per network (not per
        device); mirrors the EfficientIP/Infoblox plugins' equivalent.
        """
        by_ip: Dict[str, List[Dict[str, Any]]] = {}
        for network in networks or ["Default"]:
            try:
                for entry in self.lvi_client.search_device_interfaces(network=network):
                    mgmt_ip = entry.get("ipAddress", "")
                    if mgmt_ip:
                        by_ip.setdefault(mgmt_ip, []).append(entry)
            except Exception as e:
                logger.warning("Could not prefetch interfaces for network '%s': %s", network, e)

        mac_lookup: Dict[str, str] = {}
        for mgmt_ip, entries in by_ip.items():
            matched = next(
                (e for e in entries if any(ip.split("/")[0] == mgmt_ip for ip in e.get("interfaceIps", []) or [])),
                entries[0],
            )
            mac = ((matched.get("interface") or {}).get("macAddress") or "").replace("-", ":").lower()
            if mac:
                mac_lookup[mgmt_ip] = mac
        return mac_lookup

    def sync(self) -> bool:
        """
        Execute full LogicVein to NetBox sync.

        Returns:
            True if sync succeeded, False otherwise
        """
        logger.info("=" * 70)
        logger.info("LogicVein to NetBox IPAM Sync")
        logger.info("=" * 70)

        if self.dry_run:
            logger.info("DRY RUN MODE - No changes will be made to NetBox")

        self.task_name = self._generate_task_name()
        started_at = datetime.now(timezone.utc).isoformat()

        success = (
            self._test_netbox_connection()
            and self._resolve_site()
            and self._resolve_tenant()
            and self._resolve_device_role()
            and self._sync_devices()
        )

        if self._pending_items and not self.dry_run:
            try:
                record_pending_conflicts(PLUGIN_NAME, self._pending_items)
            except Exception as e:
                logger.warning("Could not record pending conflicts: %s", e)

        self.last_report = SyncReport(
            plugin_name=PLUGIN_NAME,
            started_at=started_at,
            finished_at=datetime.now(timezone.utc).isoformat(),
            dry_run=self.dry_run,
            outcomes=self._outcomes,
        )
        return success

    def _test_netbox_connection(self) -> bool:
        """Test connectivity to NetBox API.

        Returns:
            True if connection successful, False otherwise
        """
        logger.info("Testing NetBox connection...")
        try:
            if self.netbox_client.test_connection():
                logger.info("✓ NetBox connection successful")
                return True
            else:
                logger.error("✗ NetBox connection test failed")
                return False
        except Exception as e:
            logger.error(f"✗ NetBox connection error: {e}")
            return False

    def _resolve_site(self) -> bool:
        """Resolve site name to ID in NetBox.

        If create_missing_resources is True and site doesn't exist, it will be created.

        Returns:
            True if site resolved/created or not required, False on error
        """
        if not self.site_name:
            logger.info("No site specified, will use LVI network name per-device")
            return True

        logger.info(f"Resolving NetBox site: {self.site_name}")
        try:
            if self.create_missing_resources:
                site = self.netbox_client.get_or_create_site(self.site_name)
            else:
                site = self.netbox_client.get_site_by_name(self.site_name)

            if site:
                site_id = site.get("id")
                if site_id is not None:
                    self.site_id = site_id
                    self._site_cache[self.site_name] = site_id
                logger.info(f"✓ Resolved site '{self.site_name}' to ID {self.site_id}")
                return True
            else:
                logger.error(f"✗ Site '{self.site_name}' not found in NetBox")
                return False
        except Exception as e:
            logger.error(f"✗ Error resolving site: {e}")
            return False

    def _resolve_tenant(self) -> bool:
        """Resolve tenant name to ID in NetBox.

        If create_missing_resources is True and tenant doesn't exist, it will be created.

        Returns:
            True if tenant resolved/created or not required, False on error
        """
        if not self.tenant_name:
            logger.info("No tenant specified, skipping tenant resolution")
            return True

        logger.info(f"Resolving NetBox tenant: {self.tenant_name}")
        try:
            if self.create_missing_resources:
                tenant = self.netbox_client.get_or_create_tenant(self.tenant_name)
            else:
                tenant = self.netbox_client.get_tenant_by_name(self.tenant_name)

            if tenant:
                self.tenant_id = tenant.get("id")
                logger.info(f"✓ Resolved tenant '{self.tenant_name}' to ID {self.tenant_id}")
                return True
            else:
                logger.error(f"✗ Tenant '{self.tenant_name}' not found in NetBox")
                return False
        except Exception as e:
            logger.error(f"✗ Error resolving tenant: {e}")
            return False

    def _resolve_device_role(self) -> bool:
        """Resolve default device role name to ID in NetBox.

        This resolves the fallback device role. Each device may use a different role
        based on its LVI deviceType field.

        If create_missing_resources is True and role doesn't exist, it will be created.

        Returns:
            True if device role resolved/created or not required, False on error
        """
        if not self.device_role_name:
            logger.info("No default device role specified, will use LVI deviceType per-device")
            return True

        logger.info(f"Resolving default device role: {self.device_role_name}")
        try:
            if self.create_missing_resources:
                role = self.netbox_client.get_or_create_device_role(self.device_role_name)
            else:
                role = self.netbox_client.get_device_role_by_name(self.device_role_name)

            if role:
                role_id = role.get("id")
                if role_id is not None:
                    self.device_role_id = role_id
                    self._role_cache[self.device_role_name] = role_id
                logger.info(f"✓ Resolved device role '{self.device_role_name}' to ID {self.device_role_id}")
                return True
            else:
                logger.error(f"✗ Device role '{self.device_role_name}' not found in NetBox")
                return False
        except Exception as e:
            logger.error(f"✗ Error resolving device role: {e}")
            return False

    def _sync_devices(self) -> bool:
        """Sync devices from LogicVein to NetBox.

        Returns:
            True if sync succeeded, False otherwise
        """
        _network_label = "all LVI networks" if not self.networks else f"LVI network '{', '.join(self.networks)}'"
        logger.info(f"Exporting devices from {_network_label}")
        try:
            # Get devices from LogicVein
            devices = self.lvi_client.search_devices_in_network(network=self.networks)

            if not devices:
                logger.warning(f"No devices found in {_network_label}")
                return True

            self._mac_lookup = self._prefetch_mac_lookup(self.networks)

            logger.info(f"Found {len(devices)} devices in LogicVein")

            # Sync each device
            synced_count = 0
            error_count = 0

            for device in devices:
                # Check for cancellation before each device
                self._check_cancelled()

                try:
                    if self._sync_single_device(device):
                        synced_count += 1
                    else:
                        error_count += 1
                        if not self.continue_on_error:
                            return False
                except Exception as e:
                    logger.error(f"Error syncing device {device.get('ipAddress', 'unknown')}: {e}")
                    error_count += 1
                    if not self.continue_on_error:
                        return False

            logger.info(f"✓ Device sync complete: {synced_count} synced, {error_count} errors")

            # Check for cancellation before stale deletion
            self._check_cancelled()

            # Delete stale devices and IPs if configured
            if not self.dry_run and (self.delete_stale_devices or self.delete_stale_ips):
                self._delete_stale_devices_and_ips()

            # Check for cancellation before CSV write
            self._check_cancelled()

            return error_count == 0 or self.continue_on_error

        except Exception as e:
            # Re-raise SyncCancelled to propagate cancellation
            if isinstance(e, SyncCancelled):
                raise
            logger.error(f"✗ Error exporting devices: {e}")
            return False

    def _sync_single_device(self, lvi_device: Dict[str, Any]) -> bool:
        """Sync a single device from LogicVein to NetBox.

        Maps LogicVein fields to NetBox:
        - site: config site_name, or falls back to LVI network name
        - device role: LVI deviceType (e.g., "Router", "Switch")
        - device type: LVI model + hardwareVendor

        Args:
            lvi_device: Device data from LogicVein

        Returns:
            True if sync succeeded, False otherwise
        """
        # Core fields
        ip_address = lvi_device.get("ipAddress", "")
        hostname, alt_hostname = self._resolve_display_name(lvi_device.get("hostname", ""))
        lvi_device_type = lvi_device.get("deviceType", "")  # e.g., "Router"
        lvi_model = lvi_device.get("model", "")  # e.g., "2500"
        lvi_vendor = lvi_device.get("hardwareVendor", "")  # e.g., "Cisco"
        lvi_network = lvi_device.get("network") or (self.networks[0] if self.networks else "Default")

        # Additional fields for extended sync
        lvi_os_type = lvi_device.get("osType", "")  # e.g., "IOS", "JunOS"
        lvi_memo = lvi_device.get("memoSummary", "")  # User notes
        lvi_sys_descr = lvi_device.get("sysDescr", "")  # SNMP sysDescr
        # LVI's device search never returns a MAC address directly (confirmed
        # against a live instance) - it comes from the separate bulk
        # interface fetch in _prefetch_mac_lookup(), matched by management IP.
        lvi_mac_address = self._mac_lookup.get(ip_address, "")
        lvi_sys_location = lvi_device.get("sysLocation", "")  # SNMP sysLocation

        logger.debug("Syncing device: %s (%s)", hostname, ip_address)

        def _err(reason: str) -> bool:
            self._outcomes.append(
                DeviceSyncOutcome(
                    ip_address=ip_address, hostname=hostname, action="error", error=reason, mac=lvi_mac_address
                )
            )
            return False

        if not hostname:
            logger.warning(f"Skipping device without hostname: {ip_address}")
            return _err("no hostname in LVI data")

        try:
            if not self.sync_to_dcim:
                # DCIM sync off entirely - devices are managed externally
                # (e.g. NetBox's own discovery/onboarding). Never create or
                # touch a device's fields; only look one up by name (with
                # the same alt_hostname fallback the normal path uses, so
                # a strip_domain_from_names toggle doesn't lose the match)
                # to hang IPAM/interface sync off of. No match means
                # nothing to sync this device onto - skip rather than
                # create a device we were told not to manage.
                existing_device = self.netbox_client.get_device_by_name(hostname)
                if existing_device is None and alt_hostname:
                    existing_device = self.netbox_client.get_device_by_name(alt_hostname)
                if existing_device is None:
                    logger.debug("Skipping %s: sync_to_dcim is off and no existing NetBox device found", hostname)
                    self._outcomes.append(
                        DeviceSyncOutcome(
                            ip_address=ip_address,
                            hostname=hostname,
                            action="ignored",
                            detail="sync_to_dcim is off and no existing NetBox device found",
                            mac=lvi_mac_address,
                        )
                    )
                    return True
                device_id = existing_device.get("id")
                if device_id:
                    self._synced_device_ids.add(device_id)
                self._outcomes.append(
                    DeviceSyncOutcome(
                        ip_address=ip_address,
                        hostname=hostname,
                        action="updated",
                        detail="IPAM only (sync_to_dcim is off) - device managed externally",
                        mac=lvi_mac_address,
                    )
                )
            else:
                # Resolve site: use config site_name, or fall back to LVI network
                site_name = self.site_name if self.site_name else lvi_network
                site_id = self._resolve_or_create_site(site_name)
                if not site_id:
                    logger.warning(f"Skipping {hostname}: could not resolve/create site '{site_name}'")
                    return _err(f"could not resolve/create site '{site_name}'")

                # Resolve device role from LVI deviceType (e.g., "Router")
                role_name = lvi_device_type if lvi_device_type else self.device_role_name
                if not role_name:
                    logger.warning(
                        f"Skipping {hostname}: no deviceType in LVI data and no default device_role_name configured"
                    )
                    return _err("no deviceType in LVI data and no default device_role_name configured")

                role_id = self._resolve_or_create_device_role(role_name)
                if not role_id:
                    logger.warning(f"Skipping {hostname}: could not resolve/create device role '{role_name}'")
                    return _err(f"could not resolve/create device role '{role_name}'")

                # Resolve device type from LVI model + vendor
                model_name = lvi_model if lvi_model else self.default_device_type
                vendor_name = lvi_vendor if lvi_vendor else self.default_manufacturer

                if not model_name:
                    logger.warning(f"Skipping {hostname}: no model in LVI data and no default_device_type configured")
                    return _err("no model in LVI data and no default_device_type configured")

                device_type_id = self._resolve_or_create_device_type(model_name, vendor_name)
                if not device_type_id:
                    logger.warning(f"Skipping {hostname}: could not resolve/create device type '{model_name}'")
                    return _err(f"could not resolve/create device type '{model_name}'")

                # Resolve platform from LVI osType (optional)
                platform_id = None
                if self.sync_platform and lvi_os_type:
                    platform_id = self._resolve_or_create_platform(lvi_os_type)

                # Resolve location from LVI sysLocation (optional)
                location_id = None
                if self.sync_location and lvi_sys_location:
                    location_id = self._resolve_or_create_location(lvi_sys_location, site_id)

                # Check if device already exists in NetBox - falling back to
                # alt_hostname (the name it would have under the other
                # strip_domain_from_names setting) if not found under this
                # run's name. update_device() below always sends "name":
                # hostname in device_data, so finding it under its old-style
                # name here is enough to rename it in place on the same call -
                # no separate rename step needed.
                existing_device = self.netbox_client.get_device_by_name(hostname)
                if existing_device is None and alt_hostname:
                    existing_device = self.netbox_client.get_device_by_name(alt_hostname)

                # Build device data (required fields)
                device_data = {
                    "name": hostname,
                    "device_type": device_type_id,
                    "role": role_id,
                    "site": site_id,
                    "status": "active",
                }

                # Add optional fields if available
                if self.tenant_id:
                    device_data["tenant"] = self.tenant_id

                # Add location if resolved
                if location_id:
                    device_data["location"] = location_id

                # Add serial number if available
                serial = lvi_device.get("serialNumber")
                if serial:
                    device_data["serial"] = serial

                # Add platform if resolved
                if platform_id:
                    device_data["platform"] = platform_id

                # Add comments from LVI memoSummary
                if self.sync_comments and lvi_memo:
                    device_data["comments"] = lvi_memo

                # Add description from LVI sysDescr (truncate to 200 chars - NetBox limit)
                if self.sync_description and lvi_sys_descr:
                    device_data["description"] = lvi_sys_descr[:200] if len(lvi_sys_descr) > 200 else lvi_sys_descr

                # Add custom fields if configured
                custom_fields = {}
                if self.populate_custom_fields:
                    custom_fields.update(self._build_custom_fields(lvi_device))

                # Add lifecycle custom fields
                if self.sync_lifecycle:
                    lifecycle_fields = self._build_lifecycle_fields(lvi_device)
                    custom_fields.update(lifecycle_fields)

                # Add LVI custom fields (custom1-5)
                if self.lvi_custom_field_mapping:
                    lvi_custom = self._build_lvi_custom_fields(lvi_device)
                    custom_fields.update(lvi_custom)

                if custom_fields:
                    device_data["custom_fields"] = custom_fields

                # Create or update device
                if self.dry_run:
                    logger.info(
                        "[DRY RUN] Would sync device: %s (site=%s, role=%s, type=%s)",
                        hostname,
                        site_name,
                        role_name,
                        model_name,
                    )
                    if self.create_ip_addresses and ip_address:
                        logger.info("[DRY RUN] Would create IP address: %s/%s", ip_address, self.default_subnet_mask)
                    self._outcomes.append(
                        DeviceSyncOutcome(
                            ip_address=ip_address,
                            hostname=hostname,
                            action="updated" if existing_device else "added",
                            detail="[DRY RUN]",
                            mac=lvi_mac_address,
                        )
                    )
                    return True

                device_id = None
                if existing_device:
                    logger.info("Updating existing device: %s", hostname)
                    updated_device = self.netbox_client.update_device(existing_device["id"], device_data)
                    device_id = updated_device.get("id")
                    self._outcomes.append(
                        DeviceSyncOutcome(
                            ip_address=ip_address, hostname=hostname, action="updated", mac=lvi_mac_address
                        )
                    )
                else:
                    logger.info(
                        "Creating new device: %s (site=%s, role=%s, type=%s)",
                        hostname,
                        site_name,
                        role_name,
                        model_name,
                    )
                    created_device = self.netbox_client.create_device(device_data)
                    device_id = created_device.get("id")
                    self._outcomes.append(
                        DeviceSyncOutcome(ip_address=ip_address, hostname=hostname, action="added", mac=lvi_mac_address)
                    )

                # Track synced device for stale deletion
                if device_id:
                    self._synced_device_ids.add(device_id)

            # Sync all interfaces first if configured (need to know if any has device IP)
            interface_has_device_ip = False
            if self.sync_interfaces and device_id:
                _, interface_has_device_ip = self._sync_device_interfaces(device_id, ip_address, hostname, lvi_network)

            # Create IP address if configured
            # Only create mgmt0 if:
            # - Not syncing interfaces, OR
            # - Syncing interfaces but none has the device's main IP
            if self.create_ip_addresses and ip_address and device_id:
                if not self.sync_interfaces or not interface_has_device_ip:
                    mac_to_sync = lvi_mac_address if self.sync_mac_address else None
                    ip_id = self._sync_ip_address(device_id, hostname, ip_address, mac_to_sync)
                    if ip_id:
                        self._synced_ip_ids.add(ip_id)
                else:
                    logger.debug("Skipping mgmt0 creation for %s - interface already has device IP", hostname)

            return True

        except Exception as e:
            logger.error(f"Error syncing device {hostname}: {e}")
            # The device's own added/updated outcome (if any) was already
            # appended above before this exception could have been raised
            # by a later step (interfaces/IP sync) - don't double-record it.
            if not any(o.hostname == hostname and o.ip_address == ip_address for o in self._outcomes):
                return _err(str(e))
            return False

    def _resolve_or_create_site(self, site_name: str) -> Optional[int]:
        """Resolve site name to ID, creating if necessary.

        Args:
            site_name: Name of the site

        Returns:
            Site ID, or None on error
        """
        # Check cache first
        if site_name in self._site_cache:
            return self._site_cache[site_name]

        try:
            if self.create_missing_resources:
                site = self.netbox_client.get_or_create_site(site_name)
            else:
                site = self.netbox_client.get_site_by_name(site_name)

            if site:
                site_id = site.get("id")
                if site_id is not None:
                    self._site_cache[site_name] = site_id
                    logger.debug("Resolved site '%s' to ID %s", site_name, site_id)
                    return site_id
            return None
        except Exception as e:
            logger.error(f"Error resolving site '{site_name}': {e}")
            return None

    def _resolve_or_create_device_role(self, role_name: str) -> Optional[int]:
        """Resolve device role name to ID, creating if necessary.

        Args:
            role_name: Name of the device role

        Returns:
            Device role ID, or None on error
        """
        # Check cache first
        if role_name in self._role_cache:
            return self._role_cache[role_name]

        try:
            if self.create_missing_resources:
                role = self.netbox_client.get_or_create_device_role(role_name)
            else:
                role = self.netbox_client.get_device_role_by_name(role_name)

            if role:
                role_id = role.get("id")
                if role_id is not None:
                    self._role_cache[role_name] = role_id
                    logger.debug("Resolved device role '%s' to ID %s", role_name, role_id)
                    return role_id
            return None
        except Exception as e:
            logger.error(f"Error resolving device role '{role_name}': {e}")
            return None

    def _resolve_or_create_device_type(self, model: str, manufacturer: str) -> Optional[int]:
        """Resolve device type by model, creating if necessary.

        Args:
            model: Device model name
            manufacturer: Manufacturer name

        Returns:
            Device type ID, or None on error
        """
        # Check cache first (cache key includes manufacturer for uniqueness)
        cache_key = f"{manufacturer}:{model}"
        if cache_key in self._device_type_cache:
            return self._device_type_cache[cache_key]

        try:
            if self.create_missing_resources:
                device_type = self.netbox_client.get_or_create_device_type(model, manufacturer)
            else:
                device_type = self.netbox_client.get_device_type_by_model(model)

            if device_type:
                type_id = device_type.get("id")
                if type_id is not None:
                    self._device_type_cache[cache_key] = type_id
                    logger.debug("Resolved device type '%s' to ID %s", model, type_id)
                    return type_id
            return None
        except Exception as e:
            logger.error(f"Error resolving device type '{model}': {e}")
            return None

    def _resolve_or_create_platform(self, platform_name: str) -> Optional[int]:
        """Resolve platform name to ID, creating if necessary.

        Args:
            platform_name: Platform/OS type name (e.g., "IOS", "JunOS")

        Returns:
            Platform ID, or None on error
        """
        if not platform_name:
            return None

        # Check cache first
        if platform_name in self._platform_cache:
            return self._platform_cache[platform_name]

        try:
            if self.create_missing_resources:
                platform = self.netbox_client.get_or_create_platform(platform_name)
            else:
                platform = self.netbox_client.get_platform_by_name(platform_name)

            if platform:
                platform_id = platform.get("id")
                if platform_id is not None:
                    self._platform_cache[platform_name] = platform_id
                    logger.debug("Resolved platform '%s' to ID %s", platform_name, platform_id)
                    return platform_id
            return None
        except Exception as e:
            logger.error(f"Error resolving platform '{platform_name}': {e}")
            return None

    def _sync_ip_address(
        self, device_id: int, hostname: str, ip_address: str, mac_address: Optional[str] = None
    ) -> Optional[int]:
        """Create or update IP address in NetBox and assign to device interface.

        Creates a management interface (mgmt0) on the device if needed, assigns the IP
        to that interface, then optionally sets it as the device's primary IP.

        Args:
            device_id: NetBox device ID
            hostname: Device hostname for logging
            ip_address: IP address string (without CIDR notation)
            mac_address: Optional MAC address to set on the interface

        Returns:
            IP address ID if created/found, None on error
        """
        try:
            # Format IP with subnet mask
            ip_with_cidr = f"{ip_address}/{self.default_subnet_mask}"

            # Create or get management interface for the device
            interface = self.netbox_client.get_or_create_interface(device_id, "mgmt0", "virtual")
            if not interface:
                logger.warning(f"Could not create interface for {hostname}")
                return None

            interface_id = interface.get("id")
            logger.debug("Using interface mgmt0 (ID %s) for %s", interface_id, hostname)

            device_outcome = self._find_device_outcome(hostname, ip_address)

            # Update interface with MAC address if provided, subject to
            # mac_conflict_policy - this is the device's own record, so a
            # differing existing MAC is "mac_differs"; the same MAC already
            # in use on a *different* interface is "mac_duplicate".
            if mac_address and interface_id:
                mac_to_write: Optional[str] = mac_address
                current_mac = (interface.get("mac_address") or "").strip()
                mac_changed = bool(current_mac and current_mac.lower() != mac_address.lower())
                duplicate_of = ""
                if self.mac_conflict_policy != "overwrite":
                    duplicate_of = self._detect_duplicate_interface_mac(mac_address, interface_id)

                if duplicate_of and self.mac_conflict_policy == "ask":
                    mac_to_write = None
                    logger.warning(
                        "Conflict: %s (%s) - %s, policy=ask, deferred for review", ip_address, hostname, duplicate_of
                    )
                    self._pending_items.append(
                        self._pending_item(
                            ip_address,
                            hostname,
                            "mac_duplicate",
                            duplicate_of,
                            {"interface_id": interface_id, "mac_address": mac_address},
                        )
                    )
                    if device_outcome:
                        device_outcome.detail = _append_detail(
                            device_outcome.detail, f"{duplicate_of} - awaiting decision"
                        )
                elif mac_changed:
                    if self.mac_conflict_policy == "leave_untouched":
                        mac_to_write = None
                    elif self.mac_conflict_policy == "ask":
                        mac_to_write = None
                        detail = f"MAC differs: NetBox has {current_mac}, LogicVein has {mac_address}"
                        logger.warning(
                            "Conflict: %s (%s) - %s, policy=ask, deferred for review", ip_address, hostname, detail
                        )
                        self._pending_items.append(
                            self._pending_item(
                                ip_address,
                                hostname,
                                "mac_differs",
                                detail,
                                {"interface_id": interface_id, "mac_address": mac_address},
                            )
                        )
                        if device_outcome:
                            device_outcome.detail = _append_detail(device_outcome.detail, "MAC change pending decision")
                    # "overwrite": mac_to_write stays mac_address

                if device_outcome and mac_changed:
                    device_outcome.mac_changed = True
                    device_outcome.mac_previous = current_mac

                if mac_to_write:
                    try:
                        self.netbox_client.update_interface(interface_id, {"mac_address": mac_to_write})
                        logger.debug("Set MAC address %s on interface for %s", mac_to_write, hostname)
                    except Exception as e:
                        logger.warning(f"Could not set MAC address on interface for {hostname}: {e}")

            # Check if IP already exists
            existing_ip = self.netbox_client.get_ip_address_by_address(ip_address)

            ip_data = {
                "address": ip_with_cidr,
                "status": self.default_ip_status,
                # Assign IP to the device interface
                "assigned_object_type": "dcim.interface",
                "assigned_object_id": interface_id,
            }

            # Add tenant if configured
            if self.tenant_id:
                ip_data["tenant"] = self.tenant_id

            # Add DNS name (hostname)
            ip_data["dns_name"] = hostname

            if existing_ip:
                logger.debug("IP address %s already exists, updating", ip_address)
                existing_assigned_id = existing_ip.get("assigned_object_id")
                ip_id = None
                if existing_assigned_id is not None and existing_assigned_id != interface_id:
                    if self.ip_conflict_policy == "ignore":
                        logger.info(
                            "Ignored primary IP: %s (%s) - already assigned to a different interface in NetBox",
                            ip_address,
                            hostname,
                        )
                        if device_outcome:
                            device_outcome.detail = _append_detail(
                                device_outcome.detail, "Primary IP already assigned to a different interface in NetBox"
                            )
                        return None
                    elif self.ip_conflict_policy == "ask":
                        logger.warning(
                            "Conflict: %s (%s) - IP already assigned to a different interface in NetBox,"
                            " policy=ask, deferred for review",
                            ip_address,
                            hostname,
                        )
                        self._pending_items.append(
                            self._pending_item(
                                ip_address,
                                hostname,
                                "ip_exists",
                                "Primary IP already assigned to a different interface in NetBox",
                                {"ip_id": existing_ip["id"], "ip_data": ip_data},
                            )
                        )
                        if device_outcome:
                            device_outcome.detail = _append_detail(
                                device_outcome.detail,
                                "Primary IP already assigned to a different interface in NetBox - awaiting decision",
                            )
                        return None
                    # "overwrite": keep today's behavior (steal it)
                    self._clear_primary_ip_owner(existing_ip["id"], hostname)
                ip_result = self.netbox_client.update_ip_address(existing_ip["id"], ip_data)
                ip_id = ip_result.get("id")
            else:
                logger.info("Creating IP address: %s for %s", ip_with_cidr, hostname)
                ip_result = self.netbox_client.create_ip_address(ip_data)
                ip_id = ip_result.get("id")

            # Set as primary IP on device if configured
            if self.set_primary_ip and ip_id:
                self._set_device_primary_ip(device_id, ip_id, hostname)

            return ip_id

        except Exception as e:
            logger.error(f"Error creating IP address {ip_address} for {hostname}: {e}")
            return None

    def _set_device_primary_ip(self, device_id: int, ip_id: int, hostname: str) -> bool:
        """Set the primary IPv4 address for a device.

        Args:
            device_id: NetBox device ID
            ip_id: NetBox IP address ID
            hostname: Device hostname for logging

        Returns:
            True if successful, False otherwise
        """
        try:
            device_update = {"primary_ip4": ip_id}
            self.netbox_client.update_device(device_id, device_update)
            logger.debug("Set primary IP for %s to IP ID %s", hostname, ip_id)
            return True
        except Exception as e:
            logger.warning(f"Could not set primary IP for {hostname}: {e}")
            return False

    def _find_device_outcome(self, hostname: str, ip_address: str) -> Optional[DeviceSyncOutcome]:
        """Find the device-level outcome already appended for this device, so a
        later step (IP/interface sync) can annotate it after the fact - the
        device's own added/updated/ignored outcome is always appended before
        IP/interface sync runs (see _sync_single_device())."""
        for outcome in self._outcomes:
            if outcome.hostname == hostname and outcome.ip_address == ip_address:
                return outcome
        return None

    def _pending_item(
        self, ip_address: str, hostname: str, conflict_type: str, detail: str, desired_payload: Dict[str, Any]
    ) -> Dict[str, Any]:
        return {
            "ip_address": ip_address,
            "hostname": hostname,
            "conflict_type": conflict_type,
            "detail": detail,
            "desired_payload": desired_payload,
        }

    def _detect_duplicate_interface_mac(self, mac_address: str, exclude_interface_id: Optional[int]) -> str:
        """Return a human-readable note if *mac_address* is already set on a
        *different* interface anywhere in NetBox, else "". Only called when
        mac_conflict_policy != "overwrite" - an extra API round-trip that's
        skipped entirely for the default (no-comparison) behavior."""
        try:
            matches = self.netbox_client.search_interfaces(filters={"mac_address": mac_address})
        except Exception as e:
            logger.warning("Could not check for duplicate MAC %s: %s", mac_address, e)
            return ""
        for iface in matches:
            if iface.get("id") == exclude_interface_id:
                continue
            device = iface.get("device")
            device_name = device.get("name") if isinstance(device, dict) else None
            return f"MAC {mac_address} already used by interface '{iface.get('name')}' on device '{device_name or '?'}'"
        return ""

    def _clear_primary_ip_owner(self, ip_id: int, hostname: str) -> None:
        """Clear primary_ip4 from any device that owns this IP to allow reassignment.

        Args:
            ip_id: NetBox IP address ID to unset as primary.
            hostname: Device hostname being updated (for log context).
        """
        try:
            devices = self.netbox_client.get_devices(filters={"primary_ip4_id": ip_id})
            for device in devices:
                self.netbox_client.update_device(device["id"], {"primary_ip4": None})
                logger.info(
                    "Cleared primary IP (ID %d) from '%s' to allow reassignment for %s",
                    ip_id,
                    device.get("name", device.get("id")),
                    hostname,
                )
        except Exception as e:
            logger.warning(
                "Could not clear primary IP owner for IP ID %d (%s): %s",
                ip_id,
                hostname,
                e,
            )

    def _sync_device_interfaces(
        self, device_id: int, ip_address: str, hostname: str, device_network: str = "Default"
    ) -> tuple:
        """Sync all interfaces from LogicVein to NetBox for a device.

        Args:
            device_id: NetBox device ID
            ip_address: Device IP address for LVI lookup
            hostname: Device hostname for logging

        Returns:
            Tuple of (synced_count, interface_has_device_ip)
        """
        try:
            # Get interfaces from LogicVein
            lvi_interfaces = self.lvi_client.get_device_interfaces(ip_address, device_network)

            if not lvi_interfaces:
                logger.debug("No interfaces found in LVI for %s", hostname)
                return 0, False

            synced_count = 0
            synced_interface_names: set = set()
            interface_has_device_ip = False

            for lvi_iface in lvi_interfaces:
                try:
                    iface_name = lvi_iface.get("name", "")
                    if not iface_name:
                        continue

                    # Truncate interface name to 64 characters (NetBox limit)
                    if len(iface_name) > 64:
                        iface_name = iface_name[:64].rstrip()

                    synced_interface_names.add(iface_name)

                    # Check if this interface has the device's main IP (from ipAddresses array)
                    iface_ip_list = lvi_iface.get("ipAddresses", []) or []
                    for ip_entry in iface_ip_list:
                        if ip_entry.get("ipAddress") == ip_address:
                            interface_has_device_ip = True
                            break

                    # Map LVI interface type/speed to NetBox interface type
                    netbox_type = self._map_interface_type(lvi_iface)

                    # Check if interface exists (use truncated name for lookup)
                    existing_iface = self.netbox_client.get_interface_by_name(device_id, iface_name)
                    existing_iface_id = existing_iface.get("id") if existing_iface else None

                    interface_data = {
                        "device": device_id,
                        "name": iface_name,
                        "type": netbox_type,
                    }

                    # Add optional fields
                    description = lvi_iface.get("description", "")
                    if description:
                        interface_data["description"] = description[:200]  # NetBox limit

                    # MAC handling, gated by sync_mac_address (previously
                    # unconditional here - only _sync_ip_address's mgmt0
                    # interface respected the toggle) and subject to
                    # mac_conflict_policy the same way _sync_ip_address is:
                    # "mac_differs" for this interface's own existing MAC
                    # disagreeing with LVI's, "mac_duplicate" for the
                    # incoming MAC already belonging to a *different*
                    # interface elsewhere in NetBox. Conflict detection only
                    # applies to an already-existing interface - a brand new
                    # interface has no prior NetBox state of its own to
                    # conflict with, so its MAC is always written as-is.
                    mac_address = lvi_iface.get("macAddress", "") if self.sync_mac_address else ""
                    if mac_address and not existing_iface:
                        interface_data["mac_address"] = mac_address
                    elif mac_address and existing_iface:
                        mac_to_write: Optional[str] = mac_address
                        current_mac = (existing_iface.get("mac_address") or "").strip()
                        mac_changed = bool(current_mac and current_mac.lower() != mac_address.lower())
                        duplicate_of = ""
                        if self.mac_conflict_policy != "overwrite":
                            duplicate_of = self._detect_duplicate_interface_mac(mac_address, existing_iface_id)

                        if duplicate_of and self.mac_conflict_policy == "ask":
                            mac_to_write = None
                            self._pending_items.append(
                                self._pending_item(
                                    ip_address,
                                    hostname,
                                    "mac_duplicate",
                                    f"{duplicate_of} (interface {iface_name})",
                                    {"interface_id": existing_iface_id, "mac_address": mac_address},
                                )
                            )
                            device_outcome = self._find_device_outcome(hostname, ip_address)
                            if device_outcome:
                                device_outcome.detail = _append_detail(
                                    device_outcome.detail,
                                    f"{duplicate_of} (interface {iface_name}) - awaiting decision",
                                )
                        elif mac_changed:
                            if self.mac_conflict_policy == "leave_untouched":
                                mac_to_write = None
                            elif self.mac_conflict_policy == "ask":
                                mac_to_write = None
                                detail = (
                                    f"MAC differs on {iface_name}: NetBox has {current_mac}, "
                                    f"LogicVein has {mac_address}"
                                )
                                self._pending_items.append(
                                    self._pending_item(
                                        ip_address,
                                        hostname,
                                        "mac_differs",
                                        detail,
                                        {"interface_id": existing_iface_id, "mac_address": mac_address},
                                    )
                                )
                                device_outcome = self._find_device_outcome(hostname, ip_address)
                                if device_outcome:
                                    device_outcome.detail = _append_detail(
                                        device_outcome.detail, f"MAC change pending decision ({iface_name})"
                                    )
                            # "overwrite": mac_to_write stays mac_address

                        if mac_to_write:
                            interface_data["mac_address"] = mac_to_write

                    # Set enabled status
                    admin_up = lvi_iface.get("adminUp", True)
                    interface_data["enabled"] = admin_up

                    # Add MTU if available; clamp to NetBox's maximum of 65536.
                    # Some Junos virtual/internal interfaces report values well above
                    # this limit (e.g. 2147483647) which NetBox rejects with HTTP 400.
                    mtu = lvi_iface.get("mtu")
                    if mtu and isinstance(mtu, int) and mtu > 0:
                        interface_data["mtu"] = min(mtu, 65536)

                    if existing_iface:
                        # Update existing interface
                        iface_id = existing_iface["id"]
                        self.netbox_client.update_interface(iface_id, interface_data)
                        logger.debug("Updated interface %s on %s", iface_name, hostname)
                    else:
                        # Create new interface
                        created_iface = self.netbox_client.create_interface(interface_data)
                        iface_id = created_iface.get("id") if created_iface else None
                        logger.debug("Created interface %s on %s", iface_name, hostname)

                    # Sync IP addresses for this interface
                    if self.create_ip_addresses and iface_id and iface_ip_list:
                        self._sync_interface_ips(iface_id, iface_name, hostname, iface_ip_list, ip_address)

                    synced_count += 1

                except Exception as e:
                    logger.warning(f"Error syncing interface {lvi_iface.get('name', 'unknown')} on {hostname}: {e}")
                    continue

            # Delete stale interfaces if configured
            if not self.dry_run and self.delete_stale_interfaces:
                self._delete_stale_interfaces(device_id, hostname, synced_interface_names)

            logger.info("Synced %d interfaces for %s", synced_count, hostname)
            return synced_count, interface_has_device_ip

        except Exception as e:
            logger.error(f"Error syncing interfaces for {hostname}: {e}")
            return 0, False

    def _sync_interface_ips(
        self, interface_id: int, iface_name: str, hostname: str, ip_list: list, device_ip_address: str = ""
    ) -> int:
        """Sync IP addresses from LogicVein to a NetBox interface.

        Args:
            interface_id: NetBox interface ID
            iface_name: Interface name for logging
            hostname: Device hostname for logging
            ip_list: List of IP address entries from LogicVein
            device_ip_address: The device's own primary IP, used to look up
                its report outcome (see _find_device_outcome()) to annotate
                when a secondary interface IP hits an "ask" conflict.

        Returns:
            Number of IPs synced
        """
        synced_count = 0
        for ip_entry in ip_list:
            try:
                ip_addr = ip_entry.get("ipAddress")
                if not ip_addr:
                    continue

                # Build IP with CIDR notation
                subnet_mask = ip_entry.get("subnetMask", self.default_subnet_mask)
                # If subnetMask is a dotted notation, convert to CIDR
                if isinstance(subnet_mask, str) and "." in subnet_mask:
                    # Count bits in dotted notation
                    try:
                        octets = [int(x) for x in subnet_mask.split(".")]
                        cidr = sum(bin(x).count("1") for x in octets)
                        subnet_mask = cidr
                    except (ValueError, AttributeError):
                        subnet_mask = self.default_subnet_mask
                elif not isinstance(subnet_mask, int):
                    subnet_mask = self.default_subnet_mask

                ip_with_cidr = f"{ip_addr}/{subnet_mask}"

                # Check if IP already exists in NetBox
                existing_ip = self.netbox_client.get_ip_address_by_address(ip_with_cidr)

                ip_data = {
                    "address": ip_with_cidr,
                    "status": self.default_ip_status,
                    "assigned_object_type": "dcim.interface",
                    "assigned_object_id": interface_id,
                }

                if existing_ip:
                    existing_assigned_id = existing_ip.get("assigned_object_id")
                    if existing_assigned_id is not None and existing_assigned_id != interface_id:
                        if self.ip_conflict_policy == "ignore":
                            logger.info(
                                "Ignored IP: %s (%s) - already assigned to a different interface in NetBox",
                                ip_with_cidr,
                                iface_name,
                            )
                            continue
                        elif self.ip_conflict_policy == "ask":
                            detail = f"IP {ip_with_cidr} already assigned to a different interface (not {iface_name})"
                            self._pending_items.append(
                                self._pending_item(
                                    ip_addr,
                                    hostname,
                                    "ip_exists",
                                    detail,
                                    {"ip_id": existing_ip["id"], "ip_data": ip_data},
                                )
                            )
                            device_outcome = self._find_device_outcome(hostname, device_ip_address)
                            if device_outcome:
                                device_outcome.detail = _append_detail(
                                    device_outcome.detail, f"{detail} - awaiting decision"
                                )
                            continue
                        # "overwrite": keep today's behavior (reassign)
                    # Update existing IP to point to this interface
                    ip_id = existing_ip["id"]
                    self.netbox_client.update_ip_address(ip_id, ip_data)
                    logger.debug("Updated IP %s on %s (%s)", ip_with_cidr, iface_name, hostname)
                    # Track synced IP
                    if self.delete_stale_ips:
                        self._synced_ip_ids.add(ip_id)
                else:
                    # Create new IP address
                    created_ip = self.netbox_client.create_ip_address(ip_data)
                    if created_ip:
                        logger.debug("Created IP %s on %s (%s)", ip_with_cidr, iface_name, hostname)
                        # Track synced IP
                        if self.delete_stale_ips:
                            self._synced_ip_ids.add(created_ip.get("id"))

                synced_count += 1

            except Exception as e:
                logger.warning(f"Error syncing IP {ip_entry.get('ipAddress', 'unknown')} on {iface_name}: {e}")
                continue

        return synced_count

    def _delete_stale_interfaces(self, device_id: int, hostname: str, synced_names: set) -> int:
        """Delete interfaces from NetBox that are no longer in LogicVein.

        Args:
            device_id: NetBox device ID
            hostname: Device hostname for logging
            synced_names: Set of interface names that were synced

        Returns:
            Number of interfaces deleted
        """
        try:
            # Get all interfaces for this device from NetBox
            netbox_interfaces = self.netbox_client.get_interfaces(device_id)

            deleted_count = 0
            for iface in netbox_interfaces:
                iface_name = iface.get("name", "")
                iface_id = iface["id"]

                # Delete if not in synced set (includes mgmt0 if it wasn't from LVI)
                if iface_name not in synced_names:
                    try:
                        self.netbox_client.delete_interface(iface_id)
                        logger.info("Deleted stale interface %s from %s", iface_name, hostname)
                        deleted_count += 1
                    except Exception as e:
                        logger.warning(f"Error deleting interface {iface_name} from {hostname}: {e}")

            if deleted_count > 0:
                logger.info("Deleted %d stale interfaces from %s", deleted_count, hostname)

            return deleted_count

        except Exception as e:
            logger.error(f"Error cleaning up stale interfaces for {hostname}: {e}")
            return 0

    def _delete_stale_devices_and_ips(self) -> tuple:
        """Delete devices and IPs from NetBox that are no longer in LogicVein.

        Only considers devices in the configured site (if set).

        Returns:
            Tuple of (deleted_devices_count, deleted_ips_count)
        """
        deleted_devices = 0
        deleted_ips = 0

        try:
            # Build filter for devices - must be in the same site
            device_filters = {}
            if self.site_id:
                device_filters["site_id"] = self.site_id
            if self.tenant_id:
                device_filters["tenant_id"] = self.tenant_id

            if not device_filters:
                logger.warning("Skipping stale deletion - no site or tenant filter configured")
                return 0, 0

            # Get all devices from NetBox matching our filters
            netbox_devices = self.netbox_client.get_devices(filters=device_filters)
            logger.info("Checking %d NetBox devices for stale entries", len(netbox_devices))

            for device in netbox_devices:
                device_id = device["id"]
                device_name = device.get("name", "unknown")

                if device_id not in self._synced_device_ids:
                    # This device was not synced - it's stale
                    if self.delete_stale_devices:
                        try:
                            # Delete associated IPs first if configured
                            if self.delete_stale_ips:
                                deleted_ips += self._delete_device_ips(device_id, device_name)

                            # Delete the device
                            self.netbox_client.delete_device(device_id)
                            logger.info("Deleted stale device: %s", device_name)
                            deleted_devices += 1
                        except Exception as e:
                            logger.warning(f"Error deleting stale device {device_name}: {e}")
                    elif self.delete_stale_ips:
                        # Only delete IPs, not the device
                        deleted_ips += self._delete_device_ips(device_id, device_name)

            if deleted_devices > 0 or deleted_ips > 0:
                logger.info("Stale cleanup: %d devices, %d IPs deleted", deleted_devices, deleted_ips)

            return deleted_devices, deleted_ips

        except Exception as e:
            logger.error(f"Error during stale device/IP cleanup: {e}")
            return deleted_devices, deleted_ips

    def _delete_device_ips(self, device_id: int, device_name: str) -> int:
        """Delete all IP addresses associated with a device.

        Args:
            device_id: NetBox device ID
            device_name: Device name for logging

        Returns:
            Number of IPs deleted
        """
        deleted_count = 0
        try:
            # Get all interfaces for this device
            interfaces = self.netbox_client.get_interfaces(device_id)

            for iface in interfaces:
                iface_id = iface["id"]
                # Get IPs assigned to this interface
                ips = self.netbox_client.get_ip_addresses(filters={"interface_id": iface_id})

                for ip in ips:
                    ip_id = ip["id"]
                    ip_addr = ip.get("address", "unknown")
                    try:
                        self.netbox_client.delete_ip_address(ip_id)
                        logger.debug("Deleted IP %s from %s", ip_addr, device_name)
                        deleted_count += 1
                    except Exception as e:
                        logger.warning(f"Error deleting IP {ip_addr}: {e}")

            return deleted_count

        except Exception as e:
            logger.error(f"Error deleting IPs for {device_name}: {e}")
            return deleted_count

    def _map_interface_type(self, lvi_interface: Dict[str, Any]) -> str:
        """Map LVI interface speed/type to NetBox interface type."""
        return field_mapping.map_interface_type(lvi_interface)

    def _build_custom_fields(self, lvi_device: Dict[str, Any]) -> Dict[str, Any]:
        """Build custom fields data from LogicVein device."""
        return field_mapping.build_custom_fields(lvi_device, self.custom_field_mapping)

    def _build_lifecycle_fields(self, lvi_device: Dict[str, Any]) -> Dict[str, Any]:
        """Build lifecycle custom fields from LogicVein device (epochs -> ISO dates)."""
        return field_mapping.build_lifecycle_fields(lvi_device, self.lifecycle_field_mapping)

    def _build_lvi_custom_fields(self, lvi_device: Dict[str, Any]) -> Dict[str, Any]:
        """Build custom fields from LogicVein custom1-5 fields."""
        return field_mapping.build_lvi_custom_fields(lvi_device, self.lvi_custom_field_mapping)

    def _format_timestamp(self, epoch_ms: Optional[int]) -> str:
        """Format epoch milliseconds to ISO timestamp string."""
        return field_mapping.format_timestamp(epoch_ms)

    def _resolve_or_create_location(self, location_name: str, site_id: int) -> Optional[int]:
        """Resolve location name to ID, creating if necessary.

        Args:
            location_name: Location name (from LVI sysLocation)
            site_id: Site ID the location belongs to

        Returns:
            Location ID, or None on error
        """
        # LVI sysLocation values sometimes arrive with surrounding quotes - strip them.
        location_name = location_name.strip().strip('"').strip("'").strip()

        if not location_name or not site_id:
            return None

        # Check cache first (cache key includes site_id for uniqueness)
        cache_key = f"{site_id}:{location_name}"
        if cache_key in self._location_cache:
            return self._location_cache[cache_key]

        try:
            if self.create_missing_locations:
                location = self.netbox_client.get_or_create_location(location_name, site_id)
            else:
                location = self.netbox_client.get_location_by_name_and_site(location_name, site_id)

            if location:
                location_id = location.get("id")
                if location_id is not None:
                    self._location_cache[cache_key] = location_id
                    logger.debug(f"Resolved location '{location_name}' to ID {location_id}")
                    return location_id
            return None
        except Exception as e:
            logger.error(f"Error resolving location '{location_name}': {e}")
            return None
