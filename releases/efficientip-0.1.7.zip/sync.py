"""LogicVein to EfficientIP SOLIDserver IPAM sync engine.

Per-device REST upserts (SOLIDserver has no bulk-import mechanism analogous
to Infoblox's discovery CSV, so this follows the NetBox plugin's per-object
style instead).
"""

import ipaddress
import logging
from typing import Any, Dict, List, Optional

from src.plugin_api import CancellationToken, SyncCancelled, normalize_networks

from .client import EfficientIPClient

logger = logging.getLogger(__name__)


class LogicVeinEfficientIPSync:
    """Sync LogicVein device inventory into EfficientIP SOLIDserver IPAM."""

    def __init__(
        self,
        lvi_client: Any,
        efficientip_client: EfficientIPClient,
        config: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialise the sync engine.

        Args:
            lvi_client: LogicVeinAPIClient instance.
            efficientip_client: EfficientIPClient instance.
            config: Configuration dict from EfficientIPPlugin.build_sync_config().
        """
        self.lvi = lvi_client
        self.target = efficientip_client
        self.config = config or {}

        self.dry_run = bool(self.config.get("dry_run", False))
        self.continue_on_error = bool(self.config.get("continue_on_error", True))
        self.networks = normalize_networks(self.config.get("network", "Default"))
        self.space_name = self.config.get("space_name", "Local")
        self.create_missing_subnets = bool(self.config.get("create_missing_subnets", False))
        self.create_missing_blocks = bool(self.config.get("create_missing_blocks", False))
        self.class_parameter_mapping: Dict[str, str] = self.config.get("class_parameter_mapping", {}) or {}

        self._cancel: Optional[CancellationToken] = None
        self._site_id: Optional[str] = None

    def set_cancel_token(self, token: CancellationToken) -> None:
        """Set the cancellation token for this sync operation."""
        self._cancel = token

    def _check_cancel(self) -> None:
        if self._cancel is not None:
            self._cancel.check()  # raises SyncCancelled

    def _resolve_site_id(self) -> Optional[str]:
        """Look up the configured IP space (site) by name, once per sync."""
        if self._site_id is not None:
            return self._site_id
        space = self.target.get_space_by_name(self.space_name)
        if not space:
            logger.error("EfficientIP IP space '%s' not found", self.space_name)
            return None
        self._site_id = space["site_id"]
        return self._site_id

    def _build_class_parameters(self, device: Dict[str, Any]) -> Dict[str, str]:
        """Map configured LVI device fields to SOLIDserver class parameter names."""
        params: Dict[str, str] = {}
        for lvi_field, class_param_name in self.class_parameter_mapping.items():
            value = device.get(lvi_field)
            if value:
                params[class_param_name] = str(value)
        return params

    def _ensure_block_exists(self, ip_address: str, site_id: str) -> bool:
        """Return True once a covering IP block exists for *ip_address*.

        Creates one (a /16) only when create_missing_blocks is enabled -
        independent of create_missing_subnets, which only controls whether
        the /24 subnet itself gets created. A /16 is large enough to hold
        many /24 subnets, so devices sharing a /16 reuse the same block
        instead of each needing their own. Only called when not in
        dry-run mode.
        """
        if self.target.find_block_for_ip(ip_address, site_id=site_id) is not None:
            return True
        if not self.create_missing_blocks:
            return False
        try:
            block_network = ipaddress.ip_interface(f"{ip_address}/16").network
        except ValueError:
            return False
        created = self.target.create_block(str(block_network), site_id=site_id)
        if created:
            logger.info("Created block %s in space '%s'", block_network, self.space_name)
        else:
            logger.warning("Could not create block %s for %s", block_network, ip_address)
        return created

    def _resolve_subnet_id(self, ip_address: str, site_id: str) -> Optional[str]:
        """Return the subnet_id containing *ip_address*, creating the subnet (and its parent
        block, if needed) first if configured to.

        This lookup always runs (not just when create_missing_subnets is
        set) because create_or_update_address needs the subnet_id to link
        the address record - without it, SOLIDserver creates the address
        under the site but leaves it unassociated with any subnet, where it
        shows up under "Orphan Addresses" in the UI.

        create_missing_blocks and create_missing_subnets are independent:
        enabling only create_missing_blocks still ensures/creates the
        covering block (useful to pre-provision address space) but never
        attempts the subnet itself; enabling only create_missing_subnets
        never creates a block, so subnet creation fails when none exists.
        """
        subnet = self.target.find_subnet_for_ip(ip_address, site_id=site_id)
        if subnet is not None:
            return subnet.get("subnet_id")

        if not self.create_missing_blocks and not self.create_missing_subnets:
            return None

        if self.dry_run:
            if self.create_missing_blocks and self.target.find_block_for_ip(ip_address, site_id=site_id) is None:
                block_network = ipaddress.ip_interface(f"{ip_address}/16").network
                logger.info("[DRY RUN] Would create block %s in space '%s'", block_network, self.space_name)
            if self.create_missing_subnets:
                try:
                    network = ipaddress.ip_interface(f"{ip_address}/24").network
                    logger.info("[DRY RUN] Would create subnet %s in space '%s'", network, self.space_name)
                except ValueError:
                    pass
            return None

        # Ensure/create the covering block regardless of whether we are
        # also going to create the subnet - a standalone create_missing_blocks
        # must still take effect.
        block_exists = self._ensure_block_exists(ip_address, site_id)

        if not self.create_missing_subnets:
            return None

        try:
            network = ipaddress.ip_interface(f"{ip_address}/24").network
        except ValueError:
            logger.warning("Could not derive a subnet for invalid IP: %s", ip_address)
            return None

        if not block_exists:
            logger.warning(
                "Could not create subnet %s for %s: no covering IP block (create_missing_blocks is %s)",
                network,
                ip_address,
                "on but creation failed" if self.create_missing_blocks else "off",
            )
            return None

        created = self.target.create_subnet(str(network), site_id=site_id)
        if not created:
            logger.warning("Could not create subnet %s for %s", network, ip_address)
            return None

        logger.info("Created subnet %s in space '%s'", network, self.space_name)
        subnet = self.target.find_subnet_for_ip(ip_address, site_id=site_id)
        return subnet.get("subnet_id") if subnet else None

    def sync(self) -> bool:
        """Run one sync. Return True if every device synced without error."""
        logger.info("LogicVein to EfficientIP SOLIDserver sync starting (dry_run=%s)", self.dry_run)

        site_id = self._resolve_site_id()
        if site_id is None:
            return False

        devices: List[dict] = self.lvi.search_devices_in_network(network=self.networks)
        logger.info("Fetched %d device(s) from LogicVein", len(devices))

        errors = 0
        for device in devices:
            self._check_cancel()

            ip_address = device.get("ipAddress", "")
            if not ip_address:
                continue

            hostname = device.get("hostname", "")
            mac_address = (device.get("macAddress") or "").replace("-", ":").lower()
            class_parameters = self._build_class_parameters(device)

            try:
                subnet_id = self._resolve_subnet_id(ip_address, site_id)

                if self.dry_run:
                    logger.info(
                        "[DRY RUN] Would upsert %s (%s) into EfficientIP", ip_address, hostname or "no hostname"
                    )
                    continue

                if subnet_id is None:
                    # No containing subnet (missing, or create_missing_subnets
                    # failed) - skip rather than create an address unlinked
                    # to any subnet ("Orphan Addresses" in the SOLIDserver UI).
                    logger.warning(
                        "Skipping %s: no subnet found in space '%s' (device not synced)",
                        ip_address,
                        self.space_name,
                    )
                    errors += 1
                    if not self.continue_on_error:
                        logger.error("Stopping due to error (continue_on_error=False)")
                        return False
                    continue

                success = self.target.create_or_update_address(
                    ip_address=ip_address,
                    site_id=site_id,
                    subnet_id=subnet_id,
                    hostname=hostname,
                    mac_address=mac_address,
                    class_parameters=class_parameters,
                )
                if not success:
                    errors += 1
                    if not self.continue_on_error:
                        logger.error("Stopping due to error (continue_on_error=False)")
                        return False
            except SyncCancelled:
                raise
            except Exception as exc:
                errors += 1
                logger.error("EfficientIP sync failed on %s: %s", ip_address, exc)
                if not self.continue_on_error:
                    logger.error("Stopping due to error (continue_on_error=False)")
                    return False

        logger.info("EfficientIP sync complete: %d device(s), %d error(s)", len(devices), errors)
        return errors == 0
