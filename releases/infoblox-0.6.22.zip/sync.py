"""LogicVein to Infoblox IPAM Sync Module."""

import csv
import io
import ipaddress
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Set

# logicvein (the vendored LVI API client) lives in the sibling lvi_sync_manager repo too.
from logicvein import LogicVeinAPIClient  # pyright: ignore[reportMissingImports]

# src.plugin_api lives in the sibling lvi_sync_manager repo - not a real import error.
from src.plugin_api import (  # pyright: ignore[reportMissingImports]
    CancellableSync,
    CancellationToken,
    DeviceSyncOutcome,
    SyncReport,
    format_epoch_ms,
    generate_task_name,
    get_product_name,
    get_vendor_name,
    normalize_networks,
    pending_conflict_item,
    record_pending_conflicts,
)

from .client import InfobloxClient

logger = logging.getLogger(__name__)

PLUGIN_NAME = "infoblox"


def _classful_network_for_ip(ip_address: str) -> Optional[str]:
    """Return the traditional classful network CIDR for an IPv4 address.

    Class A (1-126):   /8  - e.g. 10.1.2.3   → 10.0.0.0/8
    Class B (128-191): /16 - e.g. 172.16.1.1  → 172.16.0.0/16
    Class C (192-223): /24 - e.g. 192.168.1.5 → 192.168.1.0/24

    Args:
        ip_address: The IPv4 address to classify.

    Returns:
        The classful network CIDR, or None for loopback (127),
        multicast (224+), or reserved (0) addresses.
    """
    try:
        addr = ipaddress.IPv4Address(ip_address)
        first_octet = int(addr) >> 24
        if 1 <= first_octet <= 126:
            prefix_len = 8
        elif 128 <= first_octet <= 191:
            prefix_len = 16
        elif 192 <= first_octet <= 223:
            prefix_len = 24
        else:
            return None
        return str(ipaddress.IPv4Network(f"{ip_address}/{prefix_len}", strict=False))
    except ValueError:
        return None


def _fqdn_matches_zone(fqdn: str, known_zones: Set[str]) -> bool:
    """Return True if any domain suffix of fqdn is a known authoritative DNS zone."""
    parts = fqdn.split(".")
    for i in range(1, len(parts)):
        if ".".join(parts[i:]) in known_zones:
            return True
    return False


# Infoblox discovery_csv column order (40 columns required by fileop/setdiscoverycsv)
_INFOBLOX_CSV_COLUMNS = [
    "ip_address",
    "mac_address",
    "discovered_name",
    "device_vendor",
    "device_model",
    "device_location",
    "os",
    "vrf_name",
    "discoverer",
    "task_name",
    "first_discovered_timestamp",
    "last_discovered_timestamp",
    "network_component_ip",
    "network_component_name",
    "network_component_description",
    "network_component_location",
    "network_component_model",
    "network_component_vendor",
    "network_component_type",
    "network_component_port_name",
    "device_port_name",
    "network_component_port_description",
    "network_component_port_number",
    "port_speed",
    "port_status",
    "port_type",
    "port_vlan_name",
    "port_vlan_number",
    "ap_ip_address",
    "ap_name",
    "ap_ssid",
    "bgp_as",
    "bridge_domain",
    "device_contact",
    "endpoint_groups",
    "netbios_name",
    "network_component_contact",
    "port_duplex",
    "port_link_status",
    "tenant",
    "vrf_description",
    "vrf_rd",
]


class LogicVeinInfobloxIPAMSync(CancellableSync):
    """IPAM sync using Infoblox WAPI calls."""

    def __init__(
        self,
        lvi_client: LogicVeinAPIClient,
        ipam_client: InfobloxClient,
        config: Optional[Dict[str, Any]] = None,
    ):
        """
        Initialize sync.

        Args:
            lvi_client: LogicVeinAPIClient instance
            ipam_client: InfobloxClient instance
            config: Configuration dictionary with sync, logicvein, and infoblox settings
        """
        self.lvi_client = lvi_client
        self.ipam_client = ipam_client

        # Store config dict for access throughout object lifetime
        self.config = config or {}

        # Extract commonly used config values to avoid nested .get() calls
        self.dry_run = self.config.get("dry_run", False)
        self.continue_on_error = self.config.get("continue_on_error", True)
        self.networks = normalize_networks(self.config.get("network", "Default"))
        self.network_view = self.config.get("network_view", "default")
        self.sync_networks = self.config.get("sync_networks", False)
        self.create_network_containers = self.config.get("create_network_containers", False)
        self.convert_ips_to_hosts = self.config.get("convert_ips_to_hosts", False)
        self.configure_for_dns = self.config.get("configure_for_dns", True)
        self.host_domain_name = self.config.get("host_domain_name", "")
        self.post_host_conversion = self.config.get("post_host_conversion", {})
        self.discoverer = self.config.get("discoverer") or get_product_name()
        # Dedicated gate over writing MAC addresses, matching EfficientIP/
        # NetBox/SNOW/Jira's boolean toggle. There are two separate MAC
        # write paths here, mutually exclusive per run (see
        # _update_devices_in_ipam_wrapper()'s early-return on
        # convert_ips_to_hosts): host-conversion creation
        # (_convert_ips_to_hosts, via host_field_mapping, when
        # convert_ips_to_hosts is on) and the EA-only update path
        # (_update_devices_in_ipam -> update_device_in_ipam(), only when
        # convert_ips_to_hosts is off AND an extensible_attribute_mapping
        # is configured) - that second path wrote mac_address
        # unconditionally with no toggle of its own, unlike
        # populate_host_fields, which only ever covered the first path.
        self.sync_mac_address = bool(self.config.get("sync_mac_address", True))
        # What to do when the host-conversion path finds this IP already
        # claimed by a *different* host record/fixedaddress (checked only
        # when this device has no existing host record of its own yet -
        # see _convert_ips_to_hosts()): "overwrite" (default, proceed with
        # create as today), "ignore" (skip the device this run), "ask"
        # (defer for review in the Resolve Conflicts screen).
        self.ip_conflict_policy = self.config.get("ip_conflict_policy", "overwrite")
        # Off by default: renaming a host record moves its DNS name, which is
        # not something an upgrade should start doing unasked.
        self.rename_host_to_configured_domain = self.config.get("rename_host_to_configured_domain", False)
        # What to do when an existing host record's own MAC differs from
        # LogicVein's, or the incoming MAC is already set on a different
        # fixedaddress object: "overwrite" (default), "leave_untouched"
        # (skip the MAC field only, other host fields still sync), "ask"
        # (defer for review). Only consulted when sync_mac_address is on.
        self.mac_conflict_policy = self.config.get("mac_conflict_policy", "overwrite")

        self.task_name = ""

        # Post-sync data exposed for UI download buttons
        self.last_lvi_devices: Optional[List[Dict[str, str]]] = None
        self.last_infoblox_csv: Optional[bytes] = None

        # Per-device outcomes for this run's SyncReport (see sync()). Populated
        # by whichever per-device pass ran (_convert_ips_to_hosts or
        # _update_devices_in_ipam); if neither ran (bulk-CSV-only path), sync()
        # falls back to one coarse outcome per device from _csv_import_ok.
        self._outcomes: List[DeviceSyncOutcome] = []
        self._csv_import_ok: Optional[bool] = None

        # Conflicts deferred this run under an "ask" policy - recorded once
        # at the end of sync() via record_pending_conflicts().
        self._pending_items: List[Dict[str, Any]] = []

        # All interface entries per management IP - populated by _prefetch_interface_lookup
        self._all_iface_entries_by_ip: Dict[str, List[Dict[str, Any]]] = {}

        # Raw LVI device dicts keyed by management IP - populated by _fetch_devices
        self._raw_devices_by_ip: Dict[str, Dict[str, Any]] = {}

        # Cancellation support
        self._cancel_token: Optional["CancellationToken"] = None

    def _get_mac_address(self, ip_address: str, device_network: str = "Default") -> str:
        """Get MAC address for a device via switch port lookup.

        Args:
            ip_address: Device IP address
            device_network: LVI network the device belongs to

        Returns:
            MAC address string or empty string if not found
        """
        try:
            arp_table = self.lvi_client.get_arp_entries(network_address=ip_address, networks=[device_network])

            if arp_table and isinstance(arp_table, list) and len(arp_table) > 0:
                # Search arp_table list for matching ipAddress and return macAddress
                for entry in arp_table:
                    if entry.get("ipAddress") == ip_address:
                        mac_address = entry.get("macAddress", "")
                        if mac_address:
                            # Convert to standard format (e.g., AA:BB:CC:DD:EE:FF)
                            mac_address = mac_address.replace("-", ":").lower()
                            return mac_address
            return ""

        except Exception as e:
            logger.debug("Could not get MAC address for %s: %s", ip_address, e)
            return ""

    def _get_vrf_name(self, ip_address: str, device_network: str = "Default") -> str:
        """Get VRF name from ARP table lookup.

        Args:
            ip_address: Device IP address
            device_network: LVI network the device belongs to

        Returns:
            VRF name string or empty string if not found
        """
        try:
            # Get ARP entries for this device IP
            arp_entries = self.lvi_client.get_device_arp_table(
                ip_address=ip_address, network=device_network, page_size=1000
            )

            # Search for matching IP in ARP entries and extract vrfName
            if arp_entries and isinstance(arp_entries, list):
                for entry in arp_entries:
                    if entry.get("ipAddress") == ip_address:
                        vrf_name = entry.get("vrfName", "")
                        if vrf_name:
                            return vrf_name

            return ""

        except Exception as e:
            logger.debug("Could not get VRF name for %s: %s", ip_address, e)
            return ""

    def _find_switch_port(self, ip_address: str, matched_mac: str, device_network: str) -> Dict[str, str]:
        """Find the upstream switch port for a server via MAC lookup.

        Tries each MAC address found on the device's interfaces, starting with
        the MAC from the interface whose IP matches the management IP.

        Args:
            ip_address: Device management IP (used to look up all interface entries).
            matched_mac: MAC from the interface already matched to this device IP - tried first.
            device_network: LVI network name passed to find_switch_port_for_host.

        Returns:
            Dict with network_component_name, network_component_port_name, port_vlan_number,
            or empty strings if no switch port found.
        """
        if self.lvi_client is None:
            return self._empty_switch_port()

        macs: List[str] = []
        if matched_mac:
            macs.append(matched_mac)
        for entry in self._all_iface_entries_by_ip.get(ip_address, []):
            mac = entry.get("interface", {}).get("macAddress", "") or ""
            if mac and mac not in macs:
                macs.append(mac)

        for mac in macs:
            try:
                result = self.lvi_client.find_switch_port_for_host(mac, networks=[device_network])
                if result and result.get("macEntry"):
                    mac_entry = result["macEntry"]
                    switch_ip = mac_entry.get("device", "") or ""
                    port_name = mac_entry.get("port", "") or ""
                    switch_raw = self._raw_devices_by_ip.get(switch_ip, {})
                    port_desc = ""
                    for iface_entry in self._all_iface_entries_by_ip.get(switch_ip, []):
                        if iface_entry.get("interface", {}).get("name") == port_name:
                            port_desc = iface_entry.get("interface", {}).get("description", "") or ""
                            break
                    return {
                        "network_component_name": mac_entry.get("hostname", "") or "",
                        "network_component_port_name": port_name,
                        "network_component_port_description": port_desc,
                        "port_vlan_number": str(mac_entry.get("vlan", "") or ""),
                        "network_component_ip": switch_ip,
                        "network_component_description": (switch_raw.get("sysDescr", "") or "")
                        .replace("\n", "")
                        .replace("\r", ""),
                        "network_component_location": switch_raw.get("sysLocation", "") or "",
                        "network_component_model": switch_raw.get("model", "") or "",
                        "network_component_type": switch_raw.get("deviceType", "") or "",
                        "network_component_vendor": switch_raw.get("hardwareVendor", "") or "",
                    }
            except Exception as e:
                logger.debug("Switch port lookup failed for MAC %s on %s: %s", mac, ip_address, e)

        return self._empty_switch_port()

    def _empty_switch_port(self) -> Dict[str, str]:
        """Return the switch-port field dict with every value blank (no match found)."""
        return {
            "network_component_name": "",
            "network_component_port_name": "",
            "network_component_port_description": "",
            "port_vlan_number": "",
            "network_component_ip": "",
            "network_component_description": "",
            "network_component_location": "",
            "network_component_model": "",
            "network_component_type": "",
            "network_component_vendor": "",
        }

    def _prefetch_interface_lookup(self, networks: List[str]) -> Dict[str, Dict[str, Any]]:
        """Pre-fetch all device interfaces and index them by management IP.

        Calls search_device_interfaces() once per network (it paginates internally)
        and returns a dict mapping management IP → the interface entry whose
        interfaceIps list contains that IP.

        Args:
            networks: List of LVI network names to query.

        Returns:
            Dict mapping management IP to the matching interface entry dict.
        """
        # Group entries by management IP so we can pick the best match per device.
        by_ip: Dict[str, List[Dict[str, Any]]] = {}
        for network in networks or ["Default"]:
            try:
                for entry in self.lvi_client.search_device_interfaces(network=network):
                    mgmt_ip = entry.get("ipAddress", "")
                    if mgmt_ip:
                        by_ip.setdefault(mgmt_ip, []).append(entry)
            except Exception as e:
                logger.warning("Could not prefetch interfaces for network '%s': %s", network, e)

        lookup: Dict[str, Dict[str, Any]] = {}
        for mgmt_ip, entries in by_ip.items():
            # Prefer the interface whose interfaceIps list contains the management IP.
            # Fall back to the first entry when interfaceIps is absent or empty.
            matched = next(
                (e for e in entries if any(ip.split("/")[0] == mgmt_ip for ip in e.get("interfaceIps", []) or [])),
                entries[0],
            )
            lookup[mgmt_ip] = matched

        self._all_iface_entries_by_ip = by_ip
        logger.debug("Prefetched interface data for %d devices", len(lookup))
        return lookup

    def _build_logicvein_device_row(self, device: Dict[str, Any], enrichment: Dict[str, str]) -> Dict[str, str]:
        """Build a device data dict from LVI API response and enrichment data.

        Args:
            device: Device data from Inventory.search
            enrichment: Enrichment data - mac_address and vrf_name.

        Returns:
            Dictionary of device fields
        """
        row = {
            "ip_address": device.get("ipAddress", ""),
            "mac_address": enrichment.get("mac_address", ""),
            "hostname": device.get("hostname", ""),
            "network": device.get("network", ""),
            "adapter": device.get("adapterId", ""),
            "memo": device.get("memoSummary", ""),
            "hw_vendor": device.get("hardwareVendor", ""),
            "device_model": device.get("model", ""),
            "device_type": device.get("deviceType", ""),
            "os_version": device.get("osVersion", ""),
            "os_type": device.get("osType", ""),
            "serial_number": device.get("serialNumber", ""),
            "sys_location": device.get("sysLocation", ""),
            "sys_description": (device.get("sysDescr") or "").replace("\n", "").replace("\r", ""),
            "vrf_name": enrichment.get("vrf_name", ""),
            "port_speed": enrichment.get("port_speed", ""),
            "port_type": enrichment.get("port_type", ""),
            "port_status": enrichment.get("port_status", ""),
            "port_name": enrichment.get("port_name", ""),
            "network_component_ip": enrichment.get("network_component_ip", ""),
            "network_component_name": enrichment.get("network_component_name", ""),
            "network_component_description": enrichment.get("network_component_description", ""),
            "network_component_location": enrichment.get("network_component_location", ""),
            "network_component_model": enrichment.get("network_component_model", ""),
            "network_component_type": enrichment.get("network_component_type", ""),
            "network_component_vendor": enrichment.get("network_component_vendor", ""),
            "network_component_port_name": enrichment.get("network_component_port_name", ""),
            "network_component_port_description": enrichment.get("network_component_port_description", ""),
            "port_vlan_number": enrichment.get("port_vlan_number", ""),
            "last_discovery": format_epoch_ms(device.get("lastDiscovery", "")),
            "last_backup": format_epoch_ms(device.get("lastBackup", "")),
            "last_change": format_epoch_ms(device.get("lastChange", "")),
            "end_of_sale": format_epoch_ms(device.get("endOfSale", ""), date_only=True),
            "end_of_life": format_epoch_ms(device.get("endOfLife", ""), date_only=True),
            "software_end_of_sale": format_epoch_ms(device.get("softwareEndOfSale", ""), date_only=True),
            "software_end_of_life": format_epoch_ms(device.get("softwareEndOfLife", ""), date_only=True),
            "custom1": device.get("custom1", ""),
            "custom2": device.get("custom2", ""),
            "custom3": device.get("custom3", ""),
            "custom4": device.get("custom4", ""),
            "custom5": device.get("custom5", ""),
        }

        # Strip leading/trailing whitespace from all string fields
        for key, value in row.items():
            if isinstance(value, str):
                row[key] = value.strip()

        return row

    def _get_devices(self) -> List[Dict[str, Any]]:
        """Get all devices from LogicVein network.

        Returns:
            List of device dictionaries
        """
        _network_label = (
            f"all {get_product_name()} networks"
            if not self.networks
            else f"{get_product_name()} network '{', '.join(self.networks)}'"
        )
        logger.debug("Fetching devices from %s", _network_label)
        devices = self.lvi_client.search_devices_in_network(network=self.networks)
        return devices if devices else []

    def _fetch_devices(self) -> Optional[List[Dict[str, str]]]:
        """Fetch all devices from LogicVein and enrich them into in-memory dicts.

        Returns:
            List of enriched device dicts, or None on failure.
        """
        _network_label = (
            f"all {get_product_name()} networks"
            if not self.networks
            else f"{get_product_name()} network '{', '.join(self.networks)}'"
        )
        logger.info("Fetching devices from %s", _network_label)
        try:
            raw_devices = self._get_devices()
            if not raw_devices:
                logger.warning("No devices found in %s", _network_label)
                return None

            logger.info("Found %d devices", len(raw_devices))

            self._raw_devices_by_ip = {d.get("ipAddress", ""): d for d in raw_devices if d.get("ipAddress")}

            unique_networks = list(
                {d.get("network") or (self.networks[0] if self.networks else "Default") for d in raw_devices}
            )
            interface_lookup = self._prefetch_interface_lookup(unique_networks)

            devices = []

            for idx, device in enumerate(raw_devices, 1):
                self._check_cancelled()

                ip_address = device.get("ipAddress", "")
                if not ip_address:
                    continue

                if idx % 50 == 0:
                    logger.info("Processing device %d/%d: %s", idx, len(raw_devices), ip_address)

                device_network = device.get("network") or (self.networks[0] if self.networks else "Default")
                is_server = (device.get("deviceType") or "").lower() == "server"
                try:
                    iface_entry = interface_lookup.get(ip_address, {})
                    iface = iface_entry.get("interface", {}) if iface_entry else {}

                    if is_server:
                        mac_raw = iface.get("macAddress", "")
                        admin_up = iface.get("adminUp")
                        speed = iface.get("speed") or 0
                        enrichment: Dict[str, str] = {
                            "mac_address": mac_raw.replace("-", ":").lower() if mac_raw else "",
                            "vrf_name": iface.get("vrfName", "") or "",
                            "port_speed": str(speed) if speed else "",
                            "port_type": iface.get("type", "") or "",
                            "port_status": "Up" if admin_up is True else ("Down" if admin_up is False else ""),
                            "port_name": iface.get("name", "") or "",
                        }
                        enrichment.update(self._find_switch_port(ip_address, mac_raw, device_network))
                    else:
                        mac = self._get_mac_address(ip_address, device_network)
                        if not mac:
                            mac_raw = iface.get("macAddress", "")
                            mac = mac_raw.replace("-", ":").lower() if mac_raw else ""
                        enrichment = {
                            "mac_address": mac,
                            "vrf_name": self._get_vrf_name(ip_address, device_network),
                        }

                    row = self._build_logicvein_device_row(device, enrichment)
                    devices.append(row)

                except Exception as e:
                    logger.error("Error processing device %s: %s", ip_address, e)
                    continue

            logger.info("Fetched %d devices from %s", len(devices), get_product_name())
            self.last_lvi_devices = devices
            return devices

        except Exception as e:
            logger.error("Error fetching devices from %s: %s", get_product_name(), e)
            return None

    def _build_infoblox_csv_bytes(self, devices: List[Dict[str, str]]) -> Optional[bytes]:
        """Build Infoblox discovery CSV in memory from device dicts.

        Args:
            devices: List of enriched device dicts from _fetch_devices().

        Returns:
            UTF-8 encoded CSV bytes ready for upload, or None on failure.
        """
        logger.info("Building Infoblox discovery CSV in memory...")
        try:
            output = io.StringIO()
            writer = csv.DictWriter(output, fieldnames=_INFOBLOX_CSV_COLUMNS, quoting=csv.QUOTE_ALL)
            writer.writeheader()

            for row in devices:
                os_type = row.get("os_type", "")
                os_version = row.get("os_version", "")
                os_field = f"{os_type} {os_version}".strip() if os_type or os_version else ""

                last_discovery_iso = row.get("last_discovery", "")
                last_discovered = self._convert_iso_to_infoblox_timestamp(last_discovery_iso)
                if not last_discovered:
                    last_discovered = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                hostname_raw = row.get("hostname") or ""
                domain_suffix = f".{self.host_domain_name}" if self.host_domain_name else ""
                short_hostname = (
                    hostname_raw[: -len(domain_suffix)]
                    if domain_suffix and hostname_raw.endswith(domain_suffix)
                    else hostname_raw
                )

                ib_row = {
                    "ip_address": row.get("ip_address", ""),
                    "mac_address": row.get("mac_address", ""),
                    "discovered_name": short_hostname,
                    "device_vendor": row.get("hw_vendor", ""),
                    "device_model": row.get("device_model", ""),
                    "device_location": row.get("sys_location", ""),
                    "os": os_field,
                    "vrf_name": row.get("vrf_name", ""),
                    "discoverer": self.discoverer,
                    "task_name": self.task_name,
                    "first_discovered_timestamp": last_discovered,
                    "last_discovered_timestamp": last_discovered,
                    # Network component fields
                    # Network component fields - LVI devices are infrastructure, not end-hosts;
                    # these fields describe the upstream switch an end-host is attached to.
                    "network_component_ip": row.get("network_component_ip", ""),
                    "network_component_name": row.get("network_component_name", ""),
                    "network_component_description": row.get("network_component_description", ""),
                    "network_component_location": row.get("network_component_location", ""),
                    "network_component_model": row.get("network_component_model", ""),
                    "network_component_vendor": row.get("network_component_vendor", ""),
                    "network_component_type": row.get("network_component_type", ""),
                    "network_component_port_name": row.get("network_component_port_name", ""),
                    "device_port_name": row.get("port_name", ""),
                    "network_component_port_description": row.get("network_component_port_description", ""),
                    "network_component_port_number": "",
                    "port_speed": row.get("port_speed", ""),
                    "port_status": row.get("port_status", ""),
                    "port_type": row.get("port_type", ""),
                    "port_vlan_name": "",
                    "port_vlan_number": row.get("port_vlan_number", ""),
                    # Empty fields (not available from LogicVein)
                    "ap_ip_address": "",
                    "ap_name": "",
                    "ap_ssid": "",
                    "bgp_as": "",
                    "bridge_domain": "",
                    "device_contact": "",
                    "endpoint_groups": "",
                    "netbios_name": "",
                    "network_component_contact": "",
                    "port_duplex": "",
                    "port_link_status": "",
                    "tenant": "",
                    "vrf_description": "",
                    "vrf_rd": "",
                }
                writer.writerow(ib_row)

            csv_bytes = output.getvalue().encode("utf-8")
            logger.info("Built Infoblox CSV in memory (%d bytes)", len(csv_bytes))
            self.last_infoblox_csv = csv_bytes
            return csv_bytes

        except Exception as e:
            logger.error("Error building Infoblox CSV: %s", e)
            return None

    def _convert_iso_to_infoblox_timestamp(self, iso_timestamp: str) -> str:
        """Convert ISO timestamp to Infoblox format.

        Args:
            iso_timestamp: ISO format timestamp (e.g., "2024-01-06T15:30:45")

        Returns:
            Infoblox format timestamp (e.g., "2024-01-06 15:30:45") or empty string

        Note:
            Infoblox requires "yyyy-MM-dd HH:mm:ss" format WITHOUT microseconds
        """
        if not iso_timestamp:
            return ""
        try:
            # ISO format uses 'T' separator, Infoblox uses space
            result = iso_timestamp.replace("T", " ")

            # Remove microseconds if present (e.g., "2024-01-06 15:30:45.123456" -> "2024-01-06 15:30:45")
            if "." in result:
                result = result.split(".")[0]

            return result
        except (AttributeError, TypeError) as e:
            # iso_timestamp not a string (the only way replace/split fails here).
            logger.debug("Error converting timestamp %s: %s", iso_timestamp, e)
            return ""

    def sync(self) -> bool:
        """
        Orchestrate the full sync workflow.

        Workflow:
            1. Fetch devices from LogicVein into memory
            2. Build Infoblox discovery CSV in memory
            3. Test Infoblox connection
            4. Ensure networks exist in IPAM
            5. Convert ipv4address to record:host (must run before CSV import so
               setdiscoverycsv merges discovered_data into existing managed objects)
            6. Upload and import CSV via fileop
            7. Update devices in IPAM (native fields and EAs)

        Returns:
            True if successful, False otherwise
        """
        logger.info("=" * 70)
        logger.info("%s to Infoblox IPAM Sync", get_product_name())
        logger.info("=" * 70)

        if self.dry_run:
            logger.info("DRY RUN MODE - No changes will be made to Infoblox")

        self.task_name = generate_task_name(self.lvi_client.host, self.networks)
        started_at = datetime.now(timezone.utc).isoformat()

        devices = self._fetch_devices()
        if not devices:
            self.last_report = SyncReport(
                plugin_name=PLUGIN_NAME,
                started_at=started_at,
                finished_at=datetime.now(timezone.utc).isoformat(),
                dry_run=self.dry_run,
                run_errors=[f"No devices found or could not fetch devices from {get_product_name()}"],
            )
            return False

        csv_bytes = self._build_infoblox_csv_bytes(devices)
        if csv_bytes is None:
            self.last_report = SyncReport(
                plugin_name=PLUGIN_NAME,
                started_at=started_at,
                finished_at=datetime.now(timezone.utc).isoformat(),
                dry_run=self.dry_run,
                run_errors=["Could not build the Infoblox discovery CSV"],
            )
            return False

        success = (
            self._test_infoblox_connection()
            and self._ensure_networks_exist_wrapper(devices)
            and self._convert_ips_to_hosts_wrapper(devices)
            and self._import_infoblox_csv_data(csv_bytes)
            and self._update_devices_in_ipam_wrapper(devices)
        )

        if not self._outcomes:
            # Neither per-device pass ran (convert_ips_to_hosts is off and no
            # extensible_attribute_mapping is configured) - only the bulk CSV
            # import happened, which has no per-device signal. Fall back to
            # one coarse outcome per device from the CSV import's own result.
            action = "updated" if self._csv_import_ok else "error"
            failure_reason = "Infoblox CSV import failed"
            for row in devices:
                self._outcomes.append(
                    DeviceSyncOutcome(
                        ip_address=row.get("ip_address", ""),
                        hostname=row.get("hostname", ""),
                        action=action,
                        error=failure_reason if action == "error" else "",
                        mac=row.get("mac_address", ""),
                    )
                )

        if self._pending_items and not self.dry_run:
            try:
                record_pending_conflicts(PLUGIN_NAME, self._pending_items)
            except Exception as e:
                logger.warning("Could not record pending conflicts: %s", e)

        self.last_report = SyncReport(
            plugin_name=PLUGIN_NAME,
            started_at=started_at,
            finished_at=datetime.now(timezone.utc).isoformat(),
            dry_run=self.dry_run,
            outcomes=self._outcomes,
        )
        return success

    def _ensure_networks_exist_wrapper(self, devices: List[Dict[str, str]]) -> bool:
        """Ensure classful networks exist for all device IPs (if sync_networks enabled)."""
        if not self.sync_networks:
            return True
        logger.info("Syncing networks to DDI...")
        return self._ensure_networks_exist(devices)

    def _ensure_networks_exist(self, devices: List[Dict[str, str]]) -> bool:
        """Check each device IP against existing DDI networks; create missing classful networks.

        Fetches all networks and network containers from the configured network view,
        then for every device IP that is not covered by an existing network, derives
        the traditional classful network (A=/8, B=/16, C=/24) and creates it.

        Args:
            devices: In-memory device list from _fetch_devices().

        Returns:
            True on success or when continue_on_error=True absorbs failures.
        """
        logger.info("Fetching existing networks and containers from view '%s'...", self.network_view)
        raw_networks = self.ipam_client.get_networks(self.network_view)
        raw_containers = self.ipam_client.get_network_containers(self.network_view)

        existing: set = set()
        for obj in raw_networks + raw_containers:
            cidr = obj.get("network")
            if cidr:
                try:
                    existing.add(ipaddress.IPv4Network(cidr, strict=False))
                except ValueError:
                    pass

        logger.info(
            "Found %d existing networks and %d containers in view '%s'",
            len(raw_networks),
            len(raw_containers),
            self.network_view,
        )

        # Determine which classful networks need to be created
        to_create: Dict[str, ipaddress.IPv4Network] = {}  # cidr_str → IPv4Network

        for row in devices:
            ip_address = row.get("ip_address", "")
            if not ip_address:
                continue

            try:
                ip = ipaddress.IPv4Address(ip_address)
            except ValueError:
                logger.warning("Skipping invalid IP address: %s", ip_address)
                continue

            # IP is covered if it falls within any existing or already-queued network
            if any(ip in net for net in existing) or any(ip in net for net in to_create.values()):
                continue

            classful = _classful_network_for_ip(ip_address)
            if classful is None:
                logger.debug("Skipping non-routable IP (loopback/multicast/reserved): %s", ip_address)
                continue

            to_create[classful] = ipaddress.IPv4Network(classful, strict=False)

        if not to_create:
            logger.info("All device IPs are covered by existing networks - nothing to create")
            return True

        # Determine whether each proposed classful network would contain existing child
        # networks.  Infoblox rejects creating a flat network that overlaps existing ones;
        # a network container must be used instead.  Skip CIDRs that would need a
        # container when create_network_containers is disabled.
        create_as_container: Dict[str, bool] = {}
        skipped_cidrs: List[str] = []
        for cidr, net in to_create.items():
            has_children = any(ex_net.subnet_of(net) for ex_net in existing if ex_net != net)
            if has_children and not self.create_network_containers:
                logger.info(
                    "Skipping %s - existing subnets detected and create_network_containers is disabled",
                    cidr,
                )
                skipped_cidrs.append(cidr)
            else:
                create_as_container[cidr] = has_children

        for cidr in skipped_cidrs:
            del to_create[cidr]

        if not to_create:
            logger.info("No networks to create after filtering")
            return True

        if self.dry_run:
            for cidr in sorted(to_create):
                kind = "network container" if create_as_container[cidr] else "network"
                logger.info("[DRY RUN] Would create %s: %s", kind, cidr)
            return True

        logger.info(
            "%d classful network(s) to create: %s",
            len(to_create),
            ", ".join(sorted(to_create)),
        )

        created = 0
        failed = 0
        for cidr in sorted(to_create):
            self._check_cancelled()
            if create_as_container[cidr]:
                success, message = self.ipam_client.create_network_container(
                    cidr=cidr,
                    network_view=self.network_view,
                    comment=f"Created by {get_vendor_name()} Sync Manager",
                )
                kind = "network container"
            else:
                success, message = self.ipam_client.create_network(
                    cidr=cidr,
                    network_view=self.network_view,
                    comment=f"Created by {get_vendor_name()} Sync Manager",
                )
                kind = "network"
            if success:
                logger.info("Created %s: %s", kind, cidr)
                created += 1
            else:
                logger.warning("Failed to create %s %s: %s", kind, cidr, message)
                failed += 1
                if not self.continue_on_error:
                    logger.error("Stopping due to error (continue_on_error=False)")
                    return False

        logger.info("Network sync complete: %d created, %d failed", created, failed)
        return True

    def _test_infoblox_connection(self) -> bool:
        """Test connection to Infoblox."""
        logger.info("Testing Infoblox connection...")
        if not self.ipam_client.test_connection():
            logger.error("Failed to connect to Infoblox")
            return False
        logger.info("Infoblox connection successful")
        return True

    def _import_infoblox_csv_data(self, csv_bytes: bytes) -> bool:
        """Upload and import Infoblox discovery CSV.

        Args:
            csv_bytes: In-memory CSV content from _build_infoblox_csv_bytes().
        """
        if self.dry_run:
            logger.info("[DRY RUN] Would import Infoblox CSV to Infoblox")
            self._csv_import_ok = True
            return True

        logger.info("Importing Infoblox CSV to Infoblox (network_view: %s)...", self.network_view)
        success, message = self.ipam_client.import_discovery_data(csv_bytes=csv_bytes, network_view=self.network_view)
        logger.debug("Import results: %s %s", success, message)
        self._csv_import_ok = success

        if not success:
            logger.error("Infoblox CSV import failed")
            if not self.continue_on_error:
                return False
        else:
            logger.info("Infoblox CSV import successful")

        return True

    def _update_devices_in_ipam_wrapper(self, devices: List[Dict[str, str]]) -> bool:
        """Orchestrate updating EAs on ipv4address objects (skipped when convert_ips_to_hosts is true)."""
        if self.convert_ips_to_hosts:
            return True

        ea_mapping = self.post_host_conversion.get("extensible_attribute_mapping", {})
        if not ea_mapping:
            return True

        if self.dry_run:
            logger.info("[DRY RUN] Would update Extensible Attributes on ipv4address objects")
            return True

        logger.info("Updating Extensible Attributes on ipv4address objects...")
        success_count, fail_count, skip_count = self._update_devices_in_ipam(
            devices=devices,
            create_eas=self.config.get("create_missing_extensible_attributes", False),
            ea_mapping=ea_mapping,
        )
        logger.info(
            "Device update results: %s updated, %s skipped (read-only/not found), %s failed",
            success_count,
            skip_count,
            fail_count,
        )
        return True

    def _convert_ips_to_hosts_wrapper(self, devices: List[Dict[str, str]]) -> bool:
        """Orchestrate converting ipv4address objects to record:host objects."""
        if not self.convert_ips_to_hosts:
            return True

        if self.configure_for_dns and not self.host_domain_name:
            logger.error("convert_ips_to_hosts=True with configure_for_dns=True but host_domain_name is not set")
            return False

        if self.dry_run:
            logger.info("[DRY RUN] Would convert ipv4address objects to record:host objects")
            return True

        logger.info("Converting ipv4address to record:host (domain: %s)...", self.host_domain_name)
        created, existing, failed = self._convert_ips_to_hosts(devices)
        logger.info("IP-to-host conversion results: %s created, %s updated, %s failed", created, existing, failed)
        return True

    def _update_devices_in_ipam(
        self,
        devices: List[Dict[str, str]],
        create_eas: bool,
        ea_mapping: dict,
    ) -> tuple:
        """
        Update native fields and Extensible Attributes for devices in Infoblox.

        Args:
            devices: In-memory device list from _fetch_devices().
            create_eas: If True, create EA definitions if they don't exist
            ea_mapping: Mapping of {field: ea_name} for Extensible Attributes

        Returns:
            Tuple of (success_count, fail_count, skip_count)
        """
        success_count = 0
        fail_count = 0
        skip_count = 0

        for idx, row in enumerate(devices, 1):
            self._check_cancelled()

            ip_address = row.get("ip_address", "")
            if not ip_address:
                continue

            hostname = row.get("hostname", "")
            logger.info("Updating device %d: %s", idx, ip_address)

            success, message = self.ipam_client.update_device_in_ipam(
                ip_address=ip_address,
                device_data=row,
                network_view=self.network_view,
                create_eas=create_eas,
                ea_mapping=ea_mapping,
                sync_mac_address=self.sync_mac_address,
            )

            mac_address = row.get("mac_address", "")
            if success:
                if "Skipped" in message or "not found" in message:
                    skip_count += 1
                    self._outcomes.append(
                        DeviceSyncOutcome(
                            ip_address=ip_address, hostname=hostname, action="ignored", detail=message, mac=mac_address
                        )
                    )
                else:
                    success_count += 1
                    self._outcomes.append(
                        DeviceSyncOutcome(ip_address=ip_address, hostname=hostname, action="updated", mac=mac_address)
                    )
            else:
                fail_count += 1
                self._outcomes.append(
                    DeviceSyncOutcome(
                        ip_address=ip_address, hostname=hostname, action="error", error=message, mac=mac_address
                    )
                )
                logger.warning("Failed to update %s: %s", ip_address, message)
                if not self.continue_on_error:
                    logger.error("Stopping due to error (continue_on_error=False)")
                    break

        return success_count, fail_count, skip_count

    @staticmethod
    def _host_mac_for_ip(existing_host: Dict[str, Any], ip_address: str) -> str:
        """Extract the current mac already set on *existing_host*'s ipv4addrs
        entry for *ip_address*, or "" if none. Pure - existing_host is
        already fetched by the caller, no extra API call.

        Args:
            existing_host: The current host record.
            ip_address: The address whose MAC to extract.

        Returns:
            The current MAC, or "" if none.
        """
        for addr in existing_host.get("ipv4addrs", []) or []:
            if addr.get("ipv4addr") == ip_address:
                return (addr.get("mac") or "").strip()
        return ""

    @staticmethod
    def _strip_mac_field(host_fields: Optional[Dict[str, str]]) -> Optional[Dict[str, str]]:
        """Return *host_fields* with the entry mapped to "mac" removed, so a
        deferred/skipped MAC still lets every other host field sync normally."""
        if not host_fields:
            return host_fields
        return {k: v for k, v in host_fields.items() if v != "mac"}

    def _convert_ips_to_hosts(self, devices: List[Dict[str, str]]) -> tuple:
        """
        Convert ipv4address objects to record:host objects.

        For each device:
        1. Build FQDN from hostname + host_domain_name
        2. Create or update host record
        3. Optionally populate EAs on the host

        Args:
            devices: In-memory device list from _fetch_devices().

        Returns:
            Tuple of (created_count, existing_count, fail_count)
        """
        created_count = 0
        existing_count = 0
        fail_count = 0

        populate_host_fields = self.post_host_conversion.get("populate_host_fields", True)
        host_field_mapping = self.post_host_conversion.get("host_field_mapping", {})
        if not self.sync_mac_address:
            # Strip mac_address specifically rather than gating the whole
            # mapping - sync_mac_address is independent of the other
            # host_field_mapping entries (device_type, memo, etc.).
            host_field_mapping = {k: v for k, v in host_field_mapping.items() if v != "mac"}
        create_missing_eas = self.config.get("create_missing_extensible_attributes", False)
        ea_mapping = self.post_host_conversion.get("extensible_attribute_mapping", {})

        known_zones: Optional[Set[str]] = None
        if self.configure_for_dns:
            known_zones = self.ipam_client.get_dns_zones()
            logger.info("Fetched %d DNS zones for validation", len(known_zones))

        for idx, row in enumerate(devices, 1):
            self._check_cancelled()

            ip_address = row.get("ip_address") or ""
            hostname = row.get("hostname") or ""

            if not ip_address:
                continue

            if not hostname:
                logger.debug("Skipping %s - no hostname", ip_address)
                continue

            # Build FQDN for the host record name.
            # Append the default domain only when DNS is enabled and the hostname
            # is a short name (no dot).  If the hostname already looks like an
            # FQDN, use it verbatim regardless of the DNS setting.
            has_domain = "." in hostname
            if has_domain:
                fqdn = hostname
            elif self.configure_for_dns and self.host_domain_name:
                fqdn = f"{hostname}.{self.host_domain_name}"
            else:
                fqdn = hostname

            dns_enabled = self.configure_for_dns
            if dns_enabled and known_zones is not None and not _fqdn_matches_zone(fqdn, known_zones):
                dns_enabled = False
                logger.debug("No DNS zone for %s - creating as IPAM-only host", fqdn)

            logger.info("Processing device %d: %s -> %s", idx, ip_address, fqdn)

            host_fields = host_field_mapping if populate_host_fields else None
            mac_address = row.get("mac_address", "")

            # Conflict checks only run an extra lookup when a non-default
            # policy is configured - zero cost when both policies are
            # "overwrite" (today's only behavior).
            existing_host = None
            if self.ip_conflict_policy != "overwrite" or self.mac_conflict_policy != "overwrite":
                existing_host = self.ipam_client.get_host_record(fqdn, self.network_view)

            # IP conflict: this device has no host record of its own yet,
            # but a *different* host record/fixedaddress already claims
            # the IP.
            if existing_host is None and self.ip_conflict_policy != "overwrite":
                # The MAC is passed so a record that is this same device under
                # a different domain suffix is not counted as a rival owner -
                # the writer already updates such a record in place, so
                # reporting it here produced a conflict no resolution cleared.
                conflicting = self.ipam_client.find_conflicting_ip_owner(
                    ip_address, fqdn, self.network_view, mac_address
                )
                if conflicting:
                    if self.ip_conflict_policy == "ignore":
                        logger.info("Ignored %s (%s) - %s", ip_address, fqdn, conflicting)
                        self._outcomes.append(
                            DeviceSyncOutcome(
                                ip_address=ip_address,
                                hostname=hostname,
                                action="ignored",
                                detail=conflicting,
                                mac=mac_address,
                            )
                        )
                    else:  # ask
                        logger.warning(
                            "Conflict: %s (%s) - %s, policy=ask, deferred for review", ip_address, fqdn, conflicting
                        )
                        self._pending_items.append(
                            pending_conflict_item(
                                ip_address,
                                hostname,
                                "ip_exists",
                                conflicting,
                                {
                                    "ip_address": ip_address,
                                    "fqdn": fqdn,
                                    "network_view": self.network_view,
                                    "host_fields": host_fields,
                                    "device_data": row,
                                    "configure_for_dns": dns_enabled,
                                    "rename_to_configured_domain": self.rename_host_to_configured_domain,
                                },
                            )
                        )
                        self._outcomes.append(
                            DeviceSyncOutcome(
                                ip_address=ip_address,
                                hostname=hostname,
                                action="pending",
                                detail=f"{conflicting} - awaiting decision",
                                mac=mac_address,
                            )
                        )
                    continue

            # MAC handling, subject to mac_conflict_policy: "mac_differs"
            # when this device's own existing host record disagrees with
            # LogicVein; "mac_duplicate" when the incoming MAC is already
            # set on a different fixedaddress object anywhere in Infoblox
            # (checked regardless of existing_host, since the fqdn is
            # known upfront either way - no create-then-patch needed).
            mac_fields = host_fields
            mac_changed = False
            mac_previous = ""
            mac_pending_note = ""
            if mac_address and existing_host is not None:
                mac_previous = self._host_mac_for_ip(existing_host, ip_address)
                mac_changed = bool(mac_previous and mac_previous.lower() != mac_address.lower())

            duplicate_of = ""
            if mac_address and self.mac_conflict_policy != "overwrite":
                duplicate_of = self.ipam_client.find_duplicate_mac_fixedaddress(mac_address, self.network_view)

            if duplicate_of and self.mac_conflict_policy == "ask":
                mac_fields = self._strip_mac_field(host_fields)
                mac_pending_note = f"{duplicate_of} - awaiting decision"
                logger.warning(
                    "Conflict: %s (%s) - %s, policy=ask, deferred for review", ip_address, fqdn, duplicate_of
                )
                self._pending_items.append(
                    pending_conflict_item(
                        ip_address,
                        hostname,
                        "mac_duplicate",
                        duplicate_of,
                        {
                            "ip_address": ip_address,
                            "fqdn": fqdn,
                            "network_view": self.network_view,
                            "mac_address": mac_address,
                        },
                    )
                )
            elif mac_changed:
                if self.mac_conflict_policy == "leave_untouched":
                    mac_fields = self._strip_mac_field(host_fields)
                elif self.mac_conflict_policy == "ask":
                    mac_fields = self._strip_mac_field(host_fields)
                    mac_pending_note = "MAC change pending decision"
                    detail = f"MAC differs: Infoblox has {mac_previous}, {get_product_name()} has {mac_address}"
                    logger.warning("Conflict: %s (%s) - %s, policy=ask, deferred for review", ip_address, fqdn, detail)
                    self._pending_items.append(
                        pending_conflict_item(
                            ip_address,
                            hostname,
                            "mac_differs",
                            detail,
                            {
                                "ip_address": ip_address,
                                "fqdn": fqdn,
                                "network_view": self.network_view,
                                "mac_address": mac_address,
                            },
                        )
                    )
                # "overwrite": mac_fields stays host_fields (writes mac)

            success, message = self.ipam_client.create_or_update_host_record(
                ip_address=ip_address,
                fqdn=fqdn,
                network_view=self.network_view,
                host_fields=mac_fields,
                device_data=row,
                configure_for_dns=dns_enabled,
                rename_to_configured_domain=self.rename_host_to_configured_domain,
            )

            if success:
                detail = mac_pending_note
                # "renamed:<old fqdn>" is still an update (the record already
                # existed) - it must not fall into the "else" (created) branch
                # below, which a bare message == "updated" check would do.
                if message.startswith("renamed:"):
                    existing_count += 1
                    old_name = message.split(":", 1)[1]
                    logger.info("Renamed host record: %s -> %s", old_name, fqdn)
                    rename_note = f"Renamed from '{old_name}' to '{fqdn}'"
                    detail = f"{rename_note}; {detail}" if detail else rename_note
                    self._outcomes.append(
                        DeviceSyncOutcome(
                            ip_address=ip_address,
                            hostname=hostname,
                            action="updated",
                            detail=detail,
                            mac=mac_address,
                            mac_changed=mac_changed,
                            mac_previous=mac_previous,
                        )
                    )
                elif message == "updated":
                    existing_count += 1
                    logger.debug("Updated existing host: %s", fqdn)
                    self._outcomes.append(
                        DeviceSyncOutcome(
                            ip_address=ip_address,
                            hostname=hostname,
                            action="updated",
                            detail=detail,
                            mac=mac_address,
                            mac_changed=mac_changed,
                            mac_previous=mac_previous,
                        )
                    )
                else:
                    created_count += 1
                    logger.debug("Created host: %s", fqdn)
                    self._outcomes.append(
                        DeviceSyncOutcome(
                            ip_address=ip_address,
                            hostname=hostname,
                            action="added",
                            detail=detail,
                            mac=mac_address,
                            mac_changed=mac_changed,
                            mac_previous=mac_previous,
                        )
                    )

                if ea_mapping:
                    self._update_host_eas(
                        fqdn=fqdn,
                        device_data=row,
                        ea_mapping=ea_mapping,
                        create_missing_eas=create_missing_eas,
                    )
            else:
                fail_count += 1
                self._outcomes.append(
                    DeviceSyncOutcome(
                        ip_address=ip_address, hostname=hostname, action="error", error=message, mac=mac_address
                    )
                )
                logger.warning("Failed to create host %s: %s", fqdn, message)
                if not self.continue_on_error:
                    logger.error("Stopping due to error (continue_on_error=False)")
                    break

        return created_count, existing_count, fail_count

    def _update_host_eas(
        self,
        fqdn: str,
        device_data: dict,
        ea_mapping: dict,
        create_missing_eas: bool = False,
    ) -> bool:
        """
        Update Extensible Attributes on a host record.

        Args:
            fqdn: Fully qualified domain name of the host
            device_data: Device data dictionary
            ea_mapping: Dict mapping field names to EA names
            create_missing_eas: If True, create EA definitions if missing

        Returns:
            True if successful
        """
        try:
            host = self.ipam_client.get_host_record(fqdn, self.network_view)
            if not host:
                logger.warning("Host not found for EA update: %s", fqdn)
                return False

            host_ref = host.get("_ref")
            if not host_ref:
                logger.warning("No _ref for host: %s", fqdn)
                return False

            extattrs = {}
            for field, ea_name in ea_mapping.items():
                value = device_data.get(field, "")
                if value:
                    extattrs[ea_name] = {"value": value}

            if not extattrs:
                logger.debug("No EAs to update for %s", fqdn)
                return True

            if create_missing_eas:
                self.ipam_client.ensure_extensible_attributes(list(extattrs.keys()), create_if_missing=True)

            success, message = self.ipam_client.update_object_fields(host_ref, {}, extattrs)
            if success:
                logger.debug("Updated EAs on host: %s", fqdn)
            else:
                logger.warning("Failed to update EAs on %s: %s", fqdn, message)

            return success

        except Exception as e:
            logger.error("Error updating host EAs for %s: %s", fqdn, e)
            return False
