"""Background services contributed by the Jira plugin.

The Jira plugin registers the alert handler for the core ``/webhook/lvi-alert``
route and, when config-change detection is enabled (features.change_detection),
the config-change issue creator plus the detection backend the app-wide settings
select (a WebSocket event-bus watcher or a REST poller).

NOTE: the detection backend should have a single owner. If both the ServiceNow
and Jira plugins enable change detection at once, each starts its own backend and
a change is detected twice. Enable change detection on one plugin at a time.
"""

from typing import Any, List, Optional


def build_services() -> List[Any]:
    """Register the Jira handlers and build the enabled detection backend.

    Reentrant: the host calls it again when detection settings change. The alert
    and change handlers re-register idempotently; the websocket-only event
    handler is dropped first so a poll<->websocket switch leaves none stale.
    """
    from src.plugin_api import get_app_settings

    from .settings import get_change_detection_settings

    _unregister_event_handlers()

    # LVI alert handler (capability "alerts"); the core /webhook/lvi-alert route
    # fans events out to it. Independent of config-change detection below.
    if get_app_settings().get("features", {}).get("alerts", True):
        from src.plugin_api import register_alert_handler

        from .webhook.alert_handler import get_alert_handler

        register_alert_handler(get_alert_handler())

    cfg = get_change_detection_settings()
    if not cfg.get("enabled", False):
        return []

    # Core detects config changes and emits ConfigChangeEvents; our issue creator
    # consumes them in either detection mode.
    from src.plugin_api import register_change_handler

    from .change_detection.issue import get_change_creator

    register_change_handler(get_change_creator())

    if cfg.get("mode", "websocket") == "websocket":
        from src.plugin_api import (
            EventBusWatcher,
            event_bus_client,
            get_websocket_detector,
            register_event_handler,
        )

        subscribe_all = bool(get_app_settings().get("event_bus", {}).get("subscribe_all_events", False))
        topics = event_bus_client.ALL_TOPICS if subscribe_all else event_bus_client.CHANGE_TOPICS
        register_event_handler(get_websocket_detector())
        return [EventBusWatcher(topics=topics)]

    from src.plugin_api import ConfigChangePoller

    return [ConfigChangePoller()]


def services_match_config() -> bool:
    """Whether the running detection backend matches the saved configuration."""
    from src.plugin_api import service_config_matches

    return service_config_matches()


def active_watcher() -> Optional[Any]:
    """Return the running event-bus watcher, if websocket mode is active."""
    from src.plugin_api import running_plugin_service

    return running_plugin_service("jira", "EventBusWatcher")


def active_poller() -> Optional[Any]:
    """Return the running config-change poller, if poll mode is active."""
    from src.plugin_api import running_plugin_service

    return running_plugin_service("jira", "ConfigChangePoller")


def _unregister_event_handlers() -> None:
    """Drop the websocket-only event handler (idempotent; safe in any mode)."""
    try:
        from src.plugin_api import get_websocket_detector, unregister_event_handler

        unregister_event_handler(get_websocket_detector())
    except Exception:
        pass  # best-effort cleanup; never block a rebuild
