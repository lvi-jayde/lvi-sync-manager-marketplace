"""Create a Jira issue for each detected LogicVein configuration change.

Registered with the core change dispatch (``register_change_handler``). Core
config-change detection (the REST poller or the websocket detector) emits a
:class:`ConfigChangeEvent` per unseen change; this handler opens a Jira issue
describing it. Like the alert handler it correlates Jira-side with a label
(``lvi-chg-<hash>``) found via JQL, so a restart does not re-open an issue for a
change that already has one, and it honours JSM mode (``service_desk_id`` +
``request_type_id``) so issues land in service-desk queues.

A config change is informational - there is no resolve lifecycle (unlike alerts);
the handler only creates.
"""

import hashlib
import logging
from typing import Any, Optional

from src.plugin_api import ConfigChangeEvent
from src.plugin_api import webhook_store as store

from .. import adf
from ..settings import get_change_detection_settings, get_jira_client, get_jira_settings

logger = logging.getLogger(__name__)

_PLUGIN_ID = "jira"


def _log_event(**kwargs: Any) -> None:
    """Record a webhook event tagged with this plugin's id (UI per-plugin filter)."""
    store.log_event(plugin=_PLUGIN_ID, **kwargs)


def _change_label(event_key: str) -> str:
    """A correlation label for a config-change event (labels disallow spaces)."""
    return "lvi-chg-" + hashlib.sha1(event_key.encode("utf-8")).hexdigest()[:12]


def _change_title(event: ConfigChangeEvent) -> str:
    """The issue summary / Description-column title for a config change."""
    return f"[LVI] Config change on {event.hostname or event.ip_address or 'unknown'}"


def _build_change_description(event: ConfigChangeEvent) -> dict:
    """ADF body summarising the config change."""
    paths = ", ".join(event.paths) if event.paths else "unknown"
    rows = [
        ("Device", adf.text(event.hostname or "")),
        ("IP Address", adf.text(event.ip_address or "")),
        ("Network", adf.text(event.managed_network or "")),
        ("Changed At", adf.text(event.last_changed or "")),
        ("Author", adf.text(event.author or "unknown")),
        ("Config Paths", adf.text(paths)),
    ]
    return adf.doc(adf.detail_table(rows))


def _build_change_description_text(event: ConfigChangeEvent) -> str:
    """Plain-text body for the JSM Service Desk API (it does not accept ADF)."""
    paths = ", ".join(event.paths) if event.paths else "unknown"
    return (
        f"Device: {event.hostname or ''}\n"
        f"IP Address: {event.ip_address or ''}\n"
        f"Network: {event.managed_network or ''}\n"
        f"Changed At: {event.last_changed or ''}\n"
        f"Author: {event.author or 'unknown'}\n"
        f"Config Paths: {paths}"
    )


class JiraIssueChangeCreator:
    """Change handler that opens a Jira issue for each LVI config change."""

    def __call__(self, event: ConfigChangeEvent, lvi: Any) -> bool:
        """Create a Jira issue for *event*. Return True if one was created."""
        node = event.hostname or event.ip_address or "?"
        try:
            jira = get_jira_client()
        except Exception as exc:
            logger.error("JiraIssueChangeCreator: failed to create Jira client: %s", exc)
            _log_event(
                direction="sync mgr→jira",
                action="config_change",
                node=node,
                correlation_hash=event.event_key,
                severity="",
                result="error",
                src="Sync Manager",
                dst="",
                error=f"Jira client init failed: {exc}",
                status_code=500,
                event_type="config_change",
                description=_change_title(event),
            )
            return False

        label = _change_label(event.event_key)
        try:
            existing = jira.find_any_issue_by_label(label)
            if existing:
                logger.info("Config change for %s already has Jira issue %s", node, existing.get("key"))
                return False
            key = self._create_issue(jira, event, label)
        except Exception as exc:
            logger.error("JiraIssueChangeCreator: failed to create Jira issue for %s: %s", node, exc)
            _log_event(
                direction="sync mgr→jira",
                action="config_change",
                node=node,
                correlation_hash=event.event_key,
                severity="",
                result="error",
                src="Sync Manager",
                dst=jira.base_url,
                error=str(exc),
                status_code=500,
                event_type="config_change",
                description=_change_title(event),
            )
            return False

        _log_event(
            direction="sync mgr→jira",
            action="config_change",
            node=node,
            correlation_hash=event.event_key,
            severity="",
            result="created",
            src="LogicVein",
            dst=jira.base_url,
            incident=key,
            status_code=201,
            event_type="config_change",
            description=_change_title(event),
        )
        logger.info("Created Jira issue %s for config change on %s", key, node)
        return True

    def _create_issue(self, jira: Any, event: ConfigChangeEvent, label: str) -> str:
        """Create the Jira issue (JSM request when configured, else a plain issue)."""
        cfg = get_jira_settings().get("jira", {})
        sd_id = str(cfg.get("service_desk_id", "") or "").strip()
        rt_id = str(cfg.get("request_type_id", "") or "").strip()
        summary = _change_title(event)
        if sd_id and rt_id:
            created = jira.create_request(
                service_desk_id=sd_id,
                request_type_id=rt_id,
                summary=summary,
                description=_build_change_description_text(event),
                labels=[label],
            )
        else:
            change_cfg = get_change_detection_settings().get("jira_change", {})
            issue_type = change_cfg.get("issue_type") or cfg.get("issue_type", "Task")
            created = jira.create_issue(
                {
                    "project": {"key": cfg.get("project_key", "")},
                    "issuetype": {"name": issue_type},
                    "summary": summary,
                    "description": _build_change_description(event),
                    "labels": [label],
                }
            )
        return created.get("key", created.get("id", "unknown"))


_creator: Optional[JiraIssueChangeCreator] = None


def get_change_creator() -> JiraIssueChangeCreator:
    """Return the module-level singleton change handler (created on first use)."""
    global _creator
    if _creator is None:
        _creator = JiraIssueChangeCreator()
    return _creator
