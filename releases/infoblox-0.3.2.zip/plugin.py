"""Infoblox IPAM sync plugin implementation."""

import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, cast

from src.plugin_api import SyncPlugin, load_plugin_config, normalize_networks

from .client import InfobloxClient
from .sync import LogicVeinInfobloxIPAMSync

logger = logging.getLogger(__name__)


class InfobloxPlugin(SyncPlugin):
    """Plugin for synchronizing LogicVein devices to Infoblox IPAM."""

    def __init__(self):
        """Initialize the Infoblox plugin from its manifest.json."""
        self.config = load_plugin_config(Path(__file__).parent)

    def create_client(self, credentials: Dict[str, Any]) -> Any:
        """Create Infoblox client.

        Args:
            credentials: Dictionary with 'host', 'username', 'password' keys.

        Returns:
            InfobloxClient instance.
        """
        from .settings import get_infoblox_settings

        ib_cfg = get_infoblox_settings().get("infoblox", {})
        kwargs: Dict[str, Any] = {
            "verify_ssl": bool(ib_cfg.get("verify_ssl", False)),
            "timeout": int(ib_cfg.get("timeout", 120)),
            "wapi_version": ib_cfg.get("wapi_version") or "v2.11",
        }
        if credentials.get("ignore_env_vars"):
            kwargs["ignore_env_vars"] = True
        if credentials.get("host"):
            kwargs["host"] = credentials["host"]
        if credentials.get("username"):
            kwargs["username"] = credentials["username"]
        if credentials.get("password"):
            kwargs["password"] = credentials["password"]

        return InfobloxClient(**kwargs)

    def create_sync_engine(
        self,
        lvi_client: Any,
        target_client: Any,
        sync_config: Dict[str, Any],
    ) -> Any:
        """Create Infoblox sync engine.

        Args:
            lvi_client: LogicVein API client.
            target_client: Infoblox client.
            sync_config: Sync configuration dictionary.

        Returns:
            LogicVeinInfobloxIPAMSync instance.
        """
        return LogicVeinInfobloxIPAMSync(
            lvi_client=lvi_client,
            ipam_client=target_client,
            config=sync_config,
        )

    def build_sync_config(
        self,
        yaml_config: Dict[str, Any],
        timestamp: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Build sync configuration from YAML config.

        Args:
            yaml_config: Parsed YAML configuration dictionary.
            timestamp: Optional timestamp for archive file naming.

        Returns:
            Configuration dictionary ready for LogicVeinInfobloxIPAMSync.
        """
        sync_config = yaml_config.get("sync", {})
        lvi_config = yaml_config.get("logicvein", {})
        ib_config = yaml_config.get("infoblox", {})

        return {
            # Sync options
            "dry_run": sync_config.get("dry_run", False),
            "continue_on_error": sync_config.get("continue_on_error", True),
            # LogicVein options
            "network": lvi_config.get("networks", "Default"),
            # Infoblox options
            "network_view": ib_config.get("network_view", "default"),
            "discoverer": ib_config.get("discoverer", "LogicVein"),
            # Network sync options
            "sync_networks": ib_config.get("sync_networks", False),
            "create_network_containers": ib_config.get("create_network_containers", False),
            # Extensible Attribute options
            "create_missing_extensible_attributes": ib_config.get("create_missing_extensible_attributes", False),
            "sync_mac_address": ib_config.get("sync_mac_address", True),
            "ip_conflict_policy": ib_config.get("ip_conflict_policy", "overwrite"),
            "mac_conflict_policy": ib_config.get("mac_conflict_policy", "overwrite"),
            # Post-conversion options (IP to host conversion)
            "convert_ips_to_hosts": ib_config.get("convert_ips_to_hosts", False),
            "configure_for_dns": ib_config.get("configure_for_dns", True),
            "host_domain_name": ib_config.get("host_domain_name", ""),
            "post_host_conversion": ib_config.get("post_host_conversion", {}),
        }

    def test_connection(
        self,
        credentials: Dict[str, Any],
    ) -> Tuple[bool, str]:
        """Test connection to Infoblox.

        Args:
            credentials: Dictionary with 'host', 'username', 'password' keys.

        Returns:
            Tuple of (success, message).
        """
        try:
            client = self.create_client(credentials)
            if client.test_connection():
                return True, "Connected to Infoblox Grid"
            return False, "Connection test failed"
        except Exception as e:
            return False, f"Connection failed: {e}"

    def supports_preview(self) -> bool:
        """Infoblox plugin does not support preview."""
        return False

    def get_preview_downloads(
        self,
        lvi_client: Any,
        config: Dict[str, Any],
    ) -> List[Tuple[str, str, bytes]]:
        """Build the Infoblox discovery CSV from enriched LVI devices for preview download."""
        try:
            sync_config = self.build_sync_config(config)
            # Preview never reaches the WAPI paths, so no client is needed;
            # the cast keeps the engine's required-client signature honest.
            engine = LogicVeinInfobloxIPAMSync(
                lvi_client=lvi_client,
                ipam_client=cast(InfobloxClient, None),
                config=sync_config,
            )
            engine.task_name = datetime.now().strftime("preview_%Y%m%d_%H%M%S")
            devices = engine._fetch_devices()
            if not devices:
                return []
            csv_bytes = engine._build_infoblox_csv_bytes(devices)
            if not csv_bytes:
                return []
            return [("Download Infoblox Import CSV", "infoblox_import.csv", csv_bytes)]
        except Exception as e:
            logger.warning("Could not build Infoblox preview CSV: %s", e)
            return []

    def get_status_detail(self, config: Dict[str, Any]) -> str:
        """Return a one-line status string for the Infoblox sync tab header.

        Args:
            config: Parsed YAML configuration dictionary.

        Returns:
            Human-readable summary of the active network(s) and network view.
        """
        networks = normalize_networks(config.get("logicvein", {}).get("networks", "Default"))
        network_str = ", ".join(networks) if networks else "all"
        network_view = config.get("infoblox", {}).get("network_view", "default")
        return f"Network: {network_str} | Network View: {network_view}"

    def get_preview_info(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Return a dict of preview metadata shown before a sync run.

        Args:
            config: Parsed YAML configuration dictionary.

        Returns:
            Dict with "target" and "sync_options" sub-dicts for display.
        """
        ib_config = config.get("infoblox", {})
        return {
            "target": {
                "network_view": ib_config.get("network_view", "default"),
            },
            "sync_options": {
                "convert_ips_to_hosts": ib_config.get("convert_ips_to_hosts", False),
                "host_domain_name": ib_config.get("host_domain_name", ""),
            },
        }

    def resolve_conflict(self, conflict_type: str, desired_payload: Dict[str, Any]) -> bool:
        """Apply an "Overwrite" decision for one pending conflict.

        Uses create_client({}) - the same "no override, resolve from stored
        credentials/settings" call real sync runs make. "ip_exists" performs
        the deferred host create/update with its full original payload;
        "mac_differs"/"mac_duplicate" both apply just the MAC via
        set_host_mac(), leaving every other host field untouched.
        """
        client = self.create_client({})
        if conflict_type == "ip_exists":
            success, _ = client.create_or_update_host_record(
                ip_address=desired_payload["ip_address"],
                fqdn=desired_payload["fqdn"],
                network_view=desired_payload.get("network_view", "default"),
                host_fields=desired_payload.get("host_fields"),
                device_data=desired_payload.get("device_data"),
                configure_for_dns=desired_payload.get("configure_for_dns", True),
            )
            return success
        return client.set_host_mac(
            fqdn=desired_payload["fqdn"],
            ip_address=desired_payload["ip_address"],
            mac_address=desired_payload.get("mac_address", ""),
            network_view=desired_payload.get("network_view", "default"),
        )

    def get_quick_settings(self) -> List[Dict[str, Any]]:
        """Return the quick-settings definition for the Infoblox config editor.

        Returns:
            List of group dicts, each with "name", "toggles", and "text_fields" keys.
        """
        return [
            {
                "name": "General",
                "toggles": [
                    ("sync.dry_run", "Dry Run", "Preview changes without modifying Infoblox"),
                    ("sync.continue_on_error", "Continue on Error", "Continue sync even if some devices fail"),
                    (
                        "infoblox.sync_mac_address",
                        "Sync MAC Address",
                        "Set the device's MAC address on its Infoblox object. Turn off to never read, "
                        "compare, or write it - the existing value is left exactly as-is. Covers both "
                        "the host-conversion path (post_host_conversion.populate_host_fields only "
                        "covers that one) and the separate Extensible-Attribute-only update path used "
                        "when Convert IPs to Hosts is off with an Extensible Attribute mapping "
                        "configured.",
                    ),
                ],
                "text_fields": [
                    (
                        "logicvein.networks",
                        "LogicVein Network(s)",
                        "Network name(s) in LogicVein. Use 'all' to sync every network, or enter multiple names separated by commas.",
                    ),
                    ("infoblox.network_view", "Network View", "Infoblox network view"),
                    (
                        "infoblox.discoverer",
                        "Discoverer Name",
                        "Label written to the discoverer field in the Infoblox discovery CSV",
                    ),
                ],
            },
            {
                "name": "Network Sync",
                "toggles": [
                    (
                        "infoblox.sync_networks",
                        "Sync Networks",
                        "Create classful networks (A/B/C) in DDI for any IPs not already covered by an existing network",
                    ),
                    (
                        "infoblox.create_network_containers",
                        "Create Network Containers",
                        "When a classful network would contain existing subnets, create it as a network container instead of skipping it",
                        "infoblox.sync_networks",
                    ),
                ],
                "text_fields": [],
            },
            {
                "name": "Host Conversion",
                "toggles": [
                    ("infoblox.convert_ips_to_hosts", "Convert IPs to Hosts", "Create host records from IPs"),
                    (
                        "infoblox.configure_for_dns",
                        "Enable in DNS",
                        "Create a DNS A record for each converted host. Disable for pure IPAM use (no managed DNS zone required).",
                        "infoblox.convert_ips_to_hosts",
                    ),
                ],
                "text_fields": [
                    (
                        "infoblox.host_domain_name",
                        "Default Domain Name",
                        "Appended to short hostnames when Enable in DNS is on (e.g. corp.example.com)",
                        "infoblox.configure_for_dns",
                    ),
                ],
            },
            {
                "name": "Conflict Handling",
                "toggles": [],
                "selects": [
                    (
                        "infoblox.ip_conflict_policy",
                        "When an IP already exists",
                        "What to do when a device's IP is already claimed by a different host record or "
                        "fixedaddress object (only checked when this device has no host record of its own yet).",
                        ["overwrite", "ignore", "ask"],
                    ),
                    (
                        "infoblox.mac_conflict_policy",
                        "When the MAC differs",
                        "What to do when an existing host record's MAC differs from LogicVein's, or the "
                        "incoming MAC is already set on a different fixedaddress object (other host fields "
                        "still sync either way). Only consulted when 'Sync MAC Address' is on.",
                        ["overwrite", "leave_untouched", "ask"],
                        "infoblox.sync_mac_address",
                    ),
                ],
            },
        ]
