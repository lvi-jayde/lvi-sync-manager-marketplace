"""Background services contributed by the ServiceNow plugin.

The config-change detection component runs in one of two mutually
exclusive modes (lvi_config_change_poller.mode): a WebSocket event-bus
watcher or a REST poller. build_services() instantiates the configured
one; the active instances are kept as module singletons so the plugin's
tabs can reflect live status.
"""

from typing import Any, List, Optional

_active_watcher: Optional[Any] = None
_active_poller: Optional[Any] = None


def build_services() -> List[Any]:
    """Instantiate the background services enabled by configuration.

    Also registers the ServiceNow handlers for core-owned event sources: the LVI
    alert handler (for the core /webhook/lvi-alert route) and, when change
    detection is enabled, the config-change incident creator.
    """
    global _active_watcher, _active_poller
    from .settings import get_change_detection_settings, get_snow_settings

    # Register the LVI alert handler unless lvi_alerts is explicitly disabled. The
    # core /webhook/lvi-alert route fans events out to it; this is independent of
    # config-change detection below.
    if get_snow_settings().get("lvi_alerts", {}).get("enabled", True):
        from src.plugin_api import register_alert_handler

        from .webhook.alert_incident import get_alert_handler

        register_alert_handler(get_alert_handler())

    cfg = get_change_detection_settings()
    if not cfg.get("enabled", False):
        return []

    # Core detects config changes and emits ConfigChangeEvents; our incident
    # creator consumes them in either detection mode.
    from src.plugin_api import register_change_handler

    from .change_detection.incident import get_incident_creator

    register_change_handler(get_incident_creator())

    if cfg.get("mode", "websocket") == "websocket":
        from src.plugin_api import (
            EventBusWatcher,
            event_bus_client,
            get_app_settings,
            get_websocket_detector,
            register_event_handler,
        )

        from .event_bus.handler import get_handler as get_job_completion_handler

        # App-level (admin-only) toggle: subscribe to every LogicVein event topic
        # for the Event Bus tab, not just the config-change topics we act on.
        subscribe_all = bool(get_app_settings().get("event_bus", {}).get("subscribe_all_events", False))
        topics = event_bus_client.ALL_TOPICS if subscribe_all else event_bus_client.CHANGE_TOPICS

        # The core watcher produces raw events; the core detector turns backup
        # events into ConfigChangeEvents, and our handler bridges job completion.
        register_event_handler(get_websocket_detector())
        register_event_handler(get_job_completion_handler())
        _active_watcher = EventBusWatcher(topics=topics)
        return [_active_watcher]

    from src.plugin_api import ConfigChangePoller

    _active_poller = ConfigChangePoller()
    return [_active_poller]


def active_watcher() -> Optional[Any]:
    """Return the running event-bus watcher, if websocket mode is active."""
    return _active_watcher


def active_poller() -> Optional[Any]:
    """Return the running config-change poller, if poll mode is active."""
    return _active_poller
