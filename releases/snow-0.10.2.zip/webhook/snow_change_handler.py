"""FastAPI route handler for ServiceNow Change Request → LVI Command Runner."""

import asyncio
import logging
import os
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from zoneinfo import ZoneInfo

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Request, status
from logicvein import LogicVeinAPIClient
from pydantic import BaseModel, Field, field_validator
from src.plugin_api import enforce_body_limit, normalize_networks
from src.plugin_api import webhook_store as store

from ..settings import get_snow_client, get_snow_settings

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/webhook", tags=["webhook"])

_IMPACT_MAP: dict = {"1": "High", "2": "Medium", "3": "Low"}


# ---------------------------------------------------------------------------
# Pydantic model
# ---------------------------------------------------------------------------


class SnowChangePayload(BaseModel):
    """Expected JSON payload from the SNOW Business Rule."""

    change_number: str = Field(..., description="SNOW Change Request number (e.g. CHG0012345)")
    change_sys_id: str = Field(..., description="SNOW Change Request sys_id")
    ci_name: str = Field(default="", description="CI name / hostname from SNOW")
    ci_ip: str = Field(default="", description="CI IP address from SNOW")
    commands: str = Field(default="", description="CLI commands to execute, one per line")
    requested_by: str = Field(default="", description="SNOW user who initiated the change")
    scheduled_at: str = Field(
        default="",
        description="ISO datetime for scheduled execution (e.g. '2026-03-17T09:00'). "
        "Omit or leave blank for immediate execution.",
    )
    action: str = Field(
        default="run",
        description="'run' (default), 'reschedule', or 'cancel'.",
    )
    backup_on_completion: bool = Field(
        default=False,
        description="If true, LVI backs up the device configuration after the job completes.",
    )
    lvi_job_id: str = Field(
        default="",
        description="LVI job ID stored in u_lvi_job_id on the SNOW change record. "
        "Required for reschedule and cancel actions.",
    )
    impact: str = Field(
        default="",
        description="SNOW Change Request impact (1=High, 2=Medium, 3=Low).",
    )
    lvi_network: str = Field(
        default="",
        description="LVI network the CI belongs to, read from u_lvi_network on the SNOW CI. "
        "When provided, used directly as the job network without probing LVI.",
    )

    @field_validator("scheduled_at", "lvi_job_id", "ci_ip", "ci_name", "impact", "lvi_network", mode="before")
    @classmethod
    def _strip_snow_template_artifacts(cls, v: Any) -> str:
        """Sanitise unresolved SNOW REST Message template variables.

        When a SNOW Business Rule sets a template variable to an empty string
        via ``setStringParameterNoEscape``, the REST Message may substitute it
        with the literal string ``"undefined"`` (or leave a ``${var}``
        placeholder).  Treat these as empty so downstream logic doesn't mistake
        them for real values.
        """
        if not isinstance(v, str):
            return v
        stripped = v.strip()
        if stripped.lower() in ("undefined", "null", "") or stripped.startswith("${"):
            return ""
        return v


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_change_runner_config() -> Dict[str, Any]:
    """Load the lvi_change_runner section from the ServiceNow plugin config.

    Returns:
        The ``lvi_change_runner`` config dict, or an empty dict if absent.
    """
    return get_snow_settings().get("lvi_change_runner", {})


def _get_lvi_client() -> LogicVeinAPIClient:
    """Build a LogicVeinAPIClient from environment variables.

    Returns:
        LogicVeinAPIClient instance.
    """
    return LogicVeinAPIClient()


def _get_snow_client() -> Any:
    """Build a ServiceNowClient from environment variables.

    Returns:
        Any instance.
    """
    return get_snow_client()


def _check_allowlist(commands: str, allowlist: List[str]) -> Optional[str]:
    """Return the first disallowed command line, or None if all are permitted.

    Deny-by-default: an empty allowlist rejects every command. To permit a
    command, add a case-insensitive prefix to the allowlist. A single ``*``
    entry is an explicit opt-in that permits all commands (use with care in
    production).
    """
    prefixes = [p.strip() for p in allowlist if p and p.strip()]
    # Explicit opt-in to permit everything.
    if "*" in prefixes:
        return None
    for line in commands.splitlines():
        line = line.strip()
        if not line:
            continue
        if not any(line.lower().startswith(prefix.lower()) for prefix in prefixes):
            return line
    return None


def _check_denylist(commands: str, denylist: List[str]) -> Optional[str]:
    """Return the first command line matching a deny prefix, or None.

    The denylist takes precedence over the allowlist: a command matching a
    deny prefix (case-insensitive, same prefix semantics as the allowlist) is
    rejected even when the allowlist is ``*`` (permit all), and it can carve a
    specific exception out of a broader allow (e.g. allow ``show`` but deny
    ``show startup-config``). An empty denylist denies nothing.
    """
    prefixes = [p.strip() for p in denylist if p and p.strip()]
    if not prefixes:
        return None
    for line in commands.splitlines():
        line = line.strip()
        if not line:
            continue
        if any(line.lower().startswith(prefix.lower()) for prefix in prefixes):
            return line
    return None


def _determine_close_code(output: str, failure_conditions: List[str]) -> str:
    """Return 'Unsuccessful' if output contains any failure condition string, else 'Successful'."""
    if output and failure_conditions:
        for condition in failure_conditions:
            if condition and condition in output:
                return "Unsuccessful"
    return "Successful"


def _node_label(name: str, ip: str) -> str:
    """Format a node identifier as 'hostname (ip)' to match the incident display format."""
    if name and ip:
        return f"{name} ({ip})"
    return name or ip or "unknown"


def _advance_chg_state(
    snow: Any,
    payload: SnowChangePayload,
    state_value: str,
    state_label: str,
    extra_fields: Optional[Dict[str, Any]] = None,
) -> bool:
    """Attempt to set the SNOW Change Request state; return True on success."""
    fields: Dict[str, Any] = {"state": state_value}
    if extra_fields:
        fields.update(extra_fields)
    try:
        snow.update_record("change_request", payload.change_sys_id, fields)
        logger.info(
            "snow-change %s: state advanced to %s (%s)",
            payload.change_number,
            state_label,
            state_value,
        )
        return True
    except Exception as exc:
        logger.warning(
            "snow-change %s: failed to advance state to %s: %s",
            payload.change_number,
            state_label,
            exc,
        )
        return False


def _cancel_chg(snow: Any, payload: SnowChangePayload, cfg: Dict[str, Any], reason: str) -> None:
    """Note the cancellation reason and advance the CHG to the configured cancel state.

    Always posts a work note so the cause is visible. When
    ``lvi_change_runner.cancel_state`` is set (an instance-specific state value,
    e.g. the Canceled state), the CHG is advanced to it; when blank, only the
    work note is posted (no state change), preserving prior behaviour.
    """
    _post_work_note(snow, payload, f"[LVI Sync Manager] Change canceled: {reason}")
    cancel_state = (cfg.get("cancel_state") or "").strip()
    if cancel_state:
        _advance_chg_state(snow, payload, cancel_state, "canceled")


def _post_work_note(snow: Any, payload: SnowChangePayload, note: str) -> None:
    """Post a work note to the SNOW Change Request; log but don't raise on failure."""
    try:
        snow.add_work_note_to_change(payload.change_sys_id, note)
    except Exception as exc:
        logger.error(
            "snow-change %s: failed to post work note to SNOW: %s",
            payload.change_number,
            exc,
        )


def _find_device_ip_by_name(lvi: LogicVeinAPIClient, name: str, networks: List[str]) -> tuple:
    """Search LVI networks for a device by hostname.

    Returns:
        ``(ip_address, network_name)`` on success, ``(None, None)`` if not found.
    """
    for network in networks:
        try:
            devices = lvi.search_devices_in_network(network=[network])
            for device in devices or []:
                if device.get("hostname", "").lower() == name.lower():
                    return device.get("ipAddress") or "", network
        except Exception as exc:
            logger.warning("LVI device lookup failed for '%s' in network '%s': %s", name, network, exc)
    return None, None


def _find_device_network(lvi: LogicVeinAPIClient, device_ip: str, networks: List[str]) -> Optional[str]:
    """Return the first network name in which *device_ip* exists, or None.

    Used when the SNOW payload already contains the CI's IP address but the
    network is unknown - LVI requires the correct network in the Command Runner
    job payload or it will return a blank device selection.
    """
    for network in networks:
        try:
            device = lvi.get_device_by_ip(device_ip, network)
            if device:
                return network
        except Exception as exc:
            logger.debug("Network '%s' probe failed for %s: %s", network, device_ip, exc)
    return None


def _format_execution_output(
    lvi: "LogicVeinAPIClient",
    execution_id: int,
    details: List[Dict[str, Any]],
) -> str:
    """Format ToolRunDetails records into a readable work-note block.

    Fetches the actual command output for each device via the LVI servlet
    (``/servlet/pluginDetail?executionId=X&recordId=Y``).  The ``gridData``
    field returned by ``Plugins.getExecutionDetails`` is a status summary
    string, not the command output text.
    """
    if not details:
        return "(no output returned)"
    lines = []
    for entry in details:
        device = entry.get("ipAddress") or entry.get("hostname") or "unknown"
        record_id = entry.get("id")
        if record_id is not None:
            output = lvi.get_execution_output(execution_id, record_id)
        else:
            logger.warning(
                "snow-change: no 'id' field in execution detail record - available keys: %s",
                list(entry.keys()),
            )
            output = ""
        lines.append(f"--- {device} ---")
        lines.append(output.strip() if output else "(no output)")
    return "\n".join(lines)


async def _poll_for_output(
    lvi: LogicVeinAPIClient,
    execution_id: int,
    max_wait: int,
    poll_interval: int,
) -> Optional[str]:
    """Wait for the job to finish, then return its formatted output (None on timeout).

    Hybrid completion detection: when the Event Bus watcher is running, register
    a waiter for the job id so the ``client.scheduler.trigger`` ``complete`` event
    ends the wait immediately (near-zero latency). A ``getExecutionDetails`` poll
    still runs each interval as a safety net, and is the sole mechanism when the
    watcher is not running (poll mode / disabled / WebSocket down). Because the
    event only short-circuits the wait, ``poll_interval_seconds`` can be raised to
    cut API load without hurting completion latency.
    """
    from ..event_bus import job_waiters
    from ..services import active_watcher

    job_id = str(execution_id)
    registered = active_watcher() is not None
    waiter = job_waiters.register(job_id) if registered else None
    loop = asyncio.get_event_loop()
    elapsed = 0
    try:
        while elapsed < max_wait:
            if waiter is not None:
                # Block up to poll_interval for the completion event; returns
                # immediately when it fires. Consume it once, then fall back to
                # plain polling so output that isn't ready yet doesn't busy-loop.
                fired = await loop.run_in_executor(None, waiter.event.wait, poll_interval)
                if fired:
                    logger.info("snow-change: completion event received for job %s", job_id)
                    waiter = None
            else:
                await asyncio.sleep(poll_interval)
            elapsed += poll_interval
            try:
                # Plugins.getExecutionDetails returns rows only after the job finishes;
                # an empty result means still running.
                details = lvi.get_execution_details(execution_id)
                if details:
                    return _format_execution_output(lvi, execution_id, details)
            except Exception as exc:
                logger.warning("Polling execution %d failed: %s", execution_id, exc)
        return None
    finally:
        if registered:
            job_waiters.unregister(job_id)


# ---------------------------------------------------------------------------
# Scheduled execution helper
# ---------------------------------------------------------------------------


def _convert_to_lvi_time(utc_str: str, lvi_tz: str) -> str:
    """Convert a UTC ISO datetime string to the LVI server's local timezone.

    SNOW stores ``start_date`` in UTC.  LVI's ``Scheduler.saveTrigger``
    interprets ``cronExpression`` as being in the supplied ``timeZone``, so
    we must convert before calling ``save_trigger`` - otherwise LVI treats a
    UTC time like ``17:45`` as ``17:45 America/Toronto``, firing 4 h late.

    Returns the converted datetime in the same format as the input (with or
    without seconds).  Falls back to the original string on any parse error.
    """
    try:
        dt_utc = datetime.fromisoformat(utc_str).replace(tzinfo=timezone.utc)
        dt_local = dt_utc.astimezone(ZoneInfo(lvi_tz))
        fmt = "%Y-%m-%dT%H:%M" if len(utc_str) <= 16 else "%Y-%m-%dT%H:%M:%S"
        return dt_local.strftime(fmt)
    except Exception:
        return utc_str


async def _schedule_change(
    snow: Any,
    lvi: LogicVeinAPIClient,
    payload: SnowChangePayload,
    device_ip: str,
    network: str,
    lvi_tz: str = "",
) -> None:
    """Create a Command Runner job in LVI Scheduler and attach a one-time trigger."""
    # SNOW stores start_date in UTC.  LVI's Scheduler.saveTrigger interprets
    # cronExpression AS being in the supplied timeZone - it does not convert from
    # UTC.  So we must pre-convert the UTC time to LVI local time when lvi_tz is
    # set; otherwise LVI would treat e.g. "17:45 UTC" as "17:45 America/Toronto"
    # and fire 4 hours late.
    #
    # When lvi_tz is blank we use "Etc/GMT" (the valid LVI UTC entry - "UTC" is
    # not in LVI's accepted timezone list and causes a fallback to Pacific/Midway).
    scheduled_at = payload.scheduled_at  # UTC - used for the trigger name
    trigger_tz = lvi_tz if lvi_tz else "Etc/GMT"
    cron_time = _convert_to_lvi_time(scheduled_at, lvi_tz) if lvi_tz else scheduled_at

    # Create the job definition (does not run it)
    try:
        job_result = lvi.create_command_runner_job(
            device_ip=device_ip,
            network=network,
            commands=payload.commands,
            job_name=f"SNOW:{payload.change_number}",
            backup_on_completion=payload.backup_on_completion,
            description=f"Job scheduled by ServiceNow for {payload.change_number}",
        )
    except Exception as exc:
        logger.error("snow-change %s: job creation failed: %s", payload.change_number, exc)
        _post_work_note(
            snow,
            payload,
            f"[LVI Sync Manager] ERROR: Failed to create scheduled Command Runner job.\n{exc}",
        )
        store.log_event(
            direction="sync mgr→lvi",
            action="change",
            node=_node_label(payload.ci_name, device_ip),
            correlation_hash=payload.change_sys_id,
            severity=_IMPACT_MAP.get(payload.impact, ""),
            event_type="change",
            result="submit_error",
            src="Sync Manager",
            dst="LogicVein",
            incident=payload.change_number,
            error=str(exc),
            status_code=500,
        )
        return

    if not job_result:
        logger.error("snow-change %s: create_command_runner_job returned None", payload.change_number)
        _post_work_note(snow, payload, "[LVI Sync Manager] ERROR: LVI did not return a job record.")
        return

    job_id = job_result.get("jobId")
    if not job_id:
        logger.error("snow-change %s: no jobId in job result", payload.change_number)
        _post_work_note(snow, payload, "[LVI Sync Manager] ERROR: LVI job record missing jobId.")
        return

    # Schedule the trigger - name always shows UTC for clarity; cronExpression
    # uses the pre-converted local time so LVI fires at the correct moment.
    trigger_name = f"SNOW:{payload.change_number} at {scheduled_at} UTC"
    try:
        trigger_result = lvi.save_trigger(
            job_id=job_id,
            trigger_name=trigger_name,
            cron_expression=cron_time,
            time_zone=trigger_tz,
        )
    except Exception as exc:
        logger.error("snow-change %s: trigger creation failed: %s", payload.change_number, exc)
        _post_work_note(
            snow,
            payload,
            f"[LVI Sync Manager] ERROR: Job created (ID {job_id}) but failed to schedule trigger.\n{exc}",
        )
        store.log_event(
            direction="sync mgr→lvi",
            action="change",
            node=_node_label(payload.ci_name, device_ip),
            correlation_hash=payload.change_sys_id,
            severity=_IMPACT_MAP.get(payload.impact, ""),
            event_type="change",
            result="submit_error",
            src="Sync Manager",
            dst="LogicVein",
            incident=payload.change_number,
            error=str(exc),
            status_code=500,
        )
        return

    trigger_id = (trigger_result or {}).get("triggerId", "")
    logger.info(
        "snow-change %s: scheduled job_id=%s trigger_id=%s at %s (lvi_tz=%s)",
        payload.change_number,
        job_id,
        trigger_id,
        scheduled_at,
        lvi_tz or "none",
    )

    # Write the LVI job ID back to the SNOW change record so reschedule/cancel
    # rules can reference it without parsing work notes.
    try:
        snow.update_record("change_request", payload.change_sys_id, {"u_lvi_job_id": str(job_id)})
    except Exception as exc:
        logger.warning(
            "snow-change %s: failed to write u_lvi_job_id=%s to SNOW: %s",
            payload.change_number,
            job_id,
            exc,
        )

    store.log_event(
        direction="sync mgr→lvi",
        action="change",
        node=_node_label(payload.ci_name, device_ip),
        correlation_hash=payload.change_sys_id,
        severity=_IMPACT_MAP.get(payload.impact, ""),
        event_type="change",
        result="scheduled",
        src="Sync Manager",
        dst="LogicVein",
        incident=payload.change_number,
        status_code=200,
    )

    _post_work_note(
        snow,
        payload,
        f"[LVI Sync Manager] Command Runner job scheduled in LogicVein.\n"
        f"Target device: {device_ip}\n"
        f"Job ID: {job_id}\n"
        f"Scheduled at: {scheduled_at} UTC"
        + (f" ({cron_time} {lvi_tz})" if lvi_tz else "")
        + f"\nRequested by: {payload.requested_by}\n\n"
        f"Commands:\n{payload.commands}",
    )


# ---------------------------------------------------------------------------
# Cancel helper
# ---------------------------------------------------------------------------


async def _cancel_change(
    snow: Any,
    lvi: LogicVeinAPIClient,
    payload: SnowChangePayload,
) -> None:
    """Delete the LVI scheduled job for a cancelled change."""
    job_id = int(payload.lvi_job_id)
    try:
        deleted = lvi.delete_job(job_id)
    except Exception as exc:
        logger.error("snow-change %s: failed to cancel LVI job %d: %s", payload.change_number, job_id, exc)
        _post_work_note(
            snow,
            payload,
            f"[LVI Sync Manager] ERROR: Failed to cancel LVI job {job_id}.\n{exc}",
        )
        store.log_event(
            direction="sync mgr→lvi",
            action="cancel",
            node=_node_label(payload.ci_name, payload.ci_ip),
            correlation_hash=payload.change_sys_id,
            severity=_IMPACT_MAP.get(payload.impact, ""),
            event_type="change",
            result="cancel_error",
            src="Sync Manager",
            dst="LogicVein",
            incident=payload.change_number,
            error=str(exc),
            status_code=500,
        )
        return

    if deleted:
        logger.info("snow-change %s: cancelled LVI job %d", payload.change_number, job_id)
        _post_work_note(
            snow,
            payload,
            f"[LVI Sync Manager] Scheduled LVI job {job_id} has been cancelled.",
        )
        store.log_event(
            direction="sync mgr→lvi",
            action="cancel",
            node=_node_label(payload.ci_name, payload.ci_ip),
            correlation_hash=payload.change_sys_id,
            severity=_IMPACT_MAP.get(payload.impact, ""),
            event_type="change",
            result="cancelled",
            src="Sync Manager",
            dst="LogicVein",
            incident=payload.change_number,
            status_code=200,
        )
    else:
        logger.warning("snow-change %s: delete_job returned False for job %d", payload.change_number, job_id)
        _post_work_note(
            snow,
            payload,
            f"[LVI Sync Manager] WARNING: Could not confirm cancellation of LVI job {job_id}. "
            "Check LogicVein directly.",
        )


# ---------------------------------------------------------------------------
# Background task
# ---------------------------------------------------------------------------


async def _execute_change(payload: SnowChangePayload, cfg: Dict[str, Any]) -> None:
    """Find the device in LVI, submit a Command Runner job, poll, post results to SNOW."""
    # The LVI search scope is the shared logicvein.networks setting, not a
    # runner-specific list.
    networks = normalize_networks(get_snow_settings().get("logicvein", {}).get("networks", "Default")) or ["Default"]
    max_wait = int(cfg.get("max_poll_seconds", 300))
    poll_interval = int(cfg.get("poll_interval_seconds", 10))
    dry_run = bool(cfg.get("dry_run", False))
    snow_dst = os.getenv("SNOW_INSTANCE", "")

    try:
        snow = _get_snow_client()
    except Exception as exc:
        logger.error("snow-change %s: failed to build SNOW client: %s", payload.change_number, exc)
        return

    try:
        lvi = _get_lvi_client()
    except Exception as exc:
        logger.error("snow-change %s: failed to build LVI client: %s", payload.change_number, exc)
        _post_work_note(
            snow,
            payload,
            f"[LVI Sync Manager] ERROR: Could not connect to LogicVein.\n{exc}",
        )
        _cancel_chg(snow, payload, cfg, f"could not connect to LogicVein: {exc}")
        return

    # Cancel: no device resolution needed - delete the LVI job and return
    if payload.action == "cancel":
        await _cancel_change(snow, lvi, payload)
        return

    # Resolve device IP and its LVI network.
    # LVI requires the correct managedNetwork in the Command Runner job payload -
    # passing the wrong network results in a blank device selection and a silent failure.
    #
    # Primary source: lvi_network from the SNOW CI (u_lvi_network custom field),
    # populated by the sync job.  Fallback: probe each configured network via
    # get_device_by_ip / search_devices_in_network for legacy or manually-created CIs.
    device_ip = payload.ci_ip
    device_network: Optional[str] = None

    if payload.lvi_network:
        # Network supplied by SNOW - use it directly, no LVI probing needed.
        device_network = payload.lvi_network
        if not device_ip:
            device_ip, _ = _find_device_ip_by_name(lvi, payload.ci_name, [device_network])
            device_ip = device_ip or ""
    elif device_ip:
        # IP known but network not - probe configured networks.
        device_network = _find_device_network(lvi, device_ip, networks)
    else:
        # Neither IP nor network - search by name across all configured networks.
        device_ip, device_network = _find_device_ip_by_name(lvi, payload.ci_name, networks)
        device_ip = device_ip or ""

    if not device_ip or not device_network:
        networks_str = ", ".join(networks)
        identifier = device_ip or payload.ci_name or "unknown"
        msg = (
            f"[LVI Sync Manager] ERROR: CI '{identifier}' not found in any "
            f"configured LogicVein network ({networks_str})."
        )
        logger.warning("snow-change %s: CI not found in LVI", payload.change_number)
        _post_work_note(snow, payload, msg)
        store.log_event(
            direction="sync mgr→lvi",
            action="change",
            node=_node_label(payload.ci_name, device_ip),
            correlation_hash=payload.change_sys_id,
            severity=_IMPACT_MAP.get(payload.impact, ""),
            event_type="change",
            result="ci_not_found",
            src="Sync Manager",
            dst="LogicVein",
            incident=payload.change_number,
            error="CI not found in any configured LVI network",
            status_code=404,
        )
        _cancel_chg(snow, payload, cfg, f"CI '{identifier}' not found in any configured LogicVein network")
        return

    # Use the resolved network for all subsequent LVI calls.
    network = device_network

    # Dry run - describe what would happen without submitting
    if dry_run:
        logger.info(
            "snow-change %s: DRY RUN - would run on %s",
            payload.change_number,
            device_ip,
        )
        _post_work_note(
            snow,
            payload,
            f"[LVI Sync Manager] DRY RUN - would execute on {device_ip}:\n\n{payload.commands}",
        )
        store.log_event(
            direction="sync mgr→lvi",
            action="change",
            node=_node_label(payload.ci_name, device_ip),
            correlation_hash=payload.change_sys_id,
            severity=_IMPACT_MAP.get(payload.impact, ""),
            event_type="change",
            result="dry_run",
            src="Sync Manager",
            dst="LogicVein",
            incident=payload.change_number,
            status_code=200,
        )
        return

    # Reschedule: delete the old LVI job then create a new scheduled one
    if payload.action == "reschedule":
        if payload.lvi_job_id:
            try:
                lvi.delete_job(int(payload.lvi_job_id))
                logger.info(
                    "snow-change %s: deleted old LVI job %s for reschedule",
                    payload.change_number,
                    payload.lvi_job_id,
                )
            except Exception as exc:
                logger.warning(
                    "snow-change %s: failed to delete old LVI job %s: %s",
                    payload.change_number,
                    payload.lvi_job_id,
                    exc,
                )
        lvi_tz = cfg.get("lvi_time_zone", "")
        await _schedule_change(snow, lvi, payload, device_ip, network, lvi_tz)
        return

    # Scheduled execution - create job + trigger, then return (no polling)
    if payload.scheduled_at:
        lvi_tz = cfg.get("lvi_time_zone", "")
        await _schedule_change(snow, lvi, payload, device_ip, network, lvi_tz)
        return

    # Forced-immediate: CHG moved to Implement while a scheduled LVI job exists.
    # Delete the scheduled job so it doesn't also fire later, then fall through
    # to the immediate-execution path below.
    if payload.lvi_job_id:
        try:
            lvi.delete_job(int(payload.lvi_job_id))
            snow.update_record("change_request", payload.change_sys_id, {"u_lvi_job_id": ""})
            logger.info(
                "snow-change %s: deleted scheduled LVI job %s (forced immediate)",
                payload.change_number,
                payload.lvi_job_id,
            )
            _post_work_note(
                snow,
                payload,
                f"[LVI Sync Manager] Scheduled LVI job {payload.lvi_job_id} cancelled "
                "(change moved to Implement - executing immediately).",
            )
        except Exception as exc:
            logger.warning(
                "snow-change %s: could not delete scheduled job %s: %s",
                payload.change_number,
                payload.lvi_job_id,
                exc,
            )

    # Immediate execution - submit Command Runner job
    try:
        job_result = lvi.run_command_runner_job(
            device_ip=device_ip,
            network=network,
            commands=payload.commands,
            job_name=f"SNOW:{payload.change_number}",
            backup_on_completion=payload.backup_on_completion,
            description=f"Job scheduled by ServiceNow for {payload.change_number}",
        )
    except Exception as exc:
        logger.error("snow-change %s: job submission failed: %s", payload.change_number, exc)
        _post_work_note(
            snow,
            payload,
            f"[LVI Sync Manager] ERROR: Failed to submit Command Runner job.\n{exc}",
        )
        store.log_event(
            direction="sync mgr→lvi",
            action="change",
            node=_node_label(payload.ci_name, device_ip),
            correlation_hash=payload.change_sys_id,
            severity=_IMPACT_MAP.get(payload.impact, ""),
            event_type="change",
            result="submit_error",
            src="Sync Manager",
            dst="LogicVein",
            incident=payload.change_number,
            error=str(exc),
            status_code=500,
        )
        _cancel_chg(snow, payload, cfg, f"failed to submit Command Runner job: {exc}")
        return

    if not job_result:
        msg = "[LVI Sync Manager] ERROR: LVI did not return a job execution record."
        logger.error("snow-change %s: run_command_runner_job returned None", payload.change_number)
        _post_work_note(snow, payload, msg)
        _cancel_chg(snow, payload, cfg, "LVI did not return a job execution record")
        return

    execution_id = job_result.get("id") or job_result.get("executionId")
    logger.info(
        "snow-change %s: Command Runner job submitted, execution_id=%s",
        payload.change_number,
        execution_id,
    )

    store.log_event(
        direction="sync mgr→lvi",
        action="change",
        node=_node_label(payload.ci_name, device_ip),
        correlation_hash=payload.change_sys_id,
        severity=_IMPACT_MAP.get(payload.impact, ""),
        event_type="change",
        result="submitted",
        src="Sync Manager",
        dst="LogicVein",
        incident=payload.change_number,
        status_code=200,
    )

    _post_work_note(
        snow,
        payload,
        f"[LVI Sync Manager] Command Runner job submitted to LogicVein.\n"
        f"Target device: {device_ip}\n"
        f"Execution ID: {execution_id}\n"
        f"Requested by: {payload.requested_by}\n\n"
        f"Commands:\n{payload.commands}\n\n"
        "Results will be posted here when the job completes.",
    )

    if not execution_id:
        logger.warning(
            "snow-change %s: no execution_id in job result - cannot poll",
            payload.change_number,
        )
        return

    # Poll for completion
    output = await _poll_for_output(lvi, int(execution_id), max_wait, poll_interval)

    if output is None:
        logger.warning("snow-change %s: polling timed out after %ds", payload.change_number, max_wait)
        _post_work_note(
            snow,
            payload,
            f"[LVI Sync Manager] Command Runner job timed out after {max_wait}s.\n"
            f"Execution ID: {execution_id}\n"
            "Check LogicVein directly for results.",
        )
        store.log_event(
            direction="sync mgr→lvi",
            action="change",
            node=_node_label(payload.ci_name, device_ip),
            correlation_hash=payload.change_sys_id,
            severity=_IMPACT_MAP.get(payload.impact, ""),
            event_type="change",
            result="timeout",
            src="LogicVein",
            dst="Sync Manager",
            incident=payload.change_number,
            status_code=0,
        )
        _cancel_chg(snow, payload, cfg, f"Command Runner job timed out after {max_wait}s")
        return

    # Post completed output
    _post_work_note(
        snow,
        payload,
        f"[LVI Sync Manager] Command Runner job completed.\n"
        f"Target device: {device_ip}\n"
        f"Execution ID: {execution_id}\n\n"
        f"Output:\n{output}",
    )
    logger.info("snow-change %s: results posted to SNOW", payload.change_number)

    store.log_event(
        direction="sync mgr→snow",
        action="change",
        node=_node_label(payload.ci_name, device_ip),
        correlation_hash=payload.change_sys_id,
        severity=_IMPACT_MAP.get(payload.impact, ""),
        event_type="change",
        result="completed",
        src="LogicVein",
        dst=snow_dst,
        incident=payload.change_number,
        status_code=200,
    )

    # If the job completed but its output matched a configured failure
    # condition, treat it as a failure: cancel the CHG (when cancel_state is set)
    # instead of advancing it. With no failure_conditions configured this never
    # triggers, so behaviour is unchanged.
    failure_conditions = cfg.get("failure_conditions") or []
    if _determine_close_code(output, failure_conditions) == "Unsuccessful":
        _cancel_chg(snow, payload, cfg, "job output matched a configured failure condition")
        return

    # Optionally advance the CHG state on successful completion.
    # Review=0, Closed=3 - values specific to this instance's sys_choice table.
    # "closed" uses a two-step transition (Implement→Review→Closed) because SNOW's
    # "Change Model: Check State Transition" business rule rejects the direct jump.
    # Closing also requires close_code and close_notes on the change_request record.
    complete_state = (cfg.get("complete_state") or "").strip().lower()
    if complete_state == "review":
        _advance_chg_state(snow, payload, "0", "review")
    elif complete_state == "closed":
        if _advance_chg_state(snow, payload, "0", "review"):
            _advance_chg_state(
                snow,
                payload,
                "3",
                "closed",
                {"close_code": "Successful", "close_notes": output},
            )


# ---------------------------------------------------------------------------
# Route
# ---------------------------------------------------------------------------


@router.post(
    "/snow-change",
    status_code=status.HTTP_202_ACCEPTED,
    summary="Receive SNOW Change Request and trigger LVI Command Runner job",
    dependencies=[Depends(enforce_body_limit)],
)
async def snow_change_webhook(
    request: Request,
    payload: SnowChangePayload,
    background_tasks: BackgroundTasks,
) -> Dict[str, Any]:
    """Process an incoming ServiceNow Change Request webhook.

    Three actions are supported, each sent by a dedicated SNOW Business Rule:

    - ``run`` (default): CHG transitions to Scheduled (with ``scheduled_at``) or
      Implement (no ``scheduled_at``).  Creates a scheduled or immediate LVI job.
    - ``reschedule``: CHG planned_start_date changed while in Scheduled state.
      Deletes the old LVI job and creates a new one at the updated time.
    - ``cancel``: CHG cancelled or closed before the job ran.  Deletes the LVI job.

    Returns 202 immediately; all LVI calls and SNOW work-note updates happen in a
    background task.
    """
    cfg = _get_change_runner_config()

    if not cfg.get("enabled", True):
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Change Runner integration is disabled in configuration",
        )

    # Shared-secret validation
    webhook_secret = os.getenv("SNOW_WEBHOOK_HEADER_SECRET", "")
    if webhook_secret:
        provided = request.headers.get("X-Webhook-Secret", "")
        if provided != webhook_secret:
            logger.warning("Rejected snow-change webhook: invalid X-Webhook-Secret header")
            store.log_event(
                direction="snow→sync manager",
                action="change",
                node=_node_label(payload.ci_name, payload.ci_ip),
                correlation_hash=payload.change_sys_id,
                severity=_IMPACT_MAP.get(payload.impact, ""),
                event_type="change",
                result="rejected",
                src=request.client.host if request.client else "unknown",
                dst="Sync Manager",
                incident=payload.change_number,
                error="Invalid webhook secret",
                status_code=401,
            )
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid webhook secret",
            )

    def _reject(detail: str) -> None:
        """Log and raise a 422 HTTPException to reject the current request.

        Args:
            detail: Human-readable rejection reason included in the response body.
        """
        logger.warning("Rejected snow-change %s: %s", payload.change_number, detail)
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=detail)

    if payload.action == "cancel":
        if not payload.lvi_job_id:
            _reject("lvi_job_id is required for cancel action")
    elif payload.action == "reschedule":
        if not payload.lvi_job_id:
            _reject("lvi_job_id is required for reschedule action")
        if not payload.scheduled_at:
            _reject("scheduled_at is required for reschedule action")
        if not payload.ci_ip and not payload.ci_name:
            _reject("At least one of ci_ip or ci_name must be provided")
        if not payload.commands.strip():
            _reject("commands field is empty")
    else:
        if not payload.ci_ip and not payload.ci_name:
            _reject("At least one of ci_ip or ci_name must be provided")
        if not payload.commands.strip():
            _reject("commands field is empty")

    # Command policy check (not applicable to cancel). The denylist is checked
    # first and takes precedence over the allowlist, so a denied command is
    # rejected even when the allowlist is '*' (permit all).
    if payload.action != "cancel":

        def _reject_command(line: str, error: str, detail: str) -> None:
            logger.warning("Rejected snow-change %s: %s: %s", payload.change_number, error, line)
            store.log_event(
                direction="snow→sync manager",
                action="change",
                node=_node_label(payload.ci_name, payload.ci_ip),
                correlation_hash=payload.change_sys_id,
                severity=_IMPACT_MAP.get(payload.impact, ""),
                event_type="change",
                result="rejected",
                src=request.client.host if request.client else "unknown",
                dst="Sync Manager",
                incident=payload.change_number,
                error=f"{error}: {line}",
                status_code=403,
            )
            # Reflect the rejection back to SNOW: note the reason and, if a
            # cancel_state is configured, cancel the Change Request. Best-effort -
            # never let a SNOW failure prevent the 403.
            try:
                _cancel_chg(_get_snow_client(), payload, cfg, f"{error}: {line}")
            except Exception as exc:
                logger.warning("snow-change %s: could not cancel CHG after rejection: %s", payload.change_number, exc)
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=f"{detail}: {line}")

        denied = _check_denylist(payload.commands, cfg.get("command_denylist", []))
        if denied is not None:
            _reject_command(denied, "Command explicitly denied", "Command explicitly denied by denylist")

        not_allowed = _check_allowlist(payload.commands, cfg.get("command_allowlist", []))
        if not_allowed is not None:
            _reject_command(not_allowed, "Command not in allowlist", "Command not permitted by allowlist")

    logger.info(
        "Received SNOW change webhook: change=%s ci=%s requested_by=%s impact=%r",
        payload.change_number,
        payload.ci_ip or payload.ci_name,
        payload.requested_by,
        payload.impact,
    )

    store.log_event(
        direction="snow→sync manager",
        action="change",
        node=_node_label(payload.ci_name, payload.ci_ip),
        correlation_hash=payload.change_sys_id,
        severity=_IMPACT_MAP.get(payload.impact, ""),
        event_type="change",
        result="received",
        src=request.client.host if request.client else "unknown",
        dst="Sync Manager",
        incident=payload.change_number,
        status_code=202,
    )

    background_tasks.add_task(_execute_change, payload, cfg)

    return {
        "result": "accepted",
        "change_number": payload.change_number,
        "message": "Command Runner job will be submitted to LogicVein",
    }
