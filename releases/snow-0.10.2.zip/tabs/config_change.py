"""Config Change tab (ServiceNow plugin)."""

import logging

from nicegui import ui
from src.plugin_api import cycle_store, t

from .. import services
from ..settings import get_change_detection_settings

logger = logging.getLogger(__name__)


def render_config_change_tab():
    """Render the config-change diagnostics tab (poll or WebSocket mode)."""
    _poller_cfg = get_change_detection_settings()
    _is_websocket = _poller_cfg.get("mode", "websocket") == "websocket"

    _ERROR_STATUSES = {
        "lvi_error",
        "snow_error",
        "error",
        "plugin_not_installed",
        "no_license",
        "expired_license",
    }
    _STATUS_COLORS = {
        "running": "#2563eb",
        "new_changes_detected": "#16a34a",
        "no_changes": "#6b7280",
        "already_seen": "#6b7280",
        **{s: "#dc2626" for s in _ERROR_STATUSES},
    }

    _show_new_only = [True]

    def _row_data():
        if cycle_store is None:
            return []
        rows = []
        for c in cycle_store.get_cycles():
            if _show_new_only[0]:
                # Hide cycles with no new changes: the quiet "no changes" cases
                # and any error that occurred without detecting a change.
                if c["status"] in ("no_changes", "already_seen"):
                    continue
                if c["status"] in _ERROR_STATUSES and not c["new_events"]:
                    continue
            duration = f"{c['duration_s']}s" if c["duration_s"] is not None else "…"
            rows.append(
                {
                    "started": c["started"],
                    "status": c["status"],
                    "statusColor": _STATUS_COLORS.get(c["status"], "#374151"),
                    "networks": c["networks"],
                    "poll_interval": f"{c.get('poll_interval_min', '?')} min",
                    "items_found": c["items_found"],
                    "events_found": c["events_found"],
                    "new_events": c["new_events"],
                    "incidents_created": c["incidents_created"],
                    "duration": duration,
                    "error": c["error"] or "",
                    "new_event_details": c.get("new_event_details", []),
                }
            )
        return rows

    ui.label(t("config_change.section_title")).classes("text-base font-semibold text-gray-700 dark:text-gray-200 mb-1")

    # ── Top toolbar ───────────────────────────────────────────────────────────
    def _on_cc_refresh_change(e):
        try:
            _cc_timer.interval = max(1.0, float(e.value))
        except Exception as exc:
            logger.debug("Ignoring invalid refresh interval %r: %s", e.value, exc)

    with ui.row().classes("w-full items-center justify-between mb-3 gap-2"):
        with ui.row().classes("items-center gap-3"):
            _status_dot = ui.icon("circle", color="gray").classes("text-sm")
            _status_label = ui.label(t("config_change.status_checking")).classes(
                "text-sm text-gray-500 dark:text-gray-400"
            )
            _mode_key = "config_change.mode_websocket" if _is_websocket else "config_change.mode_poll"
            ui.badge(t(_mode_key), color="blue-grey").props("rounded").classes("text-xs ml-1")
            ui.label(t("config_change.refresh_label")).classes("text-sm text-gray-500 dark:text-gray-400 ml-3")
            ui.number(value=5, min=1, max=300, step=1, format="%.0f", on_change=_on_cc_refresh_change).props(
                "dense outlined"
            ).classes("w-20")
            _cycle_count_label = ui.label("").classes(
                "text-sm text-gray-400 dark:text-gray-500 ml-2"
            )  # set by _do_refresh

        with ui.row().classes("items-center gap-1"):

            def _do_poll_now():
                if services.active_poller() is not None:
                    services.active_poller().poll_now()
                    ui.notify(t("config_change.notify_poll_triggered"), type="positive")
                else:
                    ui.notify(t("config_change.notify_not_running"), type="warning")

            _poll_now_btn = ui.button(t("config_change.poll_now_btn"), icon="refresh", on_click=_do_poll_now).props(
                "flat dense size=sm color=primary"
            )
            _poll_now_btn.visible = not _is_websocket

            _CC_TOGGLEABLE_COLS = [
                (t("config_change.col_started"), "started", True),
                (t("config_change.col_status"), "status", True),
                (t("config_change.col_networks"), "networks", True),
                *([] if _is_websocket else [(t("config_change.col_interval"), "poll_interval", True)]),
                (t("config_change.col_total_changes"), "items_found", False),
                (t("config_change.col_unique_changes"), "events_found", False),
                (t("config_change.col_new_changes"), "new_events", True),
                (t("config_change.col_incidents"), "incidents_created", False),
                (t("config_change.col_duration"), "duration", False),
                (t("config_change.col_error"), "error", False),
            ]

            ui.button(
                t("config_change.export_btn"),
                icon="download",
                on_click=lambda: _grid.run_grid_method("exportDataAsCsv", {"fileName": "config_change_runs.csv"}),
            ).props("flat dense size=sm color=primary")

            def _make_cc_toggle(f):
                def _toggle(e):
                    _grid.run_grid_method(
                        "applyColumnState",
                        {"state": [{"colId": f, "hide": not e.value}]},
                    )

                return _toggle

            with ui.button(t("config_change.columns_btn"), icon="view_column").props("flat dense size=sm"):
                with ui.menu().props("anchor='bottom right' self='top right'").classes("p-1"):
                    for _lbl, _fld, _vis in _CC_TOGGLEABLE_COLS:
                        ui.checkbox(_lbl, value=_vis, on_change=_make_cc_toggle(_fld)).classes("px-2")

            ui.button(
                t("config_change.clear_btn"),
                icon="delete_sweep",
                on_click=lambda: (cycle_store.clear() if cycle_store else None, _do_refresh()),
            ).props("flat dense size=sm color=negative")

    # ── Quick filter + Show New Only ─────────────────────────────────────────
    with ui.row().classes("w-full items-center gap-2 mb-2"):
        ui.icon("search").classes("text-gray-400")
        _cc_filter_input = (
            ui.input(placeholder=t("config_change.filter_placeholder"))
            .props("dense outlined clearable")
            .classes("flex-1")
        )

        def _toggle_show_new(e):
            _show_new_only[0] = e.value
            _do_refresh()

        ui.checkbox(t("config_change.show_new_only"), value=True, on_change=_toggle_show_new).props("dense").classes(
            "text-sm"
        )

    # ── ag-Grid ───────────────────────────────────────────────────────────────
    _grid = (
        ui.aggrid(
            options={
                "columnDefs": [
                    {
                        "headerName": t("config_change.col_started"),
                        "field": "started",
                        "width": 185,
                        "sort": "desc",
                        "cellClass": "font-mono text-xs",
                    },
                    {
                        "headerName": t("config_change.col_status"),
                        "field": "status",
                        "width": 115,
                        ":cellStyle": "params => ({color: params.data.statusColor, fontWeight: 'bold'})",
                    },
                    {
                        "headerName": t("config_change.col_networks"),
                        "field": "networks",
                        "flex": 1,
                        "minWidth": 100,
                        # Network lists can be long; flex-fill but cap the width.
                        "maxWidth": 280,
                    },
                    {
                        "headerName": t("config_change.col_interval"),
                        "field": "poll_interval",
                        "width": 120,
                        "hide": _is_websocket,
                    },
                    {
                        "headerName": t("config_change.col_total_changes"),
                        "field": "items_found",
                        "width": 100,
                        "hide": True,
                        "type": "numericColumn",
                    },
                    {
                        "headerName": t("config_change.col_unique_changes"),
                        "field": "events_found",
                        "width": 100,
                        "hide": True,
                        "type": "numericColumn",
                    },
                    {
                        "headerName": t("config_change.col_new_changes"),
                        "field": "new_events",
                        "width": 90,
                        "type": "numericColumn",
                    },
                    {
                        "headerName": t("config_change.col_incidents"),
                        "field": "incidents_created",
                        "width": 105,
                        "hide": True,
                        "type": "numericColumn",
                    },
                    {
                        "headerName": t("config_change.col_duration"),
                        "field": "duration",
                        "width": 90,
                        "hide": True,
                        "cellClass": "font-mono text-xs",
                    },
                    {
                        "headerName": t("config_change.col_error"),
                        "field": "error",
                        "flex": 2,
                        "minWidth": 120,
                        "hide": True,
                        ":cellStyle": "params => params.value ? {color: '#dc2626'} : null",
                    },
                ],
                "rowData": _row_data(),
                "defaultColDef": {"sortable": True, "resizable": True, "filter": True},
                # Size each column to its header + cell contents on first load.
                "autoSizeStrategy": {"type": "fitCellContents"},
                "suppressScrollOnNewData": True,
                "rowSelection": {"mode": "singleRow"},
                "rowHeight": 28,
                "headerHeight": 32,
            },
            theme="alpine",
            auto_size_columns=False,
        )
        .classes("w-full")
        .style("height: 250px; font-size: 11px;")
    )

    _cc_filter_input.on_value_change(lambda e: _grid.run_grid_method("setGridOption", "quickFilterText", e.value or ""))

    # ── Change Details section ────────────────────────────────────────────────
    _DETAIL_COLS = [
        (t("config_change.detail_col_ip"), "ip_address", True),
        (t("config_change.detail_col_hostname"), "hostname", True),
        (t("config_change.detail_col_network"), "network", True),
        (t("config_change.detail_col_path"), "path", True),
        (t("config_change.detail_col_changed"), "changed", True),
        (t("config_change.detail_col_author"), "author", True),
    ]

    with ui.column().classes("w-full mt-3 gap-1"):
        with ui.row().classes("w-full items-center justify-between"):
            ui.label(t("config_change.details_title")).classes(
                "text-base font-semibold text-gray-700 dark:text-gray-200"
            )
            with ui.row().classes("items-center gap-1"):
                ui.button(
                    t("config_change.export_btn"),
                    icon="download",
                    on_click=lambda: _detail_grid.run_grid_method(
                        "exportDataAsCsv", {"fileName": "config_change_details.csv"}
                    ),
                ).props("flat dense size=sm color=primary")
                with ui.button(t("config_change.columns_btn"), icon="view_column").props("flat dense size=sm"):
                    with ui.menu().props("anchor='bottom right' self='top right'").classes("p-1"):

                        def _make_detail_toggle(f):
                            def _t(e):
                                _detail_grid.run_grid_method(
                                    "applyColumnState",
                                    {"state": [{"colId": f, "hide": not e.value}]},
                                )

                            return _t

                        for _lbl, _fld, _vis in _DETAIL_COLS:
                            ui.checkbox(_lbl, value=_vis, on_change=_make_detail_toggle(_fld)).classes("px-2")

        _diff_js = """
async (params) => {
  if (params.column.colId !== 'path') return;
  const d = params.data;
  if (!d || !d.path) return;

  const BIN_EXTS = ['.gz', '.tgz', '.tar', '.zip', '.bak', '.dat'];
  if (BIN_EXTS.some(ext => d.path.toLowerCase().endsWith(ext))) return;

  const overlay = document.createElement('div');
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.55);z-index:9999;display:flex;align-items:flex-start;justify-content:center;padding:40px 16px;overflow-y:auto;cursor:default';
  const box = document.createElement('div');
  box.style.cssText = 'background:#fff;color:#1e293b;border-radius:8px;padding:20px 24px;width:100%;max-width:960px;position:relative;box-shadow:0 8px 32px rgba(0,0,0,0.3)';
  const closeBtn = '<button onclick="this.closest(\\'.diff-overlay\\').remove()" style="background:none;border:none;font-size:22px;cursor:pointer;color:#64748b;line-height:1;float:right">&times;</button>';
  box.innerHTML = `
    <div style="font-family:sans-serif;margin-bottom:12px">
      ${closeBtn}
      <strong style="font-size:15px">${d.hostname||d.ip_address}</strong>
      <span style="color:#64748b;margin-left:8px;font-size:13px">${d.ip_address}</span>
      <code style="background:#f1f5f9;padding:2px 7px;border-radius:4px;margin-left:8px;font-size:12px">${d.path}</code>
      <div style="font-size:11px;color:#94a3b8;margin-top:6px">${d.prev_change||'(no previous)'} &rarr; ${d.last_changed||d.changed||''}</div>
    </div>
    <div style="display:flex;gap:3px;align-items:stretch">
      <pre id="diff-pre" style="flex:1;min-width:0;margin:0;white-space:pre-wrap;word-break:break-all;font-family:monospace;font-size:12px;line-height:1.5;background:#f8fafc;color:#1e293b;padding:14px;border-radius:6px;overflow:auto;max-height:62vh">Loading…</pre>
      <div id="diff-bar" style="display:none;width:8px;flex-shrink:0;background:#e2e8f0;border-radius:4px;position:relative;overflow:hidden"></div>
    </div>
  `;
  overlay.className = 'diff-overlay';
  overlay.appendChild(box);
  document.body.appendChild(overlay);
  overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });

  const pre = box.querySelector('#diff-pre');
  const bar = box.querySelector('#diff-bar');

  // LCS-based line diff. Falls back to a sequential diff for very large files.
  function lineDiff(a, b) {
    const m = a.length, n = b.length;
    if (m * n > 1000000) {
      const out = [];
      const len = Math.max(m, n);
      for (let i = 0; i < len; i++) {
        if (i < m && i < n) {
          if (a[i] === b[i]) out.push({t:'eq',l:a[i]});
          else { out.push({t:'del',l:a[i]}); out.push({t:'add',l:b[i]}); }
        } else if (i < m) { out.push({t:'del',l:a[i]}); }
        else { out.push({t:'add',l:b[i]}); }
      }
      return out;
    }
    const dp = [];
    for (let i = 0; i <= m; i++) dp[i] = new Int32Array(n + 1);
    for (let i = 1; i <= m; i++)
      for (let j = 1; j <= n; j++)
        dp[i][j] = a[i-1] === b[j-1] ? dp[i-1][j-1]+1 : Math.max(dp[i-1][j], dp[i][j-1]);
    const out = []; let i = m, j = n;
    while (i > 0 || j > 0) {
      if (i > 0 && j > 0 && a[i-1] === b[j-1]) { out.push({t:'eq',l:a[i-1]}); i--; j--; }
      else if (j > 0 && (i === 0 || dp[i][j-1] >= dp[i-1][j])) { out.push({t:'add',l:b[j-1]}); j--; }
      else { out.push({t:'del',l:a[i-1]}); i--; }
    }
    return out.reverse();
  }

  try {
    const resp = await fetch('/api/config-diff', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ip_address:d.ip_address, network:d.network, path:d.path, prev_change:d.prev_change||'', last_changed:d.last_changed||d.changed||''})
    });
    if (!resp.ok) { pre.textContent = 'Error ' + resp.status + ': ' + resp.statusText; return; }
    const diff = await resp.json();
    if (!Array.isArray(diff) || !diff.length) { pre.textContent = '(no diff available)'; return; }

    // Reconstruct old and new full texts from word-diff segments.
    let oldText = '', newText = '';
    for (const s of diff) {
      if (s.op === 'EQUAL')       { oldText += s.text; newText += s.text; }
      else if (s.op === 'DELETE') { oldText += s.text; }
      else if (s.op === 'ADD')    { newText += s.text; }
      else if (s.op === 'CHANGE') { oldText += s.text; newText += (s.newText || ''); }
    }

    const oldLines = oldText.split('\\n');
    const newLines = newText.split('\\n');
    if (oldLines[oldLines.length - 1] === '') oldLines.pop();
    if (newLines[newLines.length - 1] === '') newLines.pop();

    const esc = s => (s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    const items = lineDiff(oldLines, newLines);
    let html = '';
    for (const item of items) {
      const ln = esc(item.l);
      if (item.t === 'eq') {
        html += ln + '\\n';
      } else if (item.t === 'del') {
        html += `<del style="background:#fee2e2;color:#991b1b;text-decoration:line-through">${ln}\\n</del>`;
      } else {
        html += `<mark style="background:#bbf7d0;color:#166534;text-decoration:none">${ln}\\n</mark>`;
      }
    }
    pre.innerHTML = html;

    // Build the scrollbar indicator strip once layout is settled.
    requestAnimationFrame(() => {
      const totalH = pre.scrollHeight;
      const visibleH = pre.clientHeight;
      if (totalH <= visibleH) return;
      bar.style.display = '';
      const preTop = pre.getBoundingClientRect().top;
      let bHtml = '';
      function addDot(el, color) {
        const relTop = el.getBoundingClientRect().top - preTop + pre.scrollTop;
        const dotTop = Math.round((relTop / totalH) * visibleH);
        bHtml += `<div style="position:absolute;top:${dotTop}px;left:0;right:0;height:3px;background:${color};border-radius:2px"></div>`;
      }
      for (const el of pre.querySelectorAll('del'))  addDot(el, '#f87171');
      for (const el of pre.querySelectorAll('mark')) addDot(el, '#4ade80');
      bar.innerHTML = bHtml;
    });

  } catch(err) { pre.textContent = 'Error: ' + err.message; }
}
"""
        _DETAIL_PLACEHOLDER = [{"_placeholder": True, "ip_address": t("config_change.detail_placeholder")}]

        _detail_grid = (
            ui.aggrid(
                options={
                    "columnDefs": [
                        {
                            "headerName": t("config_change.detail_col_ip"),
                            "field": "ip_address",
                            "width": 135,
                            ":cellClass": "p => p.data._placeholder ? '' : 'font-mono'",
                            ":colSpan": "p => p.data._placeholder ? 6 : 1",
                            ":cellStyle": "p => p.data._placeholder ? {color:'#6b7280',fontStyle:'italic',fontFamily:'sans-serif'} : null",
                        },
                        {
                            "headerName": t("config_change.detail_col_hostname"),
                            "field": "hostname",
                            "flex": 1,
                            "minWidth": 130,
                        },
                        {"headerName": t("config_change.detail_col_network"), "field": "network", "width": 110},
                        {
                            "headerName": t("config_change.detail_col_path"),
                            "field": "path",
                            "width": 160,
                            "cellClass": "font-mono",
                            ":cellStyle": "p => { if (!p.value) return {}; const b=['.gz','.tgz','.tar','.zip','.bak','.dat']; return b.some(e=>p.value.toLowerCase().endsWith(e)) ? {cursor:'not-allowed',color:'#94a3b8'} : {cursor:'pointer',color:'#2563eb',textDecoration:'underline'}; }",
                        },
                        {
                            "headerName": t("config_change.detail_col_changed"),
                            "field": "changed",
                            "width": 160,
                            "cellClass": "font-mono",
                        },
                        {"headerName": t("config_change.detail_col_author"), "field": "author", "width": 110},
                    ],
                    "rowData": _DETAIL_PLACEHOLDER,
                    "defaultColDef": {"sortable": True, "resizable": True, "filter": True},
                    "rowHeight": 28,
                    "headerHeight": 32,
                    ":onCellClicked": _diff_js,
                },
                theme="alpine",
                auto_size_columns=False,
            )
            .classes("w-full")
            .style("height: 210px; font-size: 11px;")
        )

    # Wire row click in pure JS - bypasses NiceGUI's Python event routing.
    # An error row (status error/snow_error/lvi_error, or a non-empty error)
    # opens an overlay with the failure cause for troubleshooting; any other row
    # loads its config-change details into the grid below.
    _placeholder_text = t("config_change.detail_placeholder").replace('"', '\\"')
    _PLACEHOLDER_JS = f'[{{_placeholder:true,ip_address:"{_placeholder_text}"}}]'
    _err_title_js = t("config_change.error_detail_title").replace("\\", "\\\\").replace('"', '\\"')
    _on_row_clicked_js = """
params => {
  const d = params.data;
  const errStatuses = ['error', 'snow_error', 'lvi_error', 'plugin_not_installed', 'no_license', 'expired_license'];
  if (d.error || errStatuses.includes(d.status)) {
    const overlay = document.createElement('div');
    overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.55);z-index:9999;display:flex;align-items:flex-start;justify-content:center;padding:40px 16px;overflow-y:auto';
    const box = document.createElement('div');
    box.style.cssText = 'background:#fff;color:#1e293b;border-radius:8px;padding:20px 24px;width:100%;max-width:820px;box-shadow:0 8px 32px rgba(0,0,0,0.3)';
    const esc = s => (s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    box.innerHTML =
      '<button class="err-close" style="background:none;border:none;font-size:22px;cursor:pointer;color:#64748b;float:right">&times;</button>'
      + '<div style="font-family:sans-serif;margin-bottom:10px"><strong style="font-size:15px">__TITLE__</strong>'
      + '<div style="font-size:12px;color:#64748b;margin-top:4px">' + esc(d.status) + ' &middot; ' + esc(d.started) + ' &middot; ' + esc(d.networks) + '</div></div>'
      + '<pre style="margin:0;white-space:pre-wrap;word-break:break-all;font-family:monospace;font-size:12px;line-height:1.5;background:#fef2f2;color:#991b1b;padding:14px;border-radius:6px;overflow:auto;max-height:60vh"></pre>';
    box.querySelector('pre').textContent = d.error || d.status;
    box.querySelector('.err-close').addEventListener('click', () => overlay.remove());
    overlay.appendChild(box);
    document.body.appendChild(overlay);
    overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });
    return;
  }
  const det = d.new_event_details;
  getElement(__DETAIL_ID__).api.setGridOption('rowData', det && det.length ? det : __PLACEHOLDER__);
}
"""
    _grid.options[":onRowClicked"] = (
        _on_row_clicked_js.replace("__TITLE__", _err_title_js)
        .replace("__DETAIL_ID__", str(_detail_grid.id))
        .replace("__PLACEHOLDER__", _PLACEHOLDER_JS)
    )
    _grid.update()

    def _update_status():
        _backend = services.active_watcher() if _is_websocket else services.active_poller()
        if _backend is None:
            _status_dot.props("color=gray")
            _status_label.set_text(t("config_change.status_not_configured"))
        elif _backend.is_running():
            _status_dot.props("color=green")
            _status_label.set_text(t("config_change.status_running"))
        else:
            _status_dot.props("color=red")
            _status_label.set_text(t("config_change.status_stopped"))

    def _do_refresh():
        rows = _row_data()
        _grid.run_grid_method("setGridOption", "rowData", rows)
        _cycle_count_label.set_text(t("config_change.cycle_count", count=len(rows)))
        _update_status()

    _update_status()
    _cycle_count_label.set_text(t("config_change.cycle_count", count=len(_row_data())))
    _cc_timer = ui.timer(5.0, _do_refresh)
