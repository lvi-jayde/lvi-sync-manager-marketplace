"""ServiceNow plugin tabs subsystem."""
