"""NetBox IPAM sync plugin implementation."""

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from src.plugin_api import SyncPlugin, load_plugin_config, normalize_networks

from .client import NetBoxClient
from .sync import LogicVeinNetBoxSync

logger = logging.getLogger(__name__)


class NetBoxPlugin(SyncPlugin):
    """Plugin for synchronizing LogicVein devices to NetBox IPAM."""

    def __init__(self):
        """Initialize the NetBox plugin from its manifest.json."""
        self.config = load_plugin_config(Path(__file__).parent)

    def create_client(self, credentials: Dict[str, Any]) -> Any:
        """Create NetBox client.

        Args:
            credentials: Dictionary with 'host' and 'token' keys.

        Returns:
            NetBoxClient instance.
        """
        from .settings import get_netbox_settings

        netbox_cfg = get_netbox_settings().get("netbox", {})
        kwargs: Dict[str, Any] = {
            "verify_ssl": bool(netbox_cfg.get("verify_ssl", False)),
            "timeout": int(netbox_cfg.get("timeout", 120)),
        }
        if credentials.get("ignore_env_vars"):
            kwargs["ignore_env_vars"] = True
        if credentials.get("host"):
            kwargs["host"] = credentials["host"]
        if credentials.get("token"):
            kwargs["api_token"] = credentials["token"]

        return NetBoxClient(**kwargs)

    def create_sync_engine(
        self,
        lvi_client: Any,
        target_client: Any,
        sync_config: Dict[str, Any],
    ) -> Any:
        """Create NetBox sync engine.

        Args:
            lvi_client: LogicVein API client.
            target_client: NetBox client.
            sync_config: Sync configuration dictionary.

        Returns:
            LogicVeinNetBoxSync instance.
        """
        return LogicVeinNetBoxSync(
            lvi_client=lvi_client,
            netbox_client=target_client,
            config=sync_config,
        )

    def build_sync_config(
        self,
        yaml_config: Dict[str, Any],
        timestamp: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Build sync configuration from YAML config.

        Args:
            yaml_config: Parsed YAML configuration dictionary.
            timestamp: Optional timestamp for archive file naming.

        Returns:
            Configuration dictionary ready for LogicVeinNetBoxSync.
        """
        sync_config = yaml_config.get("sync", {})
        lvi_config = yaml_config.get("logicvein", {})
        netbox_config = yaml_config.get("netbox", {})

        return {
            # Sync options
            "dry_run": sync_config.get("dry_run", False),
            "network": lvi_config.get("networks", "Default"),
            "continue_on_error": sync_config.get("continue_on_error", True),
            # NetBox device options
            "sync_to_dcim": netbox_config.get("sync_to_dcim", True),
            "strip_domain_from_names": netbox_config.get("strip_domain_from_names", True),
            "site_name": netbox_config.get("site_name", ""),
            "tenant_name": netbox_config.get("tenant_name", ""),
            "device_role_name": netbox_config.get("device_role_name", ""),
            "default_device_type": netbox_config.get("default_device_type", ""),
            "default_manufacturer": netbox_config.get("default_manufacturer", "Unknown"),
            "create_missing_resources": netbox_config.get("create_missing_resources", True),
            "populate_custom_fields": netbox_config.get("populate_custom_fields", False),
            "custom_field_mapping": netbox_config.get("custom_field_mapping", {}),
            # NetBox IPAM options
            "create_ip_addresses": netbox_config.get("create_ip_addresses", True),
            "set_primary_ip": netbox_config.get("set_primary_ip", True),
            "default_ip_status": netbox_config.get("default_ip_status", "active"),
            "default_subnet_mask": netbox_config.get("default_subnet_mask", 32),
            # Extended field sync options
            "sync_platform": netbox_config.get("sync_platform", False),
            "sync_comments": netbox_config.get("sync_comments", False),
            "sync_description": netbox_config.get("sync_description", False),
            "sync_mac_address": netbox_config.get("sync_mac_address", False),
            "ip_conflict_policy": netbox_config.get("ip_conflict_policy", "overwrite"),
            "mac_conflict_policy": netbox_config.get("mac_conflict_policy", "overwrite"),
            # Lifecycle custom fields
            "sync_lifecycle": netbox_config.get("sync_lifecycle", False),
            "lifecycle_field_mapping": netbox_config.get("lifecycle_field_mapping", {}),
            # LVI custom fields (custom1-5)
            "lvi_custom_field_mapping": netbox_config.get("lvi_custom_field_mapping", {}),
            # Location sync options
            "sync_location": netbox_config.get("sync_location", False),
            "create_missing_locations": netbox_config.get("create_missing_locations", True),
            # Interface sync options
            "sync_interfaces": netbox_config.get("sync_interfaces", False),
            "delete_stale_interfaces": netbox_config.get("delete_stale_interfaces", False),
            # Stale device/IP deletion options
            "delete_stale_devices": netbox_config.get("delete_stale_devices", False),
            "delete_stale_ips": netbox_config.get("delete_stale_ips", False),
        }

    def test_connection(
        self,
        credentials: Dict[str, Any],
    ) -> Tuple[bool, str]:
        """Test connection to NetBox.

        Args:
            credentials: Dictionary with 'host' and 'token' keys.

        Returns:
            Tuple of (success, message).
        """
        try:
            client = self.create_client(credentials)
            # Try a simple API call to verify connection
            if client.test_connection():
                return True, "Connected to NetBox successfully"
            else:
                return False, "Connection test failed - check credentials"
        except Exception as e:
            return False, f"Connection failed: {e}"

    def supports_preview(self) -> bool:
        """NetBox plugin supports preview."""
        return True

    def get_preview(
        self,
        lvi_client: Any,
        target_client: Any,
        config: Dict[str, Any],
    ) -> Optional[Dict[str, Any]]:
        """Get preview of sync changes.

        Args:
            lvi_client: LogicVein API client.
            target_client: NetBox client.
            config: Sync configuration dictionary.

        Returns:
            Dictionary with preview data.
        """
        # Get devices from LogicVein
        networks = normalize_networks(config.get("network", "Default"))
        devices = lvi_client.search_devices_in_network(network=networks)

        # Get existing devices from NetBox
        site_name = config.get("site_name")
        if site_name:
            existing_devices = target_client.get_devices(site=site_name)
        else:
            existing_devices = target_client.get_devices()

        # Build preview
        existing_names = {d.name for d in existing_devices}
        lvi_names = {d.get("hostname", d.get("name", "")) for d in devices}

        to_create = lvi_names - existing_names
        to_update = lvi_names & existing_names
        to_delete = existing_names - lvi_names if config.get("delete_stale_devices") else set()

        return {
            "total_lvi_devices": len(devices),
            "total_netbox_devices": len(existing_devices),
            "devices_to_create": len(to_create),
            "devices_to_update": len(to_update),
            "devices_to_delete": len(to_delete),
            "create_list": sorted(list(to_create))[:10],  # First 10 for preview
            "delete_list": sorted(list(to_delete))[:10],
        }

    def get_status_detail(self, config: Dict[str, Any]) -> str:
        """Return a one-line status string for the NetBox sync tab header.

        Args:
            config: Parsed YAML configuration dictionary.

        Returns:
            Human-readable summary of the active network(s) and target site.
        """
        networks = normalize_networks(config.get("logicvein", {}).get("networks", "Default"))
        network_str = ", ".join(networks) if networks else "all"
        site = config.get("netbox", {}).get("site_name", "")
        return f"Network: {network_str} | Site: {site or 'Not set'}"

    def get_preview_info(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Return a dict of preview metadata shown before a sync run.

        Args:
            config: Parsed YAML configuration dictionary.

        Returns:
            Dict with "target" and "sync_options" sub-dicts for display.
        """
        netbox_config = config.get("netbox", {})
        return {
            "target": {
                "site": netbox_config.get("site_name", ""),
                "tenant": netbox_config.get("tenant_name", ""),
                "create_missing_resources": netbox_config.get("create_missing_resources", True),
            },
            "sync_options": {
                "create_ip_addresses": netbox_config.get("create_ip_addresses", True),
                "sync_interfaces": netbox_config.get("sync_interfaces", False),
                "sync_lifecycle": netbox_config.get("sync_lifecycle", False),
                "delete_stale_devices": netbox_config.get("delete_stale_devices", False),
            },
        }

    def get_quick_settings(self) -> List[Dict[str, Any]]:
        """Return the quick-settings definition for the NetBox config editor.

        Returns:
            List of group dicts, each with "name", "toggles", and optional "text_fields" keys.
        """
        return [
            {
                "name": "General",
                "toggles": [
                    ("sync.dry_run", "Dry Run", "Preview changes without modifying NetBox"),
                    ("sync.continue_on_error", "Continue on Error", "Continue sync even if some devices fail"),
                ],
                "text_fields": [
                    (
                        "logicvein.networks",
                        "LogicVein Network(s)",
                        "Network name(s) in LogicVein. Use 'all' to sync every network, or enter multiple names separated by commas.",
                    ),
                    ("netbox.site_name", "Site Name", "NetBox site for devices"),
                    ("netbox.tenant_name", "Tenant Name", "NetBox tenant for devices"),
                ],
            },
            {
                "name": "Device Sync",
                "toggles": [
                    (
                        "netbox.sync_to_dcim",
                        "Sync to DCIM",
                        "Create/update the NetBox Device object and its role, type, platform, "
                        "comments, lifecycle, and custom fields. Independent of 'Create IP "
                        "Addresses' below - turn this off for sites that manage Devices "
                        "themselves (e.g. via NetBox's own discovery) and only want LogicVein to "
                        "keep IPAM/interfaces in sync against the existing device; a device with "
                        "no existing NetBox match is skipped entirely rather than created.",
                    ),
                    (
                        "netbox.create_missing_resources",
                        "Create Missing Resources",
                        "Auto-create sites, roles, device types",
                    ),
                    (
                        "netbox.strip_domain_from_names",
                        "Strip Domain From Names",
                        "Truncate an FQDN-looking LogicVein hostname to its short name before writing "
                        "it as the NetBox device name (e.g. 'asa5505.home.arpa' -> 'asa5505'). Toggling "
                        "this renames the existing device rather than creating a duplicate.",
                    ),
                    (
                        "netbox.sync_platform",
                        "Sync Platform",
                        "Map LVI osType to NetBox platform",
                        "netbox.sync_to_dcim",
                    ),
                    (
                        "netbox.sync_comments",
                        "Sync Comments",
                        "Map LVI memoSummary to comments",
                        "netbox.sync_to_dcim",
                    ),
                    (
                        "netbox.sync_description",
                        "Sync Description",
                        "Map LVI sysDescr to description",
                        "netbox.sync_to_dcim",
                    ),
                    ("netbox.sync_mac_address", "Sync MAC Address", "Set MAC on mgmt interface"),
                    (
                        "netbox.sync_lifecycle",
                        "Sync Lifecycle",
                        "Map end-of-life dates to custom fields",
                        "netbox.sync_to_dcim",
                    ),
                ],
            },
            {
                "name": "Conflict Handling",
                "toggles": [],
                "selects": [
                    (
                        "netbox.ip_conflict_policy",
                        "When an IP already exists",
                        "What to do when a device's IP already has a record in NetBox assigned to "
                        "a different interface/device.",
                        ["overwrite", "ignore", "ask"],
                    ),
                    (
                        "netbox.mac_conflict_policy",
                        "When the MAC differs",
                        "What to do when an interface's existing MAC differs from LogicVein's, or "
                        "the incoming MAC is already used by a different interface (other device "
                        "attributes still sync either way). Only consulted when 'Sync MAC Address' is on.",
                        ["overwrite", "leave_untouched", "ask"],
                        "netbox.sync_mac_address",
                    ),
                ],
            },
            {
                "name": "Location",
                "toggles": [
                    (
                        "netbox.sync_location",
                        "Sync Location",
                        "Map sysLocation to NetBox location",
                        "netbox.sync_to_dcim",
                    ),
                    (
                        "netbox.create_missing_locations",
                        "Create Missing Locations",
                        "Auto-create locations",
                        "netbox.sync_location",
                    ),
                ],
            },
            {
                "name": "Interfaces",
                "toggles": [
                    ("netbox.sync_interfaces", "Sync Interfaces", "Sync all device interfaces"),
                    (
                        "netbox.delete_stale_interfaces",
                        "Delete Stale Interfaces",
                        "Remove interfaces not in LVI",
                        "netbox.sync_interfaces",
                    ),
                ],
            },
            {
                "name": "IP Addresses & Cleanup",
                "toggles": [
                    ("netbox.create_ip_addresses", "Create IP Addresses", "Create IPs in NetBox IPAM"),
                    (
                        "netbox.set_primary_ip",
                        "Set Primary IP",
                        "Set IP as device primary",
                        "netbox.create_ip_addresses",
                    ),
                    ("netbox.delete_stale_devices", "Delete Stale Devices", "Remove devices not in LVI"),
                    ("netbox.delete_stale_ips", "Delete Stale IPs", "Remove IPs not in LVI"),
                ],
            },
        ]

    def resolve_conflict(self, conflict_type: str, desired_payload: Dict[str, Any]) -> bool:
        """Apply an "Overwrite" decision for one pending conflict.

        Uses create_client({}) - the same "no override, resolve from stored
        credentials/settings" call real sync runs make. "ip_exists" writes
        the deferred IP assignment; "mac_duplicate"/"mac_differs" write the
        deferred MAC onto the interface (both primary/mgmt0 and secondary
        interfaces use the same {"interface_id", "mac_address"} shape).
        """
        client = self.create_client({})
        if conflict_type == "ip_exists":
            return bool(client.update_ip_address(desired_payload["ip_id"], desired_payload["ip_data"]))
        interface_id = desired_payload.get("interface_id")
        if not interface_id:
            return False
        return bool(client.update_interface(interface_id, {"mac_address": desired_payload.get("mac_address", "")}))

    def get_output_csv_paths(self, yaml_config: Dict[str, Any]) -> List[str]:
        """Return output CSV file paths for this plugin.

        Args:
            yaml_config: Parsed YAML configuration dictionary.

        Returns:
            Empty list - NetBox sync does not produce CSV output files.
        """
        return []
