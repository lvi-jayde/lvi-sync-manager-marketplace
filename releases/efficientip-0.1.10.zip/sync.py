"""LogicVein to EfficientIP SOLIDserver IPAM sync engine.

Per-device REST upserts (SOLIDserver has no bulk-import mechanism analogous
to Infoblox's discovery CSV, so this follows the NetBox plugin's per-object
style instead).
"""

import ipaddress
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from src.plugin_api import (
    CancellationToken,
    DeviceSyncOutcome,
    SyncCancelled,
    SyncReport,
    normalize_networks,
    record_pending_conflicts,
)

from .client import EfficientIPClient

logger = logging.getLogger(__name__)

PLUGIN_NAME = "efficientip"


class LogicVeinEfficientIPSync:
    """Sync LogicVein device inventory into EfficientIP SOLIDserver IPAM."""

    def __init__(
        self,
        lvi_client: Any,
        efficientip_client: EfficientIPClient,
        config: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialise the sync engine.

        Args:
            lvi_client: LogicVeinAPIClient instance.
            efficientip_client: EfficientIPClient instance.
            config: Configuration dict from EfficientIPPlugin.build_sync_config().
        """
        self.lvi = lvi_client
        self.target = efficientip_client
        self.config = config or {}

        self.dry_run = bool(self.config.get("dry_run", False))
        self.continue_on_error = bool(self.config.get("continue_on_error", True))
        self.networks = normalize_networks(self.config.get("network", "Default"))
        self.space_name = self.config.get("space_name", "Local")
        self.create_missing_subnets = bool(self.config.get("create_missing_subnets", False))
        self.create_missing_blocks = bool(self.config.get("create_missing_blocks", False))
        self.class_parameter_mapping: Dict[str, str] = self.config.get("class_parameter_mapping", {}) or {}
        self.sync_mac_address = bool(self.config.get("sync_mac_address", True))
        self.ip_conflict_policy = self.config.get("ip_conflict_policy", "overwrite")
        self.mac_conflict_policy = self.config.get("mac_conflict_policy", "overwrite")

        self._cancel: Optional[CancellationToken] = None
        self._site_id: Optional[str] = None
        self.last_report: Optional[SyncReport] = None

    def set_cancel_token(self, token: CancellationToken) -> None:
        """Set the cancellation token for this sync operation."""
        self._cancel = token

    def _check_cancel(self) -> None:
        if self._cancel is not None:
            self._cancel.check()  # raises SyncCancelled

    def _resolve_site_id(self) -> Optional[str]:
        """Look up the configured IP space (site) by name, once per sync."""
        if self._site_id is not None:
            return self._site_id
        space = self.target.get_space_by_name(self.space_name)
        if not space:
            logger.error("EfficientIP IP space '%s' not found", self.space_name)
            return None
        self._site_id = space["site_id"]
        return self._site_id

    def _build_class_parameters(self, device: Dict[str, Any]) -> Dict[str, str]:
        """Map configured LVI device fields to SOLIDserver class parameter names."""
        params: Dict[str, str] = {}
        for lvi_field, class_param_name in self.class_parameter_mapping.items():
            value = device.get(lvi_field)
            if value:
                params[class_param_name] = str(value)
        return params

    def _prefetch_mac_lookup(self, networks: List[str]) -> Dict[str, str]:
        """Bulk-fetch device interfaces per network and build a management-IP -> MAC map.

        LVI's device search (Inventory.search) does not return a MAC
        address at all - confirmed against a live instance, it's only
        available per-interface via a separate bulk call
        (Inventory.searchDeviceInterfaces). One call per network (not per
        device); mirrors the Infoblox plugin's _prefetch_interface_lookup().
        """
        by_ip: Dict[str, List[Dict[str, Any]]] = {}
        for network in networks or ["Default"]:
            try:
                for entry in self.lvi.search_device_interfaces(network=network):
                    mgmt_ip = entry.get("ipAddress", "")
                    if mgmt_ip:
                        by_ip.setdefault(mgmt_ip, []).append(entry)
            except Exception as e:
                logger.warning("Could not prefetch interfaces for network '%s': %s", network, e)

        mac_lookup: Dict[str, str] = {}
        for mgmt_ip, entries in by_ip.items():
            # Prefer the interface whose own IP is the device's management
            # IP (a device may have several interfaces/MACs); fall back to
            # the first entry seen when none match.
            matched = next(
                (e for e in entries if any(ip.split("/")[0] == mgmt_ip for ip in e.get("interfaceIps", []) or [])),
                entries[0],
            )
            mac = ((matched.get("interface") or {}).get("macAddress") or "").replace("-", ":").lower()
            if mac:
                mac_lookup[mgmt_ip] = mac
        return mac_lookup

    def _ensure_block_exists(self, ip_address: str, site_id: str) -> bool:
        """Return True once a covering IP block exists for *ip_address*.

        Creates one (a /16) only when create_missing_blocks is enabled -
        independent of create_missing_subnets, which only controls whether
        the /24 subnet itself gets created. A /16 is large enough to hold
        many /24 subnets, so devices sharing a /16 reuse the same block
        instead of each needing their own. Only called when not in
        dry-run mode.
        """
        if self.target.find_block_for_ip(ip_address, site_id=site_id) is not None:
            return True
        if not self.create_missing_blocks:
            return False
        try:
            block_network = ipaddress.ip_interface(f"{ip_address}/16").network
        except ValueError:
            return False
        created = self.target.create_block(str(block_network), site_id=site_id)
        if created:
            logger.info("Created block %s in space '%s'", block_network, self.space_name)
        else:
            logger.warning("Could not create block %s for %s", block_network, ip_address)
        return created

    def _resolve_subnet_id(self, ip_address: str, site_id: str) -> Optional[str]:
        """Return the subnet_id containing *ip_address*, creating the subnet (and its parent
        block, if needed) first if configured to.

        This lookup always runs (not just when create_missing_subnets is
        set) because create_or_update_address needs the subnet_id to link
        the address record - without it, SOLIDserver creates the address
        under the site but leaves it unassociated with any subnet, where it
        shows up under "Orphan Addresses" in the UI.

        create_missing_blocks and create_missing_subnets are independent:
        enabling only create_missing_blocks still ensures/creates the
        covering block (useful to pre-provision address space) but never
        attempts the subnet itself; enabling only create_missing_subnets
        never creates a block, so subnet creation fails when none exists.
        """
        subnet = self.target.find_subnet_for_ip(ip_address, site_id=site_id)
        if subnet is not None:
            return subnet.get("subnet_id")

        if not self.create_missing_blocks and not self.create_missing_subnets:
            return None

        if self.dry_run:
            if self.create_missing_blocks and self.target.find_block_for_ip(ip_address, site_id=site_id) is None:
                block_network = ipaddress.ip_interface(f"{ip_address}/16").network
                logger.info("[DRY RUN] Would create block %s in space '%s'", block_network, self.space_name)
            if self.create_missing_subnets:
                try:
                    network = ipaddress.ip_interface(f"{ip_address}/24").network
                    logger.info("[DRY RUN] Would create subnet %s in space '%s'", network, self.space_name)
                except ValueError:
                    pass
            return None

        # Ensure/create the covering block regardless of whether we are
        # also going to create the subnet - a standalone create_missing_blocks
        # must still take effect.
        block_exists = self._ensure_block_exists(ip_address, site_id)

        if not self.create_missing_subnets:
            return None

        try:
            network = ipaddress.ip_interface(f"{ip_address}/24").network
        except ValueError:
            logger.warning("Could not derive a subnet for invalid IP: %s", ip_address)
            return None

        if not block_exists:
            logger.warning(
                "Could not create subnet %s for %s: no covering IP block (create_missing_blocks is %s)",
                network,
                ip_address,
                "on but creation failed" if self.create_missing_blocks else "off",
            )
            return None

        created = self.target.create_subnet(str(network), site_id=site_id)
        if not created:
            logger.warning("Could not create subnet %s for %s", network, ip_address)
            return None

        logger.info("Created subnet %s in space '%s'", network, self.space_name)
        subnet = self.target.find_subnet_for_ip(ip_address, site_id=site_id)
        return subnet.get("subnet_id") if subnet else None

    @staticmethod
    def _normalize_mac(mac: str) -> str:
        return (mac or "").replace("-", ":").lower()

    def _detect_duplicate_mac(self, ip_address: str, mac: str, site_id: str, mac_to_ips: Dict[str, List[str]]) -> str:
        """Return a human-readable note if *mac* is also used by another device, else "".

        Checks both sources independently: the same LVI sync run (free, from
        the already-prefetched interface data) and existing EfficientIP
        address records (one lookup call, only for devices that have a MAC).
        Purely informational - never gates the write.
        """
        lvi_siblings = [ip for ip in mac_to_ips.get(mac, []) if ip != ip_address]
        if lvi_siblings:
            return f"duplicate MAC in LogicVein, also on {', '.join(lvi_siblings)}"

        try:
            eip_matches = self.target.find_addresses_by_mac(mac, site_id=site_id)
        except Exception as e:
            logger.debug("Could not check for duplicate MAC %s in EfficientIP: %s", mac, e)
            return ""
        eip_siblings = [
            r.get("hostaddr", "") for r in eip_matches if r.get("hostaddr") and r.get("hostaddr") != ip_address
        ]
        if eip_siblings:
            return f"MAC already assigned in EfficientIP to {', '.join(eip_siblings)}"
        return ""

    def sync(self) -> bool:
        """Run one sync. Return True if every device synced without error.

        Builds self.last_report (a SyncReport) with a per-device outcome for
        every processed device - picked up by the core after the run to
        render/store an HTML report. Devices deferred by an "ask" conflict
        policy are recorded as pending in the sync_pending_conflicts table
        (see src.common.sync_reports) rather than written now.
        """
        logger.info("LogicVein to EfficientIP SOLIDserver sync starting (dry_run=%s)", self.dry_run)
        started_at = datetime.now(timezone.utc).isoformat()

        site_id = self._resolve_site_id()
        if site_id is None:
            self.last_report = SyncReport(
                plugin_name=PLUGIN_NAME,
                started_at=started_at,
                finished_at=datetime.now(timezone.utc).isoformat(),
                dry_run=self.dry_run,
                run_errors=[f"IP space '{self.space_name}' not found"],
            )
            return False

        devices: List[dict] = self.lvi.search_devices_in_network(network=self.networks)
        logger.info("Fetched %d device(s) from LogicVein", len(devices))
        mac_lookup = self._prefetch_mac_lookup(self.networks) if self.sync_mac_address else {}
        mac_to_ips: Dict[str, List[str]] = {}
        for ip, mac in mac_lookup.items():
            mac_to_ips.setdefault(mac, []).append(ip)

        outcomes: List[DeviceSyncOutcome] = []
        pending_items: List[Dict[str, Any]] = []
        errors = 0
        stopped_early = False

        for device in devices:
            self._check_cancel()

            ip_address = device.get("ipAddress", "")
            if not ip_address:
                continue

            hostname = device.get("hostname", "")
            new_mac = mac_lookup.get(ip_address, "")
            class_parameters = self._build_class_parameters(device)

            try:
                subnet_id = self._resolve_subnet_id(ip_address, site_id)

                if self.dry_run:
                    logger.info(
                        "[DRY RUN] Would upsert %s (%s) into EfficientIP", ip_address, hostname or "no hostname"
                    )
                    continue

                if subnet_id is None:
                    # No containing subnet (missing, or create_missing_subnets
                    # failed) - skip rather than create an address unlinked
                    # to any subnet ("Orphan Addresses" in the SOLIDserver UI).
                    logger.warning(
                        "Skipping %s: no subnet found in space '%s' (device not synced)",
                        ip_address,
                        self.space_name,
                    )
                    errors += 1
                    outcomes.append(
                        DeviceSyncOutcome(
                            ip_address=ip_address,
                            hostname=hostname,
                            action="error",
                            error=f"no subnet found in space '{self.space_name}'",
                        )
                    )
                    if not self.continue_on_error:
                        logger.error("Stopping due to error (continue_on_error=False)")
                        stopped_early = True
                        break
                    continue

                existing = self.target.find_address(ip_address, site_id=site_id)

                # IP-level conflict: the address already has a record.
                if existing is not None and self.ip_conflict_policy in ("ignore", "ask"):
                    if self.ip_conflict_policy == "ignore":
                        outcomes.append(
                            DeviceSyncOutcome(
                                ip_address=ip_address,
                                hostname=hostname,
                                action="ignored",
                                detail="IP already exists in EfficientIP",
                            )
                        )
                    else:  # ask
                        logger.warning(
                            "Conflict: %s (%s) - IP already exists in EfficientIP, policy=ask, deferred for review",
                            ip_address,
                            hostname or "no hostname",
                        )
                        pending_items.append(
                            {
                                "ip_address": ip_address,
                                "hostname": hostname,
                                "conflict_type": "ip_exists",
                                "detail": "IP already exists in EfficientIP",
                                "desired_payload": {
                                    "ip_address": ip_address,
                                    "site_id": site_id,
                                    "subnet_id": subnet_id,
                                    "hostname": hostname,
                                    "mac_address": new_mac,
                                    "class_parameters": class_parameters,
                                },
                            }
                        )
                        outcomes.append(
                            DeviceSyncOutcome(
                                ip_address=ip_address,
                                hostname=hostname,
                                action="pending",
                                detail="IP already exists in EfficientIP - awaiting decision",
                            )
                        )
                    continue

                # MAC handling - only when the master toggle is on and LVI
                # has a MAC for this device.
                mac_to_write = new_mac
                mac_changed = False
                mac_previous = ""
                duplicate_of = ""
                mac_pending_note = ""
                if self.sync_mac_address and new_mac:
                    mac_previous = self._normalize_mac((existing or {}).get("mac_addr", "")) if existing else ""
                    mac_changed = bool(mac_previous and mac_previous != new_mac)
                    if mac_changed:
                        if self.mac_conflict_policy == "leave_untouched":
                            mac_to_write = ""
                        elif self.mac_conflict_policy == "ask":
                            mac_to_write = ""
                            mac_pending_note = "MAC change pending decision"
                            logger.warning(
                                "Conflict: %s (%s) - MAC differs (EfficientIP has %s, LogicVein has %s),"
                                " policy=ask, MAC deferred for review",
                                ip_address,
                                hostname or "no hostname",
                                mac_previous,
                                new_mac,
                            )
                            pending_items.append(
                                {
                                    "ip_address": ip_address,
                                    "hostname": hostname,
                                    "conflict_type": "mac_differs",
                                    "detail": f"MAC differs: EfficientIP has {mac_previous}, LogicVein has {new_mac}",
                                    "desired_payload": {
                                        "ip_address": ip_address,
                                        "site_id": site_id,
                                        "mac_address": new_mac,
                                    },
                                }
                            )
                        # "overwrite": mac_to_write stays new_mac

                    duplicate_of = self._detect_duplicate_mac(ip_address, new_mac, site_id, mac_to_ips)

                success = self.target.create_or_update_address(
                    ip_address=ip_address,
                    site_id=site_id,
                    subnet_id=subnet_id,
                    hostname=hostname,
                    mac_address=mac_to_write,
                    class_parameters=class_parameters,
                )
                if success:
                    detail_parts = [p for p in (mac_pending_note,) if p]
                    outcomes.append(
                        DeviceSyncOutcome(
                            ip_address=ip_address,
                            hostname=hostname,
                            action="updated" if existing is not None else "added",
                            detail="; ".join(detail_parts),
                            mac=mac_to_write or new_mac,
                            mac_changed=mac_changed,
                            mac_previous=mac_previous,
                            duplicate_mac_of=duplicate_of,
                        )
                    )
                else:
                    errors += 1
                    outcomes.append(
                        DeviceSyncOutcome(
                            ip_address=ip_address, hostname=hostname, action="error", error="write failed"
                        )
                    )
                    if not self.continue_on_error:
                        logger.error("Stopping due to error (continue_on_error=False)")
                        stopped_early = True
                        break
            except SyncCancelled:
                raise
            except Exception as exc:
                errors += 1
                logger.error("EfficientIP sync failed on %s: %s", ip_address, exc)
                outcomes.append(
                    DeviceSyncOutcome(ip_address=ip_address, hostname=hostname, action="error", error=str(exc))
                )
                if not self.continue_on_error:
                    logger.error("Stopping due to error (continue_on_error=False)")
                    stopped_early = True
                    break

        if pending_items and not self.dry_run:
            try:
                record_pending_conflicts(PLUGIN_NAME, pending_items)
            except Exception as e:
                logger.warning("Could not record pending conflicts: %s", e)

        self.last_report = SyncReport(
            plugin_name=PLUGIN_NAME,
            started_at=started_at,
            finished_at=datetime.now(timezone.utc).isoformat(),
            dry_run=self.dry_run,
            outcomes=outcomes,
            run_errors=["Stopped early (continue_on_error=False)"] if stopped_early else [],
            pending_conflicts=len(pending_items),
        )

        logger.info("EfficientIP sync complete: %d device(s), %d error(s)", len(devices), errors)
        return errors == 0
