"""LogicVein to EfficientIP SOLIDserver IPAM sync engine.

Per-device REST upserts (SOLIDserver has no bulk-import mechanism analogous
to Infoblox's discovery CSV, so this follows the NetBox plugin's per-object
style instead).
"""

import ipaddress
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from src.plugin_api import (
    CancellationToken,
    DeviceSyncOutcome,
    SyncCancelled,
    SyncReport,
    format_epoch_ms,
    normalize_networks,
    record_pending_conflicts,
)

from .client import EfficientIPClient

logger = logging.getLogger(__name__)

PLUGIN_NAME = "efficientip"


class LogicVeinEfficientIPSync:
    """Sync LogicVein device inventory into EfficientIP SOLIDserver IPAM."""

    def __init__(
        self,
        lvi_client: Any,
        efficientip_client: EfficientIPClient,
        config: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialise the sync engine.

        Args:
            lvi_client: LogicVeinAPIClient instance.
            efficientip_client: EfficientIPClient instance.
            config: Configuration dict from EfficientIPPlugin.build_sync_config().
        """
        self.lvi = lvi_client
        self.target = efficientip_client
        self.config = config or {}

        self.dry_run = bool(self.config.get("dry_run", False))
        self.continue_on_error = bool(self.config.get("continue_on_error", True))
        self.networks = normalize_networks(self.config.get("network", "Default"))
        self.space_name = self.config.get("space_name", "Local")
        self.create_missing_subnets = bool(self.config.get("create_missing_subnets", False))
        self.create_missing_blocks = bool(self.config.get("create_missing_blocks", False))
        self.class_parameter_mapping: Dict[str, str] = self.config.get("class_parameter_mapping", {}) or {}
        self.lifecycle_class_parameter_mapping: Dict[str, str] = (
            self.config.get("lifecycle_class_parameter_mapping", {}) or {}
        )
        self.sync_mac_address = bool(self.config.get("sync_mac_address", True))
        self.ip_conflict_policy = self.config.get("ip_conflict_policy", "overwrite")
        self.mac_conflict_policy = self.config.get("mac_conflict_policy", "overwrite")

        # Two independent sync targets - IPAM (the original, and only, target
        # until this toggle was added) and NOM (Network Object Manager: a
        # device object plus all its interfaces/ports, organized under one
        # flat folder). Either can be turned off; a device with an unresolved
        # IPAM conflict this run is not also synced to NOM this run (see
        # sync()'s per-device early `continue`s).
        self.sync_to_ipam = bool(self.config.get("sync_to_ipam", True))
        self.sync_to_nom = bool(self.config.get("sync_to_nom", False))
        self.nom_folder_name = self.config.get("nom_folder_name", "LogicVein Devices")

        # Devices always sync to NOM when sync_to_nom is on; interfaces are
        # a separate opt-out (default on, for backward compatibility with
        # the original NOM sync behavior). Turning this off never deletes
        # interfaces already synced from an earlier run - it just stops
        # touching them going forward.
        self.sync_nom_interfaces = bool(self.config.get("sync_nom_interfaces", True))

        # VLAN numbers on synced NOM interfaces - only meaningful (and only
        # read/checked) when sync_to_nom is also on. The VLAN Domain is a
        # real VLAN Manager object (auto-created if missing, like the NOM
        # folder), not just a free-text label - see client.py's NOM
        # docstring section for why that distinction matters.
        self.sync_nom_vlans = bool(self.config.get("sync_nom_vlans", False))
        self.nom_vlan_domain_name = self.config.get("nom_vlan_domain_name", "Default")

        # "Find connected objects" - populates NOM's Connected Object/Port
        # fields from LVI's LLDP/CDP neighbor data. Only meaningful with
        # interfaces on too (there'd be no NOM ports to link otherwise) -
        # the sync() call site ANDs both toggles together, same pattern as
        # sync_nom_vlans.
        self.sync_nom_connections = bool(self.config.get("sync_nom_connections", False))

        self._cancel: Optional[CancellationToken] = None
        self._site_id: Optional[str] = None
        self._nom_folder_id: Optional[str] = None
        self._vlan_domain_ready: Optional[bool] = None
        self.last_report: Optional[SyncReport] = None

    def set_cancel_token(self, token: CancellationToken) -> None:
        """Set the cancellation token for this sync operation."""
        self._cancel = token

    def _check_cancel(self) -> None:
        if self._cancel is not None:
            self._cancel.check()  # raises SyncCancelled

    def _resolve_site_id(self) -> Optional[str]:
        """Look up the configured IP space (site) by name, once per sync."""
        if self._site_id is not None:
            return self._site_id
        space = self.target.get_space_by_name(self.space_name)
        if not space:
            logger.error("EfficientIP IP space '%s' not found", self.space_name)
            return None
        self._site_id = space["site_id"]
        return self._site_id

    def _resolve_nom_folder_id(self) -> Optional[str]:
        """Look up (or create) the configured NOM folder, once per sync.

        Unlike the IPAM space (which must already exist - it's a
        fundamental, user-managed construct), the NOM folder is just an
        organizational container for this sync's own devices, so it's
        created automatically if missing.
        """
        if self._nom_folder_id is not None:
            return self._nom_folder_id
        folder = self.target.get_nom_folder_by_name(self.nom_folder_name)
        if folder:
            self._nom_folder_id = folder["nomfolder_id"]
            return self._nom_folder_id
        folder_id = self.target.create_nom_folder(self.nom_folder_name, site_name=self.space_name)
        if folder_id:
            logger.info("Created NOM folder '%s'", self.nom_folder_name)
        self._nom_folder_id = folder_id
        return folder_id

    def _ensure_vlan_domain(self) -> bool:
        """Look up (or create) the configured VLAN Domain, once per sync.

        Only called when sync_nom_vlans is on. Like the NOM folder (and
        unlike the IPAM space), this is created automatically if missing -
        `vlm_domain_add` with just a name defaults to a full 1-4094 VLAN ID
        range, confirmed against a live instance.
        """
        if self._vlan_domain_ready is not None:
            return self._vlan_domain_ready
        if self.target.get_vlan_domain_by_name(self.nom_vlan_domain_name):
            self._vlan_domain_ready = True
            return True
        created = self.target.create_vlan_domain(self.nom_vlan_domain_name)
        if created:
            logger.info("Created VLAN domain '%s'", self.nom_vlan_domain_name)
        self._vlan_domain_ready = bool(created)
        return self._vlan_domain_ready

    def _build_vlan_lookup(self, ip_address: str, network: str) -> Dict[str, str]:
        """Map port name -> VLAN number for one device.

        Unlike the bulk per-network interface fetch, LVI's VLAN/port
        mapping call (Inventory.getDeviceVlanPortMappings) is one call per
        device - only made when sync_nom_vlans is on, to avoid this extra
        round-trip otherwise. Entries with no port (VLAN definitions not
        assigned to any interface) are skipped.
        """
        lookup: Dict[str, str] = {}
        try:
            for mapping in self.lvi.get_device_vlan_port_mappings(ip_address, network=network):
                port = mapping.get("port")
                number = mapping.get("number")
                if port and number:
                    lookup[port] = str(number)
        except Exception as e:
            logger.warning("Could not fetch VLAN port mappings for %s: %s", ip_address, e)
        return lookup

    @staticmethod
    def _choose_main_interface(ip_address: str, entries: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """Return the interface entry NOM's "Main" attribute should be set on -
        the one whose own IP exactly matches the device's management IP.

        If more than one interface has that exact IP, the lower-numbered
        (SNMP ifIndex) interface wins.
        """
        candidates = [
            entry for entry in entries if ip_address in [ip.split("/")[0] for ip in (entry.get("interfaceIps") or [])]
        ]
        if not candidates:
            return None
        return min(candidates, key=lambda e: (e.get("interface") or {}).get("index") or 0)

    @staticmethod
    def _merge_outcome(base: DeviceSyncOutcome, other: DeviceSyncOutcome) -> DeviceSyncOutcome:
        """Combine two sync targets' outcomes for the SAME device into one report row.

        Without this, IPAM and NOM each produce their own DeviceSyncOutcome
        when both are enabled - the report showed two rows per device (one
        with IPAM's MAC/hostname fields and an empty notes cell, one with
        NOM's notes and nothing else), which reads as two separate devices
        rather than one device synced to two places. *base* (IPAM's
        outcome, since it carries the fields - MAC, mac_changed, etc - a
        report reader actually cares about) keeps its own action/MAC
        fields; *other*'s note (its detail, or its error if it has no
        detail - the "NOM: failed to write device" case sets error, not
        detail) is appended into the notes cell. Every note
        _sync_device_to_nom() produces already starts with "NOM: ", so no
        extra labeling is added here - if a third sync target is ever
        added, its own outcome should self-label the same way rather than
        this method guessing whose note it is.
        """
        other_note = other.detail or other.error
        if other_note:
            base.detail = f"{base.detail}; {other_note}" if base.detail else other_note
        return base

    def _build_class_parameters(self, device: Dict[str, Any]) -> Dict[str, str]:
        """Map configured LVI device fields to SOLIDserver class parameter names."""
        params: Dict[str, str] = {}
        for lvi_field, class_param_name in self.class_parameter_mapping.items():
            value = device.get(lvi_field)
            if value:
                params[class_param_name] = str(value)
        return params

    # LVI lifecycle/discovery fields come back as raw epoch-milliseconds -
    # calendar-date fields render as YYYY-MM-DD, instant fields as a full
    # ISO-8601 timestamp (matches NetBox/Infoblox's conventions for the same
    # LVI fields).
    _LIFECYCLE_DATE_FIELDS = {
        "end_of_sale": "endOfSale",
        "end_of_life": "endOfLife",
        "sw_end_of_sale": "softwareEndOfSale",
        "sw_end_of_life": "softwareEndOfLife",
    }
    _LIFECYCLE_INSTANT_FIELDS = {
        "last_discovery": "lastDiscovery",
        "last_backup": "lastBackup",
        "last_change": "lastChange",
    }

    def _build_lifecycle_class_parameters(self, device: Dict[str, Any]) -> Dict[str, str]:
        """Map configured LVI lifecycle/discovery fields to SOLIDserver class parameter names.

        Keys of lifecycle_class_parameter_mapping: end_of_sale, end_of_life,
        sw_end_of_sale, sw_end_of_life (calendar dates), last_discovery,
        last_backup, last_change (instants) - unmapped keys are skipped.
        """
        params: Dict[str, str] = {}
        for mapping_key, lvi_field in self._LIFECYCLE_DATE_FIELDS.items():
            class_param_name = self.lifecycle_class_parameter_mapping.get(mapping_key)
            if not class_param_name:
                continue
            value = format_epoch_ms(device.get(lvi_field), date_only=True)
            if value:
                params[class_param_name] = value
        for mapping_key, lvi_field in self._LIFECYCLE_INSTANT_FIELDS.items():
            class_param_name = self.lifecycle_class_parameter_mapping.get(mapping_key)
            if not class_param_name:
                continue
            value = format_epoch_ms(device.get(lvi_field))
            if value:
                params[class_param_name] = value
        return params

    def _prefetch_mac_lookup(self, networks: List[str]) -> Dict[str, str]:
        """Bulk-fetch device interfaces per network and build a management-IP -> MAC map.

        LVI's device search (Inventory.search) does not return a MAC
        address at all - confirmed against a live instance, it's only
        available per-interface via a separate bulk call
        (Inventory.searchDeviceInterfaces). One call per network (not per
        device); mirrors the Infoblox plugin's _prefetch_interface_lookup().
        """
        by_ip: Dict[str, List[Dict[str, Any]]] = {}
        for network in networks or ["Default"]:
            try:
                for entry in self.lvi.search_device_interfaces(network=network):
                    mgmt_ip = entry.get("ipAddress", "")
                    if mgmt_ip:
                        by_ip.setdefault(mgmt_ip, []).append(entry)
            except Exception as e:
                logger.warning("Could not prefetch interfaces for network '%s': %s", network, e)

        mac_lookup: Dict[str, str] = {}
        for mgmt_ip, entries in by_ip.items():
            # Prefer the interface whose own IP is the device's management
            # IP (a device may have several interfaces/MACs); fall back to
            # the first entry seen when none match.
            matched = next(
                (e for e in entries if any(ip.split("/")[0] == mgmt_ip for ip in e.get("interfaceIps", []) or [])),
                entries[0],
            )
            mac = ((matched.get("interface") or {}).get("macAddress") or "").replace("-", ":").lower()
            if mac:
                mac_lookup[mgmt_ip] = mac
        return mac_lookup

    def _prefetch_all_interfaces(self, networks: List[str]) -> Dict[str, List[Dict[str, Any]]]:
        """Bulk-fetch EVERY interface per device (not just the one matching the
        management IP, unlike _prefetch_mac_lookup) for NOM interface/port sync.

        A separate call from _prefetch_mac_lookup (one extra round-trip per
        network when both sync_mac_address and sync_to_nom are on) rather
        than sharing its fetch - keeps the two independent and simple; the
        LVI call itself is cheap (paginates internally, one call per
        network, not per device).
        """
        by_ip: Dict[str, List[Dict[str, Any]]] = {}
        for network in networks or ["Default"]:
            try:
                for entry in self.lvi.search_device_interfaces(network=network):
                    mgmt_ip = entry.get("ipAddress", "")
                    if mgmt_ip:
                        by_ip.setdefault(mgmt_ip, []).append(entry)
            except Exception as e:
                logger.warning("Could not prefetch interfaces for network '%s': %s", network, e)
        return by_ip

    def _sync_device_to_nom(
        self,
        ip_address: str,
        hostname: str,
        device: Dict[str, Any],
        class_parameters: Dict[str, str],
        folder_id: str,
        interfaces: List[Dict[str, Any]],
        sync_vlans: bool,
        netobj_id_by_ip: Optional[Dict[str, str]] = None,
    ) -> DeviceSyncOutcome:
        """Create or update one device (and all its interfaces/ports) in NOM.

        Runs independently of IPAM - identifies the device by name (LVI's
        hostname, falling back to its IP when LVI has none) inside one flat
        configured folder. Every interface LVI has for this device syncs
        (from _prefetch_all_interfaces - the full per-network interface
        fetch, not just the single management-IP match IPAM/MAC lookup
        uses). An interface with no name or no MAC is skipped -
        nom_iface_add's port MAC field is mandatory on this appliance,
        confirmed empirically.

        NOM enforces MAC uniqueness per port *within a device*, confirmed
        against a live instance (errno 82026, "The port MAC address is
        already used for another port in the same network object") - but
        LVI devices commonly have several logical interfaces sharing one
        physical MAC (port-channel/LAG members, VLAN sub-interfaces,
        virtual OS-level adapters bound to one NIC; seen on real hardware
        during development, not a hypothetical). Only the first interface
        seen per MAC is synced (preferring one that actually has an IP);
        the rest are counted as skipped, not errors - this is an expected
        consequence of the physical MAC, not a write failure.

        Existing interfaces are looked up by MAC (find_interface()), not
        port name - a port's LVI-reported name is not stable identity
        (seen in production: the same physical port/MAC got a different
        display name across syncs), while MAC is the real uniqueness
        constraint above. Looking up by the old name missed the existing
        row and tried to create a new one with an already-claimed MAC,
        failing every time (the same errno 82026 as the duplicate-MAC
        case, but for a genuinely single physical port). A name change is
        applied as a rename on the existing row, not a new interface.

        The interface whose own IP exactly matches the device's management
        IP gets NOM's "Main" attribute (nomiface_main) - every other
        interface explicitly gets it cleared, not just left alone, so the
        Main interface moves correctly if the match changes across runs.
        See _choose_main_interface().

        *sync_vlans* (only True when sync_nom_vlans is on and the VLAN
        Domain was successfully resolved this run) fetches this device's
        port->VLAN-number mapping (one extra LVI call per device - see
        _build_vlan_lookup()) and applies it to each synced interface.
        VLAN itself has no clearing path (SOLIDserver rejects
        nomiface_vlan_number "0"/empty outright) - a port whose mapping
        disappears just keeps its last-known VLAN.

        An interface whose IP is removed in LogicVein (iface_hostaddr
        becomes "") is deleted and recreated rather than updated in place
        - PUT can change hostaddr between two non-empty values but can't
        clear a previously-set one back to empty (confirmed live: it
        reports success but silently keeps the stale IP). Recreating also
        resets that interface's VLAN to 0, since there's no other way to
        clear it either.

        NOM has no single-call upsert like IPAM's ip_add - creating an
        already-existing object errors even with an explicit ID, and
        updating requires PUT on the same "_add" service instead of POST
        (both confirmed empirically; see EfficientIPClient's NOM methods).
        So the existing/not-existing decision is made explicitly here, not
        delegated to the client.

        *interfaces* is already an empty list by the time it reaches here
        when sync_nom_interfaces is off (sync()'s call site passes {}
        instead of the real prefetch) - so the device itself still syncs,
        but no interface is looked up, created, updated, or deleted.
        Interfaces synced from an earlier run when the toggle was on are
        never touched, let alone removed, while it's off.

        *netobj_id_by_ip*, when given, gets this device's ip_address ->
        netobj_id recorded on a successful device write - sync()'s
        "Find connected objects" pass (_sync_nom_connections()) uses this
        to resolve a neighbor's IP to its own already-synced NOM device,
        without a second round of find_network_object() lookups.
        """
        nom_name = hostname or ip_address
        existing = self.target.find_network_object(folder_id, nom_name)
        device_type = device.get("deviceType", "")

        if existing is not None:
            netobj_id = existing["nomnetobj_id"]
            device_ok = self.target.update_network_object(
                netobj_id, type_=device_type, class_parameters=class_parameters
            )
        else:
            netobj_id = self.target.create_network_object(
                folder_id, nom_name, type_=device_type, class_parameters=class_parameters
            )
            device_ok = netobj_id is not None

        if device_ok and netobj_id and netobj_id_by_ip is not None:
            netobj_id_by_ip[ip_address] = netobj_id

        if not device_ok or not netobj_id:
            logger.warning("NOM: failed to sync device %s (%s)", ip_address, nom_name)
            return DeviceSyncOutcome(
                ip_address=ip_address, hostname=hostname, action="error", error="NOM: failed to write device"
            )

        synced = 0
        skipped = 0
        duplicate_macs = 0
        iface_errors = 0
        by_mac: Dict[str, Dict[str, Any]] = {}
        for entry in interfaces:
            iface_info = entry.get("interface") or {}
            port_name = (iface_info.get("name") or iface_info.get("ifName") or "").strip()
            port_mac = (iface_info.get("macAddress") or "").replace("-", ":").lower()
            if not port_name or not port_mac:
                skipped += 1
                continue
            if port_mac in by_mac:
                duplicate_macs += 1
                # Prefer an entry that actually has an IP over one that doesn't.
                if (entry.get("interfaceIps") or []) and not (by_mac[port_mac].get("interfaceIps") or []):
                    by_mac[port_mac] = entry
                continue
            by_mac[port_mac] = entry

        main_entry = self._choose_main_interface(ip_address, list(by_mac.values()))
        vlan_lookup = self._build_vlan_lookup(ip_address, device.get("network", "Default")) if sync_vlans else {}

        for port_mac, entry in by_mac.items():
            iface_info = entry.get("interface") or {}
            port_name = (iface_info.get("name") or iface_info.get("ifName") or "").strip()
            iface_ips = entry.get("interfaceIps") or []
            iface_hostaddr = iface_ips[0].split("/")[0] if iface_ips else ""
            # VLAN can't be explicitly cleared via update at all - confirmed
            # against a live instance: nom_iface_add rejects
            # nomiface_vlan_number "0"/empty as errno 4 "Missing parameter",
            # even with nomiface_vlan_domain also set (likely a PHP
            # empty()-style truthiness check server-side treating "0" as
            # absent). A port with no current mapping just omits both
            # fields, leaving any previous VLAN value untouched.
            vlan_number = vlan_lookup.get(port_name, "") if sync_vlans else ""
            vlan_domain = self.nom_vlan_domain_name if vlan_number else ""
            is_main = entry is main_entry

            # Keyed on MAC, not port name - see find_interface()'s docstring.
            # A port's LVI-reported name isn't stable identity; its MAC is
            # the real per-device uniqueness constraint SOLIDserver
            # enforces (errno 82026 if two ports collide on one).
            existing_iface = self.target.find_interface(netobj_id, port_mac)
            if existing_iface is not None:
                # PUT can change hostaddr between two non-empty values, but
                # can't clear a previously-set one back to empty - confirmed
                # live: it returns success but silently leaves the old IP
                # in place. Delete + recreate is the only way that actually
                # blanks it (and resets VLAN to 0 too, which has no
                # clearing path of its own via update).
                needs_recreate = bool(existing_iface.get("nomiface_hostaddr")) and not iface_hostaddr
                if needs_recreate:
                    self.target.delete_interface(existing_iface["nomiface_id"])
                    iface_ok = self.target.create_interface(
                        netobj_id,
                        iface_name=port_name,
                        port_name=port_name,
                        port_mac=port_mac,
                        hostaddr=iface_hostaddr,
                        vlan_domain=vlan_domain,
                        vlan_number=vlan_number,
                        is_main=is_main,
                    )
                else:
                    iface_ok = self.target.update_interface(
                        existing_iface["nomiface_id"],
                        iface_name=port_name,
                        port_name=port_name,
                        port_mac=port_mac,
                        hostaddr=iface_hostaddr,
                        vlan_domain=vlan_domain,
                        vlan_number=vlan_number,
                        is_main=is_main,
                    )
            else:
                iface_ok = self.target.create_interface(
                    netobj_id,
                    iface_name=port_name,
                    port_name=port_name,
                    port_mac=port_mac,
                    hostaddr=iface_hostaddr,
                    vlan_domain=vlan_domain,
                    vlan_number=vlan_number,
                    is_main=is_main,
                )
            if iface_ok:
                synced += 1
            else:
                iface_errors += 1

        verb = "Updated" if existing is not None else "Created"
        logger.info("NOM: %s device %s (%s), %d interface(s) synced", verb, ip_address, nom_name, synced)
        detail = f"NOM: {verb.lower()} device"
        if interfaces:
            detail += f", {synced}/{len(interfaces)} interface(s) synced"
        if iface_errors:
            detail += f" ({iface_errors} failed)"
        if skipped:
            detail += f" ({skipped} skipped - no name/MAC)"
        if duplicate_macs:
            detail += f" ({duplicate_macs} skipped - MAC shared with another interface on this device)"

        return DeviceSyncOutcome(
            ip_address=ip_address,
            hostname=hostname,
            action="updated" if existing is not None else "added",
            detail=detail,
        )

    def _sync_nom_connections(
        self,
        netobj_id_by_ip: Dict[str, str],
        network_by_ip: Dict[str, str],
        outcome_by_ip: Dict[str, DeviceSyncOutcome],
    ) -> None:
        """Link each synced device's LLDP/CDP neighbor ports as NOM connections.

        Runs as a second pass, after every device in this run already has
        its NOM device+interfaces synced - *netobj_id_by_ip* only has
        entries for devices _sync_device_to_nom() actually wrote
        successfully this run. A neighbor can only be linked if its own
        device was *also* synced to NOM in this same run: LVI's neighbor
        data (get_device_neighbors()) gives an IP and a port name, not a
        NOM id, and resolving a neighbor outside this run (LVI device
        search by IP, then NOM lookup by hostname) is out of scope for now
        - such neighbors are just skipped, counted, and noted.

        Only LLDP/CDP entries represent a physical port-to-port link -
        confirmed live that routing-protocol neighbors (OSPF, etc.) always
        report remoteInterface as null (an L3 adjacency, not a cable), so
        they're filtered out rather than hardcoding every non-physical
        protocol LVI might ever report.

        The actual link is EfficientIPClient.set_interface_connection() -
        confirmed live this is automatically bidirectional and
        automatically clears a port's previous connection when it's
        reassigned, so this method never needs to clear one explicitly,
        even across repeated runs as physical topology changes.
        """
        ports_by_netobj: Dict[str, Dict[str, str]] = {}

        def _ports_for(netobj_id: str) -> Dict[str, str]:
            if netobj_id not in ports_by_netobj:
                ports_by_netobj[netobj_id] = {
                    iface["nomiface_port_name"]: iface["nomiface_id"]
                    for iface in self.target.get_interfaces_for_netobj(netobj_id)
                    if iface.get("nomiface_port_name")
                }
            return ports_by_netobj[netobj_id]

        for ip_address, netobj_id in netobj_id_by_ip.items():
            network = network_by_ip.get(ip_address, "Default")
            try:
                neighbors = self.lvi.get_device_neighbors(ip_address, network)
            except Exception as exc:
                logger.warning("NOM: failed to fetch neighbors for %s: %s", ip_address, exc)
                continue
            physical = [n for n in neighbors if n.get("protocol") in ("LLDP", "CDP") and n.get("remoteInterface")]
            if not physical:
                continue

            local_ports = _ports_for(netobj_id)
            linked = 0
            skipped = 0
            for neighbor in physical:
                local_port_id = local_ports.get(neighbor.get("localInterface", ""))
                neighbor_netobj_id = netobj_id_by_ip.get(neighbor.get("ipAddress", ""))
                if not local_port_id or not neighbor_netobj_id:
                    skipped += 1
                    continue
                remote_port_id = _ports_for(neighbor_netobj_id).get(neighbor.get("remoteInterface", ""))
                if not remote_port_id:
                    skipped += 1
                    continue
                if self.target.set_interface_connection(local_port_id, remote_port_id):
                    linked += 1
                else:
                    skipped += 1

            if not linked and not skipped:
                continue
            note = f"NOM: {linked} connection(s) linked"
            if skipped:
                note += f" ({skipped} skipped - neighbor not found)"
            outcome = outcome_by_ip.get(ip_address)
            if outcome is not None:
                outcome.detail = f"{outcome.detail}; {note}" if outcome.detail else note

    def _ensure_block_exists(self, ip_address: str, site_id: str) -> bool:
        """Return True once a covering IP block exists for *ip_address*.

        Creates one (a /16) only when create_missing_blocks is enabled -
        independent of create_missing_subnets, which only controls whether
        the /24 subnet itself gets created. A /16 is large enough to hold
        many /24 subnets, so devices sharing a /16 reuse the same block
        instead of each needing their own. Only called when not in
        dry-run mode.
        """
        if self.target.find_block_for_ip(ip_address, site_id=site_id) is not None:
            return True
        if not self.create_missing_blocks:
            return False
        try:
            block_network = ipaddress.ip_interface(f"{ip_address}/16").network
        except ValueError:
            return False
        created = self.target.create_block(str(block_network), site_id=site_id)
        if created:
            logger.info("Created block %s in space '%s'", block_network, self.space_name)
        else:
            logger.warning("Could not create block %s for %s", block_network, ip_address)
        return created

    def _resolve_subnet_id(self, ip_address: str, site_id: str) -> Optional[str]:
        """Return the subnet_id containing *ip_address*, creating the subnet (and its parent
        block, if needed) first if configured to.

        This lookup always runs (not just when create_missing_subnets is
        set) because create_or_update_address needs the subnet_id to link
        the address record - without it, SOLIDserver creates the address
        under the site but leaves it unassociated with any subnet, where it
        shows up under "Orphan Addresses" in the UI.

        create_missing_blocks and create_missing_subnets are independent:
        enabling only create_missing_blocks still ensures/creates the
        covering block (useful to pre-provision address space) but never
        attempts the subnet itself; enabling only create_missing_subnets
        never creates a block, so subnet creation fails when none exists.
        """
        subnet = self.target.find_subnet_for_ip(ip_address, site_id=site_id)
        if subnet is not None:
            return subnet.get("subnet_id")

        if not self.create_missing_blocks and not self.create_missing_subnets:
            return None

        if self.dry_run:
            if self.create_missing_blocks and self.target.find_block_for_ip(ip_address, site_id=site_id) is None:
                block_network = ipaddress.ip_interface(f"{ip_address}/16").network
                logger.info("[DRY RUN] Would create block %s in space '%s'", block_network, self.space_name)
            if self.create_missing_subnets:
                try:
                    network = ipaddress.ip_interface(f"{ip_address}/24").network
                    logger.info("[DRY RUN] Would create subnet %s in space '%s'", network, self.space_name)
                except ValueError:
                    pass
            return None

        # Ensure/create the covering block regardless of whether we are
        # also going to create the subnet - a standalone create_missing_blocks
        # must still take effect.
        block_exists = self._ensure_block_exists(ip_address, site_id)

        if not self.create_missing_subnets:
            return None

        try:
            network = ipaddress.ip_interface(f"{ip_address}/24").network
        except ValueError:
            logger.warning("Could not derive a subnet for invalid IP: %s", ip_address)
            return None

        if not block_exists:
            logger.warning(
                "Could not create subnet %s for %s: no covering IP block (create_missing_blocks is %s)",
                network,
                ip_address,
                "on but creation failed" if self.create_missing_blocks else "off",
            )
            return None

        created = self.target.create_subnet(str(network), site_id=site_id)
        if not created:
            logger.warning("Could not create subnet %s for %s", network, ip_address)
            return None

        logger.info("Created subnet %s in space '%s'", network, self.space_name)
        subnet = self.target.find_subnet_for_ip(ip_address, site_id=site_id)
        return subnet.get("subnet_id") if subnet else None

    @staticmethod
    def _normalize_mac(mac: str) -> str:
        return (mac or "").replace("-", ":").lower()

    def _detect_duplicate_mac(self, ip_address: str, mac: str, site_id: str, mac_to_ips: Dict[str, List[str]]) -> str:
        """Return a human-readable note if *mac* is also used by another device, else "".

        Checks both sources independently: the same LVI sync run (free, from
        the already-prefetched interface data) and existing EfficientIP
        address records (one lookup call, only for devices that have a MAC).

        Callers decide whether this gates the write - mac_conflict_policy
        "ask" defers the whole device (see sync()); "overwrite" and
        "leave_untouched" only use this as a report annotation, matching
        their existing same-IP-MAC-changed behavior.
        """
        lvi_siblings = [ip for ip in mac_to_ips.get(mac, []) if ip != ip_address]
        if lvi_siblings:
            return f"duplicate MAC in LogicVein, also on {', '.join(lvi_siblings)}"

        try:
            eip_matches = self.target.find_addresses_by_mac(mac, site_id=site_id)
        except Exception as e:
            logger.debug("Could not check for duplicate MAC %s in EfficientIP: %s", mac, e)
            return ""
        eip_siblings = [
            r.get("hostaddr", "") for r in eip_matches if r.get("hostaddr") and r.get("hostaddr") != ip_address
        ]
        if eip_siblings:
            return f"MAC already assigned in EfficientIP to {', '.join(eip_siblings)}"
        return ""

    def sync(self) -> bool:
        """Run one sync. Return True if every device synced without error.

        Builds self.last_report (a SyncReport) with a per-device outcome for
        every processed device - picked up by the core after the run to
        render/store an HTML report. Devices deferred by an "ask" conflict
        policy are recorded as pending in the sync_pending_conflicts table
        (see src.common.sync_reports) rather than written now.
        """
        logger.info(
            "LogicVein to EfficientIP SOLIDserver sync starting (dry_run=%s, ipam=%s, nom=%s)",
            self.dry_run,
            self.sync_to_ipam,
            self.sync_to_nom,
        )
        started_at = datetime.now(timezone.utc).isoformat()

        site_id: Optional[str] = None
        if self.sync_to_ipam:
            site_id = self._resolve_site_id()
            if site_id is None:
                self.last_report = SyncReport(
                    plugin_name=PLUGIN_NAME,
                    started_at=started_at,
                    finished_at=datetime.now(timezone.utc).isoformat(),
                    dry_run=self.dry_run,
                    run_errors=[f"IP space '{self.space_name}' not found"],
                )
                return False

        nom_folder_id: Optional[str] = None
        vlan_domain_ready = False
        if self.sync_to_nom:
            nom_folder_id = self._resolve_nom_folder_id()
            if nom_folder_id is None:
                logger.error(
                    "NOM folder '%s' could not be found or created - NOM sync skipped this run", self.nom_folder_name
                )
            if self.sync_nom_vlans:
                vlan_domain_ready = self._ensure_vlan_domain()
                if not vlan_domain_ready:
                    logger.error(
                        "VLAN domain '%s' could not be found or created - VLAN numbers skipped this run",
                        self.nom_vlan_domain_name,
                    )

        devices: List[dict] = self.lvi.search_devices_in_network(network=self.networks)
        logger.info("Fetched %d device(s) from LogicVein", len(devices))
        mac_lookup = self._prefetch_mac_lookup(self.networks) if self.sync_mac_address else {}
        mac_to_ips: Dict[str, List[str]] = {}
        for ip, mac in mac_lookup.items():
            mac_to_ips.setdefault(mac, []).append(ip)
        all_interfaces_by_ip = (
            self._prefetch_all_interfaces(self.networks) if self.sync_to_nom and self.sync_nom_interfaces else {}
        )

        outcomes: List[DeviceSyncOutcome] = []
        pending_items: List[Dict[str, Any]] = []
        errors = 0
        stopped_early = False
        # Built up across the loop below, only used by the "Find connected
        # objects" pass after it - see _sync_nom_connections()'s docstring.
        nom_netobj_id_by_ip: Dict[str, str] = {}
        network_by_ip: Dict[str, str] = {}
        outcome_by_ip: Dict[str, DeviceSyncOutcome] = {}

        for device in devices:
            self._check_cancel()

            ip_address = device.get("ipAddress", "")
            if not ip_address:
                continue

            network_by_ip[ip_address] = device.get("network", "Default")
            hostname = device.get("hostname", "")
            new_mac = mac_lookup.get(ip_address, "")
            class_parameters = self._build_class_parameters(device)
            class_parameters.update(self._build_lifecycle_class_parameters(device))

            ipam_outcome: Optional[DeviceSyncOutcome] = None
            nom_outcome: Optional[DeviceSyncOutcome] = None
            ipam_stop = False

            try:
                if self.dry_run:
                    targets = [t for t, on in (("IPAM", self.sync_to_ipam), ("NOM", self.sync_to_nom)) if on]
                    logger.info(
                        "[DRY RUN] Would sync %s (%s) to %s",
                        ip_address,
                        hostname or "no hostname",
                        "/".join(targets) or "nothing",
                    )
                    continue

                if self.sync_to_ipam:
                    assert site_id is not None  # guaranteed: sync() returns early otherwise
                    subnet_id = self._resolve_subnet_id(ip_address, site_id)

                    if subnet_id is None:
                        # No containing subnet (missing, or create_missing_subnets
                        # failed) - skip rather than create an address unlinked
                        # to any subnet ("Orphan Addresses" in the SOLIDserver UI).
                        logger.warning(
                            "Skipping %s: no subnet found in space '%s' (device not synced)",
                            ip_address,
                            self.space_name,
                        )
                        errors += 1
                        outcomes.append(
                            DeviceSyncOutcome(
                                ip_address=ip_address,
                                hostname=hostname,
                                action="error",
                                error=f"no subnet found in space '{self.space_name}'",
                            )
                        )
                        if not self.continue_on_error:
                            logger.error("Stopping due to error (continue_on_error=False)")
                            stopped_early = True
                            break
                        continue

                    existing = self.target.find_address(ip_address, site_id=site_id)

                    # IP-level conflict: the address already has a record.
                    if existing is not None and self.ip_conflict_policy in ("ignore", "ask"):
                        if self.ip_conflict_policy == "ignore":
                            logger.info(
                                "Ignored address: %s (%s) - IP already exists in EfficientIP",
                                ip_address,
                                hostname or "no hostname",
                            )
                            outcomes.append(
                                DeviceSyncOutcome(
                                    ip_address=ip_address,
                                    hostname=hostname,
                                    action="ignored",
                                    detail="IP already exists in EfficientIP",
                                    mac=new_mac,
                                )
                            )
                        else:  # ask
                            logger.warning(
                                "Conflict: %s (%s) - IP already exists in EfficientIP,"
                                " policy=ask, deferred for review",
                                ip_address,
                                hostname or "no hostname",
                            )
                            pending_items.append(
                                {
                                    "ip_address": ip_address,
                                    "hostname": hostname,
                                    "conflict_type": "ip_exists",
                                    "detail": "IP already exists in EfficientIP",
                                    "desired_payload": {
                                        "ip_address": ip_address,
                                        "site_id": site_id,
                                        "subnet_id": subnet_id,
                                        "hostname": hostname,
                                        "mac_address": new_mac,
                                        "class_parameters": class_parameters,
                                    },
                                }
                            )
                            outcomes.append(
                                DeviceSyncOutcome(
                                    ip_address=ip_address,
                                    hostname=hostname,
                                    action="pending",
                                    detail="IP already exists in EfficientIP - awaiting decision",
                                    mac=new_mac,
                                )
                            )
                        continue

                    # MAC handling - only when the master toggle is on and LVI
                    # has a MAC for this device.
                    mac_to_write = new_mac
                    mac_changed = False
                    mac_previous = ""
                    duplicate_of = ""
                    mac_pending_note = ""
                    if self.sync_mac_address and new_mac:
                        duplicate_of = self._detect_duplicate_mac(ip_address, new_mac, site_id, mac_to_ips)

                        # A MAC shared with a *different* device/IP - distinct
                        # from mac_changed below, which is this same IP's own
                        # previous record disagreeing with LVI. Only "ask" gates
                        # on this; "overwrite"/"leave_untouched" keep writing and
                        # just carry the note through to the report (unchanged
                        # behavior - see _detect_duplicate_mac's docstring).
                        if duplicate_of and self.mac_conflict_policy == "ask":
                            logger.warning(
                                "Conflict: %s (%s) - %s, policy=ask, deferred for review",
                                ip_address,
                                hostname or "no hostname",
                                duplicate_of,
                            )
                            pending_items.append(
                                {
                                    "ip_address": ip_address,
                                    "hostname": hostname,
                                    "conflict_type": "mac_duplicate",
                                    "detail": duplicate_of,
                                    "desired_payload": {
                                        "ip_address": ip_address,
                                        "site_id": site_id,
                                        "subnet_id": subnet_id,
                                        "hostname": hostname,
                                        "mac_address": new_mac,
                                        "class_parameters": class_parameters,
                                    },
                                }
                            )
                            outcomes.append(
                                DeviceSyncOutcome(
                                    ip_address=ip_address,
                                    hostname=hostname,
                                    action="pending",
                                    detail=f"{duplicate_of} - awaiting decision",
                                    mac=new_mac,
                                )
                            )
                            continue

                        mac_previous = self._normalize_mac((existing or {}).get("mac_addr", "")) if existing else ""
                        mac_changed = bool(mac_previous and mac_previous != new_mac)
                        if mac_changed:
                            if self.mac_conflict_policy == "leave_untouched":
                                mac_to_write = ""
                            elif self.mac_conflict_policy == "ask":
                                mac_to_write = ""
                                mac_pending_note = "MAC change pending decision"
                                logger.warning(
                                    "Conflict: %s (%s) - MAC differs (EfficientIP has %s, LogicVein has %s),"
                                    " policy=ask, MAC deferred for review",
                                    ip_address,
                                    hostname or "no hostname",
                                    mac_previous,
                                    new_mac,
                                )
                                pending_items.append(
                                    {
                                        "ip_address": ip_address,
                                        "hostname": hostname,
                                        "conflict_type": "mac_differs",
                                        "detail": (
                                            f"MAC differs: EfficientIP has {mac_previous}," f" LogicVein has {new_mac}"
                                        ),
                                        "desired_payload": {
                                            "ip_address": ip_address,
                                            "site_id": site_id,
                                            "mac_address": new_mac,
                                        },
                                    }
                                )
                            # "overwrite": mac_to_write stays new_mac

                    success = self.target.create_or_update_address(
                        ip_address=ip_address,
                        site_id=site_id,
                        subnet_id=subnet_id,
                        hostname=hostname,
                        mac_address=mac_to_write,
                        class_parameters=class_parameters,
                    )
                    if success:
                        logger.info(
                            "%s address: %s (%s)",
                            "Updated" if existing is not None else "Created",
                            ip_address,
                            hostname or "no hostname",
                        )
                        detail_parts = [p for p in (mac_pending_note,) if p]
                        ipam_outcome = DeviceSyncOutcome(
                            ip_address=ip_address,
                            hostname=hostname,
                            action="updated" if existing is not None else "added",
                            detail="; ".join(detail_parts),
                            mac=mac_to_write or new_mac,
                            mac_changed=mac_changed,
                            mac_previous=mac_previous,
                            duplicate_mac_of=duplicate_of,
                        )
                    else:
                        errors += 1
                        logger.warning("Failed to write address: %s (%s)", ip_address, hostname or "no hostname")
                        ipam_outcome = DeviceSyncOutcome(
                            ip_address=ip_address,
                            hostname=hostname,
                            action="error",
                            error="write failed",
                            mac=mac_to_write or new_mac,
                        )
                        if not self.continue_on_error:
                            ipam_stop = True

                # IPAM failing with continue_on_error off stops before NOM,
                # matching that setting's meaning for this device - but the
                # IPAM outcome itself still gets appended below before the
                # loop breaks, so the report doesn't silently drop the row.
                if not ipam_stop and self.sync_to_nom and nom_folder_id:
                    nom_outcome = self._sync_device_to_nom(
                        ip_address,
                        hostname,
                        device,
                        class_parameters,
                        nom_folder_id,
                        all_interfaces_by_ip.get(ip_address, []),
                        self.sync_nom_interfaces and vlan_domain_ready and self.sync_nom_vlans,
                        nom_netobj_id_by_ip,
                    )
                    if nom_outcome.action == "error":
                        errors += 1

                # One report row per device even when both targets ran -
                # see _merge_outcome()'s docstring for why.
                if ipam_outcome is not None and nom_outcome is not None:
                    outcome_by_ip[ip_address] = self._merge_outcome(ipam_outcome, nom_outcome)
                elif ipam_outcome is not None:
                    outcome_by_ip[ip_address] = ipam_outcome
                elif nom_outcome is not None:
                    outcome_by_ip[ip_address] = nom_outcome
                if ip_address in outcome_by_ip:
                    outcomes.append(outcome_by_ip[ip_address])

                if ipam_stop or (
                    nom_outcome is not None and nom_outcome.action == "error" and not self.continue_on_error
                ):
                    logger.error("Stopping due to error (continue_on_error=False)")
                    stopped_early = True
                    break
            except SyncCancelled:
                raise
            except Exception as exc:
                errors += 1
                logger.error("EfficientIP sync failed on %s: %s", ip_address, exc)
                outcomes.append(
                    DeviceSyncOutcome(
                        ip_address=ip_address, hostname=hostname, action="error", error=str(exc), mac=new_mac
                    )
                )
                if not self.continue_on_error:
                    logger.error("Stopping due to error (continue_on_error=False)")
                    stopped_early = True
                    break

        if self.sync_to_nom and self.sync_nom_interfaces and self.sync_nom_connections and nom_netobj_id_by_ip:
            try:
                self._sync_nom_connections(nom_netobj_id_by_ip, network_by_ip, outcome_by_ip)
            except SyncCancelled:
                raise
            except Exception as exc:
                logger.error("NOM: failed to sync connected objects: %s", exc)

        if pending_items and not self.dry_run:
            try:
                record_pending_conflicts(PLUGIN_NAME, pending_items)
            except Exception as e:
                logger.warning("Could not record pending conflicts: %s", e)

        self.last_report = SyncReport(
            plugin_name=PLUGIN_NAME,
            started_at=started_at,
            finished_at=datetime.now(timezone.utc).isoformat(),
            dry_run=self.dry_run,
            outcomes=outcomes,
            run_errors=["Stopped early (continue_on_error=False)"] if stopped_early else [],
            pending_conflicts=len(pending_items),
        )

        logger.info("EfficientIP sync complete: %d device(s), %d error(s)", len(devices), errors)
        return errors == 0
