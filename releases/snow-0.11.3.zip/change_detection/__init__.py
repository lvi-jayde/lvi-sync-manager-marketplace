"""ServiceNow change-detection consumer.

Core (src/change_detection) detects LogicVein configuration changes and emits
``ConfigChangeEvent``s. This package registers the ServiceNow handler that turns
each event into a ServiceNow incident.
"""
