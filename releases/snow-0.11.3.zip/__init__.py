"""ServiceNow sync plugin."""

from .plugin import ServiceNowPlugin

__all__ = ["ServiceNowPlugin"]
