"""ServiceNow plugin tabs subsystem."""

from nicegui import ui


def autosize_on_visible(grid) -> None:
    """Auto-size a grid's columns to fit content whenever it becomes visible.

    AG Grid can only measure cell text when the grid is actually on screen.
    Sizing on a timer therefore narrows columns while the tab is hidden and
    re-expands them a few seconds after it is shown - the visible "narrow then
    widen" flicker on every tab flip. A ResizeObserver fires exactly when the
    grid gains width (i.e. its tab is flipped to), so columns are sized once,
    immediately, and never while hidden. Degrades gracefully (columns keep their
    defined widths) if the client handles are unavailable.
    """
    gid = grid.id
    ui.run_javascript(f"""
        setTimeout(() => {{
            const h = window.getElement({gid});
            const d = document.getElementById('c{gid}');
            if (!h || !d) return;
            // Poll the element's width and auto-size only when it CHANGES while
            // visible: width 0 means the tab is hidden (skip - never size while
            // hidden, which is what caused the narrow-then-widen flicker); when
            // the tab is flipped to, width jumps 0 -> real and we size once. The
            // change guard means this is idle (a width read) the rest of the time.
            let lastW = -1;
            setInterval(() => {{
                const cw = d.clientWidth;
                if (cw > 0 && cw !== lastW && h.api) {{ lastW = cw; h.api.autoSizeAllColumns(); }}
            }}, 1000);
        }}, 0);
        """)
