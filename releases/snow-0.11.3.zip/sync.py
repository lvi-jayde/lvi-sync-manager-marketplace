"""LogicVein to ServiceNow CMDB inventory sync."""

import logging
from typing import Any, Dict, Optional

from logicvein import LogicVeinAPIClient
from src.plugin_api import CancellationToken, SyncCancelled, normalize_networks

from .client import ServiceNowClient

logger = logging.getLogger(__name__)

# Default LVI device-type → SNOW CMDB table mapping
_DEFAULT_CI_TABLE_MAP: Dict[str, str] = {
    "Router": "cmdb_ci_ip_router",
    "Switch": "cmdb_ci_ip_switch",
    "Firewall": "cmdb_ci_ip_firewall",
    "Load Balancer": "cmdb_ci_netgear",
    "Wireless Controller": "cmdb_ci_wireless_lan_controller",
    "Server": "cmdb_ci_server",
    "Power Supply": "cmdb_ci_power_supply",
}

# Default LVI field → SNOW CI field mapping
_DEFAULT_FIELD_MAPPING: Dict[str, str] = {
    "hostname": "name",
    "ipAddress": "ip_address",
    "hardwareVendor": "manufacturer",
    "model": "model_id",
    "serialNumber": "serial_number",
    "osType": "os",
    "osVersion": "os_version",
    "macAddress": "mac_address",
    "deviceType": "subcategory",
    "sysLocation": "location",
    "sysDescr": "short_description",
    "memoSummary": "comments",
}

# Default LVI interface field → SNOW cmdb_ci_network_adapter field mapping
_DEFAULT_INTERFACE_FIELD_MAPPING: Dict[str, str] = {
    "name": "name",
    "macAddress": "mac_address",
    "description": "short_description",
}


class LogicVeinSnowSync:
    """Sync LogicVein device inventory into ServiceNow CMDB Configuration Items."""

    def __init__(
        self,
        lvi_client: LogicVeinAPIClient,
        snow_client: ServiceNowClient,
        config: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialise the sync engine.

        Args:
            lvi_client: Authenticated LogicVein API client.
            snow_client: Authenticated ServiceNow client.
            config: Sync configuration dict produced by ServiceNowPlugin.build_sync_config().
        """
        self.lvi_client = lvi_client
        self.snow_client = snow_client
        self.config = config or {}

        self.dry_run: bool = self.config.get("dry_run", False)
        self.networks: list = normalize_networks(self.config.get("network", "Default"))
        self.continue_on_error: bool = self.config.get("continue_on_error", True)

        cmdb = self.config.get("cmdb", {})
        self.ci_table_map: Dict[str, str] = cmdb.get("ci_table_map", _DEFAULT_CI_TABLE_MAP)
        self.default_ci_table: str = cmdb.get("default_ci_table", "cmdb_ci_netgear")
        self.create_missing_cis: bool = cmdb.get("create_missing_cis", True)
        self.update_existing_cis: bool = cmdb.get("update_existing_cis", True)
        _fm = cmdb.get("field_mapping")
        self.field_mapping: Dict[str, str] = _fm if _fm is not None else _DEFAULT_FIELD_MAPPING
        self.custom_field_mapping: Dict[str, str] = cmdb.get("custom_field_mapping", {})

        interfaces_cfg = self.config.get("interfaces", {})
        self.sync_interfaces: bool = interfaces_cfg.get("sync_interfaces", False)
        self.delete_stale_interfaces: bool = interfaces_cfg.get("delete_stale_interfaces", False)
        _ifm = interfaces_cfg.get("field_mapping")
        self.interface_field_mapping: Dict[str, str] = _ifm if _ifm is not None else _DEFAULT_INTERFACE_FIELD_MAPPING

        # Caches for reference field lookups (avoids repeated SNOW API calls)
        self._location_cache: Dict[str, str] = {}
        self._company_cache: Dict[str, str] = {}
        self._model_cache: Dict[str, str] = {}

        self._cancel_token: Optional[CancellationToken] = None

    def set_cancel_token(self, token: CancellationToken) -> None:
        """Register a cancellation token so the sync can be aborted.

        Args:
            token: CancellationToken instance.
        """
        self._cancel_token = token

    def _check_cancelled(self) -> None:
        """Raise SyncCancelled if a cancellation has been requested."""
        if self._cancel_token:
            self._cancel_token.check()

    # ------------------------------------------------------------------ #
    # Public entry point                                                   #
    # ------------------------------------------------------------------ #

    def sync(self) -> bool:
        """Execute the inventory sync.

        Returns:
            True if the sync completed without errors, False otherwise.
        """
        logger.info("=" * 70)
        logger.info("LogicVein → ServiceNow CMDB Inventory Sync")
        logger.info("=" * 70)
        if self.dry_run:
            logger.info("DRY RUN - no changes will be written to ServiceNow")

        try:
            self._check_cancelled()
            if not self.snow_client.test_connection():
                logger.error("ServiceNow connection test failed")
                return False
            logger.info("ServiceNow connection verified")
        except SyncCancelled:
            logger.warning("Sync cancelled before connecting")
            return False
        except Exception as e:
            logger.error(f"ServiceNow connection error: {e}")
            return False

        try:
            self._check_cancelled()
            return self._sync_cmdb()
        except SyncCancelled:
            logger.warning("Sync cancelled")
            return False

    # ------------------------------------------------------------------ #
    # CMDB sync                                                            #
    # ------------------------------------------------------------------ #

    def _sync_cmdb(self) -> bool:
        """Sync LVI devices to SNOW CMDB Configuration Items.

        Returns:
            True if all devices were processed without fatal errors.
        """
        logger.info("-" * 70)
        logger.info("CMDB Sync: LVI Devices → SNOW Configuration Items")
        logger.info("-" * 70)

        # Iterate per-network so each device's source network is known.
        # This allows us to write u_lvi_network on the CI during sync.
        # When self.networks is empty we do a single pass with network=[] (all networks).
        network_batches: list = self.networks if self.networks else [""]

        synced = 0
        errors = 0

        for network in network_batches:
            network_arg = [network] if network else []
            net_label = f"LVI network '{network}'" if network else "all LVI networks"
            try:
                devices = self.lvi_client.search_devices_in_network(network=network_arg)
            except Exception as e:
                logger.error(f"Failed to retrieve devices from {net_label}: {e}")
                if not self.continue_on_error:
                    return False
                errors += 1
                continue

            if not devices:
                logger.warning(f"No devices found in {net_label}")
                continue

            logger.info(f"Found {len(devices)} devices in {net_label} (sync_interfaces={self.sync_interfaces})")

            for device in devices:
                try:
                    self._check_cancelled()
                    ci_sys_id = self._sync_device(device, network=network)
                    if self.sync_interfaces and ci_sys_id:
                        self._sync_device_interfaces(device, ci_sys_id)
                    synced += 1
                except SyncCancelled:
                    raise
                except Exception as e:
                    ip = device.get("ipAddress", "unknown")
                    logger.error(f"Error syncing device {ip}: {e}")
                    errors += 1
                    if not self.continue_on_error:
                        return False

        logger.info(f"CMDB sync complete - {synced} processed, {errors} errors")
        return errors == 0 or self.continue_on_error

    def _sync_device(self, device: Dict[str, Any], network: str = "") -> Optional[str]:
        """Create or update a single SNOW CI from an LVI device record.

        Args:
            device: LVI device dict from search_devices_in_network().
            network: LVI network name the device belongs to.

        Returns:
            The sys_id of the created or existing CI, or None if skipped/dry-run.
        """
        device_type = device.get("deviceType", "")
        ci_table = self.ci_table_map.get(device_type, self.default_ci_table)
        hostname = device.get("hostname") or device.get("ipAddress", "unknown")

        ci_data = self._build_ci_data(device, network=network)

        # Use stable correlation_id so we can idempotently find the record again
        device_id = device.get("id") or device.get("ipAddress", "")
        correlation_id = f"LVI:device:{device_id}"
        ci_data["correlation_id"] = correlation_id

        existing = self.snow_client.get_ci_by_correlation_id(correlation_id, table=ci_table)
        if not existing:
            # Fall back to name lookup for devices that pre-existed without a correlation_id
            existing = self.snow_client.get_ci_by_name(hostname, table=ci_table)
        if not existing:
            # Search base cmdb_ci table to catch CIs that live under a different class
            existing = self.snow_client.get_ci_by_correlation_id(correlation_id, table="cmdb_ci")
            if not existing:
                existing = self.snow_client.get_ci_by_name(hostname, table="cmdb_ci")

        if existing:
            if self.update_existing_cis:
                class_raw = existing.get("sys_class_name", ci_table)
                existing_class = class_raw if isinstance(class_raw, str) else class_raw.get("value", ci_table)
                if existing_class != ci_table:
                    # CI is under a different CMDB class - reclassify it
                    reclassify_data = dict(ci_data)
                    reclassify_data["sys_class_name"] = ci_table
                    if self.dry_run:
                        logger.info("[DRY RUN] Would reclassify CI: %s (%s → %s)", hostname, existing_class, ci_table)
                    else:
                        self.snow_client.update_ci(existing_class, existing["sys_id"], reclassify_data)
                        logger.info("Reclassified CI: %s (%s → %s)", hostname, existing_class, ci_table)
                else:
                    if self.dry_run:
                        logger.info("[DRY RUN] Would update CI: %s (%s)", hostname, ci_table)
                    else:
                        self.snow_client.update_ci(ci_table, existing["sys_id"], ci_data)
                        logger.info("Updated CI: %s (%s)", hostname, ci_table)
            else:
                logger.debug("Skipping existing CI (update disabled): %s", hostname)
            return existing["sys_id"]
        elif self.create_missing_cis:
            if self.dry_run:
                logger.info("[DRY RUN] Would create CI: %s (%s)", hostname, ci_table)
                return None
            else:
                result = self.snow_client.create_ci(ci_table, ci_data)
                logger.info("Created CI: %s (%s)", hostname, ci_table)
                return result.get("sys_id")
        else:
            logger.debug("Skipping missing CI (create disabled): %s", hostname)
            return None

    # ------------------------------------------------------------------ #
    # Interface sync                                                       #
    # ------------------------------------------------------------------ #

    def _sync_device_interfaces(self, device: Dict[str, Any], ci_sys_id: str) -> None:
        """Sync all interfaces for one LVI device to SNOW cmdb_ci_network_adapter.

        Args:
            device: LVI device dict.
            ci_sys_id: sys_id of the parent SNOW CI.
        """
        ip_address = device.get("ipAddress", "")
        device_network = device.get("network") or (self.networks[0] if self.networks else "Default")
        try:
            interfaces = self.lvi_client.get_device_interfaces(ip_address, device_network)
        except Exception as e:
            logger.warning(f"Failed to fetch interfaces for {ip_address}: {e}")
            return

        if not interfaces:
            logger.debug("No interfaces returned from LVI for %s", ip_address)
            return

        logger.info("Syncing %d interfaces for %s", len(interfaces), ip_address)
        lvi_names: set = set()
        synced = 0
        for iface in interfaces:
            try:
                self._sync_interface(iface, ci_sys_id, ip_address)
                name = iface.get("name")
                if name:
                    lvi_names.add(name)
                    synced += 1
            except Exception as e:
                iface_name = iface.get("name", "unknown")
                logger.warning(f"Failed to sync interface {iface_name} on {ip_address}: {e}")
        logger.info("Interface sync complete for %s: %d/%d synced", ip_address, synced, len(interfaces))

        if self.delete_stale_interfaces:
            try:
                existing = self.snow_client.get_network_adapters_for_ci(ci_sys_id)
                for adapter in existing:
                    if adapter.get("name") not in lvi_names:
                        if self.dry_run:
                            logger.info(
                                "[DRY RUN] Would delete stale interface: %s %s", ip_address, adapter.get("name")
                            )
                        else:
                            self.snow_client.delete_record("cmdb_ci_network_adapter", adapter["sys_id"])
                            logger.info("Deleted stale interface: %s %s", ip_address, adapter.get("name"))
            except Exception as e:
                logger.warning(f"Failed to delete stale interfaces for {ip_address}: {e}")

    def _sync_interface(self, iface: Dict[str, Any], ci_sys_id: str, device_ip: str) -> None:
        """Create or update a single SNOW network adapter from an LVI interface.

        Args:
            iface: LVI interface dict from get_device_interfaces().
            ci_sys_id: sys_id of the parent SNOW CI.
            device_ip: Device IP (for log messages).
        """
        iface_name = iface.get("name", "")
        if not iface_name:
            return

        iface_data = self._build_interface_data(iface)
        iface_data["cmdb_ci"] = ci_sys_id

        existing = self.snow_client.get_network_adapter(ci_sys_id, iface_name)
        if existing:
            if self.dry_run:
                logger.info("[DRY RUN] Would update interface: %s %s", device_ip, iface_name)
            else:
                self.snow_client.update_record("cmdb_ci_network_adapter", existing["sys_id"], iface_data)
                logger.info("Updated interface: %s %s", device_ip, iface_name)
        else:
            if self.dry_run:
                logger.info("[DRY RUN] Would create interface: %s %s", device_ip, iface_name)
            else:
                self.snow_client.create_record("cmdb_ci_network_adapter", iface_data)
                logger.info("Created interface: %s %s", device_ip, iface_name)

    # ------------------------------------------------------------------ #
    # Field mapping                                                        #
    # ------------------------------------------------------------------ #

    def _build_ci_data(self, device: Dict[str, Any], network: str = "") -> Dict[str, Any]:
        """Map an LVI device record to a SNOW CI field dict.

        Args:
            device: LVI device dict.
            network: LVI network name the device belongs to.  When non-empty,
                written to ``u_lvi_network`` so SNOW Change BRs can pass the
                correct network back to the Sync Manager webhook.

        Returns:
            Dict of SNOW CI field values ready for create/update.
        """
        ci_data: Dict[str, Any] = {}

        for lvi_field, snow_field in self.field_mapping.items():
            value = device.get(lvi_field)
            if not value:
                continue
            if snow_field == "manufacturer":
                resolved = self._resolve_company(str(value))
                if resolved:
                    ci_data[snow_field] = resolved
            elif snow_field == "model_id":
                resolved = self._resolve_model(str(value))
                if resolved:
                    ci_data[snow_field] = resolved
            elif snow_field == "location":
                resolved = self._resolve_location(str(value))
                if resolved:
                    ci_data[snow_field] = resolved
            elif snow_field == "short_description":
                ci_data[snow_field] = str(value)[:160]
            else:
                ci_data[snow_field] = value

        # sysLocation → location fallback if not already resolved via field_mapping.
        # Only apply when sysLocation is present in the user's field mapping - if they
        # removed it we must not silently re-introduce it.
        if "location" not in ci_data and "sysLocation" in self.field_mapping:
            sys_location = device.get("sysLocation", "")
            if sys_location:
                resolved = self._resolve_location(sys_location)
                if resolved:
                    ci_data["location"] = resolved

        # Ensure name is always set - fall back to IP address if hostname is absent
        if "name" not in ci_data:
            ip = device.get("ipAddress")
            if ip:
                ci_data["name"] = ip

        # LVI custom fields (custom1–custom5) mapped to SNOW fields
        for lvi_custom, snow_field in self.custom_field_mapping.items():
            if snow_field:
                value = device.get(lvi_custom)
                if value:
                    ci_data[snow_field] = value

        # Write the LVI network name so SNOW Change BRs can include it in the
        # webhook payload, allowing the Sync Manager to route the job correctly
        # without needing to probe multiple networks at runtime.
        if network:
            ci_data["u_lvi_network"] = network

        return ci_data

    def _build_interface_data(self, iface: Dict[str, Any]) -> Dict[str, Any]:
        """Map an LVI interface record to a SNOW cmdb_ci_network_adapter field dict.

        Args:
            iface: LVI interface dict from get_device_interfaces().

        Returns:
            Dict of SNOW field values (without cmdb_ci, which is added by the caller).
        """
        data: Dict[str, Any] = {}
        for lvi_field, snow_field in self.interface_field_mapping.items():
            value = iface.get(lvi_field)
            if value:
                data[snow_field] = value

        # ipAddresses is an array - take the first address for ip_address
        if "ip_address" not in data:
            ip_list = iface.get("ipAddresses") or []
            if ip_list and isinstance(ip_list, list):
                first_ip = ip_list[0].get("ipAddress") if isinstance(ip_list[0], dict) else str(ip_list[0])
                if first_ip:
                    data["ip_address"] = first_ip

        return data

    # ------------------------------------------------------------------ #
    # Reference resolution (cached)                                        #
    # ------------------------------------------------------------------ #

    def _resolve_location(self, name: str) -> str:
        """Resolve a location name to its SNOW sys_id, creating if absent.

        Args:
            name: Location name string.

        Returns:
            sys_id string, or "" on error.
        """
        if name not in self._location_cache:
            try:
                record = self.snow_client.get_location_by_name(name)
                if not record:
                    record = self.snow_client.create_record("cmn_location", {"name": name})
                    logger.info(f"Created SNOW location: {name}")
                self._location_cache[name] = record.get("sys_id", "") if record else ""
            except Exception as e:
                logger.warning(f"Failed to resolve/create location '{name}': {e}")
                self._location_cache[name] = ""
        return self._location_cache[name]

    def _resolve_company(self, name: str) -> str:
        """Resolve a company/manufacturer name to its SNOW sys_id, creating if absent.

        Args:
            name: Company name string.

        Returns:
            sys_id string, or "" on error.
        """
        if name not in self._company_cache:
            try:
                record = self.snow_client.get_company_by_name(name)
                if not record:
                    record = self.snow_client.create_record("core_company", {"name": name})
                    logger.info(f"Created SNOW company: {name}")
                self._company_cache[name] = record.get("sys_id", "") if record else ""
            except Exception as e:
                logger.warning(f"Failed to resolve/create company '{name}': {e}")
                self._company_cache[name] = ""
        return self._company_cache[name]

    def _resolve_model(self, name: str) -> str:
        """Resolve a model name to its SNOW cmdb_model sys_id, creating if absent.

        Args:
            name: Model name string.

        Returns:
            sys_id string, or "" on error.
        """
        if name not in self._model_cache:
            try:
                record = self.snow_client.get_model_by_name(name)
                if not record:
                    record = self.snow_client.create_record("cmdb_model", {"name": name})
                    logger.info(f"Created SNOW model: {name}")
                self._model_cache[name] = record.get("sys_id", "") if record else ""
            except Exception as e:
                logger.warning(f"Failed to resolve/create model '{name}': {e}")
                self._model_cache[name] = ""
        return self._model_cache[name]
