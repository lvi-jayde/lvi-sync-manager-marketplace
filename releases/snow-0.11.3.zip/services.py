"""Background services contributed by the ServiceNow plugin.

The config-change detection component runs in one of two mutually exclusive modes
(lvi_config_change_poller.mode): a WebSocket event-bus watcher or a REST poller. A
single ``_DetectionServices`` instance owns the active watcher/poller and the
event-handler registrations, so the lifecycle - build, teardown and rebuild on a
live settings change - lives in one place instead of scattered module globals. The
plugin's tabs read live status through the module-level accessors below.
"""

from typing import Any, List, Optional


class _DetectionServices:
    """Owns the plugin's background detection lifecycle.

    ``build()`` is reentrant: the app calls it again when detection settings change
    (e.g. a websocket<->poll switch, or ``features.alerts`` toggled). It tears down
    the prior watcher/poller and the websocket-only handlers, then constructs the
    backend the current settings ask for. Keeping that state on one object means the
    teardown/rebuild ordering is enforced here, not by every caller.
    """

    def __init__(self) -> None:
        self._watcher: Optional[Any] = None
        self._poller: Optional[Any] = None

    @property
    def watcher(self) -> Optional[Any]:
        """The running event-bus watcher, if websocket mode is active."""
        return self._watcher

    @property
    def poller(self) -> Optional[Any]:
        """The running config-change poller, if poll mode is active."""
        return self._poller

    def build(self) -> List[Any]:
        """Instantiate the background services enabled by configuration.

        Also registers the ServiceNow handlers for core-owned event sources: the LVI
        alert handler (for the core /webhook/lvi-alert route) and, when change
        detection is enabled, the config-change incident creator.
        """
        from src.plugin_api import get_app_settings

        from .settings import get_change_detection_settings

        # Clear the prior singletons and drop the websocket-only event handlers so a
        # poll<->websocket switch does not leave a stale watcher reference or stale
        # handlers registered. The alert/change handlers below re-register idempotently.
        self._watcher = None
        self._poller = None
        self._unregister_event_handlers()

        # Register the LVI alert handler when features.alerts is on (capability
        # "alerts"). The core /webhook/lvi-alert route fans events out to it; this is
        # independent of config-change detection below.
        if get_app_settings().get("features", {}).get("alerts", True):
            from src.plugin_api import register_alert_handler

            from .webhook.alert_incident import get_alert_handler

            register_alert_handler(get_alert_handler())

        cfg = get_change_detection_settings()
        if not cfg.get("enabled", False):
            return []

        # Core detects config changes and emits ConfigChangeEvents; our incident
        # creator consumes them in either detection mode.
        from src.plugin_api import register_change_handler

        from .change_detection.incident import get_incident_creator

        register_change_handler(get_incident_creator())

        if cfg.get("mode", "websocket") == "websocket":
            from src.plugin_api import (
                EventBusWatcher,
                event_bus_client,
                get_websocket_detector,
                register_event_handler,
            )

            from .event_bus.handler import get_handler as get_job_completion_handler

            # App-level (admin-only) toggle: subscribe to every LogicVein event topic
            # for the Event Bus tab, not just the config-change topics we act on.
            subscribe_all = bool(get_app_settings().get("event_bus", {}).get("subscribe_all_events", False))
            topics = event_bus_client.ALL_TOPICS if subscribe_all else event_bus_client.CHANGE_TOPICS

            # The core watcher produces raw events; the core detector turns backup
            # events into ConfigChangeEvents, and our handler bridges job completion.
            register_event_handler(get_websocket_detector())
            register_event_handler(get_job_completion_handler())
            self._watcher = EventBusWatcher(topics=topics)
            return [self._watcher]

        from src.plugin_api import ConfigChangePoller

        self._poller = ConfigChangePoller()
        return [self._poller]

    def matches_config(self) -> bool:
        """Whether the running detection backend matches change_detection.mode.

        Returns False when the configured mode's backend is not running - e.g. the
        mode was changed by editing conf/app.yaml directly, so the running services
        (built at startup) no longer match. The Config Change tab surfaces this as a
        "restart to apply" banner.
        """
        from .settings import get_change_detection_settings

        cfg = get_change_detection_settings()
        if not cfg.get("enabled", False):
            return True  # detection disabled - nothing to mismatch
        ws = cfg.get("mode", "websocket") == "websocket"
        running = self._watcher if ws else self._poller
        return running is not None and running.is_running()

    def _unregister_event_handlers(self) -> None:
        """Drop the websocket-only event handlers (idempotent; safe in any mode)."""
        try:
            from src.plugin_api import get_websocket_detector, unregister_event_handler

            from .event_bus.handler import get_handler as get_job_completion_handler

            unregister_event_handler(get_websocket_detector())
            unregister_event_handler(get_job_completion_handler())
        except Exception:
            pass  # best-effort cleanup; never block a rebuild


# Single owner of the plugin's detection lifecycle; the tabs and the change handler
# read live status through the thin module-level accessors below.
_services = _DetectionServices()


def build_services() -> List[Any]:
    """Build (or rebuild) the plugin's background services from current config."""
    return _services.build()


def services_match_config() -> bool:
    """Whether the running detection backend matches change_detection.mode."""
    return _services.matches_config()


def active_watcher() -> Optional[Any]:
    """Return the running event-bus watcher, if websocket mode is active."""
    return _services.watcher


def active_poller() -> Optional[Any]:
    """Return the running config-change poller, if poll mode is active."""
    return _services.poller
