"""LogicVein to EfficientIP SOLIDserver IPAM sync engine.

Per-device REST upserts (SOLIDserver has no bulk-import mechanism analogous
to Infoblox's discovery CSV, so this follows the NetBox plugin's per-object
style instead).
"""

import ipaddress
import logging
from typing import Any, Dict, List, Optional

from src.plugin_api import CancellationToken, SyncCancelled, normalize_networks

from .client import EfficientIPClient

logger = logging.getLogger(__name__)


class LogicVeinEfficientIPSync:
    """Sync LogicVein device inventory into EfficientIP SOLIDserver IPAM."""

    def __init__(
        self,
        lvi_client: Any,
        efficientip_client: EfficientIPClient,
        config: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialise the sync engine.

        Args:
            lvi_client: LogicVeinAPIClient instance.
            efficientip_client: EfficientIPClient instance.
            config: Configuration dict from EfficientIPPlugin.build_sync_config().
        """
        self.lvi = lvi_client
        self.target = efficientip_client
        self.config = config or {}

        self.dry_run = bool(self.config.get("dry_run", False))
        self.continue_on_error = bool(self.config.get("continue_on_error", True))
        self.networks = normalize_networks(self.config.get("network", "Default"))
        self.space_name = self.config.get("space_name", "Local")
        self.create_missing_subnets = bool(self.config.get("create_missing_subnets", False))
        self.class_parameter_mapping: Dict[str, str] = self.config.get("class_parameter_mapping", {}) or {}

        self._cancel: Optional[CancellationToken] = None
        self._site_id: Optional[str] = None

    def set_cancel_token(self, token: CancellationToken) -> None:
        """Set the cancellation token for this sync operation."""
        self._cancel = token

    def _check_cancel(self) -> None:
        if self._cancel is not None:
            self._cancel.check()  # raises SyncCancelled

    def _resolve_site_id(self) -> Optional[str]:
        """Look up the configured IP space (site) by name, once per sync."""
        if self._site_id is not None:
            return self._site_id
        space = self.target.get_space_by_name(self.space_name)
        if not space:
            logger.error("EfficientIP IP space '%s' not found", self.space_name)
            return None
        self._site_id = space["site_id"]
        return self._site_id

    def _build_class_parameters(self, device: Dict[str, Any]) -> Dict[str, str]:
        """Map configured LVI device fields to SOLIDserver class parameter names."""
        params: Dict[str, str] = {}
        for lvi_field, class_param_name in self.class_parameter_mapping.items():
            value = device.get(lvi_field)
            if value:
                params[class_param_name] = str(value)
        return params

    def _ensure_subnet_exists(self, ip_address: str, site_id: str) -> None:
        """Create the containing subnet if missing (best-effort; logs and continues on failure).

        SOLIDserver requires a subnet to fall within an already-provisioned
        IP block; this plugin does not create blocks, so a missing-block
        failure here is expected in some environments and does not fail the
        whole sync (continue_on_error semantics apply to the device itself,
        not this best-effort step).
        """
        if self.target.find_subnet_for_ip(ip_address, site_id=site_id):
            return
        try:
            network = ipaddress.ip_interface(f"{ip_address}/24").network
        except ValueError:
            logger.warning("Could not derive a subnet for invalid IP: %s", ip_address)
            return
        if self.dry_run:
            logger.info("[DRY RUN] Would create subnet %s in space '%s'", network, self.space_name)
            return
        created = self.target.create_subnet(str(network), site_id=site_id)
        if created:
            logger.info("Created subnet %s in space '%s'", network, self.space_name)
        else:
            logger.warning(
                "Could not create subnet %s for %s (space may require a pre-existing IP block)",
                network,
                ip_address,
            )

    def sync(self) -> bool:
        """Run one sync. Return True if every device synced without error."""
        logger.info("LogicVein to EfficientIP SOLIDserver sync starting (dry_run=%s)", self.dry_run)

        site_id = self._resolve_site_id()
        if site_id is None:
            return False

        devices: List[dict] = self.lvi.search_devices_in_network(network=self.networks)
        logger.info("Fetched %d device(s) from LogicVein", len(devices))

        errors = 0
        for device in devices:
            self._check_cancel()

            ip_address = device.get("ipAddress", "")
            if not ip_address:
                continue

            hostname = device.get("hostname", "")
            mac_address = (device.get("macAddress") or "").replace("-", ":").lower()
            class_parameters = self._build_class_parameters(device)

            try:
                if self.create_missing_subnets:
                    self._ensure_subnet_exists(ip_address, site_id)

                if self.dry_run:
                    logger.info(
                        "[DRY RUN] Would upsert %s (%s) into EfficientIP", ip_address, hostname or "no hostname"
                    )
                    continue

                success = self.target.create_or_update_address(
                    ip_address=ip_address,
                    site_id=site_id,
                    hostname=hostname,
                    mac_address=mac_address,
                    class_parameters=class_parameters,
                )
                if not success:
                    errors += 1
                    if not self.continue_on_error:
                        logger.error("Stopping due to error (continue_on_error=False)")
                        return False
            except SyncCancelled:
                raise
            except Exception as exc:
                errors += 1
                logger.error("EfficientIP sync failed on %s: %s", ip_address, exc)
                if not self.continue_on_error:
                    logger.error("Stopping due to error (continue_on_error=False)")
                    return False

        logger.info("EfficientIP sync complete: %d device(s), %d error(s)", len(devices), errors)
        return errors == 0
