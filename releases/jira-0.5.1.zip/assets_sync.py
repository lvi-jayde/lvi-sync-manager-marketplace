"""LogicVein -> Jira Assets inventory sync.

Syncs LVI devices into a pre-existing Jira Assets object type (one object per
device), mirroring the ServiceNow CMDB and NetBox/Infoblox inventory syncs. For
each device it builds the object attributes from a configured field mapping
(attribute name -> LVI device field), finds an existing object by the correlation
attribute via AQL, and updates it or creates a new one.

The target object schema + object type + attributes must already exist (a Jira
admin sets them up; see docs/dev_notes/JIRA_ASSETS_INVESTIGATION.md). The sync
resolves attribute names to ids at runtime and never creates schema structure.
"""

import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from src.plugin_api import (
    DeviceSyncOutcome,
    SyncCancelled,
    SyncReport,
    build_mac_lookup,
    normalize_networks,
    prefetch_device_interfaces,
    resolve_display_name,
    resolve_prefetch_networks,
)

logger = logging.getLogger(__name__)

PLUGIN_NAME = "jira"


class LogicVeinJiraAssetsSync:
    """Sync LogicVein devices into Jira Assets objects."""

    def __init__(self, lvi_client: Any, assets_client: Any, config: Optional[Dict[str, Any]] = None) -> None:
        """Initialise the sync.

        Args:
            lvi_client: LogicVein API client.
            assets_client: A ``JiraAssetsClient``.
            config: Sync config dict from ``build_sync_config`` (sync options +
                an ``assets`` sub-dict).
        """
        self.lvi_client = lvi_client
        self.assets_client = assets_client
        self.config = config or {}

        self.dry_run = self.config.get("dry_run", False)
        self.continue_on_error = self.config.get("continue_on_error", True)
        self.networks = normalize_networks(self.config.get("network", "Default"))

        a = self.config.get("assets", {}) or {}
        self.object_schema = a.get("object_schema", "")
        self.object_type = a.get("object_type", "Device")
        self.correlation_attribute = a.get("correlation_attribute", "Name")
        self.create_missing = a.get("create_missing", True)
        self.update_existing = a.get("update_existing", True)
        # {Assets attribute name -> LVI device field}
        self.field_mapping = a.get("field_mapping", {}) or {}
        # Truncate an FQDN-looking LVI hostname to its short name before it
        # becomes any attribute mapped from "hostname" (e.g. the default
        # Name attribute). Only correlation_attribute (the AQL lookup key)
        # is at duplicate risk from this - and only when it's actually
        # mapped from "hostname" itself (correlation_attribute is
        # user-configurable and commonly mapped from ipAddress instead,
        # e.g. this plugin's own default "LVI Key" mapping, which carries
        # no such risk at all). Computed once here since field_mapping
        # doesn't change mid-run - see _sync_device()'s alt_name handling.
        self.strip_domain_from_names = bool(a.get("strip_domain_from_names", True))
        self._correlation_is_hostname = self.field_mapping.get(self.correlation_attribute) == "hostname"

        self._cancel_token: Optional[Any] = None
        self._type_id: Optional[str] = None
        self._name_to_id: Dict[str, str] = {}

        # Per-device outcomes for this run's SyncReport (see sync())
        self._outcomes: List[DeviceSyncOutcome] = []

        # (network, management IP) -> MAC map, populated once
        # per sync (see that method for why this is needed at all).
        self._mac_lookup: Dict[Tuple[str, str], str] = {}

    def set_cancel_token(self, token: Any) -> None:
        """Set the cancellation token for this run."""
        self._cancel_token = token

    def _check_cancelled(self) -> None:
        if self._cancel_token and self._cancel_token.is_cancelled():
            raise SyncCancelled("Sync cancelled by user")

    def _resolve_display_name(self, raw_name: str) -> Tuple[str, str]:
        """Return (display_name, alt_name) for one LVI-reported hostname,
        per strip_domain_from_names - see plugin_api.resolve_display_name()'s
        docstring for the full FQDN-truncation/alt_name contract.

        alt_name only matters when correlation_attribute is itself mapped
        from "hostname" (_correlation_is_hostname) - that's the only case
        where a name change risks a duplicate object; see _sync_device().
        """
        return resolve_display_name(raw_name, self.strip_domain_from_names)

    def _mac_for(self, device: Dict[str, Any]) -> str:
        """Return the MAC address prefetched for *device*, or "".

        Keyed on (network, management IP): a management IP is only unique
        within one LVI managed network, so the bare IP would collide
        between two different devices whenever a deployment syncs more
        than one network.
        """
        return self._mac_lookup.get((device.get("network", "Default"), device.get("ipAddress", "")), "")

    # ------------------------------------------------------------------ #
    # Run                                                                  #
    # ------------------------------------------------------------------ #

    def sync(self) -> bool:
        """Execute the inventory sync. Returns True on success."""
        logger.info("=" * 70)
        logger.info("LogicVein -> Jira Assets inventory sync")
        logger.info("=" * 70)
        if self.dry_run:
            logger.info("DRY RUN - no objects will be written to Jira Assets")

        started_at = datetime.now(timezone.utc).isoformat()

        def _finish(success: bool, run_errors: Optional[List[str]] = None) -> bool:
            self.last_report = SyncReport(
                plugin_name=PLUGIN_NAME,
                started_at=started_at,
                finished_at=datetime.now(timezone.utc).isoformat(),
                dry_run=self.dry_run,
                outcomes=self._outcomes,
                run_errors=run_errors or [],
            )
            return success

        if not self.object_schema:
            logger.error("No assets.object_schema configured")
            return _finish(False, ["No assets.object_schema configured"])

        try:
            self._check_cancelled()
            if not self.assets_client.test_connection():
                logger.error("Jira Assets connection test failed")
                return _finish(False, ["Jira Assets connection test failed"])

            schema_id = self.assets_client.find_schema_id(self.object_schema)
            if not schema_id:
                logger.error("Object schema '%s' not found in Jira Assets", self.object_schema)
                return _finish(False, [f"Object schema '{self.object_schema}' not found in Jira Assets"])
            self._type_id = self.assets_client.find_object_type_id(schema_id, self.object_type)
            if not self._type_id:
                logger.error("Object type '%s' not found in schema '%s'", self.object_type, self.object_schema)
                return _finish(False, [f"Object type '{self.object_type}' not found in schema '{self.object_schema}'"])
            self._name_to_id = self.assets_client.get_type_attributes(self._type_id)

            if self.correlation_attribute not in self._name_to_id:
                logger.error(
                    "Correlation attribute '%s' is not on object type '%s'",
                    self.correlation_attribute,
                    self.object_type,
                )
                return _finish(
                    False,
                    [
                        f"Correlation attribute '{self.correlation_attribute}' is not on object type '{self.object_type}'"
                    ],
                )
            if self.correlation_attribute not in self.field_mapping:
                logger.error("Correlation attribute '%s' is not in the field mapping", self.correlation_attribute)
                return _finish(
                    False, [f"Correlation attribute '{self.correlation_attribute}' is not in the field mapping"]
                )

            return _finish(self._sync_devices())
        except SyncCancelled:
            logger.warning("Sync cancelled")
            return _finish(False, ["Sync cancelled"])

    def _sync_devices(self) -> bool:
        net_label = ", ".join(self.networks) if self.networks else "all"
        logger.info("Fetching devices from LogicVein network(s): %s", net_label)
        try:
            devices = self.lvi_client.search_devices_in_network(network=self.networks)
        except Exception as exc:
            logger.error("Could not fetch devices from LogicVein: %s", exc)
            return False
        if not devices:
            logger.warning("No devices found in network(s): %s", net_label)
            return True
        logger.info("Found %d devices", len(devices))

        self._mac_lookup = build_mac_lookup(
            prefetch_device_interfaces(self.lvi_client, resolve_prefetch_networks(self.networks, devices))
        )

        synced = 0
        errors = 0
        for device in devices:
            self._check_cancelled()
            outcomes_before = len(self._outcomes)
            try:
                if self._sync_device(device):
                    synced += 1
            except SyncCancelled:
                raise
            except Exception as exc:
                errors += 1
                logger.error("Error syncing device %s: %s", device.get("hostname") or device.get("ipAddress"), exc)
                # _sync_device() already appends its own outcome on every
                # return path - only add one here if the exception happened
                # before it could (e.g. inside build_attributes()).
                if len(self._outcomes) == outcomes_before:
                    self._outcomes.append(
                        DeviceSyncOutcome(
                            ip_address=device.get("ipAddress", ""),
                            hostname=device.get("hostname", ""),
                            action="error",
                            error=str(exc),
                            mac=self._mac_for(device),
                        )
                    )
                if not self.continue_on_error:
                    return False
        logger.info("Assets sync complete: %d synced, %d errors", synced, errors)
        return errors == 0 or self.continue_on_error

    def _sync_device(self, device: Dict[str, Any]) -> bool:
        """Create or update one Assets object from an LVI device."""
        ip_address = device.get("ipAddress", "")
        raw_hostname = device.get("hostname", "")
        if raw_hostname:
            hostname, alt_hostname = self._resolve_display_name(raw_hostname)
        else:
            hostname, alt_hostname = raw_hostname, ""
        # LVI's device search never returns a MAC directly (confirmed against
        # a live instance) - it comes from the separate bulk interface fetch
        # prefetched by plugin_api.prefetch_device_interfaces().
        mac_address = self._mac_for(device)
        values: Dict[str, str] = {}
        for attr_name, lvi_field in self.field_mapping.items():
            if lvi_field == "macAddress":
                # An absent MAC means "LogicVein has nothing to say here",
                # not "clear it" - LVI's device search never carries a MAC,
                # so an empty value is just as likely a device LVI has no
                # interface data for (or a failed interface fetch) as a
                # device with genuinely no MAC. build_attributes() sends
                # every value it is given, including "", so leaving the
                # attribute out is the only way not to blank whatever Jira
                # already holds. Matches the EfficientIP/SNOW/NetBox
                # plugins, which all skip the MAC write when it is empty.
                if not mac_address:
                    continue
                v = mac_address
            elif lvi_field == "hostname":
                v = hostname
            else:
                v = device.get(lvi_field, "")
            values[attr_name] = str(v) if v is not None else ""

        corr_value = (values.get(self.correlation_attribute) or "").strip()
        if not corr_value:
            logger.warning(
                "Skipping device with empty '%s' (ip=%s)", self.correlation_attribute, device.get("ipAddress")
            )
            self._outcomes.append(
                DeviceSyncOutcome(
                    ip_address=ip_address,
                    hostname=hostname,
                    action="ignored",
                    detail=f"empty '{self.correlation_attribute}'",
                    mac=mac_address,
                )
            )
            return False

        attributes = self.assets_client.build_attributes(self._name_to_id, values)
        existing_id = self.assets_client.find_object_id(self.object_type, self.correlation_attribute, corr_value)
        # Only relevant when the correlation attribute is itself mapped
        # from "hostname" - that's the only case where toggling
        # strip_domain_from_names risks missing the existing object (still
        # under its old-style name) and creating a duplicate. attributes
        # (built above from values, which already reflects the current
        # display name) gets sent to update_object() below regardless of
        # which name found it, so this also renames it in place.
        if not existing_id and self._correlation_is_hostname and alt_hostname:
            existing_id = self.assets_client.find_object_id(self.object_type, self.correlation_attribute, alt_hostname)

        if self.dry_run:
            logger.info("[DRY RUN] Would %s Assets object for '%s'", "update" if existing_id else "create", corr_value)
            self._outcomes.append(
                DeviceSyncOutcome(
                    ip_address=ip_address,
                    hostname=hostname,
                    action="updated" if existing_id else "added",
                    detail="[DRY RUN]",
                    mac=mac_address,
                )
            )
            return True

        if existing_id:
            if not self.update_existing:
                logger.debug("Object for '%s' exists and update_existing is off; skipping", corr_value)
                self._outcomes.append(
                    DeviceSyncOutcome(
                        ip_address=ip_address,
                        hostname=hostname,
                        action="ignored",
                        detail="update disabled",
                        mac=mac_address,
                    )
                )
                return True
            self.assets_client.update_object(existing_id, self._type_id, attributes)
            logger.info("Updated Assets object %s for '%s'", existing_id, corr_value)
            self._outcomes.append(
                DeviceSyncOutcome(ip_address=ip_address, hostname=hostname, action="updated", mac=mac_address)
            )
        else:
            if not self.create_missing:
                logger.debug("Object for '%s' missing and create_missing is off; skipping", corr_value)
                self._outcomes.append(
                    DeviceSyncOutcome(
                        ip_address=ip_address,
                        hostname=hostname,
                        action="ignored",
                        detail="create disabled",
                        mac=mac_address,
                    )
                )
                return True
            created = self.assets_client.create_object(self._type_id, attributes)
            logger.info("Created Assets object %s for '%s'", created.get("objectKey", created.get("id")), corr_value)
            self._outcomes.append(
                DeviceSyncOutcome(ip_address=ip_address, hostname=hostname, action="added", mac=mac_address)
            )
        return True
