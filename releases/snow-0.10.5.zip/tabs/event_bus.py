"""Event Bus tab (ServiceNow plugin, WebSocket mode)."""

import logging

from nicegui import ui
from src.plugin_api import event_bus_store as eb_store
from src.plugin_api import t

from .. import services

logger = logging.getLogger(__name__)


def render_event_bus_tab():
    """Render the raw Event Bus messages tab (WebSocket mode only)."""
    if eb_store is None:
        ui.label("Event Bus store unavailable.").classes("text-red-500")
        return

    def _row_data():
        return [
            {
                "time": ev["time"],
                "topic": ev["topic"],
                "type": ev["type"],
                "execution_id": ev["execution_id"],
                "host": ev["host"],
                "network": ev["network"],
                "_raw": ev["raw"],
            }
            for ev in eb_store.get_events()
        ]

    # ── Toolbar ───────────────────────────────────────────────────────────────
    with ui.row().classes("w-full items-center justify-between mb-3 gap-2"):
        with ui.row().classes("items-center gap-3"):
            _status_dot = ui.icon(
                "circle",
                color="green" if services.active_watcher() and services.active_watcher().is_running() else "gray",
            ).classes("text-sm")
            _status_label = ui.label(
                t("event_bus.status_connected")
                if services.active_watcher() and services.active_watcher().is_running()
                else t("event_bus.status_stopped")
            ).classes("text-sm text-gray-500 dark:text-gray-400")
            _count_label = ui.label(t("event_bus.event_count", count=len(_row_data()))).classes(
                "text-sm text-gray-400 dark:text-gray-500 ml-2"
            )
        with ui.row().classes("items-center gap-1"):
            ui.button(
                t("event_bus.export_btn"),
                icon="download",
                on_click=lambda: _grid.run_grid_method("exportDataAsCsv", {"fileName": "event_bus.csv"}),
            ).props("flat dense size=sm color=primary")
            ui.button(
                t("event_bus.clear_btn"),
                icon="delete_sweep",
                on_click=lambda: (eb_store.clear_events(), _do_refresh()),
            ).props("flat dense size=sm color=negative")

    # ── Filter input ──────────────────────────────────────────────────────────
    with ui.row().classes("w-full items-center gap-2 mb-2"):
        ui.icon("search").classes("text-gray-400")
        _filter_input = (
            ui.input(placeholder=t("event_bus.filter_placeholder")).props("dense outlined clearable").classes("flex-1")
        )

    # ── Main grid ─────────────────────────────────────────────────────────────
    _grid = (
        ui.aggrid(
            options={
                "columnDefs": [
                    {
                        "headerName": t("event_bus.col_time"),
                        "field": "time",
                        "width": 175,
                        "cellClass": "font-mono text-xs",
                        "sort": "desc",
                    },
                    {"headerName": t("event_bus.col_topic"), "field": "topic", "width": 110, "filter": True},
                    {"headerName": t("event_bus.col_type"), "field": "type", "width": 130, "filter": True},
                    {
                        "headerName": t("event_bus.col_exec_id"),
                        "field": "execution_id",
                        "width": 110,
                        "cellClass": "font-mono text-xs",
                    },
                    # Hostnames can be long; flex-fill but cap the width.
                    {
                        "headerName": t("event_bus.col_host"),
                        "field": "host",
                        "flex": 1,
                        "minWidth": 120,
                        "maxWidth": 280,
                    },
                    {"headerName": t("event_bus.col_network"), "field": "network", "width": 120, "filter": True},
                ],
                "rowData": _row_data(),
                "defaultColDef": {"sortable": True, "resizable": True, "filter": True},
                # Size each column to its header + cell contents on first load.
                "suppressScrollOnNewData": True,
                "rowSelection": {"mode": "singleRow"},
                "rowHeight": 28,
                "headerHeight": 32,
            },
            theme="alpine",
            auto_size_columns=False,
        )
        .classes("w-full")
        .style("height: 340px; font-size: 11px;")
    )

    _filter_input.on_value_change(lambda e: _grid.run_grid_method("setGridOption", "quickFilterText", e.value or ""))

    # ── Raw JSON detail panel ─────────────────────────────────────────────────
    _placeholder = t("event_bus.raw_envelope_placeholder")
    with ui.column().classes("w-full mt-3 gap-1"):
        ui.label(t("event_bus.raw_envelope_title")).classes(
            "text-base font-semibold text-gray-700 dark:text-gray-200 mb-1"
        )
        _detail = ui.html(
            f'<pre style="margin:0;padding:10px;font-family:monospace;font-size:11px;'
            f'color:#9cdcfe;white-space:pre-wrap;word-break:break-all;overflow:auto;height:200px;">'
            f"{_placeholder}</pre>"
        ).classes("w-full bg-gray-900 rounded")

    _placeholder_escaped = _placeholder.replace("\\", "\\\\").replace("`", "\\`")
    _grid.options[":onRowClicked"] = (
        f"params => {{"
        f"  const raw = params.data._raw;"
        f"  const pre = getElement({_detail.id}).$el.querySelector('pre');"
        f"  pre.textContent = raw != null ? JSON.stringify(raw, null, 2) : `{_placeholder_escaped}`;"
        f"}}"
    )

    def _do_refresh():
        rows = _row_data()
        _grid.run_grid_method("setGridOption", "rowData", rows)
        # Fit columns to content here rather than via autoSizeStrategy, which
        # hides rows until measured and so leaves rows invisible in a tab that
        # was not active when the grid was built.
        _grid.run_grid_method("autoSizeAllColumns")
        _count_label.set_text(t("event_bus.event_count", count=len(rows)))
        if services.active_watcher() is not None:
            running = services.active_watcher().is_running()
            _status_dot.props(f"color={'green' if running else 'gray'}")
            _status_label.set_text(t("event_bus.status_connected") if running else t("event_bus.status_stopped"))

    ui.timer(3.0, _do_refresh)
