"""Webhooks tab (ServiceNow plugin)."""

import logging

from nicegui import ui
from src.plugin_api import get_app_settings, t
from src.plugin_api import webhook_store as wh_store

logger = logging.getLogger(__name__)


def render_webhook_tab():
    """Render the webhook history tab (ServiceNow plugin only)."""
    wh_cfg = get_app_settings().get("webhooks", {})
    wh_store.set_max_events(int(wh_cfg.get("max_events", 500)))

    _RESULT_COLORS = {
        "raised": "#16a34a",
        "created": "#16a34a",
        "re-raised": "#2563eb",
        "updated": "#2563eb",
        "cleared": "#0d9488",
        "resolved": "#0d9488",
        "already_resolved": "#6b7280",
        "not_found": "#d97706",
        "suppressed": "#6b7280",
        "rejected": "#dc2626",
        "snow_error": "#dc2626",
        "error": "#dc2626",
    }

    _ACTION_BG = {
        "raise": "rgba(251,191,36,0.15)",
        "resolve": "rgba(34,197,94,0.15)",
        "create": "rgba(20,184,166,0.15)",
        "update": "rgba(59,130,246,0.15)",
        "suppress": "rgba(107,114,128,0.15)",
    }

    # ── Event-type filter state (mutable set shared across closures) ─────────
    _type_filter: set = {"incident", "change"}

    def _event_type(ev: dict) -> str:
        """Infer event type from stored event_type field or action."""
        stored = ev.get("event_type", "")
        if stored == "config_change":
            return "incident"  # config changes raise SNOW incidents
        if stored:
            return stored
        # Backwards compat: infer from action
        return "change" if ev.get("action") in ("change", "cancel") else "incident"

    def _get_description(ev: dict) -> str:
        stored_type = ev.get("event_type", "")
        action = ev.get("action", "")
        result = ev.get("result", "")
        severity = (ev.get("severity") or "").strip()

        if stored_type == "config_change":
            return t("webhooks.desc.config_change")
        if _event_type(ev) == "change":
            if action == "cancel" or result in ("cancelled", "cancel_error"):
                return t("webhooks.desc.job_cancel")
            if result == "scheduled":
                return t("webhooks.desc.job_schedule")
            return t("webhooks.desc.job_exec")
        # incident
        sev = severity if severity not in ("", "-") else ""
        if action == "resolve":
            return f"{sev} {t('webhooks.desc.alert_resolved')}".strip()
        if action in ("raise", "re-raise", "create"):
            return f"{sev} {t('webhooks.desc.alert_raised')}".strip()
        if action == "update":
            return t("webhooks.desc.alert_updated")
        return f"{sev} {t('webhooks.desc.alert')}".strip()

    def _row_data():
        rows = []
        for ev in wh_store.get_events():
            if _event_type(ev) not in _type_filter:
                continue
            err = ev.get("error", "")
            result_display = ev["result"] + (f" - {err}" if err else "")
            color = _RESULT_COLORS.get(ev["result"], "#374151")
            rows.append(
                {
                    "ts": ev["ts"],
                    "_ts_sort": ev["ts"],
                    "_bg": _ACTION_BG.get("suppress" if ev["result"] == "suppressed" else ev["action"], ""),
                    "description": _get_description(ev),
                    "direction": {
                        "lvi→sync manager": t("webhooks.dir.lvi_sync"),
                        "sync mgr→snow": t("webhooks.dir.sync_snow"),
                        "snow→sync manager": t("webhooks.dir.snow_sync"),
                        "sync mgr→lvi": t("webhooks.dir.sync_lvi"),
                    }.get(ev["direction"], ev["direction"].upper()),
                    "action": ev["action"],
                    "node": ev["node"] or "-",
                    "severity": ev["severity"] or "-",
                    "src": ev.get("src", ""),
                    "dst": ev.get("dst", ""),
                    "hash": ev["hash"],
                    "result": result_display,
                    "resultColor": color,
                    "incident": ev["incident"] or "-",
                }
            )
        return rows

    # ── Helpers defined before the toolbar that references them ───────────────
    def _on_refresh_change(e):
        # Closes over _timer; Python resolves the name at call time.
        try:
            _timer.interval = max(1.0, float(e.value))
        except Exception as exc:
            logger.debug("Ignoring invalid refresh interval %r: %s", e.value, exc)

    def _download_csv():
        # Export via ag-Grid so the CSV reflects the rows left by the active
        # filters (quick filter + column filters) and the currently visible columns.
        if not _row_data():
            ui.notify(t("webhooks.no_events_msg"), type="warning")
            return
        _grid.run_grid_method("exportDataAsCsv", {"fileName": "webhook_history.csv"})

    # ── Top toolbar (refresh + count + action buttons) ────────────────────────
    with ui.row().classes("w-full items-center justify-between mb-3 gap-2"):
        with ui.row().classes("items-center gap-2"):
            ui.label(t("webhooks.refresh_label")).classes("text-sm text-gray-500 dark:text-gray-400")
            ui.number(value=5, min=1, max=300, step=1, format="%.0f", on_change=_on_refresh_change).props(
                "dense outlined"
            ).classes("w-24")
            _count_label = ui.label(t("webhooks.event_count", count=len(_row_data()))).classes(
                "text-sm text-gray-500 dark:text-gray-400 ml-2"
            )
        with ui.row().classes("items-center gap-1"):
            ui.button(t("webhooks.download_btn"), icon="download", on_click=_download_csv).props(
                "flat dense size=sm color=primary"
            )
            # ── Columns visibility toggle ──────────────────────────────────
            _TOGGLEABLE_COLS = [
                (t("webhooks.col_time"), "ts", True),
                (t("webhooks.col_description"), "description", True),
                (t("webhooks.col_dir"), "direction", True),
                (t("webhooks.col_action"), "action", False),
                (t("webhooks.col_node"), "node", True),
                (t("webhooks.col_severity"), "severity", True),
                (t("webhooks.col_from"), "src", False),
                (t("webhooks.col_to"), "dst", False),
                (t("webhooks.col_hash"), "hash", False),
                (t("webhooks.col_result"), "result", True),
                (t("webhooks.col_incident"), "incident", True),
            ]

            def _make_toggle(f):
                def _toggle(e):
                    _grid.run_grid_method(
                        "applyColumnState",
                        {"state": [{"colId": f, "hide": not e.value}]},
                    )

                return _toggle

            with ui.button(t("webhooks.columns_btn"), icon="view_column").props("flat dense size=sm"):
                with ui.menu().props("anchor='bottom right' self='top right'").classes("p-1"):
                    for _label, _field, _vis in _TOGGLEABLE_COLS:
                        ui.checkbox(_label, value=_vis, on_change=_make_toggle(_field)).classes("px-2")
            # ──────────────────────────────────────────────────────────────
            ui.button(
                t("webhooks.clear_btn"),
                icon="delete_sweep",
                on_click=lambda: (
                    wh_store.clear_events(),
                    _do_refresh(),
                ),
            ).props("flat dense size=sm color=negative")

    # ── Global quick-filter input + event-type filter ────────────────────────
    with ui.row().classes("w-full items-center gap-2 mb-2"):
        ui.icon("search").classes("text-gray-400")
        _filter_input = (
            ui.input(placeholder=t("webhooks.filter_placeholder")).props("dense outlined clearable").classes("flex-1")
        )

        def _toggle_type(etype: str, checked: bool) -> None:
            if checked:
                _type_filter.add(etype)
            else:
                _type_filter.discard(etype)
            _do_refresh()

        ui.checkbox(
            t("webhooks.filter_changes"),
            value=True,
            on_change=lambda e: _toggle_type("change", e.value),
        ).props("dense").classes("text-sm")
        ui.checkbox(
            t("webhooks.filter_incidents"),
            value=True,
            on_change=lambda e: _toggle_type("incident", e.value),
        ).props("dense").classes("text-sm")

    # ── ag-Grid table ─────────────────────────────────────────────────────────
    # theme param uses NiceGUI 3.8's programmatic AG Grid 34 theming (not legacy CSS classes)
    _grid = (
        ui.aggrid(
            options={
                "columnDefs": [
                    {
                        "headerName": t("webhooks.col_time"),
                        "field": "ts",
                        "width": 175,
                        "cellClass": "font-mono",
                        ":cellStyle": "params => params.data?._bg ? {background: params.data._bg} : null",
                    },
                    {"field": "_ts_sort", "hide": True, "sort": "desc"},
                    {
                        "headerName": t("webhooks.col_description"),
                        "field": "description",
                        "flex": 1,
                        "minWidth": 140,
                        ":cellStyle": "params => params.data?._bg ? {background: params.data._bg} : null",
                    },
                    {
                        "headerName": t("webhooks.col_dir"),
                        "field": "direction",
                        "width": 135,
                        "filter": True,
                        ":cellStyle": (
                            "params => Object.assign("
                            "  params.data?._bg ? {background: params.data._bg} : {},"
                            "  params.value && params.value.startsWith('Sync Mgr→')"
                            "    ? {color:'#7c3aed', fontWeight:'bold'}"
                            "    : {color:'#1d4ed8', fontWeight:'bold'}"
                            ")"
                        ),
                    },
                    {
                        "headerName": t("webhooks.col_action"),
                        "field": "action",
                        "width": 85,
                        "hide": True,
                        ":cellStyle": "params => params.data?._bg ? {background: params.data._bg} : null",
                    },
                    {
                        "headerName": t("webhooks.col_node"),
                        "field": "node",
                        "flex": 1,
                        "minWidth": 110,
                        ":cellStyle": "params => params.data?._bg ? {background: params.data._bg} : null",
                    },
                    {
                        "headerName": t("webhooks.col_severity"),
                        "field": "severity",
                        "width": 115,
                        ":cellStyle": "params => params.data?._bg ? {background: params.data._bg} : null",
                    },
                    {
                        "headerName": t("webhooks.col_from"),
                        "field": "src",
                        "width": 130,
                        "hide": True,
                        "cellClass": "font-mono text-xs",
                        ":cellStyle": "params => params.data?._bg ? {background: params.data._bg} : null",
                    },
                    {
                        "headerName": t("webhooks.col_to"),
                        "field": "dst",
                        "width": 130,
                        "hide": True,
                        "cellClass": "font-mono text-xs",
                        ":cellStyle": "params => params.data?._bg ? {background: params.data._bg} : null",
                    },
                    {
                        "headerName": t("webhooks.col_hash"),
                        "field": "hash",
                        "width": 115,
                        "hide": True,
                        "cellClass": "font-mono text-xs",
                        ":cellStyle": "params => params.data?._bg ? {background: params.data._bg} : null",
                    },
                    {
                        "headerName": t("webhooks.col_result"),
                        "field": "result",
                        "flex": 1,
                        "minWidth": 140,
                        ":cellStyle": (
                            "params => Object.assign("
                            "  params.data?._bg ? {background: params.data._bg} : {},"
                            "  {color: params.data.resultColor, fontWeight: 'bold'}"
                            ")"
                        ),
                    },
                    {
                        "headerName": t("webhooks.col_incident"),
                        "field": "incident",
                        "width": 120,
                        "cellClass": "font-mono text-xs",
                        ":cellStyle": "params => params.data?._bg ? {background: params.data._bg} : null",
                    },
                ],
                "rowData": _row_data(),
                "defaultColDef": {"sortable": True, "resizable": True, "filter": True},
                # Size each column to fit its header + cell contents on first load
                # (fixed-width columns no longer truncate); flex columns still fill.
                "suppressScrollOnNewData": True,
                "rowHeight": 28,
                "headerHeight": 32,
            },
            theme="alpine",
            auto_size_columns=False,
        )
        .classes("w-full")
        .style("height: 500px; font-size: 11px;")
    )

    _filter_input.on_value_change(lambda e: _grid.run_grid_method("setGridOption", "quickFilterText", e.value or ""))

    # ── refresh (fire-and-forget run_grid_method, no await to avoid timeout issues) ──
    def _do_refresh():
        rows = _row_data()
        _grid.run_grid_method("setGridOption", "rowData", rows)
        # Fit columns to content here rather than via autoSizeStrategy, which
        # hides rows until measured and so leaves rows invisible in a tab that
        # was not active when the grid was built.
        _grid.run_grid_method("autoSizeAllColumns")
        _count_label.set_text(f"{len(rows)} events")

    _timer = ui.timer(5.0, _do_refresh)
